﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.CountBoundingBox
{
	// Token: 0x02000118 RID: 280
	public class CountBoundingBoxToolConfig : ToolConfigBase
	{
		// Token: 0x17000524 RID: 1316
		// (get) Token: 0x06000E72 RID: 3698 RVA: 0x00043298 File Offset: 0x00041498
		// (set) Token: 0x06000E73 RID: 3699 RVA: 0x000432C8 File Offset: 0x000414C8
		[Browsable(false)]
		public ImageInputLink InputLink
		{
			get
			{
				bool flag = this._inputLink == null;
				if (flag)
				{
					this._inputLink = new ImageInputLink();
				}
				return this._inputLink;
			}
			set
			{
				bool flag = this._inputLink != value;
				if (flag)
				{
					this._inputLink = (value ?? new ImageInputLink());
					base.OnPropertyChanged("InputLink");
				}
			}
		}

		// Token: 0x17000525 RID: 1317
		// (get) Token: 0x06000E74 RID: 3700 RVA: 0x00043304 File Offset: 0x00041504
		// (set) Token: 0x06000E75 RID: 3701 RVA: 0x0004330C File Offset: 0x0004150C
		[Category("Threshold")]
		[DisplayName("Polarity")]
		[Description("Only changes which way Show Threshold is described and what the defaults mean; the band below is always what is kept. Bright Objects expects a high band such as 128..255, Dark Objects a low one such as 0..80.")]
		public CountBoundingBoxPolarity Polarity
		{
			get
			{
				return this._polarity;
			}
			set
			{
				bool flag = this._polarity == value;
				if (!flag)
				{
					this._polarity = value;
					bool flag2 = value == CountBoundingBoxPolarity.DarkObjects && this._thresholdMin >= 128.0 && this._thresholdMax >= 250.0;
					if (flag2)
					{
						this._thresholdMin = 0.0;
						this._thresholdMax = 80.0;
						base.OnPropertyChanged("ThresholdMin");
						base.OnPropertyChanged("ThresholdMax");
					}
					else
					{
						bool flag3 = value == CountBoundingBoxPolarity.BrightObjects && this._thresholdMin <= 5.0 && this._thresholdMax <= 128.0;
						if (flag3)
						{
							this._thresholdMin = 128.0;
							this._thresholdMax = 255.0;
							base.OnPropertyChanged("ThresholdMin");
							base.OnPropertyChanged("ThresholdMax");
						}
					}
					base.OnPropertyChanged("Polarity");
				}
			}
		}

		// Token: 0x17000526 RID: 1318
		// (get) Token: 0x06000E76 RID: 3702 RVA: 0x00043410 File Offset: 0x00041610
		// (set) Token: 0x06000E77 RID: 3703 RVA: 0x00043418 File Offset: 0x00041618
		[Category("Threshold")]
		[DisplayName("Threshold Min")]
		[Description("Lowest gray value kept. Drag the slider and watch the yellow outline with Show Threshold on.")]
		public double ThresholdMin
		{
			get
			{
				return this._thresholdMin;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : ((value > 255.0) ? 255.0 : value);
				bool flag = this._thresholdMin != v;
				if (flag)
				{
					this._thresholdMin = v;
					base.OnPropertyChanged("ThresholdMin");
				}
			}
		}

		// Token: 0x17000527 RID: 1319
		// (get) Token: 0x06000E78 RID: 3704 RVA: 0x0004347B File Offset: 0x0004167B
		// (set) Token: 0x06000E79 RID: 3705 RVA: 0x00043484 File Offset: 0x00041684
		[Category("Threshold")]
		[DisplayName("Threshold Max")]
		[Description("Highest gray value kept.")]
		public double ThresholdMax
		{
			get
			{
				return this._thresholdMax;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : ((value > 255.0) ? 255.0 : value);
				bool flag = this._thresholdMax != v;
				if (flag)
				{
					this._thresholdMax = v;
					base.OnPropertyChanged("ThresholdMax");
				}
			}
		}

		// Token: 0x17000528 RID: 1320
		// (get) Token: 0x06000E7A RID: 3706 RVA: 0x000434E7 File Offset: 0x000416E7
		// (set) Token: 0x06000E7B RID: 3707 RVA: 0x000434F0 File Offset: 0x000416F0
		[Category("Threshold")]
		[DisplayName("Close Radius (px)")]
		[Description("Fills the holes and joins the pieces of one object, so a part broken up by a highlight is boxed once instead of several times. 0 turns it off.")]
		public double CloseRadius
		{
			get
			{
				return this._closeRadius;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._closeRadius != v;
				if (flag)
				{
					this._closeRadius = v;
					base.OnPropertyChanged("CloseRadius");
				}
			}
		}

		// Token: 0x17000529 RID: 1321
		// (get) Token: 0x06000E7C RID: 3708 RVA: 0x0004353C File Offset: 0x0004173C
		// (set) Token: 0x06000E7D RID: 3709 RVA: 0x00043544 File Offset: 0x00041744
		[Category("Threshold")]
		[DisplayName("Open Radius (px)")]
		[Description("Removes isolated specks before anything is counted. 0 turns it off - the area filters below usually do this job well enough.")]
		public double OpenRadius
		{
			get
			{
				return this._openRadius;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._openRadius != v;
				if (flag)
				{
					this._openRadius = v;
					base.OnPropertyChanged("OpenRadius");
				}
			}
		}

		// Token: 0x1700052A RID: 1322
		// (get) Token: 0x06000E7E RID: 3710 RVA: 0x00043590 File Offset: 0x00041790
		// (set) Token: 0x06000E7F RID: 3711 RVA: 0x00043598 File Offset: 0x00041798
		[Category("Blob Size")]
		[DisplayName("Min Blob Area (px)")]
		[Description("Fewest LIT pixels an object must have. This is the noise filter.")]
		public double MinBlobArea
		{
			get
			{
				return this._minBlobArea;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._minBlobArea != v;
				if (flag)
				{
					this._minBlobArea = v;
					base.OnPropertyChanged("MinBlobArea");
				}
			}
		}

		// Token: 0x1700052B RID: 1323
		// (get) Token: 0x06000E80 RID: 3712 RVA: 0x000435E4 File Offset: 0x000417E4
		// (set) Token: 0x06000E81 RID: 3713 RVA: 0x000435EC File Offset: 0x000417EC
		[Category("Blob Size")]
		[DisplayName("Max Blob Area (px)")]
		[Description("Most lit pixels an object may have. Catches the case where the threshold swallowed the whole background into one enormous object.")]
		public double MaxBlobArea
		{
			get
			{
				return this._maxBlobArea;
			}
			set
			{
				bool flag = this._maxBlobArea != value;
				if (flag)
				{
					this._maxBlobArea = value;
					base.OnPropertyChanged("MaxBlobArea");
				}
			}
		}

		// Token: 0x1700052C RID: 1324
		// (get) Token: 0x06000E82 RID: 3714 RVA: 0x0004361F File Offset: 0x0004181F
		// (set) Token: 0x06000E83 RID: 3715 RVA: 0x00043628 File Offset: 0x00041828
		[Category("Box Size")]
		[DisplayName("Min Box Area (px)")]
		[Description("Smallest bounding box kept, as width times height. Different from blob area: a thin diagonal line covers few pixels but spans a large box.")]
		public double MinBoxArea
		{
			get
			{
				return this._minBoxArea;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._minBoxArea != v;
				if (flag)
				{
					this._minBoxArea = v;
					base.OnPropertyChanged("MinBoxArea");
				}
			}
		}

		// Token: 0x1700052D RID: 1325
		// (get) Token: 0x06000E84 RID: 3716 RVA: 0x00043674 File Offset: 0x00041874
		// (set) Token: 0x06000E85 RID: 3717 RVA: 0x0004367C File Offset: 0x0004187C
		[Category("Box Size")]
		[DisplayName("Max Box Area (px)")]
		public double MaxBoxArea
		{
			get
			{
				return this._maxBoxArea;
			}
			set
			{
				bool flag = this._maxBoxArea != value;
				if (flag)
				{
					this._maxBoxArea = value;
					base.OnPropertyChanged("MaxBoxArea");
				}
			}
		}

		// Token: 0x1700052E RID: 1326
		// (get) Token: 0x06000E86 RID: 3718 RVA: 0x000436AF File Offset: 0x000418AF
		// (set) Token: 0x06000E87 RID: 3719 RVA: 0x000436B8 File Offset: 0x000418B8
		[Category("Box Size")]
		[DisplayName("Min Box Width (px)")]
		[Description("0 means no limit.")]
		public double MinBoxWidth
		{
			get
			{
				return this._minBoxWidth;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._minBoxWidth != v;
				if (flag)
				{
					this._minBoxWidth = v;
					base.OnPropertyChanged("MinBoxWidth");
				}
			}
		}

		// Token: 0x1700052F RID: 1327
		// (get) Token: 0x06000E88 RID: 3720 RVA: 0x00043704 File Offset: 0x00041904
		// (set) Token: 0x06000E89 RID: 3721 RVA: 0x0004370C File Offset: 0x0004190C
		[Category("Box Size")]
		[DisplayName("Max Box Width (px)")]
		[Description("0 means no limit.")]
		public double MaxBoxWidth
		{
			get
			{
				return this._maxBoxWidth;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._maxBoxWidth != v;
				if (flag)
				{
					this._maxBoxWidth = v;
					base.OnPropertyChanged("MaxBoxWidth");
				}
			}
		}

		// Token: 0x17000530 RID: 1328
		// (get) Token: 0x06000E8A RID: 3722 RVA: 0x00043758 File Offset: 0x00041958
		// (set) Token: 0x06000E8B RID: 3723 RVA: 0x00043760 File Offset: 0x00041960
		[Category("Box Size")]
		[DisplayName("Min Box Height (px)")]
		[Description("0 means no limit.")]
		public double MinBoxHeight
		{
			get
			{
				return this._minBoxHeight;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._minBoxHeight != v;
				if (flag)
				{
					this._minBoxHeight = v;
					base.OnPropertyChanged("MinBoxHeight");
				}
			}
		}

		// Token: 0x17000531 RID: 1329
		// (get) Token: 0x06000E8C RID: 3724 RVA: 0x000437AC File Offset: 0x000419AC
		// (set) Token: 0x06000E8D RID: 3725 RVA: 0x000437B4 File Offset: 0x000419B4
		[Category("Box Size")]
		[DisplayName("Max Box Height (px)")]
		[Description("0 means no limit.")]
		public double MaxBoxHeight
		{
			get
			{
				return this._maxBoxHeight;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._maxBoxHeight != v;
				if (flag)
				{
					this._maxBoxHeight = v;
					base.OnPropertyChanged("MaxBoxHeight");
				}
			}
		}

		// Token: 0x17000532 RID: 1330
		// (get) Token: 0x06000E8E RID: 3726 RVA: 0x00043800 File Offset: 0x00041A00
		// (set) Token: 0x06000E8F RID: 3727 RVA: 0x00043808 File Offset: 0x00041A08
		[Category("Grouping")]
		[DisplayName("Enable Grouping")]
		[Description("Merges boxes that lie close together into ONE box around all of them. Use it when a single part breaks into several pieces - characters of a printed code, the segments of a dashed line - and should be counted and measured as one object.")]
		public bool EnableGrouping
		{
			get
			{
				return this._enableGrouping;
			}
			set
			{
				bool flag = this._enableGrouping != value;
				if (flag)
				{
					this._enableGrouping = value;
					base.OnPropertyChanged("EnableGrouping");
				}
			}
		}

		// Token: 0x17000533 RID: 1331
		// (get) Token: 0x06000E90 RID: 3728 RVA: 0x0004383B File Offset: 0x00041A3B
		// (set) Token: 0x06000E91 RID: 3729 RVA: 0x00043844 File Offset: 0x00041A44
		[Category("Grouping")]
		[DisplayName("Group Gap X (px)")]
		[Description("Largest HORIZONTAL gap between two boxes that still counts as neighbouring. Measured edge to edge, so boxes that already overlap have a gap of 0. Keep it below the spacing between two separate parts, or they merge into one.")]
		public double GroupGapX
		{
			get
			{
				return this._groupGapX;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._groupGapX != v;
				if (flag)
				{
					this._groupGapX = v;
					base.OnPropertyChanged("GroupGapX");
				}
			}
		}

		// Token: 0x17000534 RID: 1332
		// (get) Token: 0x06000E92 RID: 3730 RVA: 0x00043890 File Offset: 0x00041A90
		// (set) Token: 0x06000E93 RID: 3731 RVA: 0x00043898 File Offset: 0x00041A98
		[Category("Grouping")]
		[DisplayName("Group Gap Y (px)")]
		[Description("Largest VERTICAL gap that still counts as neighbouring. Both gaps must be within range for two boxes to join, so a small Y keeps one printed line from merging with the line beneath it while a large X still joins its characters.")]
		public double GroupGapY
		{
			get
			{
				return this._groupGapY;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._groupGapY != v;
				if (flag)
				{
					this._groupGapY = v;
					base.OnPropertyChanged("GroupGapY");
				}
			}
		}

		// Token: 0x17000535 RID: 1333
		// (get) Token: 0x06000E94 RID: 3732 RVA: 0x000438E4 File Offset: 0x00041AE4
		// (set) Token: 0x06000E95 RID: 3733 RVA: 0x000438EC File Offset: 0x00041AEC
		[Category("Numbering")]
		[DisplayName("Row Pitch (px)")]
		[Description("Vertical distance between two rows of objects. Only used to number them in reading order - left to right, top to bottom - so an object number means the same thing every run.")]
		public double RowPitch
		{
			get
			{
				return this._rowPitch;
			}
			set
			{
				double v = (value < 1.0) ? 1.0 : value;
				bool flag = this._rowPitch != v;
				if (flag)
				{
					this._rowPitch = v;
					base.OnPropertyChanged("RowPitch");
				}
			}
		}

		// Token: 0x17000536 RID: 1334
		// (get) Token: 0x06000E96 RID: 3734 RVA: 0x00043938 File Offset: 0x00041B38
		// (set) Token: 0x06000E97 RID: 3735 RVA: 0x00043940 File Offset: 0x00041B40
		[Category("Display")]
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				bool flag = this._showRoi != value;
				if (flag)
				{
					this._showRoi = value;
					base.OnPropertyChanged("ShowRoi");
				}
			}
		}

		// Token: 0x17000537 RID: 1335
		// (get) Token: 0x06000E98 RID: 3736 RVA: 0x00043973 File Offset: 0x00041B73
		// (set) Token: 0x06000E99 RID: 3737 RVA: 0x0004397C File Offset: 0x00041B7C
		[Category("Display")]
		[DisplayName("Show Threshold")]
		[Description("Paints everything the threshold caught straight onto the image, before the size filters ran. Turn it on while dragging the threshold sliders; the gap between the painted area and the boxes shows which filter is rejecting an object you expected to keep.")]
		public bool ShowThreshold
		{
			get
			{
				return this._showThreshold;
			}
			set
			{
				bool flag = this._showThreshold != value;
				if (flag)
				{
					this._showThreshold = value;
					base.OnPropertyChanged("ShowThreshold");
				}
			}
		}

		// Token: 0x17000538 RID: 1336
		// (get) Token: 0x06000E9A RID: 3738 RVA: 0x000439AF File Offset: 0x00041BAF
		// (set) Token: 0x06000E9B RID: 3739 RVA: 0x000439B8 File Offset: 0x00041BB8
		[Category("Display")]
		[DisplayName("Threshold Fill")]
		[Description("Filled is what makes a threshold readable at a glance - you see the shape the threshold actually produced, holes included. Switch to outline when the fill covers the objects you are trying to judge underneath it.")]
		public bool ThresholdFill
		{
			get
			{
				return this._thresholdFill;
			}
			set
			{
				bool flag = this._thresholdFill != value;
				if (flag)
				{
					this._thresholdFill = value;
					base.OnPropertyChanged("ThresholdFill");
				}
			}
		}

		// Token: 0x17000539 RID: 1337
		// (get) Token: 0x06000E9C RID: 3740 RVA: 0x000439EB File Offset: 0x00041BEB
		// (set) Token: 0x06000E9D RID: 3741 RVA: 0x000439F4 File Offset: 0x00041BF4
		[Category("Display")]
		[DisplayName("Show Boxes")]
		public bool ShowBoxes
		{
			get
			{
				return this._showBoxes;
			}
			set
			{
				bool flag = this._showBoxes != value;
				if (flag)
				{
					this._showBoxes = value;
					base.OnPropertyChanged("ShowBoxes");
				}
			}
		}

		// Token: 0x1700053A RID: 1338
		// (get) Token: 0x06000E9E RID: 3742 RVA: 0x00043A27 File Offset: 0x00041C27
		// (set) Token: 0x06000E9F RID: 3743 RVA: 0x00043A30 File Offset: 0x00041C30
		[Category("Display")]
		[DisplayName("Show Index")]
		[Description("Writes the object number beside each box.")]
		public bool ShowIndex
		{
			get
			{
				return this._showIndex;
			}
			set
			{
				bool flag = this._showIndex != value;
				if (flag)
				{
					this._showIndex = value;
					base.OnPropertyChanged("ShowIndex");
				}
			}
		}

		// Token: 0x1700053B RID: 1339
		// (get) Token: 0x06000EA0 RID: 3744 RVA: 0x00043A63 File Offset: 0x00041C63
		// (set) Token: 0x06000EA1 RID: 3745 RVA: 0x00043A6C File Offset: 0x00041C6C
		[Category("Display")]
		[DisplayName("Show Size")]
		[Description("Writes the box size - width x height and its area - beside each box.")]
		public bool ShowSize
		{
			get
			{
				return this._showSize;
			}
			set
			{
				bool flag = this._showSize != value;
				if (flag)
				{
					this._showSize = value;
					base.OnPropertyChanged("ShowSize");
				}
			}
		}

		// Token: 0x1700053C RID: 1340
		// (get) Token: 0x06000EA2 RID: 3746 RVA: 0x00043A9F File Offset: 0x00041C9F
		// (set) Token: 0x06000EA3 RID: 3747 RVA: 0x00043AA8 File Offset: 0x00041CA8
		[Category("Display")]
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				bool flag = this._showText != value;
				if (flag)
				{
					this._showText = value;
					base.OnPropertyChanged("ShowText");
				}
			}
		}

		// Token: 0x1700053D RID: 1341
		// (get) Token: 0x06000EA4 RID: 3748 RVA: 0x00043ADB File Offset: 0x00041CDB
		// (set) Token: 0x06000EA5 RID: 3749 RVA: 0x00043AE4 File Offset: 0x00041CE4
		[Category("Display")]
		[DisplayName("Box Color")]
		public string BoxColor
		{
			get
			{
				return this._boxColor;
			}
			set
			{
				bool flag = this._boxColor != value;
				if (flag)
				{
					this._boxColor = value;
					base.OnPropertyChanged("BoxColor");
				}
			}
		}

		// Token: 0x1700053E RID: 1342
		// (get) Token: 0x06000EA6 RID: 3750 RVA: 0x00043B17 File Offset: 0x00041D17
		// (set) Token: 0x06000EA7 RID: 3751 RVA: 0x00043B20 File Offset: 0x00041D20
		[Category("Display")]
		[DisplayName("Threshold Color")]
		public string ThresholdColor
		{
			get
			{
				return this._thresholdColor;
			}
			set
			{
				bool flag = this._thresholdColor != value;
				if (flag)
				{
					this._thresholdColor = value;
					base.OnPropertyChanged("ThresholdColor");
				}
			}
		}

		// Token: 0x1700053F RID: 1343
		// (get) Token: 0x06000EA8 RID: 3752 RVA: 0x00043B53 File Offset: 0x00041D53
		// (set) Token: 0x06000EA9 RID: 3753 RVA: 0x00043B5C File Offset: 0x00041D5C
		[Category("Display")]
		[DisplayName("Index Text Color")]
		[Description("Colour of the per-object label drawn on the image - the number and, if Show Size is on, the size beside it. Separate from the summary text in the corner, because the label has to stand out against the part while the summary sits on the background.")]
		public string IndexTextColor
		{
			get
			{
				return this._indexTextColor;
			}
			set
			{
				bool flag = this._indexTextColor != value;
				if (flag)
				{
					this._indexTextColor = value;
					base.OnPropertyChanged("IndexTextColor");
				}
			}
		}

		// Token: 0x17000540 RID: 1344
		// (get) Token: 0x06000EAA RID: 3754 RVA: 0x00043B8F File Offset: 0x00041D8F
		// (set) Token: 0x06000EAB RID: 3755 RVA: 0x00043B98 File Offset: 0x00041D98
		[Category("Display")]
		[DisplayName("Index Text Size")]
		[Description("Font size of the per-object label. Raise it when the objects are far apart on a large image and the numbers become unreadable at fit-to-window zoom.")]
		public int IndexTextSize
		{
			get
			{
				return this._indexTextSize;
			}
			set
			{
				int v = (value < 8) ? 8 : value;
				bool flag = this._indexTextSize != v;
				if (flag)
				{
					this._indexTextSize = v;
					base.OnPropertyChanged("IndexTextSize");
				}
			}
		}

		// Token: 0x17000541 RID: 1345
		// (get) Token: 0x06000EAC RID: 3756 RVA: 0x00043BD4 File Offset: 0x00041DD4
		// (set) Token: 0x06000EAD RID: 3757 RVA: 0x00043BDC File Offset: 0x00041DDC
		[Category("Display")]
		[DisplayName("Index Offset X (px)")]
		[Description("Moves the per-object label sideways from the left edge of its box. Positive goes right. Use it when the label of one object sits on top of its neighbour.")]
		public double IndexOffsetX
		{
			get
			{
				return this._indexOffsetX;
			}
			set
			{
				bool flag = this._indexOffsetX != value;
				if (flag)
				{
					this._indexOffsetX = value;
					base.OnPropertyChanged("IndexOffsetX");
				}
			}
		}

		// Token: 0x17000542 RID: 1346
		// (get) Token: 0x06000EAE RID: 3758 RVA: 0x00043C0F File Offset: 0x00041E0F
		// (set) Token: 0x06000EAF RID: 3759 RVA: 0x00043C18 File Offset: 0x00041E18
		[Category("Display")]
		[DisplayName("Index Offset Y (px)")]
		[Description("Moves the per-object label up or down from its default place just above the box. Positive goes DOWN, matching image row order - a value around the box height puts the label inside the box instead of above it.")]
		public double IndexOffsetY
		{
			get
			{
				return this._indexOffsetY;
			}
			set
			{
				bool flag = this._indexOffsetY != value;
				if (flag)
				{
					this._indexOffsetY = value;
					base.OnPropertyChanged("IndexOffsetY");
				}
			}
		}

		// Token: 0x17000543 RID: 1347
		// (get) Token: 0x06000EB0 RID: 3760 RVA: 0x00043C4B File Offset: 0x00041E4B
		// (set) Token: 0x06000EB1 RID: 3761 RVA: 0x00043C54 File Offset: 0x00041E54
		[Category("Display")]
		[DisplayName("Summary Text Color")]
		public string TextColor
		{
			get
			{
				return this._textColor;
			}
			set
			{
				bool flag = this._textColor != value;
				if (flag)
				{
					this._textColor = value;
					base.OnPropertyChanged("TextColor");
				}
			}
		}

		// Token: 0x17000544 RID: 1348
		// (get) Token: 0x06000EB2 RID: 3762 RVA: 0x00043C87 File Offset: 0x00041E87
		// (set) Token: 0x06000EB3 RID: 3763 RVA: 0x00043C90 File Offset: 0x00041E90
		[Category("Display")]
		[DisplayName("Summary Text Size")]
		public int TextSize
		{
			get
			{
				return this._textSize;
			}
			set
			{
				int v = (value < 8) ? 8 : value;
				bool flag = this._textSize != v;
				if (flag)
				{
					this._textSize = v;
					base.OnPropertyChanged("TextSize");
				}
			}
		}

		// Token: 0x040005E5 RID: 1509
		private ImageInputLink _inputLink = new ImageInputLink();

		// Token: 0x040005E6 RID: 1510
		private CountBoundingBoxPolarity _polarity = CountBoundingBoxPolarity.BrightObjects;

		// Token: 0x040005E7 RID: 1511
		private double _thresholdMin = 128.0;

		// Token: 0x040005E8 RID: 1512
		private double _thresholdMax = 255.0;

		// Token: 0x040005E9 RID: 1513
		private double _closeRadius;

		// Token: 0x040005EA RID: 1514
		private double _openRadius;

		// Token: 0x040005EB RID: 1515
		private double _minBlobArea = 100.0;

		// Token: 0x040005EC RID: 1516
		private double _maxBlobArea = 10000000.0;

		// Token: 0x040005ED RID: 1517
		private double _minBoxArea = 100.0;

		// Token: 0x040005EE RID: 1518
		private double _maxBoxArea = 10000000.0;

		// Token: 0x040005EF RID: 1519
		private double _minBoxWidth;

		// Token: 0x040005F0 RID: 1520
		private double _maxBoxWidth;

		// Token: 0x040005F1 RID: 1521
		private double _minBoxHeight;

		// Token: 0x040005F2 RID: 1522
		private double _maxBoxHeight;

		// Token: 0x040005F3 RID: 1523
		private bool _enableGrouping;

		// Token: 0x040005F4 RID: 1524
		private double _groupGapX = 20.0;

		// Token: 0x040005F5 RID: 1525
		private double _groupGapY = 20.0;

		// Token: 0x040005F6 RID: 1526
		private double _rowPitch = 200.0;

		// Token: 0x040005F7 RID: 1527
		private bool _showRoi = true;

		// Token: 0x040005F8 RID: 1528
		private bool _showThreshold;

		// Token: 0x040005F9 RID: 1529
		private bool _showBoxes = true;

		// Token: 0x040005FA RID: 1530
		private bool _showIndex = true;

		// Token: 0x040005FB RID: 1531
		private bool _showSize = true;

		// Token: 0x040005FC RID: 1532
		private bool _showText = true;

		// Token: 0x040005FD RID: 1533
		private bool _thresholdFill = true;

		// Token: 0x040005FE RID: 1534
		private string _boxColor = "green";

		// Token: 0x040005FF RID: 1535
		private string _thresholdColor = "orange";

		// Token: 0x04000600 RID: 1536
		private string _indexTextColor = "yellow";

		// Token: 0x04000601 RID: 1537
		private int _indexTextSize = 16;

		// Token: 0x04000602 RID: 1538
		private double _indexOffsetX;

		// Token: 0x04000603 RID: 1539
		private double _indexOffsetY;

		// Token: 0x04000604 RID: 1540
		private string _textColor = "lime";

		// Token: 0x04000605 RID: 1541
		private int _textSize = 16;
	}
}
