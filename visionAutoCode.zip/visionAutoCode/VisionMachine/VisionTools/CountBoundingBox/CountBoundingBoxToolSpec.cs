﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.CountBoundingBox
{
	// Token: 0x02000119 RID: 281
	public class CountBoundingBoxToolSpec : ToolSpecBase
	{
		// Token: 0x17000545 RID: 1349
		// (get) Token: 0x06000EB5 RID: 3765 RVA: 0x00043DDF File Offset: 0x00041FDF
		// (set) Token: 0x06000EB6 RID: 3766 RVA: 0x00043DE8 File Offset: 0x00041FE8
		[Category("Object Count")]
		[DisplayName("Check Object Count")]
		public bool CountEnabled
		{
			get
			{
				return this._countEnabled;
			}
			set
			{
				bool flag = this._countEnabled != value;
				if (flag)
				{
					this._countEnabled = value;
					base.OnPropertyChanged("CountEnabled");
				}
			}
		}

		// Token: 0x17000546 RID: 1350
		// (get) Token: 0x06000EB7 RID: 3767 RVA: 0x00043E1B File Offset: 0x0004201B
		// (set) Token: 0x06000EB8 RID: 3768 RVA: 0x00043E24 File Offset: 0x00042024
		[Category("Object Count")]
		[DisplayName("Count Min")]
		[Description("Fewest objects a good image may hold. Set Min and Max to the SAME number to demand an exact count, which is the usual case.")]
		public double CountMin
		{
			get
			{
				return this._countMin;
			}
			set
			{
				bool flag = this._countMin != value;
				if (flag)
				{
					this._countMin = value;
					base.OnPropertyChanged("CountMin");
				}
			}
		}

		// Token: 0x17000547 RID: 1351
		// (get) Token: 0x06000EB9 RID: 3769 RVA: 0x00043E57 File Offset: 0x00042057
		// (set) Token: 0x06000EBA RID: 3770 RVA: 0x00043E60 File Offset: 0x00042060
		[Category("Object Count")]
		[DisplayName("Count Max")]
		[Description("Most objects a good image may hold. Keeping this at the expected number is what catches a double, not just a missing part.")]
		public double CountMax
		{
			get
			{
				return this._countMax;
			}
			set
			{
				bool flag = this._countMax != value;
				if (flag)
				{
					this._countMax = value;
					base.OnPropertyChanged("CountMax");
				}
			}
		}

		// Token: 0x04000606 RID: 1542
		private bool _countEnabled = true;

		// Token: 0x04000607 RID: 1543
		private double _countMin = 1.0;

		// Token: 0x04000608 RID: 1544
		private double _countMax = 1.0;
	}
}
