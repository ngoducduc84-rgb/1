﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Threading;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.PropertyGrid;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.CountBoundingBox.Views
{
	// Token: 0x0200011A RID: 282
	public partial class CountBoundingBox_para : UserControl, IStyleConnector
	{
		// Token: 0x06000EBC RID: 3772 RVA: 0x00043EC4 File Offset: 0x000420C4
		public CountBoundingBox_para()
		{
			this.InitializeComponent();
			this._previewTimer = new DispatcherTimer
			{
				Interval = TimeSpan.FromMilliseconds(200.0)
			};
			this._previewTimer.Tick += this.PreviewTimer_Tick;
			base.Unloaded += delegate(object s, RoutedEventArgs e)
			{
				this._previewTimer.Stop();
			};
		}

		// Token: 0x06000EBD RID: 3773 RVA: 0x00043F2B File Offset: 0x0004212B
		private void PreviewTimer_Tick(object sender, EventArgs e)
		{
			this._previewTimer.Stop();
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.CountBoundingBoxTrialRun();
			}
		}

		// Token: 0x06000EBE RID: 3774 RVA: 0x00043F4C File Offset: 0x0004214C
		private void Threshold_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			PropertyGridControl parameterGrid = this.ParameterGrid;
			CountBoundingBoxToolConfig config = ((parameterGrid != null) ? parameterGrid.SelectedObject : null) as CountBoundingBoxToolConfig;
			bool flag = config != null && config.ThresholdMin > config.ThresholdMax;
			if (flag)
			{
				config.ThresholdMax = config.ThresholdMin;
			}
			this._previewTimer.Stop();
			this._previewTimer.Start();
		}

		// Token: 0x06000EBF RID: 3775 RVA: 0x00043F2B File Offset: 0x0004212B
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			this._previewTimer.Stop();
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.CountBoundingBoxTrialRun();
			}
		}

		// Token: 0x06000EC2 RID: 3778 RVA: 0x0004403C File Offset: 0x0004223C
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				((TrackBarEdit)target).EditValueChanged += this.Threshold_EditValueChanged;
				break;
			case 3:
				((SpinEdit)target).EditValueChanged += this.Threshold_EditValueChanged;
				break;
			case 4:
				((TrackBarEdit)target).EditValueChanged += this.Threshold_EditValueChanged;
				break;
			case 5:
				((SpinEdit)target).EditValueChanged += this.Threshold_EditValueChanged;
				break;
			}
		}

		// Token: 0x04000609 RID: 1545
		private readonly DispatcherTimer _previewTimer;
	}
}
