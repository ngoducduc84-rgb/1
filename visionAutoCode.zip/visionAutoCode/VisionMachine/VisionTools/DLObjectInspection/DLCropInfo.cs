﻿using System;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000E2 RID: 226
	public class DLCropInfo
	{
		// Token: 0x170003E7 RID: 999
		// (get) Token: 0x06000B66 RID: 2918 RVA: 0x0003513E File Offset: 0x0003333E
		// (set) Token: 0x06000B67 RID: 2919 RVA: 0x00035146 File Offset: 0x00033346
		public int CropX { get; set; }

		// Token: 0x170003E8 RID: 1000
		// (get) Token: 0x06000B68 RID: 2920 RVA: 0x0003514F File Offset: 0x0003334F
		// (set) Token: 0x06000B69 RID: 2921 RVA: 0x00035157 File Offset: 0x00033357
		public int CropY { get; set; }

		// Token: 0x170003E9 RID: 1001
		// (get) Token: 0x06000B6A RID: 2922 RVA: 0x00035160 File Offset: 0x00033360
		// (set) Token: 0x06000B6B RID: 2923 RVA: 0x00035168 File Offset: 0x00033368
		public int CropW { get; set; }

		// Token: 0x170003EA RID: 1002
		// (get) Token: 0x06000B6C RID: 2924 RVA: 0x00035171 File Offset: 0x00033371
		// (set) Token: 0x06000B6D RID: 2925 RVA: 0x00035179 File Offset: 0x00033379
		public int CropH { get; set; }

		// Token: 0x170003EB RID: 1003
		// (get) Token: 0x06000B6E RID: 2926 RVA: 0x00035182 File Offset: 0x00033382
		// (set) Token: 0x06000B6F RID: 2927 RVA: 0x0003518A File Offset: 0x0003338A
		public string SavedPath { get; set; }
	}
}
