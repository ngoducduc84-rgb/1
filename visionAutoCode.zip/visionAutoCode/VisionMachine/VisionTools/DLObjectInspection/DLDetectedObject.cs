﻿using System;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000E8 RID: 232
	public class DLDetectedObject
	{
		// Token: 0x170003F4 RID: 1012
		// (get) Token: 0x06000B92 RID: 2962 RVA: 0x000368F1 File Offset: 0x00034AF1
		// (set) Token: 0x06000B93 RID: 2963 RVA: 0x000368F9 File Offset: 0x00034AF9
		public int ClassId { get; set; }

		// Token: 0x170003F5 RID: 1013
		// (get) Token: 0x06000B94 RID: 2964 RVA: 0x00036902 File Offset: 0x00034B02
		// (set) Token: 0x06000B95 RID: 2965 RVA: 0x0003690A File Offset: 0x00034B0A
		public string ClassName { get; set; }

		// Token: 0x170003F6 RID: 1014
		// (get) Token: 0x06000B96 RID: 2966 RVA: 0x00036913 File Offset: 0x00034B13
		// (set) Token: 0x06000B97 RID: 2967 RVA: 0x0003691B File Offset: 0x00034B1B
		public double Confidence { get; set; }

		// Token: 0x170003F7 RID: 1015
		// (get) Token: 0x06000B98 RID: 2968 RVA: 0x00036924 File Offset: 0x00034B24
		// (set) Token: 0x06000B99 RID: 2969 RVA: 0x0003692C File Offset: 0x00034B2C
		public int X1 { get; set; }

		// Token: 0x170003F8 RID: 1016
		// (get) Token: 0x06000B9A RID: 2970 RVA: 0x00036935 File Offset: 0x00034B35
		// (set) Token: 0x06000B9B RID: 2971 RVA: 0x0003693D File Offset: 0x00034B3D
		public int Y1 { get; set; }

		// Token: 0x170003F9 RID: 1017
		// (get) Token: 0x06000B9C RID: 2972 RVA: 0x00036946 File Offset: 0x00034B46
		// (set) Token: 0x06000B9D RID: 2973 RVA: 0x0003694E File Offset: 0x00034B4E
		public int X2 { get; set; }

		// Token: 0x170003FA RID: 1018
		// (get) Token: 0x06000B9E RID: 2974 RVA: 0x00036957 File Offset: 0x00034B57
		// (set) Token: 0x06000B9F RID: 2975 RVA: 0x0003695F File Offset: 0x00034B5F
		public int Y2 { get; set; }
	}
}
