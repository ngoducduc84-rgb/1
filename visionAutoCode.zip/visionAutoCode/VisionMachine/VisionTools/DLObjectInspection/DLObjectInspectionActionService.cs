﻿using System;
using System.Diagnostics;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.ResultInspection;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000E1 RID: 225
	public class DLObjectInspectionActionService : IToolActionService
	{
		// Token: 0x170003E6 RID: 998
		// (get) Token: 0x06000B62 RID: 2914 RVA: 0x00034DF0 File Offset: 0x00032FF0
		public ToolType ToolType
		{
			get
			{
				return ToolType.DLObjectInspection;
			}
		}

		// Token: 0x06000B63 RID: 2915 RVA: 0x00034E04 File Offset: 0x00033004
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						ToolActionFeedback.ReportError(context, "No original image is available.");
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext buildContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						string inputSourceToolName = this.GetInputSourceToolName(tool);
						input = this._pipelineService.BuildInputImageForTool(buildContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							if (input != null)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						Stopwatch stopwatch = Stopwatch.StartNew();
						DLObjectInspectionResult result = this._processor.Run(input, tool);
						stopwatch.Stop();
						bool flag4 = result.ProcessingTimeMs <= 0.0;
						if (flag4)
						{
							result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
						}
						bool flag5 = result.TotalProcessingTimeMs <= 0.0;
						if (flag5)
						{
							result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
						}
						result.InputSourceToolName = inputSourceToolName;
						InspectionResultStore.Record(tool.Name, result);
						Action<ToolVision, object> resultReporter = context.ResultReporter;
						if (resultReporter != null)
						{
							resultReporter(tool, result);
						}
						context.DisplayController.DisplayImage(input);
						context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
						{
							this._drawer.Draw(window, tool, result);
						}, null);
					}
				}
				finally
				{
					if (input != null)
					{
						input.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					bool flag6 = original != null;
					if (flag6)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x06000B64 RID: 2916 RVA: 0x00035080 File Offset: 0x00033280
		private string GetInputSourceToolName(ToolVision tool)
		{
			DLObjectInspectionToolConfig config = ((tool != null) ? tool.Config : null) as DLObjectInspectionToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						result = "PreviousToolOutput";
					}
					else
					{
						result = "OriginalImage";
					}
				}
			}
			return result;
		}

		// Token: 0x04000496 RID: 1174
		private readonly DLObjectInspectionProcessor _processor = new DLObjectInspectionProcessor();

		// Token: 0x04000497 RID: 1175
		private readonly DLObjectInspectionResultDrawer _drawer = new DLObjectInspectionResultDrawer();

		// Token: 0x04000498 RID: 1176
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();
	}
}
