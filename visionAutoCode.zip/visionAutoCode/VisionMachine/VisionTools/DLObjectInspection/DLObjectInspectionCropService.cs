﻿using System;
using System.Collections.Generic;
using System.IO;
using HalconDotNet;
using VisionMachine.Models.Roi;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000E3 RID: 227
	public class DLObjectInspectionCropService
	{
		// Token: 0x06000B71 RID: 2929 RVA: 0x00035194 File Offset: 0x00033394
		public DLCropInfo CropResizeSave(HObject sourceImage, IEnumerable<RoiData> rois, string savePath, int resizeW, int resizeH)
		{
			bool flag = sourceImage == null || !sourceImage.IsInitialized();
			DLCropInfo result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HTuple width;
				HTuple height;
				HOperatorSet.GetImageSize(sourceImage, out width, out height);
				int imgW = width.I;
				int imgH = height.I;
				int row;
				int col;
				int row2;
				int col2;
				bool flag2 = !this.TryGetRoiBoundingBox(rois, imgW, imgH, out row, out col, out row2, out col2);
				if (flag2)
				{
					row = 0;
					col = 0;
					row2 = imgH - 1;
					col2 = imgW - 1;
				}
				int cropX = col;
				int cropY = row;
				int cropW = col2 - col + 1;
				int cropH = row2 - row + 1;
				HObject cropped = null;
				HObject resized = null;
				try
				{
					HOperatorSet.CropRectangle1(sourceImage, out cropped, row, col, row2, col2);
					HOperatorSet.ZoomImageSize(cropped, out resized, resizeW, resizeH, "constant");
					string folder = Path.GetDirectoryName(savePath);
					bool flag3 = !string.IsNullOrWhiteSpace(folder) && !Directory.Exists(folder);
					if (flag3)
					{
						Directory.CreateDirectory(folder);
					}
					HOperatorSet.WriteImage(resized, "jpg", 0, savePath);
					result = new DLCropInfo
					{
						CropX = cropX,
						CropY = cropY,
						CropW = cropW,
						CropH = cropH,
						SavedPath = savePath
					};
				}
				finally
				{
					if (cropped != null)
					{
						cropped.Dispose();
					}
					if (resized != null)
					{
						resized.Dispose();
					}
				}
			}
			return result;
		}

		// Token: 0x06000B72 RID: 2930 RVA: 0x0003531C File Offset: 0x0003351C
		private bool TryGetRoiBoundingBox(IEnumerable<RoiData> rois, int imgW, int imgH, out int row1, out int col1, out int row2, out int col2)
		{
			row1 = (col1 = (row2 = (col2 = 0)));
			bool flag = rois == null;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				HObject union = null;
				try
				{
					foreach (RoiData roi in rois)
					{
						bool flag2 = roi == null || !roi.IsEnabled;
						if (!flag2)
						{
							HObject region = this.GenRegionFromRoi(roi);
							bool flag3 = region == null;
							if (!flag3)
							{
								try
								{
									bool flag4 = union == null;
									if (flag4)
									{
										union = region;
										region = null;
									}
									else
									{
										HObject merged;
										HOperatorSet.Union2(union, region, out merged);
										union.Dispose();
										union = merged;
									}
								}
								finally
								{
									if (region != null)
									{
										region.Dispose();
									}
								}
							}
						}
					}
					bool flag5 = union == null || !union.IsInitialized();
					if (flag5)
					{
						result = false;
					}
					else
					{
						HTuple area;
						HTuple htuple;
						HTuple htuple2;
						HOperatorSet.AreaCenter(union, out area, out htuple, out htuple2);
						bool flag6 = area.Length == 0 || area.D <= 0.0;
						if (flag6)
						{
							result = false;
						}
						else
						{
							HTuple r;
							HTuple c;
							HTuple r2;
							HTuple c2;
							HOperatorSet.SmallestRectangle1(union, out r, out c, out r2, out c2);
							row1 = DLObjectInspectionCropService.Clamp((int)r.D, 0, imgH - 1);
							col1 = DLObjectInspectionCropService.Clamp((int)c.D, 0, imgW - 1);
							row2 = DLObjectInspectionCropService.Clamp((int)r2.D, 0, imgH - 1);
							col2 = DLObjectInspectionCropService.Clamp((int)c2.D, 0, imgW - 1);
							result = (row2 > row1 && col2 > col1);
						}
					}
				}
				catch
				{
					result = false;
				}
				finally
				{
					if (union != null)
					{
						union.Dispose();
					}
				}
			}
			return result;
		}

		// Token: 0x06000B73 RID: 2931 RVA: 0x0003553C File Offset: 0x0003373C
		private HObject GenRegionFromRoi(RoiData roi)
		{
			HObject region = null;
			try
			{
				switch (roi.RoiType)
				{
				case RoiType.Rectangle1:
				case RoiType.Line:
					HOperatorSet.GenRectangle1(out region, Math.Min(roi.Row1, roi.Row2), Math.Min(roi.Col1, roi.Col2), Math.Max(roi.Row1, roi.Row2), Math.Max(roi.Col1, roi.Col2));
					break;
				case RoiType.Rectangle2:
					HOperatorSet.GenRectangle2(out region, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
					break;
				case RoiType.Circle:
					HOperatorSet.GenCircle(out region, roi.CenterRow, roi.CenterCol, roi.Radius);
					break;
				case RoiType.Ellipse:
					HOperatorSet.GenEllipse(out region, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
					break;
				case RoiType.Polygon:
				case RoiType.FreeDraw:
				case RoiType.DrawRegion:
				{
					bool flag = roi.Rows == null || roi.Cols == null || roi.Rows.Count < 3 || roi.Rows.Count != roi.Cols.Count;
					if (flag)
					{
						return null;
					}
					HObject contour;
					HOperatorSet.GenContourPolygonXld(out contour, new HTuple(roi.Rows.ToArray()), new HTuple(roi.Cols.ToArray()));
					try
					{
						HOperatorSet.GenRegionContourXld(contour, out region, "filled");
					}
					finally
					{
						if (contour != null)
						{
							contour.Dispose();
						}
					}
					break;
				}
				}
			}
			catch
			{
				if (region != null)
				{
					region.Dispose();
				}
				return null;
			}
			return region;
		}

		// Token: 0x06000B74 RID: 2932 RVA: 0x00035788 File Offset: 0x00033988
		private static int Clamp(int v, int min, int max)
		{
			bool flag = v < min;
			int result;
			if (flag)
			{
				result = min;
			}
			else
			{
				bool flag2 = v > max;
				if (flag2)
				{
					result = max;
				}
				else
				{
					result = v;
				}
			}
			return result;
		}
	}
}
