﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VisionMachine.Models.Camera;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000E4 RID: 228
	public static class DLObjectInspectionLoadModelService
	{
		// Token: 0x06000B76 RID: 2934 RVA: 0x000357B4 File Offset: 0x000339B4
		public static bool LoadAll(IEnumerable<CameraNode> cameras, out string message, Action<string, string> log = null)
		{
			message = "";
			List<ToolVision> tools = DLObjectInspectionLoadModelService.CollectDlTools(cameras);
			bool flag = tools.Count == 0;
			bool result;
			if (flag)
			{
				message = "No DL Object Inspection tool with a weight path was found.";
				result = false;
			}
			else
			{
				IEnumerable<IGrouping<string, ToolVision>> byServer = tools.GroupBy(delegate(ToolVision t)
				{
					DLObjectInspectionToolConfig cfg = t.Config as DLObjectInspectionToolConfig;
					return string.IsNullOrWhiteSpace((cfg != null) ? cfg.DetectUrl : null) ? "http://127.0.0.1:8000/detect" : cfg.DetectUrl;
				});
				StringBuilder summary = new StringBuilder();
				bool anyOk = false;
				foreach (IGrouping<string, ToolVision> serverGroup in byServer)
				{
					string detectUrl = serverGroup.Key;
					Dictionary<string, string> map = new Dictionary<string, string>();
					List<ToolVision> toolsForServer = new List<ToolVision>();
					foreach (ToolVision tool in serverGroup)
					{
						DLObjectInspectionToolTrain train = tool.TrainModel as DLObjectInspectionToolTrain;
						string key = DLObjectInspectionPathService.GetModelKey(tool, train);
						bool flag2 = string.IsNullOrWhiteSpace(key) || map.ContainsKey(key);
						if (!flag2)
						{
							map[key] = train.WeightPath;
							toolsForServer.Add(tool);
						}
					}
					bool flag3 = map.Count == 0;
					if (!flag3)
					{
						try
						{
							YoloApiClient client = new YoloApiClient(detectUrl);
							YoloReloadResponse response = Task.Run<YoloReloadResponse>(() => client.ReloadModelsAsync(map)).GetAwaiter().GetResult();
							bool ok = response != null && response.success;
							anyOk = (anyOk || ok);
							foreach (ToolVision tool2 in toolsForServer)
							{
								DLObjectInspectionToolTrain train2 = tool2.TrainModel as DLObjectInspectionToolTrain;
								bool flag4 = train2 != null;
								if (flag4)
								{
									train2.IsModelLoaded = ok;
									bool flag5 = ok;
									if (flag5)
									{
										train2.LoadMs = response.load_ms;
									}
								}
							}
							bool flag6 = ok;
							if (flag6)
							{
								string line = string.Concat(new string[]
								{
									"Loaded ",
									map.Count.ToString(),
									" model(s) on ",
									detectUrl,
									": ",
									string.Join(", ", map.Keys)
								});
								summary.AppendLine(line);
								if (log != null)
								{
									log("Info", "DL models: " + line);
								}
							}
							else
							{
								string line2 = "Failed on " + detectUrl + ": " + (((response != null) ? response.error : null) ?? "no response");
								summary.AppendLine(line2);
								if (log != null)
								{
									log("Warn", "DL models: " + line2);
								}
							}
						}
						catch (Exception ex)
						{
							foreach (ToolVision tool3 in toolsForServer)
							{
								DLObjectInspectionToolTrain train3 = tool3.TrainModel as DLObjectInspectionToolTrain;
								bool flag7 = train3 != null;
								if (flag7)
								{
									train3.IsModelLoaded = false;
								}
							}
							string line3 = string.Concat(new string[]
							{
								"Failed on ",
								detectUrl,
								": ",
								ex.Message,
								" (is the Python server running?)"
							});
							summary.AppendLine(line3);
							if (log != null)
							{
								log("Warn", "DL models: " + line3);
							}
						}
					}
				}
				message = summary.ToString().Trim();
				result = anyOk;
			}
			return result;
		}

		// Token: 0x06000B77 RID: 2935 RVA: 0x00035C14 File Offset: 0x00033E14
		private static List<ToolVision> CollectDlTools(IEnumerable<CameraNode> cameras)
		{
			List<ToolVision> tools = new List<ToolVision>();
			bool flag = cameras == null;
			List<ToolVision> result;
			if (flag)
			{
				result = tools;
			}
			else
			{
				foreach (CameraNode camera in cameras)
				{
					bool flag2 = ((camera != null) ? camera.TurnSnaps : null) == null;
					if (!flag2)
					{
						foreach (TurnSnap turnSnap in camera.TurnSnaps)
						{
							bool flag3 = ((turnSnap != null) ? turnSnap.Tools : null) == null;
							if (!flag3)
							{
								foreach (ToolVision tool in turnSnap.Tools)
								{
									bool flag4 = tool == null || tool.ToolType != ToolType.DLObjectInspection;
									if (!flag4)
									{
										DLObjectInspectionToolTrain train = tool.TrainModel as DLObjectInspectionToolTrain;
										bool flag5 = train != null && !string.IsNullOrWhiteSpace(train.WeightPath);
										if (flag5)
										{
											tools.Add(tool);
										}
									}
								}
							}
						}
					}
				}
				result = tools;
			}
			return result;
		}
	}
}
