﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000E5 RID: 229
	public class DLObjectInspectionParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x170003EC RID: 1004
		// (get) Token: 0x06000B78 RID: 2936 RVA: 0x00035DB0 File Offset: 0x00033FB0
		// (set) Token: 0x06000B79 RID: 2937 RVA: 0x00035DB8 File Offset: 0x00033FB8
		public ToolVision Tool { get; set; }

		// Token: 0x170003ED RID: 1005
		// (get) Token: 0x06000B7A RID: 2938 RVA: 0x00035DC1 File Offset: 0x00033FC1
		// (set) Token: 0x06000B7B RID: 2939 RVA: 0x00035DC9 File Offset: 0x00033FC9
		public DLObjectInspectionToolConfig Config { get; set; }

		// Token: 0x170003EE RID: 1006
		// (get) Token: 0x06000B7C RID: 2940 RVA: 0x00035DD2 File Offset: 0x00033FD2
		// (set) Token: 0x06000B7D RID: 2941 RVA: 0x00035DDA File Offset: 0x00033FDA
		public DLObjectInspectionToolSpec Spec { get; set; }

		// Token: 0x170003EF RID: 1007
		// (get) Token: 0x06000B7E RID: 2942 RVA: 0x00035DE3 File Offset: 0x00033FE3
		// (set) Token: 0x06000B7F RID: 2943 RVA: 0x00035DEB File Offset: 0x00033FEB
		public DLObjectInspectionToolTrain Train { get; set; }

		// Token: 0x170003F0 RID: 1008
		// (get) Token: 0x06000B80 RID: 2944 RVA: 0x00035DF4 File Offset: 0x00033FF4
		// (set) Token: 0x06000B81 RID: 2945 RVA: 0x00035DFC File Offset: 0x00033FFC
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x170003F1 RID: 1009
		// (get) Token: 0x06000B82 RID: 2946 RVA: 0x00035E08 File Offset: 0x00034008
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x170003F2 RID: 1010
		// (get) Token: 0x06000B83 RID: 2947 RVA: 0x00035E24 File Offset: 0x00034024
		// (set) Token: 0x06000B84 RID: 2948 RVA: 0x00035E3C File Offset: 0x0003403C
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool == value;
				if (!flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.Config != null && this.Config.InputLink != null;
					if (flag2)
					{
						this.Config.InputLink.SourceToolId = null;
						this.Config.InputLink.SourceToolName = ((this._selectedSourceTool == null) ? null : this._selectedSourceTool.ToolName);
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x14000019 RID: 25
		// (add) Token: 0x06000B85 RID: 2949 RVA: 0x00035EC4 File Offset: 0x000340C4
		// (remove) Token: 0x06000B86 RID: 2950 RVA: 0x00035EFC File Offset: 0x000340FC
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000B87 RID: 2951 RVA: 0x00035F31 File Offset: 0x00034131
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x06000B88 RID: 2952 RVA: 0x00035F50 File Offset: 0x00034150
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.Config == null || this.Config.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.Config.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.Config.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.Config.InputLink.SourceToolId = null;
				this.Config.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x0400049E RID: 1182
		private ToolImageSourceOption _selectedSourceTool;
	}
}
