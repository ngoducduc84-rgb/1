﻿using System;
using System.IO;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000E6 RID: 230
	public static class DLObjectInspectionPathService
	{
		// Token: 0x06000B8A RID: 2954 RVA: 0x00036030 File Offset: 0x00034230
		public static string GetCropFolder(ToolVision tool, DLObjectInspectionToolConfig config)
		{
			bool flag = config != null && !string.IsNullOrWhiteSpace(config.CropFolder);
			string result;
			if (flag)
			{
				result = config.CropFolder;
			}
			else
			{
				result = Path.Combine(Path.GetTempPath(), "VisionMachine_DLCrops");
			}
			return result;
		}

		// Token: 0x06000B8B RID: 2955 RVA: 0x00036074 File Offset: 0x00034274
		public static string GetModelKey(ToolVision tool, DLObjectInspectionToolTrain train)
		{
			bool flag = train != null && !string.IsNullOrWhiteSpace(train.ModelKey);
			string result;
			if (flag)
			{
				result = train.ModelKey.Trim();
			}
			else
			{
				bool flag2 = train != null && !string.IsNullOrWhiteSpace(train.WeightPath);
				if (flag2)
				{
					result = Path.GetFileNameWithoutExtension(train.WeightPath);
				}
				else
				{
					result = (((tool != null) ? tool.ToolId : null) ?? "dl_model");
				}
			}
			return result;
		}
	}
}
