﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000E7 RID: 231
	public class DLObjectInspectionProcessor : IToolProcessor
	{
		// Token: 0x170003F3 RID: 1011
		// (get) Token: 0x06000B8C RID: 2956 RVA: 0x000360E8 File Offset: 0x000342E8
		public ToolType ToolType
		{
			get
			{
				return ToolType.DLObjectInspection;
			}
		}

		// Token: 0x06000B8D RID: 2957 RVA: 0x000360FC File Offset: 0x000342FC
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			HObject image = (((context != null) ? context.InputImage : null) != null && context.InputImage.IsInitialized()) ? context.InputImage : ((context != null) ? context.OriginalImage : null);
			DLObjectInspectionResult result = this.Run(image, tool);
			bool flag = context != null && image != null && image.IsInitialized();
			if (flag)
			{
				HObject outputCopy;
				HOperatorSet.CopyImage(image, out outputCopy);
				context.OutputImage = outputCopy;
			}
			return new ToolProcessResult
			{
				IsSuccess = result.IsSuccess,
				Message = result.Message,
				Data = result
			};
		}

		// Token: 0x06000B8E RID: 2958 RVA: 0x00036198 File Offset: 0x00034398
		public DLObjectInspectionResult Run(HObject image, ToolVision tool)
		{
			DLObjectInspectionResult result = new DLObjectInspectionResult();
			Stopwatch swTotal = Stopwatch.StartNew();
			DLObjectInspectionToolConfig config = ((tool != null) ? tool.Config : null) as DLObjectInspectionToolConfig;
			DLObjectInspectionToolSpec spec = ((tool != null) ? tool.Spec : null) as DLObjectInspectionToolSpec;
			DLObjectInspectionToolTrain train = ((tool != null) ? tool.TrainModel : null) as DLObjectInspectionToolTrain;
			bool flag = image == null || !image.IsInitialized();
			DLObjectInspectionResult result2;
			if (flag)
			{
				result.IsSuccess = false;
				result.Message = "No image available for DL inspection.";
				result2 = result;
			}
			else
			{
				bool flag2 = config == null;
				if (flag2)
				{
					result.IsSuccess = false;
					result.Message = "DL Object Inspection config is missing.";
					result2 = result;
				}
				else
				{
					string modelKey = DLObjectInspectionPathService.GetModelKey(tool, train);
					bool flag3 = string.IsNullOrWhiteSpace(modelKey);
					if (flag3)
					{
						result.IsSuccess = false;
						result.Message = "No model is configured. Set the weight path and load the model.";
						result2 = result;
					}
					else
					{
						int imageSize = (config.ImageSize <= 0) ? 640 : config.ImageSize;
						string cropFolder = DLObjectInspectionPathService.GetCropFolder(tool, config);
						string frameId = string.Concat(new string[]
						{
							"DL_",
							((tool != null) ? tool.ToolId : null) ?? "tool",
							"_",
							DateTime.Now.ToString("yyyyMMdd_HHmmss_fff"),
							"_",
							Guid.NewGuid().ToString("N")
						});
						string cropPath = Path.Combine(cropFolder, frameId + ".jpg");
						HObject limitRegion = null;
						try
						{
							DLCropInfo cropInfo = this._cropService.CropResizeSave(image, tool.RoiItems, cropPath, imageSize, imageSize);
							bool flag4 = cropInfo == null;
							if (flag4)
							{
								result.IsSuccess = false;
								result.Message = "Failed to crop the ROI for DL inspection.";
								return result;
							}
							result.Row = (double)cropInfo.CropY;
							result.Column = (double)cropInfo.CropX;
							YoloApiClient client = new YoloApiClient(config.DetectUrl);
							YoloDetectResponse response = Task.Run<YoloDetectResponse>(() => client.DetectAsync(cropInfo.SavedPath, cropInfo.CropX, cropInfo.CropY, cropInfo.CropW, cropInfo.CropH, frameId, modelKey, imageSize, imageSize, config.Score)).GetAwaiter().GetResult();
							bool flag5 = response == null;
							if (flag5)
							{
								result.IsSuccess = false;
								result.Message = "YOLO server returned no response.";
								return result;
							}
							bool flag6 = !response.success;
							if (flag6)
							{
								result.IsSuccess = false;
								result.Message = "YOLO server error: " + (response.error ?? "unknown");
								return result;
							}
							List<YoloObject> rawObjects = response.objects ?? new List<YoloObject>();
							result.RawObjectCount = rawObjects.Count;
							limitRegion = DLObjectInspectionRoiHelper.BuildUnionRegion(tool.LimitRoiItems);
							HashSet<string> classFilter = DLObjectInspectionProcessor.ParseClassFilter((spec != null) ? spec.ClassFilter : null);
							foreach (YoloObject obj in rawObjects)
							{
								bool flag7 = ((obj != null) ? obj.bbox_original : null) == null;
								if (!flag7)
								{
									bool flag8 = classFilter != null && !classFilter.Contains((obj.class_name ?? "").Trim().ToLowerInvariant());
									if (!flag8)
									{
										double centerRow = (double)(obj.bbox_original.y1 + obj.bbox_original.y2) / 2.0;
										double centerCol = (double)(obj.bbox_original.x1 + obj.bbox_original.x2) / 2.0;
										bool flag9 = !DLObjectInspectionRoiHelper.IsPointInside(limitRegion, centerRow, centerCol);
										if (!flag9)
										{
											result.Objects.Add(new DLDetectedObject
											{
												ClassId = obj.class_id,
												ClassName = obj.class_name,
												Confidence = obj.confidence,
												X1 = obj.bbox_original.x1,
												Y1 = obj.bbox_original.y1,
												X2 = obj.bbox_original.x2,
												Y2 = obj.bbox_original.y2
											});
										}
									}
								}
							}
							result.ObjectCount = result.Objects.Count;
							bool flag10 = result.Objects.Count > 0;
							if (flag10)
							{
								result.Row = (double)result.Objects[0].Y1;
								result.Column = (double)result.Objects[0].X1;
							}
							DLObjectInspectionProcessor.ApplySpecAndJudge(spec, result);
							result.IsSuccess = true;
							result.Message = "OK";
						}
						catch (Exception ex)
						{
							result.IsSuccess = false;
							result.Message = "DL inspection failed: " + ex.Message;
						}
						finally
						{
							if (limitRegion != null)
							{
								limitRegion.Dispose();
							}
							try
							{
								bool flag11 = File.Exists(cropPath);
								if (flag11)
								{
									File.Delete(cropPath);
								}
							}
							catch
							{
							}
							swTotal.Stop();
							result.ProcessingTimeMs = swTotal.Elapsed.TotalMilliseconds;
							result.TotalProcessingTimeMs = swTotal.Elapsed.TotalMilliseconds;
						}
						result2 = result;
					}
				}
			}
			return result2;
		}

		// Token: 0x06000B8F RID: 2959 RVA: 0x000367B0 File Offset: 0x000349B0
		private static HashSet<string> ParseClassFilter(string classFilter)
		{
			bool flag = string.IsNullOrWhiteSpace(classFilter);
			HashSet<string> result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HashSet<string> set = new HashSet<string>();
				foreach (string part in classFilter.Split(new char[]
				{
					','
				}))
				{
					string name = part.Trim().ToLowerInvariant();
					bool flag2 = !string.IsNullOrEmpty(name);
					if (flag2)
					{
						set.Add(name);
					}
				}
				result = ((set.Count > 0) ? set : null);
			}
			return result;
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x00036838 File Offset: 0x00034A38
		private static void ApplySpecAndJudge(DLObjectInspectionToolSpec spec, DLObjectInspectionResult result)
		{
			bool enabled = spec != null && spec.IsEnabled && spec.CountEnabled;
			result.IsSpecEnabled = enabled;
			bool flag = !enabled;
			if (flag)
			{
				result.IsSpecOk = true;
				result.SpecStatus = "OK";
			}
			else
			{
				result.SpecMin = spec.MinObjectCount;
				result.SpecMax = spec.MaxObjectCount;
				bool ok = result.ObjectCount >= spec.MinObjectCount && result.ObjectCount <= spec.MaxObjectCount;
				result.IsSpecOk = ok;
				result.SpecStatus = (ok ? "OK" : "NG");
			}
		}

		// Token: 0x040004A5 RID: 1189
		private readonly DLObjectInspectionCropService _cropService = new DLObjectInspectionCropService();
	}
}
