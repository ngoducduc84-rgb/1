﻿using System;
using System.Collections.Generic;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000E9 RID: 233
	public class DLObjectInspectionResult
	{
		// Token: 0x170003FB RID: 1019
		// (get) Token: 0x06000BA1 RID: 2977 RVA: 0x00036968 File Offset: 0x00034B68
		// (set) Token: 0x06000BA2 RID: 2978 RVA: 0x00036970 File Offset: 0x00034B70
		public bool IsSuccess { get; set; }

		// Token: 0x170003FC RID: 1020
		// (get) Token: 0x06000BA3 RID: 2979 RVA: 0x00036979 File Offset: 0x00034B79
		// (set) Token: 0x06000BA4 RID: 2980 RVA: 0x00036981 File Offset: 0x00034B81
		public string Message { get; set; }

		// Token: 0x170003FD RID: 1021
		// (get) Token: 0x06000BA5 RID: 2981 RVA: 0x0003698A File Offset: 0x00034B8A
		// (set) Token: 0x06000BA6 RID: 2982 RVA: 0x00036992 File Offset: 0x00034B92
		public int ObjectCount { get; set; }

		// Token: 0x170003FE RID: 1022
		// (get) Token: 0x06000BA7 RID: 2983 RVA: 0x0003699B File Offset: 0x00034B9B
		// (set) Token: 0x06000BA8 RID: 2984 RVA: 0x000369A3 File Offset: 0x00034BA3
		public int RawObjectCount { get; set; }

		// Token: 0x170003FF RID: 1023
		// (get) Token: 0x06000BA9 RID: 2985 RVA: 0x000369AC File Offset: 0x00034BAC
		public List<DLDetectedObject> Objects { get; } = new List<DLDetectedObject>();

		// Token: 0x17000400 RID: 1024
		// (get) Token: 0x06000BAA RID: 2986 RVA: 0x000369B4 File Offset: 0x00034BB4
		// (set) Token: 0x06000BAB RID: 2987 RVA: 0x000369BC File Offset: 0x00034BBC
		public bool IsSpecEnabled { get; set; }

		// Token: 0x17000401 RID: 1025
		// (get) Token: 0x06000BAC RID: 2988 RVA: 0x000369C5 File Offset: 0x00034BC5
		// (set) Token: 0x06000BAD RID: 2989 RVA: 0x000369CD File Offset: 0x00034BCD
		public bool IsSpecOk { get; set; }

		// Token: 0x17000402 RID: 1026
		// (get) Token: 0x06000BAE RID: 2990 RVA: 0x000369D6 File Offset: 0x00034BD6
		// (set) Token: 0x06000BAF RID: 2991 RVA: 0x000369DE File Offset: 0x00034BDE
		public string SpecStatus { get; set; }

		// Token: 0x17000403 RID: 1027
		// (get) Token: 0x06000BB0 RID: 2992 RVA: 0x000369E7 File Offset: 0x00034BE7
		// (set) Token: 0x06000BB1 RID: 2993 RVA: 0x000369EF File Offset: 0x00034BEF
		public int SpecMin { get; set; }

		// Token: 0x17000404 RID: 1028
		// (get) Token: 0x06000BB2 RID: 2994 RVA: 0x000369F8 File Offset: 0x00034BF8
		// (set) Token: 0x06000BB3 RID: 2995 RVA: 0x00036A00 File Offset: 0x00034C00
		public int SpecMax { get; set; }

		// Token: 0x17000405 RID: 1029
		// (get) Token: 0x06000BB4 RID: 2996 RVA: 0x00036A09 File Offset: 0x00034C09
		// (set) Token: 0x06000BB5 RID: 2997 RVA: 0x00036A11 File Offset: 0x00034C11
		public double Row { get; set; }

		// Token: 0x17000406 RID: 1030
		// (get) Token: 0x06000BB6 RID: 2998 RVA: 0x00036A1A File Offset: 0x00034C1A
		// (set) Token: 0x06000BB7 RID: 2999 RVA: 0x00036A22 File Offset: 0x00034C22
		public double Column { get; set; }

		// Token: 0x17000407 RID: 1031
		// (get) Token: 0x06000BB8 RID: 3000 RVA: 0x00036A2B File Offset: 0x00034C2B
		// (set) Token: 0x06000BB9 RID: 3001 RVA: 0x00036A33 File Offset: 0x00034C33
		public double ProcessingTimeMs { get; set; }

		// Token: 0x17000408 RID: 1032
		// (get) Token: 0x06000BBA RID: 3002 RVA: 0x00036A3C File Offset: 0x00034C3C
		// (set) Token: 0x06000BBB RID: 3003 RVA: 0x00036A44 File Offset: 0x00034C44
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x17000409 RID: 1033
		// (get) Token: 0x06000BBC RID: 3004 RVA: 0x00036A4D File Offset: 0x00034C4D
		// (set) Token: 0x06000BBD RID: 3005 RVA: 0x00036A55 File Offset: 0x00034C55
		public string InputSourceToolName { get; set; }

		// Token: 0x1700040A RID: 1034
		// (get) Token: 0x06000BBE RID: 3006 RVA: 0x00036A5E File Offset: 0x00034C5E
		// (set) Token: 0x06000BBF RID: 3007 RVA: 0x00036A66 File Offset: 0x00034C66
		public double InputProcessingTimeMs { get; set; }
	}
}
