﻿using System;
using System.Collections.ObjectModel;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000EA RID: 234
	public class DLObjectInspectionResultDrawer
	{
		// Token: 0x06000BC1 RID: 3009 RVA: 0x00036A84 File Offset: 0x00034C84
		public void Draw(HWindow window, ToolVision tool, DLObjectInspectionResult result)
		{
			bool flag = window == null || tool == null || result == null;
			if (!flag)
			{
				DLObjectInspectionToolConfig config = tool.Config as DLObjectInspectionToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					bool showRoi = config.ShowRoi;
					if (showRoi)
					{
						this.DrawRoiList(window, tool.RoiItems, "cyan");
					}
					bool showLimitRoi = config.ShowLimitRoi;
					if (showLimitRoi)
					{
						this.DrawRoiList(window, tool.LimitRoiItems, "magenta");
					}
					bool flag3 = !result.IsSuccess;
					if (!flag3)
					{
						string boxColor = string.IsNullOrWhiteSpace(config.BoxColor) ? "red" : config.BoxColor;
						bool showBox = config.ShowBox;
						if (showBox)
						{
							try
							{
								HOperatorSet.SetDraw(window, "margin");
								HOperatorSet.SetLineWidth(window, 3);
								HOperatorSet.SetColor(window, boxColor);
							}
							catch
							{
							}
							foreach (DLDetectedObject obj in result.Objects)
							{
								try
								{
									HOperatorSet.DispRectangle1(window, obj.Y1, obj.X1, obj.Y2, obj.X2);
									bool showText = config.ShowText;
									if (showText)
									{
										HOperatorSet.SetTposition(window, obj.Y1 - config.TextSize - 4, obj.X1);
										HOperatorSet.WriteString(window, (obj.ClassName ?? "obj") + " " + obj.Confidence.ToString("0.00"));
									}
								}
								catch
								{
								}
							}
						}
						bool showText2 = config.ShowText;
						if (showText2)
						{
							this.DrawSummary(window, tool, result, config);
						}
					}
				}
			}
		}

		// Token: 0x06000BC2 RID: 3010 RVA: 0x00036CBC File Offset: 0x00034EBC
		private void DrawSummary(HWindow window, ToolVision tool, DLObjectInspectionResult result, DLObjectInspectionToolConfig config)
		{
			string status = result.IsSpecEnabled ? result.SpecStatus : "OK";
			string color = string.Equals(status, "NG", StringComparison.OrdinalIgnoreCase) ? "red" : (string.IsNullOrWhiteSpace(config.TextColor) ? "lime" : config.TextColor);
			string text = string.Concat(new string[]
			{
				tool.Name ?? "DL Object",
				": ",
				status,
				"\nObjects: ",
				result.ObjectCount.ToString()
			});
			bool isSpecEnabled = result.IsSpecEnabled;
			if (isSpecEnabled)
			{
				text = string.Concat(new string[]
				{
					text,
					" [",
					result.SpecMin.ToString(),
					" ~ ",
					result.SpecMax.ToString(),
					"]"
				});
			}
			int row = (int)((result.Row > 0.0) ? result.Row : 24.0);
			int column = (int)((result.Column > 0.0) ? result.Column : 24.0);
			try
			{
				HOperatorSet.SetColor(window, color);
				HOperatorSet.SetTposition(window, row + 18, column + 18);
				HOperatorSet.WriteString(window, text);
			}
			catch
			{
			}
		}

		// Token: 0x06000BC3 RID: 3011 RVA: 0x00036E54 File Offset: 0x00035054
		private void DrawRoiList(HWindow window, ObservableCollection<RoiData> rois, string color)
		{
			bool flag = window == null || rois == null || rois.Count == 0;
			if (!flag)
			{
				try
				{
					HOperatorSet.SetDraw(window, "margin");
					HOperatorSet.SetLineWidth(window, 2);
					HOperatorSet.SetColor(window, color);
				}
				catch
				{
				}
				foreach (RoiData roi in rois)
				{
					bool flag2 = roi == null || !roi.IsEnabled;
					if (!flag2)
					{
						using (HObject obj = DLObjectInspectionRoiHelper.GenRegionFromRoi(roi))
						{
							try
							{
								bool flag3 = obj != null && obj.IsInitialized();
								if (flag3)
								{
									HOperatorSet.DispObj(obj, window);
								}
							}
							catch
							{
							}
						}
					}
				}
			}
		}
	}
}
