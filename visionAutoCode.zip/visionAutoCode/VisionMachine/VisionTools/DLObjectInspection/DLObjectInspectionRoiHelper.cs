﻿using System;
using System.Collections.Generic;
using HalconDotNet;
using VisionMachine.Models.Roi;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000EB RID: 235
	public static class DLObjectInspectionRoiHelper
	{
		// Token: 0x06000BC5 RID: 3013 RVA: 0x00036F74 File Offset: 0x00035174
		public static HObject BuildUnionRegion(IEnumerable<RoiData> rois)
		{
			bool flag = rois == null;
			HObject result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HObject union = null;
				foreach (RoiData roi in rois)
				{
					bool flag2 = roi == null || !roi.IsEnabled;
					if (!flag2)
					{
						HObject region = DLObjectInspectionRoiHelper.GenRegionFromRoi(roi);
						bool flag3 = region == null;
						if (!flag3)
						{
							bool flag4 = union == null;
							if (flag4)
							{
								union = region;
							}
							else
							{
								try
								{
									HObject merged;
									HOperatorSet.Union2(union, region, out merged);
									union.Dispose();
									region.Dispose();
									union = merged;
								}
								catch
								{
									region.Dispose();
								}
							}
						}
					}
				}
				result = union;
			}
			return result;
		}

		// Token: 0x06000BC6 RID: 3014 RVA: 0x00037050 File Offset: 0x00035250
		public static bool IsPointInside(HObject region, double row, double col)
		{
			bool flag = region == null || !region.IsInitialized();
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				try
				{
					HTuple isInside;
					HOperatorSet.TestRegionPoint(region, row, col, out isInside);
					result = (isInside.Length > 0 && isInside.I == 1);
				}
				catch
				{
					result = true;
				}
			}
			return result;
		}

		// Token: 0x06000BC7 RID: 3015 RVA: 0x000370BC File Offset: 0x000352BC
		public static HObject GenRegionFromRoi(RoiData roi)
		{
			HObject region = null;
			try
			{
				switch (roi.RoiType)
				{
				case RoiType.Rectangle1:
				case RoiType.Line:
					HOperatorSet.GenRectangle1(out region, Math.Min(roi.Row1, roi.Row2), Math.Min(roi.Col1, roi.Col2), Math.Max(roi.Row1, roi.Row2), Math.Max(roi.Col1, roi.Col2));
					break;
				case RoiType.Rectangle2:
					HOperatorSet.GenRectangle2(out region, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
					break;
				case RoiType.Circle:
					HOperatorSet.GenCircle(out region, roi.CenterRow, roi.CenterCol, roi.Radius);
					break;
				case RoiType.Ellipse:
					HOperatorSet.GenEllipse(out region, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
					break;
				case RoiType.Polygon:
				case RoiType.FreeDraw:
				case RoiType.DrawRegion:
				{
					bool flag = roi.Rows == null || roi.Cols == null || roi.Rows.Count < 3 || roi.Rows.Count != roi.Cols.Count;
					if (flag)
					{
						return null;
					}
					HObject contour;
					HOperatorSet.GenContourPolygonXld(out contour, new HTuple(roi.Rows.ToArray()), new HTuple(roi.Cols.ToArray()));
					try
					{
						HOperatorSet.GenRegionContourXld(contour, out region, "filled");
					}
					finally
					{
						if (contour != null)
						{
							contour.Dispose();
						}
					}
					break;
				}
				}
			}
			catch
			{
				if (region != null)
				{
					region.Dispose();
				}
				return null;
			}
			return region;
		}
	}
}
