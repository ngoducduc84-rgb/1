﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VisionMachine.Models.Camera;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000EC RID: 236
	public static class DLObjectInspectionStartupLoader
	{
		// Token: 0x06000BC8 RID: 3016 RVA: 0x00037308 File Offset: 0x00035508
		public static void PreloadAll(IEnumerable<CameraNode> cameras, Action<string, string> log = null)
		{
			bool flag = cameras == null;
			if (!flag)
			{
				List<CameraNode> cameraList = new List<CameraNode>(cameras);
				Task.Run(delegate()
				{
					try
					{
						string text;
						DLObjectInspectionLoadModelService.LoadAll(cameraList, out text, log);
					}
					catch (Exception ex)
					{
						Action<string, string> log2 = log;
						if (log2 != null)
						{
							log2("Warn", "DL model preload failed: " + ex.Message);
						}
					}
				});
			}
		}
	}
}
