﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000ED RID: 237
	public class DLObjectInspectionToolConfig : ToolConfigBase
	{
		// Token: 0x1700040B RID: 1035
		// (get) Token: 0x06000BC9 RID: 3017 RVA: 0x0003734C File Offset: 0x0003554C
		// (set) Token: 0x06000BCA RID: 3018 RVA: 0x0003737C File Offset: 0x0003557C
		[Browsable(false)]
		public ImageInputLink InputLink
		{
			get
			{
				bool flag = this._inputLink == null;
				if (flag)
				{
					this._inputLink = new ImageInputLink();
				}
				return this._inputLink;
			}
			set
			{
				bool flag = this._inputLink != value;
				if (flag)
				{
					this._inputLink = (value ?? new ImageInputLink());
					base.OnPropertyChanged("InputLink");
				}
			}
		}

		// Token: 0x1700040C RID: 1036
		// (get) Token: 0x06000BCB RID: 3019 RVA: 0x000373B8 File Offset: 0x000355B8
		// (set) Token: 0x06000BCC RID: 3020 RVA: 0x000373C0 File Offset: 0x000355C0
		[Category("Search")]
		[DisplayName("Score Threshold")]
		[Description("Minimum confidence (0-1) for an object to be kept.")]
		public double Score
		{
			get
			{
				return this._score;
			}
			set
			{
				bool flag = this._score != value;
				if (flag)
				{
					this._score = value;
					base.OnPropertyChanged("Score");
				}
			}
		}

		// Token: 0x1700040D RID: 1037
		// (get) Token: 0x06000BCD RID: 3021 RVA: 0x000373F3 File Offset: 0x000355F3
		// (set) Token: 0x06000BCE RID: 3022 RVA: 0x000373FC File Offset: 0x000355FC
		[Category("Search")]
		[DisplayName("Image Size")]
		[Description("Crop is resized to this square size before being sent to the model (e.g. 640).")]
		public int ImageSize
		{
			get
			{
				return this._imageSize;
			}
			set
			{
				bool flag = this._imageSize != value;
				if (flag)
				{
					this._imageSize = ((value < 32) ? 32 : value);
					base.OnPropertyChanged("ImageSize");
				}
			}
		}

		// Token: 0x1700040E RID: 1038
		// (get) Token: 0x06000BCF RID: 3023 RVA: 0x00037438 File Offset: 0x00035638
		// (set) Token: 0x06000BD0 RID: 3024 RVA: 0x00037440 File Offset: 0x00035640
		[Category("Model")]
		[DisplayName("Detect URL")]
		[Description("Python YOLO server detect endpoint, e.g. http://127.0.0.1:8000/detect")]
		public string DetectUrl
		{
			get
			{
				return this._detectUrl;
			}
			set
			{
				bool flag = this._detectUrl != value;
				if (flag)
				{
					this._detectUrl = value;
					base.OnPropertyChanged("DetectUrl");
				}
			}
		}

		// Token: 0x1700040F RID: 1039
		// (get) Token: 0x06000BD1 RID: 3025 RVA: 0x00037473 File Offset: 0x00035673
		// (set) Token: 0x06000BD2 RID: 3026 RVA: 0x0003747C File Offset: 0x0003567C
		[Category("Model")]
		[DisplayName("Crop Folder")]
		[Description("Folder where the cropped image is temporarily saved before being sent. Leave empty to use the tool's default folder.")]
		public string CropFolder
		{
			get
			{
				return this._cropFolder;
			}
			set
			{
				bool flag = this._cropFolder != value;
				if (flag)
				{
					this._cropFolder = value;
					base.OnPropertyChanged("CropFolder");
				}
			}
		}

		// Token: 0x17000410 RID: 1040
		// (get) Token: 0x06000BD3 RID: 3027 RVA: 0x000374AF File Offset: 0x000356AF
		// (set) Token: 0x06000BD4 RID: 3028 RVA: 0x000374B8 File Offset: 0x000356B8
		[Category("Display")]
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				bool flag = this._showRoi != value;
				if (flag)
				{
					this._showRoi = value;
					base.OnPropertyChanged("ShowRoi");
				}
			}
		}

		// Token: 0x17000411 RID: 1041
		// (get) Token: 0x06000BD5 RID: 3029 RVA: 0x000374EB File Offset: 0x000356EB
		// (set) Token: 0x06000BD6 RID: 3030 RVA: 0x000374F4 File Offset: 0x000356F4
		[Category("Display")]
		[DisplayName("Show Limit ROI")]
		public bool ShowLimitRoi
		{
			get
			{
				return this._showLimitRoi;
			}
			set
			{
				bool flag = this._showLimitRoi != value;
				if (flag)
				{
					this._showLimitRoi = value;
					base.OnPropertyChanged("ShowLimitRoi");
				}
			}
		}

		// Token: 0x17000412 RID: 1042
		// (get) Token: 0x06000BD7 RID: 3031 RVA: 0x00037527 File Offset: 0x00035727
		// (set) Token: 0x06000BD8 RID: 3032 RVA: 0x00037530 File Offset: 0x00035730
		[Category("Display")]
		[DisplayName("Show Box")]
		public bool ShowBox
		{
			get
			{
				return this._showBox;
			}
			set
			{
				bool flag = this._showBox != value;
				if (flag)
				{
					this._showBox = value;
					base.OnPropertyChanged("ShowBox");
				}
			}
		}

		// Token: 0x17000413 RID: 1043
		// (get) Token: 0x06000BD9 RID: 3033 RVA: 0x00037563 File Offset: 0x00035763
		// (set) Token: 0x06000BDA RID: 3034 RVA: 0x0003756C File Offset: 0x0003576C
		[Category("Display")]
		[DisplayName("Box Color")]
		public string BoxColor
		{
			get
			{
				return this._boxColor;
			}
			set
			{
				bool flag = this._boxColor != value;
				if (flag)
				{
					this._boxColor = value;
					base.OnPropertyChanged("BoxColor");
				}
			}
		}

		// Token: 0x17000414 RID: 1044
		// (get) Token: 0x06000BDB RID: 3035 RVA: 0x0003759F File Offset: 0x0003579F
		// (set) Token: 0x06000BDC RID: 3036 RVA: 0x000375A8 File Offset: 0x000357A8
		[Category("Display")]
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				bool flag = this._showText != value;
				if (flag)
				{
					this._showText = value;
					base.OnPropertyChanged("ShowText");
				}
			}
		}

		// Token: 0x17000415 RID: 1045
		// (get) Token: 0x06000BDD RID: 3037 RVA: 0x000375DB File Offset: 0x000357DB
		// (set) Token: 0x06000BDE RID: 3038 RVA: 0x000375E4 File Offset: 0x000357E4
		[Category("Display")]
		[DisplayName("Text Color")]
		public string TextColor
		{
			get
			{
				return this._textColor;
			}
			set
			{
				bool flag = this._textColor != value;
				if (flag)
				{
					this._textColor = value;
					base.OnPropertyChanged("TextColor");
				}
			}
		}

		// Token: 0x17000416 RID: 1046
		// (get) Token: 0x06000BDF RID: 3039 RVA: 0x00037617 File Offset: 0x00035817
		// (set) Token: 0x06000BE0 RID: 3040 RVA: 0x00037620 File Offset: 0x00035820
		[Category("Display")]
		[DisplayName("Text Size")]
		public int TextSize
		{
			get
			{
				return this._textSize;
			}
			set
			{
				bool flag = this._textSize != value;
				if (flag)
				{
					this._textSize = value;
					base.OnPropertyChanged("TextSize");
				}
			}
		}

		// Token: 0x040004BD RID: 1213
		private double _score = 0.25;

		// Token: 0x040004BE RID: 1214
		private int _imageSize = 640;

		// Token: 0x040004BF RID: 1215
		private string _detectUrl = "http://127.0.0.1:8000/detect";

		// Token: 0x040004C0 RID: 1216
		private string _cropFolder = "";

		// Token: 0x040004C1 RID: 1217
		private ImageInputLink _inputLink = new ImageInputLink();

		// Token: 0x040004C2 RID: 1218
		private bool _showRoi = true;

		// Token: 0x040004C3 RID: 1219
		private bool _showLimitRoi = true;

		// Token: 0x040004C4 RID: 1220
		private bool _showBox = true;

		// Token: 0x040004C5 RID: 1221
		private bool _showText = true;

		// Token: 0x040004C6 RID: 1222
		private string _boxColor = "red";

		// Token: 0x040004C7 RID: 1223
		private string _textColor = "lime";

		// Token: 0x040004C8 RID: 1224
		private int _textSize = 16;
	}
}
