﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000EE RID: 238
	public class DLObjectInspectionToolSpec : ToolSpecBase
	{
		// Token: 0x17000417 RID: 1047
		// (get) Token: 0x06000BE2 RID: 3042 RVA: 0x000376DD File Offset: 0x000358DD
		// (set) Token: 0x06000BE3 RID: 3043 RVA: 0x000376E8 File Offset: 0x000358E8
		[Category("Object Count")]
		[DisplayName("Count Spec Enabled")]
		public bool CountEnabled
		{
			get
			{
				return this._countEnabled;
			}
			set
			{
				bool flag = this._countEnabled != value;
				if (flag)
				{
					this._countEnabled = value;
					base.OnPropertyChanged("CountEnabled");
				}
			}
		}

		// Token: 0x17000418 RID: 1048
		// (get) Token: 0x06000BE4 RID: 3044 RVA: 0x0003771B File Offset: 0x0003591B
		// (set) Token: 0x06000BE5 RID: 3045 RVA: 0x00037724 File Offset: 0x00035924
		[Category("Object Count")]
		[DisplayName("Min Object Count (OK)")]
		public int MinObjectCount
		{
			get
			{
				return this._minObjectCount;
			}
			set
			{
				bool flag = this._minObjectCount != value;
				if (flag)
				{
					this._minObjectCount = ((value < 0) ? 0 : value);
					base.OnPropertyChanged("MinObjectCount");
				}
			}
		}

		// Token: 0x17000419 RID: 1049
		// (get) Token: 0x06000BE6 RID: 3046 RVA: 0x0003775E File Offset: 0x0003595E
		// (set) Token: 0x06000BE7 RID: 3047 RVA: 0x00037768 File Offset: 0x00035968
		[Category("Object Count")]
		[DisplayName("Max Object Count (OK)")]
		public int MaxObjectCount
		{
			get
			{
				return this._maxObjectCount;
			}
			set
			{
				bool flag = this._maxObjectCount != value;
				if (flag)
				{
					this._maxObjectCount = ((value < 0) ? 0 : value);
					base.OnPropertyChanged("MaxObjectCount");
				}
			}
		}

		// Token: 0x1700041A RID: 1050
		// (get) Token: 0x06000BE8 RID: 3048 RVA: 0x000377A2 File Offset: 0x000359A2
		// (set) Token: 0x06000BE9 RID: 3049 RVA: 0x000377AC File Offset: 0x000359AC
		[Category("Object Count")]
		[DisplayName("Class Filter")]
		[Description("Only count detections whose class name matches this (comma-separated). Leave empty to count all classes.")]
		public string ClassFilter
		{
			get
			{
				return this._classFilter;
			}
			set
			{
				bool flag = this._classFilter != value;
				if (flag)
				{
					this._classFilter = value;
					base.OnPropertyChanged("ClassFilter");
				}
			}
		}

		// Token: 0x040004C9 RID: 1225
		private bool _countEnabled = true;

		// Token: 0x040004CA RID: 1226
		private int _minObjectCount = 1;

		// Token: 0x040004CB RID: 1227
		private int _maxObjectCount = 1;

		// Token: 0x040004CC RID: 1228
		private string _classFilter = "";
	}
}
