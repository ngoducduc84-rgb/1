﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000EF RID: 239
	public class DLObjectInspectionToolTrain : ToolTrainBase
	{
		// Token: 0x1700041B RID: 1051
		// (get) Token: 0x06000BEB RID: 3051 RVA: 0x00037808 File Offset: 0x00035A08
		// (set) Token: 0x06000BEC RID: 3052 RVA: 0x00037810 File Offset: 0x00035A10
		[Category("Model")]
		[DisplayName("Weight Path (.pt)")]
		[Description("Full path to the YOLO weight file (.pt) on the machine running the Python server.")]
		public string WeightPath
		{
			get
			{
				return this._weightPath;
			}
			set
			{
				bool flag = this._weightPath != value;
				if (flag)
				{
					this._weightPath = value;
					base.OnPropertyChanged("WeightPath");
				}
			}
		}

		// Token: 0x1700041C RID: 1052
		// (get) Token: 0x06000BED RID: 3053 RVA: 0x00037843 File Offset: 0x00035A43
		// (set) Token: 0x06000BEE RID: 3054 RVA: 0x0003784C File Offset: 0x00035A4C
		[Category("Model")]
		[DisplayName("Model Key")]
		[Description("Identifier the Python server uses for this model. Leave empty to derive it from the weight file name.")]
		public string ModelKey
		{
			get
			{
				return this._modelKey;
			}
			set
			{
				bool flag = this._modelKey != value;
				if (flag)
				{
					this._modelKey = value;
					base.OnPropertyChanged("ModelKey");
				}
			}
		}

		// Token: 0x1700041D RID: 1053
		// (get) Token: 0x06000BEF RID: 3055 RVA: 0x0003787F File Offset: 0x00035A7F
		// (set) Token: 0x06000BF0 RID: 3056 RVA: 0x00037888 File Offset: 0x00035A88
		[Category("Model")]
		[DisplayName("Model Loaded")]
		public bool IsModelLoaded
		{
			get
			{
				return this._isModelLoaded;
			}
			set
			{
				bool flag = this._isModelLoaded != value;
				if (flag)
				{
					this._isModelLoaded = value;
					base.OnPropertyChanged("IsModelLoaded");
				}
			}
		}

		// Token: 0x1700041E RID: 1054
		// (get) Token: 0x06000BF1 RID: 3057 RVA: 0x000378BB File Offset: 0x00035ABB
		// (set) Token: 0x06000BF2 RID: 3058 RVA: 0x000378C4 File Offset: 0x00035AC4
		[Category("Model")]
		[DisplayName("Load Time (ms)")]
		public double LoadMs
		{
			get
			{
				return this._loadMs;
			}
			set
			{
				bool flag = this._loadMs != value;
				if (flag)
				{
					this._loadMs = value;
					base.OnPropertyChanged("LoadMs");
				}
			}
		}

		// Token: 0x040004CD RID: 1229
		private string _weightPath = "";

		// Token: 0x040004CE RID: 1230
		private string _modelKey = "";

		// Token: 0x040004CF RID: 1231
		private bool _isModelLoaded;

		// Token: 0x040004D0 RID: 1232
		private double _loadMs;
	}
}
