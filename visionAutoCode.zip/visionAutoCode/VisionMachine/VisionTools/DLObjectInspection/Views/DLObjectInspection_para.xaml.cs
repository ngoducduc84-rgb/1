﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using Microsoft.Win32;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.DLObjectInspection.Views
{
	// Token: 0x020000F5 RID: 245
	public partial class DLObjectInspection_para : UserControl
	{
		// Token: 0x06000C24 RID: 3108 RVA: 0x00037B8C File Offset: 0x00035D8C
		public DLObjectInspection_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000C25 RID: 3109 RVA: 0x00037BA0 File Offset: 0x00035DA0
		private void BrowseWeight_Click(object sender, RoutedEventArgs e)
		{
			DLObjectInspectionParameterPanelViewModel vm = base.DataContext as DLObjectInspectionParameterPanelViewModel;
			bool flag = vm == null || vm.Train == null;
			if (!flag)
			{
				OpenFileDialog dialog = new OpenFileDialog
				{
					Title = "Select YOLO weight file",
					Filter = "PyTorch Weights (*.pt)|*.pt|All files (*.*)|*.*",
					CheckFileExists = true
				};
				bool flag2 = !string.IsNullOrWhiteSpace(vm.Train.WeightPath);
				if (flag2)
				{
					try
					{
						string dir = Path.GetDirectoryName(vm.Train.WeightPath);
						bool flag3 = !string.IsNullOrWhiteSpace(dir) && Directory.Exists(dir);
						if (flag3)
						{
							dialog.InitialDirectory = dir;
						}
					}
					catch
					{
					}
				}
				bool valueOrDefault = dialog.ShowDialog().GetValueOrDefault();
				if (valueOrDefault)
				{
					vm.Train.WeightPath = dialog.FileName;
				}
			}
		}

		// Token: 0x06000C26 RID: 3110 RVA: 0x00037C88 File Offset: 0x00035E88
		private void LoadModel_Click(object sender, RoutedEventArgs e)
		{
			DLObjectInspectionParameterPanelViewModel vm = base.DataContext as DLObjectInspectionParameterPanelViewModel;
			bool flag = vm != null;
			if (flag)
			{
				Form_setting instance = Form_setting.Instance;
				if (instance != null)
				{
					instance.DLObjectInspectionLoadModel(vm.Tool);
				}
			}
		}

		// Token: 0x06000C27 RID: 3111 RVA: 0x00037CC1 File Offset: 0x00035EC1
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.DLObjectInspectionTrialRun();
			}
		}
	}
}
