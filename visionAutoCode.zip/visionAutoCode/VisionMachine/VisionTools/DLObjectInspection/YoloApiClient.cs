﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000F4 RID: 244
	public class YoloApiClient
	{
		// Token: 0x06000C20 RID: 3104 RVA: 0x00037A6A File Offset: 0x00035C6A
		public YoloApiClient(string detectUrl)
		{
			this._detectUrl = (string.IsNullOrWhiteSpace(detectUrl) ? "http://127.0.0.1:8000/detect" : detectUrl);
		}

		// Token: 0x06000C21 RID: 3105 RVA: 0x00037A8C File Offset: 0x00035C8C
		[DebuggerStepThrough]
		public Task<YoloDetectResponse> DetectAsync(string imagePath, int cropX, int cropY, int cropW, int cropH, string frameId, string modelKey, int resizedW, int resizedH, double scoreThreshold)
		{
			YoloApiClient.<DetectAsync>d__3 <DetectAsync>d__ = new YoloApiClient.<DetectAsync>d__3();
			<DetectAsync>d__.<>t__builder = AsyncTaskMethodBuilder<YoloDetectResponse>.Create();
			<DetectAsync>d__.<>4__this = this;
			<DetectAsync>d__.imagePath = imagePath;
			<DetectAsync>d__.cropX = cropX;
			<DetectAsync>d__.cropY = cropY;
			<DetectAsync>d__.cropW = cropW;
			<DetectAsync>d__.cropH = cropH;
			<DetectAsync>d__.frameId = frameId;
			<DetectAsync>d__.modelKey = modelKey;
			<DetectAsync>d__.resizedW = resizedW;
			<DetectAsync>d__.resizedH = resizedH;
			<DetectAsync>d__.scoreThreshold = scoreThreshold;
			<DetectAsync>d__.<>1__state = -1;
			<DetectAsync>d__.<>t__builder.Start<YoloApiClient.<DetectAsync>d__3>(ref <DetectAsync>d__);
			return <DetectAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000C22 RID: 3106 RVA: 0x00037B20 File Offset: 0x00035D20
		[DebuggerStepThrough]
		public Task<YoloReloadResponse> ReloadModelsAsync(Dictionary<string, string> modelMap)
		{
			YoloApiClient.<ReloadModelsAsync>d__4 <ReloadModelsAsync>d__ = new YoloApiClient.<ReloadModelsAsync>d__4();
			<ReloadModelsAsync>d__.<>t__builder = AsyncTaskMethodBuilder<YoloReloadResponse>.Create();
			<ReloadModelsAsync>d__.<>4__this = this;
			<ReloadModelsAsync>d__.modelMap = modelMap;
			<ReloadModelsAsync>d__.<>1__state = -1;
			<ReloadModelsAsync>d__.<>t__builder.Start<YoloApiClient.<ReloadModelsAsync>d__4>(ref <ReloadModelsAsync>d__);
			return <ReloadModelsAsync>d__.<>t__builder.Task;
		}

		// Token: 0x040004E5 RID: 1253
		private static readonly HttpClient _httpClient = new HttpClient
		{
			Timeout = TimeSpan.FromSeconds(30.0)
		};

		// Token: 0x040004E6 RID: 1254
		private readonly string _detectUrl;
	}
}
