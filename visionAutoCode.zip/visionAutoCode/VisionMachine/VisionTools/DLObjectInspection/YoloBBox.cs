﻿using System;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000F0 RID: 240
	public class YoloBBox
	{
		// Token: 0x1700041F RID: 1055
		// (get) Token: 0x06000BF4 RID: 3060 RVA: 0x00037916 File Offset: 0x00035B16
		// (set) Token: 0x06000BF5 RID: 3061 RVA: 0x0003791E File Offset: 0x00035B1E
		public int x1 { get; set; }

		// Token: 0x17000420 RID: 1056
		// (get) Token: 0x06000BF6 RID: 3062 RVA: 0x00037927 File Offset: 0x00035B27
		// (set) Token: 0x06000BF7 RID: 3063 RVA: 0x0003792F File Offset: 0x00035B2F
		public int y1 { get; set; }

		// Token: 0x17000421 RID: 1057
		// (get) Token: 0x06000BF8 RID: 3064 RVA: 0x00037938 File Offset: 0x00035B38
		// (set) Token: 0x06000BF9 RID: 3065 RVA: 0x00037940 File Offset: 0x00035B40
		public int x2 { get; set; }

		// Token: 0x17000422 RID: 1058
		// (get) Token: 0x06000BFA RID: 3066 RVA: 0x00037949 File Offset: 0x00035B49
		// (set) Token: 0x06000BFB RID: 3067 RVA: 0x00037951 File Offset: 0x00035B51
		public int y2 { get; set; }
	}
}
