﻿using System;
using System.Collections.Generic;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000F2 RID: 242
	public class YoloDetectResponse
	{
		// Token: 0x17000428 RID: 1064
		// (get) Token: 0x06000C08 RID: 3080 RVA: 0x000379AF File Offset: 0x00035BAF
		// (set) Token: 0x06000C09 RID: 3081 RVA: 0x000379B7 File Offset: 0x00035BB7
		public bool success { get; set; }

		// Token: 0x17000429 RID: 1065
		// (get) Token: 0x06000C0A RID: 3082 RVA: 0x000379C0 File Offset: 0x00035BC0
		// (set) Token: 0x06000C0B RID: 3083 RVA: 0x000379C8 File Offset: 0x00035BC8
		public string frame_id { get; set; }

		// Token: 0x1700042A RID: 1066
		// (get) Token: 0x06000C0C RID: 3084 RVA: 0x000379D1 File Offset: 0x00035BD1
		// (set) Token: 0x06000C0D RID: 3085 RVA: 0x000379D9 File Offset: 0x00035BD9
		public string model_key { get; set; }

		// Token: 0x1700042B RID: 1067
		// (get) Token: 0x06000C0E RID: 3086 RVA: 0x000379E2 File Offset: 0x00035BE2
		// (set) Token: 0x06000C0F RID: 3087 RVA: 0x000379EA File Offset: 0x00035BEA
		public string model_path { get; set; }

		// Token: 0x1700042C RID: 1068
		// (get) Token: 0x06000C10 RID: 3088 RVA: 0x000379F3 File Offset: 0x00035BF3
		// (set) Token: 0x06000C11 RID: 3089 RVA: 0x000379FB File Offset: 0x00035BFB
		public string error { get; set; }

		// Token: 0x1700042D RID: 1069
		// (get) Token: 0x06000C12 RID: 3090 RVA: 0x00037A04 File Offset: 0x00035C04
		// (set) Token: 0x06000C13 RID: 3091 RVA: 0x00037A0C File Offset: 0x00035C0C
		public List<YoloObject> objects { get; set; }
	}
}
