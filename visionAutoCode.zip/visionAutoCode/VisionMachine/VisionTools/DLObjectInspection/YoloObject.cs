﻿using System;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000F1 RID: 241
	public class YoloObject
	{
		// Token: 0x17000423 RID: 1059
		// (get) Token: 0x06000BFD RID: 3069 RVA: 0x0003795A File Offset: 0x00035B5A
		// (set) Token: 0x06000BFE RID: 3070 RVA: 0x00037962 File Offset: 0x00035B62
		public int class_id { get; set; }

		// Token: 0x17000424 RID: 1060
		// (get) Token: 0x06000BFF RID: 3071 RVA: 0x0003796B File Offset: 0x00035B6B
		// (set) Token: 0x06000C00 RID: 3072 RVA: 0x00037973 File Offset: 0x00035B73
		public string class_name { get; set; }

		// Token: 0x17000425 RID: 1061
		// (get) Token: 0x06000C01 RID: 3073 RVA: 0x0003797C File Offset: 0x00035B7C
		// (set) Token: 0x06000C02 RID: 3074 RVA: 0x00037984 File Offset: 0x00035B84
		public double confidence { get; set; }

		// Token: 0x17000426 RID: 1062
		// (get) Token: 0x06000C03 RID: 3075 RVA: 0x0003798D File Offset: 0x00035B8D
		// (set) Token: 0x06000C04 RID: 3076 RVA: 0x00037995 File Offset: 0x00035B95
		public YoloBBox bbox_640 { get; set; }

		// Token: 0x17000427 RID: 1063
		// (get) Token: 0x06000C05 RID: 3077 RVA: 0x0003799E File Offset: 0x00035B9E
		// (set) Token: 0x06000C06 RID: 3078 RVA: 0x000379A6 File Offset: 0x00035BA6
		public YoloBBox bbox_original { get; set; }
	}
}
