﻿using System;

namespace VisionMachine.VisionTools.DLObjectInspection
{
	// Token: 0x020000F3 RID: 243
	public class YoloReloadResponse
	{
		// Token: 0x1700042E RID: 1070
		// (get) Token: 0x06000C15 RID: 3093 RVA: 0x00037A15 File Offset: 0x00035C15
		// (set) Token: 0x06000C16 RID: 3094 RVA: 0x00037A1D File Offset: 0x00035C1D
		public bool success { get; set; }

		// Token: 0x1700042F RID: 1071
		// (get) Token: 0x06000C17 RID: 3095 RVA: 0x00037A26 File Offset: 0x00035C26
		// (set) Token: 0x06000C18 RID: 3096 RVA: 0x00037A2E File Offset: 0x00035C2E
		public int loaded_count { get; set; }

		// Token: 0x17000430 RID: 1072
		// (get) Token: 0x06000C19 RID: 3097 RVA: 0x00037A37 File Offset: 0x00035C37
		// (set) Token: 0x06000C1A RID: 3098 RVA: 0x00037A3F File Offset: 0x00035C3F
		public string current_model_key { get; set; }

		// Token: 0x17000431 RID: 1073
		// (get) Token: 0x06000C1B RID: 3099 RVA: 0x00037A48 File Offset: 0x00035C48
		// (set) Token: 0x06000C1C RID: 3100 RVA: 0x00037A50 File Offset: 0x00035C50
		public double load_ms { get; set; }

		// Token: 0x17000432 RID: 1074
		// (get) Token: 0x06000C1D RID: 3101 RVA: 0x00037A59 File Offset: 0x00035C59
		// (set) Token: 0x06000C1E RID: 3102 RVA: 0x00037A61 File Offset: 0x00035C61
		public string error { get; set; }
	}
}
