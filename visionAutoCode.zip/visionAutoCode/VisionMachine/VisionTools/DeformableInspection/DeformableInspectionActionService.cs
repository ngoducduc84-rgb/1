﻿using System;
using System.Diagnostics;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.ResultInspection;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x02000156 RID: 342
	public class DeformableInspectionActionService : IToolActionService
	{
		// Token: 0x17000698 RID: 1688
		// (get) Token: 0x06001247 RID: 4679 RVA: 0x00054CD8 File Offset: 0x00052ED8
		public ToolType ToolType
		{
			get
			{
				return ToolType.DeformableInspection;
			}
		}

		// Token: 0x06001248 RID: 4680 RVA: 0x00054CEC File Offset: 0x00052EEC
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						ToolActionFeedback.ReportError(context, "No original image is available.");
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext buildContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						string inputSourceToolName = this.GetInputSourceToolName(tool);
						input = this._pipelineService.BuildInputImageForTool(buildContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							if (input != null)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						Stopwatch stopwatch = Stopwatch.StartNew();
						DeformableInspectionResult result = this._processor.Run(input, tool);
						stopwatch.Stop();
						bool flag4 = result.ProcessingTimeMs <= 0.0;
						if (flag4)
						{
							result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
						}
						bool flag5 = result.TotalProcessingTimeMs <= 0.0;
						if (flag5)
						{
							result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
						}
						result.InputSourceToolName = inputSourceToolName;
						InspectionResultStore.Record(tool.Name, result);
						Action<ToolVision, object> resultReporter = context.ResultReporter;
						if (resultReporter != null)
						{
							resultReporter(tool, result);
						}
						context.DisplayController.DisplayImage(input);
						context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
						{
							this._drawer.Draw(window, tool, result);
						}, null);
					}
				}
				finally
				{
					if (input != null)
					{
						input.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					bool flag6 = original != null;
					if (flag6)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x06001249 RID: 4681 RVA: 0x00054F68 File Offset: 0x00053168
		private string GetInputSourceToolName(ToolVision tool)
		{
			DeformableInspectionToolConfig config = ((tool != null) ? tool.Config : null) as DeformableInspectionToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						result = "PreviousToolOutput";
					}
					else
					{
						result = "OriginalImage";
					}
				}
			}
			return result;
		}

		// Token: 0x0400079D RID: 1949
		private readonly DeformableInspectionProcessor _processor = new DeformableInspectionProcessor();

		// Token: 0x0400079E RID: 1950
		private readonly DeformableInspectionResultDrawer _drawer = new DeformableInspectionResultDrawer();

		// Token: 0x0400079F RID: 1951
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();
	}
}
