﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x02000157 RID: 343
	public class DeformableInspectionParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x17000699 RID: 1689
		// (get) Token: 0x0600124B RID: 4683 RVA: 0x00055027 File Offset: 0x00053227
		// (set) Token: 0x0600124C RID: 4684 RVA: 0x0005502F File Offset: 0x0005322F
		public ToolVision Tool { get; set; }

		// Token: 0x1700069A RID: 1690
		// (get) Token: 0x0600124D RID: 4685 RVA: 0x00055038 File Offset: 0x00053238
		// (set) Token: 0x0600124E RID: 4686 RVA: 0x00055040 File Offset: 0x00053240
		public DeformableInspectionToolConfig Config { get; set; }

		// Token: 0x1700069B RID: 1691
		// (get) Token: 0x0600124F RID: 4687 RVA: 0x00055049 File Offset: 0x00053249
		// (set) Token: 0x06001250 RID: 4688 RVA: 0x00055051 File Offset: 0x00053251
		public DeformableInspectionToolSpec Spec { get; set; }

		// Token: 0x1700069C RID: 1692
		// (get) Token: 0x06001251 RID: 4689 RVA: 0x0005505A File Offset: 0x0005325A
		// (set) Token: 0x06001252 RID: 4690 RVA: 0x00055062 File Offset: 0x00053262
		public DeformableInspectionToolTrain Train { get; set; }

		// Token: 0x1700069D RID: 1693
		// (get) Token: 0x06001253 RID: 4691 RVA: 0x0005506B File Offset: 0x0005326B
		// (set) Token: 0x06001254 RID: 4692 RVA: 0x00055073 File Offset: 0x00053273
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x1700069E RID: 1694
		// (get) Token: 0x06001255 RID: 4693 RVA: 0x0005507C File Offset: 0x0005327C
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x1700069F RID: 1695
		// (get) Token: 0x06001256 RID: 4694 RVA: 0x00055098 File Offset: 0x00053298
		// (set) Token: 0x06001257 RID: 4695 RVA: 0x000550B0 File Offset: 0x000532B0
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool == value;
				if (!flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.Config != null && this.Config.InputLink != null;
					if (flag2)
					{
						this.Config.InputLink.SourceToolId = null;
						this.Config.InputLink.SourceToolName = ((this._selectedSourceTool == null) ? null : this._selectedSourceTool.ToolName);
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x14000022 RID: 34
		// (add) Token: 0x06001258 RID: 4696 RVA: 0x00055138 File Offset: 0x00053338
		// (remove) Token: 0x06001259 RID: 4697 RVA: 0x00055170 File Offset: 0x00053370
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x0600125A RID: 4698 RVA: 0x000551A5 File Offset: 0x000533A5
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x0600125B RID: 4699 RVA: 0x000551C4 File Offset: 0x000533C4
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.Config == null || this.Config.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.Config.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.Config.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.Config.InputLink.SourceToolId = null;
				this.Config.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x040007A0 RID: 1952
		private ToolImageSourceOption _selectedSourceTool;
	}
}
