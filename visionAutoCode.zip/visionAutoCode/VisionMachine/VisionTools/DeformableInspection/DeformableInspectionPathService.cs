﻿using System;
using System.IO;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x02000158 RID: 344
	public class DeformableInspectionPathService
	{
		// Token: 0x0600125D RID: 4701 RVA: 0x000552A4 File Offset: 0x000534A4
		public string GetModelFolder(string turnSnapFolder)
		{
			string folder = Path.Combine(turnSnapFolder, "DeformableModels");
			Directory.CreateDirectory(folder);
			return folder;
		}

		// Token: 0x0600125E RID: 4702 RVA: 0x000552CC File Offset: 0x000534CC
		public string GetModelFileName(ToolVision tool)
		{
			return "deformable_model_" + tool.ToolId + ".dlm";
		}

		// Token: 0x0600125F RID: 4703 RVA: 0x000552F4 File Offset: 0x000534F4
		public string GetModelFullPath(string turnSnapFolder, ToolVision tool)
		{
			return Path.Combine(this.GetModelFolder(turnSnapFolder), this.GetModelFileName(tool));
		}

		// Token: 0x06001260 RID: 4704 RVA: 0x0005531C File Offset: 0x0005351C
		public string GetModelRelativePath(ToolVision tool)
		{
			return Path.Combine("DeformableModels", this.GetModelFileName(tool));
		}
	}
}
