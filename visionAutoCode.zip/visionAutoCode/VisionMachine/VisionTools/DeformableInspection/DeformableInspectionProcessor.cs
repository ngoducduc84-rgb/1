﻿using System;
using System.Collections.Generic;
using System.IO;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.Views.Setting.Services;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x02000159 RID: 345
	public class DeformableInspectionProcessor : IToolProcessor
	{
		// Token: 0x170006A0 RID: 1696
		// (get) Token: 0x06001262 RID: 4706 RVA: 0x00055340 File Offset: 0x00053540
		public ToolType ToolType
		{
			get
			{
				return ToolType.DeformableInspection;
			}
		}

		// Token: 0x06001263 RID: 4707 RVA: 0x00055354 File Offset: 0x00053554
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			ToolProcessResult processResult = new ToolProcessResult();
			bool flag = context == null || context.InputImage == null;
			ToolProcessResult result2;
			if (flag)
			{
				processResult.IsSuccess = false;
				processResult.Message = "Input image null.";
				result2 = processResult;
			}
			else
			{
				DeformableInspectionResult result = this.Run(context.InputImage, tool);
				processResult.IsSuccess = result.IsSuccess;
				processResult.Message = result.Message;
				processResult.Data = result;
				HObject copy;
				HOperatorSet.CopyImage(context.InputImage, out copy);
				context.OutputImage = copy;
				result2 = processResult;
			}
			return result2;
		}

		// Token: 0x06001264 RID: 4708 RVA: 0x000553E4 File Offset: 0x000535E4
		public DeformableInspectionResult Run(HObject image, ToolVision tool)
		{
			DeformableInspectionResult result = new DeformableInspectionResult();
			bool flag = tool == null;
			DeformableInspectionResult result2;
			if (flag)
			{
				result.Message = "Tool null.";
				result2 = result;
			}
			else
			{
				bool flag2 = image == null || !image.IsInitialized();
				if (flag2)
				{
					result.Message = "No image is available for inspection.";
					result2 = result;
				}
				else
				{
					DeformableInspectionToolConfig config = tool.Config as DeformableInspectionToolConfig;
					DeformableInspectionToolTrain train = tool.TrainModel as DeformableInspectionToolTrain;
					DeformableInspectionToolSpec spec = tool.Spec as DeformableInspectionToolSpec;
					bool flag3 = config == null || train == null;
					if (flag3)
					{
						result.Message = "The selected tool is not a Deformable Inspection tool.";
						result2 = result;
					}
					else
					{
						bool flag4 = !train.IsTrained;
						if (flag4)
						{
							result.Message = "The deformable model has not been trained.";
							result2 = result;
						}
						else
						{
							string modelPath = this.GetModelFullPath(tool);
							bool flag5 = string.IsNullOrWhiteSpace(modelPath) || !File.Exists(modelPath);
							if (flag5)
							{
								result.Message = "Deformable model file was not found:\n" + modelPath;
								result2 = result;
							}
							else
							{
								HObject gray = null;
								HObject masked = null;
								HObject searchImage = null;
								HObject imageRectified = null;
								HObject vectorField = null;
								HObject deformedContours = null;
								HTuple modelId = null;
								try
								{
									HOperatorSet.ReadDeformableModel(modelPath, out modelId);
									gray = this.ConvertToGray(image);
									masked = this._roiImageService.ApplyMaskRois(gray, tool);
									searchImage = this._roiImageService.ReduceByRois(masked, tool.LimitRoiItems, tool);
									HTuple resultType = new HTuple("vector_field");
									resultType = resultType.TupleConcat("deformed_contours");
									HTuple score;
									HTuple row;
									HTuple column;
									this.FindDeformableModel(searchImage, modelId, config, resultType, out imageRectified, out vectorField, out deformedContours, out score, out row, out column);
									bool flag6 = (score == null || score.Length <= 0) && !this.IsLegacyDefaultSearch(config);
									if (flag6)
									{
										if (imageRectified != null)
										{
											imageRectified.Dispose();
										}
										if (vectorField != null)
										{
											vectorField.Dispose();
										}
										if (deformedContours != null)
										{
											deformedContours.Dispose();
										}
										imageRectified = null;
										vectorField = null;
										deformedContours = null;
										this.FindDeformableModelWithLegacyDefaults(searchImage, modelId, resultType, out imageRectified, out vectorField, out deformedContours, out score, out row, out column);
									}
									bool flag7 = score == null || score.Length <= 0;
									if (flag7)
									{
										result.IsSuccess = false;
										result.Message = "Deformable model was not found.";
										result2 = result;
									}
									else
									{
										result.Score = score[0].D;
										result.Row = ((row != null && row.Length > 0) ? row[0].D : 0.0);
										result.Column = ((column != null && column.Length > 0) ? column[0].D : 0.0);
										this.TryComputeDeformationMetrics(vectorField, config.DefectThreshold, result);
										bool showWarpedMesh = config.ShowWarpedMesh;
										if (showWarpedMesh)
										{
											this.TryGenerateWarpedMesh(vectorField, config, result);
										}
										this.ExtractContours(deformedContours, result.ContourRows, result.ContourColumns);
										this.ApplySpecAndJudge(spec, result);
										result.IsSuccess = true;
										result.Message = string.Concat(new string[]
										{
											"Deformable inspection completed. Score=",
											result.Score.ToString("0.000"),
											", MaxDef=",
											result.MaxDeformation.ToString("0.00"),
											", MeanDef=",
											result.MeanDeformation.ToString("0.00"),
											", DefectArea=",
											result.DefectArea.ToString("0"),
											result.IsSpecEnabled ? (", " + result.SpecStatus) : string.Empty
										});
										result2 = result;
									}
								}
								catch (Exception ex)
								{
									result.IsSuccess = false;
									result.Message = "Deformable inspection failed: " + ex.Message;
									result2 = result;
								}
								finally
								{
									if (imageRectified != null)
									{
										imageRectified.Dispose();
									}
									if (vectorField != null)
									{
										vectorField.Dispose();
									}
									if (deformedContours != null)
									{
										deformedContours.Dispose();
									}
									if (searchImage != null)
									{
										searchImage.Dispose();
									}
									if (masked != null)
									{
										masked.Dispose();
									}
									if (gray != null)
									{
										gray.Dispose();
									}
									bool flag8 = modelId != null;
									if (flag8)
									{
										HOperatorSet.ClearDeformableModel(modelId);
									}
								}
							}
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x06001265 RID: 4709 RVA: 0x00055860 File Offset: 0x00053A60
		private void ComputeDeformationMetrics(HObject vectorField, double defectThreshold, DeformableInspectionResult result)
		{
			bool flag = vectorField == null || !vectorField.IsInitialized();
			if (!flag)
			{
				HObject dr = null;
				HObject dc = null;
				HObject dr2 = null;
				HObject dc2 = null;
				HObject sumSq = null;
				HObject magnitude = null;
				HObject domain = null;
				HObject defectRegion = null;
				try
				{
					HOperatorSet.VectorFieldToReal(vectorField, out dr, out dc);
					HOperatorSet.MultImage(dr, dr, out dr2, 1.0, 0.0);
					HOperatorSet.MultImage(dc, dc, out dc2, 1.0, 0.0);
					HOperatorSet.AddImage(dr2, dc2, out sumSq, 1.0, 0.0);
					HOperatorSet.SqrtImage(sumSq, out magnitude);
					HOperatorSet.GetDomain(magnitude, out domain);
					HTuple domArea;
					HTuple dRow;
					HTuple dCol;
					HOperatorSet.AreaCenter(domain, out domArea, out dRow, out dCol);
					bool flag2 = domArea == null || domArea.Length == 0 || domArea[0].D <= 0.0;
					if (!flag2)
					{
						HTuple minVal;
						HTuple maxVal;
						HTuple range;
						HOperatorSet.MinMaxGray(domain, magnitude, 0, out minVal, out maxVal, out range);
						HTuple meanVal;
						HTuple deviation;
						HOperatorSet.Intensity(domain, magnitude, out meanVal, out deviation);
						result.MaxDeformation = ((maxVal != null && maxVal.Length > 0) ? maxVal[0].D : 0.0);
						result.MeanDeformation = ((meanVal != null && meanVal.Length > 0) ? meanVal[0].D : 0.0);
						HOperatorSet.Threshold(magnitude, out defectRegion, defectThreshold, 1000000000.0);
						HTuple defArea;
						HTuple defRow;
						HTuple defCol;
						HOperatorSet.AreaCenter(defectRegion, out defArea, out defRow, out defCol);
						result.DefectArea = ((defArea != null && defArea.Length > 0) ? defArea.TupleSum().D : 0.0);
					}
				}
				finally
				{
					if (dr != null)
					{
						dr.Dispose();
					}
					if (dc != null)
					{
						dc.Dispose();
					}
					if (dr2 != null)
					{
						dr2.Dispose();
					}
					if (dc2 != null)
					{
						dc2.Dispose();
					}
					if (sumSq != null)
					{
						sumSq.Dispose();
					}
					if (magnitude != null)
					{
						magnitude.Dispose();
					}
					if (domain != null)
					{
						domain.Dispose();
					}
					if (defectRegion != null)
					{
						defectRegion.Dispose();
					}
				}
			}
		}

		// Token: 0x06001266 RID: 4710 RVA: 0x00055AD4 File Offset: 0x00053CD4
		private void TryComputeDeformationMetrics(HObject vectorField, double defectThreshold, DeformableInspectionResult result)
		{
			try
			{
				this.ComputeDeformationMetrics(vectorField, defectThreshold, result);
			}
			catch
			{
				result.MaxDeformation = 0.0;
				result.MeanDeformation = 0.0;
				result.DefectArea = 0.0;
			}
		}

		// Token: 0x06001267 RID: 4711 RVA: 0x00055B38 File Offset: 0x00053D38
		private void GenerateWarpedMesh(HObject vectorField, DeformableInspectionToolConfig config, DeformableInspectionResult result)
		{
			bool flag = vectorField == null || !vectorField.IsInitialized() || config == null || result == null;
			if (!flag)
			{
				HObject rowVector = null;
				HObject columnVector = null;
				try
				{
					HOperatorSet.VectorFieldToReal(vectorField, out rowVector, out columnVector);
					HTuple widthTuple;
					HTuple heightTuple;
					HOperatorSet.GetImageSize(rowVector, out widthTuple, out heightTuple);
					int width = Math.Max(1, widthTuple.I);
					int height = Math.Max(1, heightTuple.I);
					int spacing = Math.Max(4, config.MeshSpacing);
					int pointStep = Math.Max(2, spacing);
					double maxDimension = (double)Math.Max(width, height);
					for (int row = 0; row < height; row += spacing)
					{
						this.AddWarpedMeshLine(rowVector, columnVector, (double)row, 0.0, (double)row, (double)(width - 1), pointStep, maxDimension, result);
					}
					bool flag2 = (height - 1) % spacing != 0;
					if (flag2)
					{
						this.AddWarpedMeshLine(rowVector, columnVector, (double)(height - 1), 0.0, (double)(height - 1), (double)(width - 1), pointStep, maxDimension, result);
					}
					for (int column = 0; column < width; column += spacing)
					{
						this.AddWarpedMeshLine(rowVector, columnVector, 0.0, (double)column, (double)(height - 1), (double)column, pointStep, maxDimension, result);
					}
					bool flag3 = (width - 1) % spacing != 0;
					if (flag3)
					{
						this.AddWarpedMeshLine(rowVector, columnVector, 0.0, (double)(width - 1), (double)(height - 1), (double)(width - 1), pointStep, maxDimension, result);
					}
				}
				catch
				{
				}
				finally
				{
					if (rowVector != null)
					{
						rowVector.Dispose();
					}
					if (columnVector != null)
					{
						columnVector.Dispose();
					}
				}
			}
		}

		// Token: 0x06001268 RID: 4712 RVA: 0x00055CFC File Offset: 0x00053EFC
		private void TryGenerateWarpedMesh(HObject vectorField, DeformableInspectionToolConfig config, DeformableInspectionResult result)
		{
			try
			{
				this.GenerateWarpedMesh(vectorField, config, result);
			}
			catch
			{
			}
		}

		// Token: 0x06001269 RID: 4713 RVA: 0x00055D30 File Offset: 0x00053F30
		private void AddWarpedMeshLine(HObject rowVector, HObject columnVector, double rowStart, double columnStart, double rowEnd, double columnEnd, int pointStep, double maxDimension, DeformableInspectionResult result)
		{
			double length = Math.Max(Math.Abs(rowEnd - rowStart), Math.Abs(columnEnd - columnStart));
			int pointCount = Math.Max(2, (int)Math.Ceiling(length / (double)Math.Max(1, pointStep)) + 1);
			double[] rows = new double[pointCount];
			double[] columns = new double[pointCount];
			for (int i = 0; i < pointCount; i++)
			{
				double t = (pointCount == 1) ? 0.0 : ((double)i / (double)(pointCount - 1));
				rows[i] = rowStart + (rowEnd - rowStart) * t;
				columns[i] = columnStart + (columnEnd - columnStart) * t;
			}
			try
			{
				HTuple rowTuple = new HTuple(rows);
				HTuple columnTuple = new HTuple(columns);
				HTuple rowValues;
				HOperatorSet.GetGrayvalInterpolated(rowVector, rowTuple, columnTuple, "bilinear", out rowValues);
				HTuple columnValues;
				HOperatorSet.GetGrayvalInterpolated(columnVector, rowTuple, columnTuple, "bilinear", out columnValues);
				bool flag = rowValues == null || columnValues == null || rowValues.Length != pointCount || columnValues.Length != pointCount;
				if (!flag)
				{
					bool vectorLooksAbsolute = this.ResultVectorLooksAbsolute(rowValues, columnValues, rowTuple, columnTuple, maxDimension);
					double[] warpedRows = new double[pointCount];
					double[] warpedColumns = new double[pointCount];
					for (int j = 0; j < pointCount; j++)
					{
						bool flag2 = vectorLooksAbsolute;
						if (flag2)
						{
							warpedRows[j] = rowValues[j].D;
							warpedColumns[j] = columnValues[j].D;
						}
						else
						{
							warpedRows[j] = rows[j] + rowValues[j].D;
							warpedColumns[j] = columns[j] + columnValues[j].D;
						}
					}
					result.MeshRows.Add(warpedRows);
					result.MeshColumns.Add(warpedColumns);
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600126A RID: 4714 RVA: 0x00055F1C File Offset: 0x0005411C
		private bool ResultVectorLooksAbsolute(HTuple rowVectorValues, HTuple columnVectorValues, HTuple contourRows, HTuple contourColumns, double maxDimension)
		{
			bool flag = rowVectorValues == null || columnVectorValues == null || contourRows == null || contourColumns == null || rowVectorValues.Length == 0;
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				int count = Math.Min(Math.Min(rowVectorValues.Length, columnVectorValues.Length), Math.Min(contourRows.Length, contourColumns.Length));
				int sampleCount = Math.Min(count, 25);
				bool flag2 = sampleCount <= 0;
				if (flag2)
				{
					result = false;
				}
				else
				{
					double offsetSum = 0.0;
					double absoluteDistanceSum = 0.0;
					for (int i = 0; i < sampleCount; i++)
					{
						int index = (sampleCount == 1) ? 0 : ((int)Math.Round((double)i * (double)(count - 1) / (double)(sampleCount - 1)));
						double rowValue = rowVectorValues[index].D;
						double columnValue = columnVectorValues[index].D;
						offsetSum += Math.Sqrt(rowValue * rowValue + columnValue * columnValue);
						double deltaRow = rowValue - contourRows[index].D;
						double deltaColumn = columnValue - contourColumns[index].D;
						absoluteDistanceSum += Math.Sqrt(deltaRow * deltaRow + deltaColumn * deltaColumn);
					}
					double averageOffset = offsetSum / (double)sampleCount;
					double averageAbsoluteDistance = absoluteDistanceSum / (double)sampleCount;
					result = (averageOffset > maxDimension * 0.2 && averageAbsoluteDistance < averageOffset);
				}
			}
			return result;
		}

		// Token: 0x0600126B RID: 4715 RVA: 0x0005607C File Offset: 0x0005427C
		private void ExtractContours(HObject contours, List<double[]> rowsOut, List<double[]> colsOut)
		{
			bool flag = contours == null || !contours.IsInitialized();
			if (!flag)
			{
				HTuple count;
				HOperatorSet.CountObj(contours, out count);
				bool flag2 = count == null || count.Length == 0;
				if (!flag2)
				{
					for (int i = 1; i <= count[0].I; i++)
					{
						HObject single = null;
						try
						{
							HOperatorSet.SelectObj(contours, out single, i);
							HTuple cRows;
							HTuple cCols;
							HOperatorSet.GetContourXld(single, out cRows, out cCols);
							bool flag3 = cRows != null && cRows.Length > 0;
							if (flag3)
							{
								rowsOut.Add(cRows.ToDArr());
								colsOut.Add(cCols.ToDArr());
							}
						}
						catch
						{
						}
						finally
						{
							if (single != null)
							{
								single.Dispose();
							}
						}
					}
				}
			}
		}

		// Token: 0x0600126C RID: 4716 RVA: 0x00056174 File Offset: 0x00054374
		private void ApplySpecAndJudge(DeformableInspectionToolSpec spec, DeformableInspectionResult result)
		{
			result.Metrics.Clear();
			bool flag = spec == null || !spec.IsEnabled;
			if (flag)
			{
				result.IsSpecEnabled = false;
				result.IsSpecOk = true;
				result.SpecStatus = "OK";
			}
			else
			{
				result.IsSpecEnabled = true;
				bool allOk = true;
				allOk &= this.AddMetric(result, "Max Deformation", result.MaxDeformation, spec.MaxDeformationEnabled, spec.MaxDeformationMin, spec.MaxDeformationMax);
				allOk &= this.AddMetric(result, "Mean Deformation", result.MeanDeformation, spec.MeanDeformationEnabled, spec.MeanDeformationMin, spec.MeanDeformationMax);
				allOk &= this.AddMetric(result, "Defect Area", result.DefectArea, spec.DefectAreaEnabled, spec.DefectAreaMin, spec.DefectAreaMax);
				allOk &= this.AddMetric(result, "Score", result.Score, spec.ScoreEnabled, spec.ScoreMin, spec.ScoreMax);
				result.IsSpecOk = allOk;
				result.SpecStatus = (allOk ? "OK" : "NG");
			}
		}

		// Token: 0x0600126D RID: 4717 RVA: 0x00056288 File Offset: 0x00054488
		private bool AddMetric(DeformableInspectionResult result, string name, double value, bool enabled, double min, double max)
		{
			bool ok = !enabled || (value >= min && value <= max);
			result.Metrics.Add(new DeformableMetricResult
			{
				Name = name,
				Value = value,
				SpecEnabled = enabled,
				SpecMin = min,
				SpecMax = max,
				IsOk = ok,
				Status = ((!enabled) ? "-" : (ok ? "OK" : "NG"))
			});
			return ok;
		}

		// Token: 0x0600126E RID: 4718 RVA: 0x00056318 File Offset: 0x00054518
		public string GetModelFullPath(ToolVision tool)
		{
			bool flag = tool == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				SettingMasterImageService masterService = new SettingMasterImageService();
				string turnSnapFolder = masterService.GetTurnSnapFolder(tool.ParentTurnSnap);
				bool flag2 = string.IsNullOrWhiteSpace(turnSnapFolder);
				if (flag2)
				{
					result = null;
				}
				else
				{
					result = this._pathService.GetModelFullPath(turnSnapFolder, tool);
				}
			}
			return result;
		}

		// Token: 0x0600126F RID: 4719 RVA: 0x00056368 File Offset: 0x00054568
		private HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject grayImage;
			if (flag)
			{
				HOperatorSet.Rgb1ToGray(image, out grayImage);
			}
			else
			{
				HOperatorSet.CopyImage(image, out grayImage);
			}
			return grayImage;
		}

		// Token: 0x06001270 RID: 4720 RVA: 0x000563BC File Offset: 0x000545BC
		private void FindDeformableModel(HObject searchImage, HTuple modelId, DeformableInspectionToolConfig config, HTuple resultType, out HObject imageRectified, out HObject vectorField, out HObject deformedContours, out HTuple score, out HTuple row, out HTuple column)
		{
			HOperatorSet.FindLocalDeformableModel(searchImage, out imageRectified, out vectorField, out deformedContours, modelId, this.DegToRad(config.AngleStart), this.DegToRad(config.AngleExtent), 1, 1, 1, 1, config.MinScore, config.NumMatches, config.MaxOverlap, config.NumLevels, config.Greediness, resultType, new HTuple("deformation_smoothness"), new HTuple((int)Math.Round(config.Smoothness)), out score, out row, out column);
		}

		// Token: 0x06001271 RID: 4721 RVA: 0x0005646C File Offset: 0x0005466C
		private void FindDeformableModelWithLegacyDefaults(HObject searchImage, HTuple modelId, HTuple resultType, out HObject imageRectified, out HObject vectorField, out HObject deformedContours, out HTuple score, out HTuple row, out HTuple column)
		{
			HOperatorSet.FindLocalDeformableModel(searchImage, out imageRectified, out vectorField, out deformedContours, modelId, this.DegToRad(-10.0), this.DegToRad(20.0), 1, 1, 1, 1, 0.5, 1, 0.5, 0, 0.5, resultType, new HTuple("deformation_smoothness"), new HTuple(19), out score, out row, out column);
		}

		// Token: 0x06001272 RID: 4722 RVA: 0x00056518 File Offset: 0x00054718
		private bool IsLegacyDefaultSearch(DeformableInspectionToolConfig config)
		{
			bool flag = config == null;
			return !flag && (this.AreClose(config.AngleStart, -10.0) && this.AreClose(config.AngleExtent, 20.0) && this.AreClose(config.MinScore, 0.5) && config.NumMatches == 1 && this.AreClose(config.MaxOverlap, 0.5) && config.NumLevels == 0 && this.AreClose(config.Greediness, 0.5)) && this.AreClose(config.Smoothness, 19.0);
		}

		// Token: 0x06001273 RID: 4723 RVA: 0x000565D8 File Offset: 0x000547D8
		private bool AreClose(double left, double right)
		{
			return Math.Abs(left - right) < 1E-06;
		}

		// Token: 0x06001274 RID: 4724 RVA: 0x00056600 File Offset: 0x00054800
		private double DegToRad(double degrees)
		{
			return degrees * 3.141592653589793 / 180.0;
		}

		// Token: 0x040007A7 RID: 1959
		private readonly DeformableInspectionPathService _pathService = new DeformableInspectionPathService();

		// Token: 0x040007A8 RID: 1960
		private readonly ShapeModelRoiImageService _roiImageService = new ShapeModelRoiImageService();
	}
}
