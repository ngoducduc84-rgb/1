﻿using System;
using System.Collections.Generic;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x0200015B RID: 347
	public class DeformableInspectionResult
	{
		// Token: 0x170006A8 RID: 1704
		// (get) Token: 0x06001285 RID: 4741 RVA: 0x000566BD File Offset: 0x000548BD
		// (set) Token: 0x06001286 RID: 4742 RVA: 0x000566C5 File Offset: 0x000548C5
		public bool IsSuccess { get; set; }

		// Token: 0x170006A9 RID: 1705
		// (get) Token: 0x06001287 RID: 4743 RVA: 0x000566CE File Offset: 0x000548CE
		// (set) Token: 0x06001288 RID: 4744 RVA: 0x000566D6 File Offset: 0x000548D6
		public string Message { get; set; }

		// Token: 0x170006AA RID: 1706
		// (get) Token: 0x06001289 RID: 4745 RVA: 0x000566DF File Offset: 0x000548DF
		// (set) Token: 0x0600128A RID: 4746 RVA: 0x000566E7 File Offset: 0x000548E7
		public double Score { get; set; }

		// Token: 0x170006AB RID: 1707
		// (get) Token: 0x0600128B RID: 4747 RVA: 0x000566F0 File Offset: 0x000548F0
		// (set) Token: 0x0600128C RID: 4748 RVA: 0x000566F8 File Offset: 0x000548F8
		public double Row { get; set; }

		// Token: 0x170006AC RID: 1708
		// (get) Token: 0x0600128D RID: 4749 RVA: 0x00056701 File Offset: 0x00054901
		// (set) Token: 0x0600128E RID: 4750 RVA: 0x00056709 File Offset: 0x00054909
		public double Column { get; set; }

		// Token: 0x170006AD RID: 1709
		// (get) Token: 0x0600128F RID: 4751 RVA: 0x00056712 File Offset: 0x00054912
		// (set) Token: 0x06001290 RID: 4752 RVA: 0x0005671A File Offset: 0x0005491A
		public double MaxDeformation { get; set; }

		// Token: 0x170006AE RID: 1710
		// (get) Token: 0x06001291 RID: 4753 RVA: 0x00056723 File Offset: 0x00054923
		// (set) Token: 0x06001292 RID: 4754 RVA: 0x0005672B File Offset: 0x0005492B
		public double MeanDeformation { get; set; }

		// Token: 0x170006AF RID: 1711
		// (get) Token: 0x06001293 RID: 4755 RVA: 0x00056734 File Offset: 0x00054934
		// (set) Token: 0x06001294 RID: 4756 RVA: 0x0005673C File Offset: 0x0005493C
		public double DefectArea { get; set; }

		// Token: 0x170006B0 RID: 1712
		// (get) Token: 0x06001295 RID: 4757 RVA: 0x00056745 File Offset: 0x00054945
		// (set) Token: 0x06001296 RID: 4758 RVA: 0x0005674D File Offset: 0x0005494D
		public bool IsSpecEnabled { get; set; }

		// Token: 0x170006B1 RID: 1713
		// (get) Token: 0x06001297 RID: 4759 RVA: 0x00056756 File Offset: 0x00054956
		// (set) Token: 0x06001298 RID: 4760 RVA: 0x0005675E File Offset: 0x0005495E
		public bool IsSpecOk { get; set; }

		// Token: 0x170006B2 RID: 1714
		// (get) Token: 0x06001299 RID: 4761 RVA: 0x00056767 File Offset: 0x00054967
		// (set) Token: 0x0600129A RID: 4762 RVA: 0x0005676F File Offset: 0x0005496F
		public string SpecStatus { get; set; }

		// Token: 0x170006B3 RID: 1715
		// (get) Token: 0x0600129B RID: 4763 RVA: 0x00056778 File Offset: 0x00054978
		public List<DeformableMetricResult> Metrics { get; } = new List<DeformableMetricResult>();

		// Token: 0x170006B4 RID: 1716
		// (get) Token: 0x0600129C RID: 4764 RVA: 0x00056780 File Offset: 0x00054980
		public List<double[]> ContourRows { get; } = new List<double[]>();

		// Token: 0x170006B5 RID: 1717
		// (get) Token: 0x0600129D RID: 4765 RVA: 0x00056788 File Offset: 0x00054988
		public List<double[]> ContourColumns { get; } = new List<double[]>();

		// Token: 0x170006B6 RID: 1718
		// (get) Token: 0x0600129E RID: 4766 RVA: 0x00056790 File Offset: 0x00054990
		public List<double[]> DefectContourRows { get; } = new List<double[]>();

		// Token: 0x170006B7 RID: 1719
		// (get) Token: 0x0600129F RID: 4767 RVA: 0x00056798 File Offset: 0x00054998
		public List<double[]> DefectContourColumns { get; } = new List<double[]>();

		// Token: 0x170006B8 RID: 1720
		// (get) Token: 0x060012A0 RID: 4768 RVA: 0x000567A0 File Offset: 0x000549A0
		public List<double[]> MeshRows { get; } = new List<double[]>();

		// Token: 0x170006B9 RID: 1721
		// (get) Token: 0x060012A1 RID: 4769 RVA: 0x000567A8 File Offset: 0x000549A8
		public List<double[]> MeshColumns { get; } = new List<double[]>();

		// Token: 0x170006BA RID: 1722
		// (get) Token: 0x060012A2 RID: 4770 RVA: 0x000567B0 File Offset: 0x000549B0
		// (set) Token: 0x060012A3 RID: 4771 RVA: 0x000567B8 File Offset: 0x000549B8
		public double ProcessingTimeMs { get; set; }

		// Token: 0x170006BB RID: 1723
		// (get) Token: 0x060012A4 RID: 4772 RVA: 0x000567C1 File Offset: 0x000549C1
		// (set) Token: 0x060012A5 RID: 4773 RVA: 0x000567C9 File Offset: 0x000549C9
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x170006BC RID: 1724
		// (get) Token: 0x060012A6 RID: 4774 RVA: 0x000567D2 File Offset: 0x000549D2
		// (set) Token: 0x060012A7 RID: 4775 RVA: 0x000567DA File Offset: 0x000549DA
		public string InputSourceToolName { get; set; }

		// Token: 0x170006BD RID: 1725
		// (get) Token: 0x060012A8 RID: 4776 RVA: 0x000567E3 File Offset: 0x000549E3
		// (set) Token: 0x060012A9 RID: 4777 RVA: 0x000567EB File Offset: 0x000549EB
		public double InputProcessingTimeMs { get; set; }
	}
}
