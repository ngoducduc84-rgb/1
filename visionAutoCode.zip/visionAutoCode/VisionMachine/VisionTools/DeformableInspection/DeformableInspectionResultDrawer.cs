﻿using System;
using System.Collections.Generic;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x0200015C RID: 348
	public class DeformableInspectionResultDrawer
	{
		// Token: 0x060012AB RID: 4779 RVA: 0x00056858 File Offset: 0x00054A58
		public void Draw(HWindow window, ToolVision tool, DeformableInspectionResult result)
		{
			bool flag = window == null || tool == null || result == null;
			if (!flag)
			{
				DeformableInspectionToolConfig config = tool.Config as DeformableInspectionToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					bool showRoi = config.ShowRoi;
					if (showRoi)
					{
						ToolRoiOverlayDrawer.DrawRoiList(window, tool, tool.RoiItems, "cyan", 2);
					}
					bool showLimitRoi = config.ShowLimitRoi;
					if (showLimitRoi)
					{
						ToolRoiOverlayDrawer.DrawRoiList(window, tool, tool.LimitRoiItems, "magenta", 2);
					}
					bool flag3 = !result.IsSuccess;
					if (!flag3)
					{
						bool showContours = config.ShowContours;
						if (showContours)
						{
							this.DrawContours(window, result.ContourRows, result.ContourColumns, string.IsNullOrWhiteSpace(config.ContourColor) ? "green" : config.ContourColor, 2);
						}
						bool showWarpedMesh = config.ShowWarpedMesh;
						if (showWarpedMesh)
						{
							this.DrawContours(window, result.MeshRows, result.MeshColumns, string.IsNullOrWhiteSpace(config.MeshColor) ? "yellow" : config.MeshColor, (config.MeshLineWidth < 1) ? 1 : config.MeshLineWidth);
						}
						bool showText = config.ShowText;
						if (showText)
						{
							this.DrawText(window, tool, result, config);
						}
					}
				}
			}
		}

		// Token: 0x060012AC RID: 4780 RVA: 0x0005698C File Offset: 0x00054B8C
		private void DrawContours(HWindow window, List<double[]> rows, List<double[]> cols, string color, int lineWidth)
		{
			bool flag = rows == null || cols == null || rows.Count == 0;
			if (!flag)
			{
				try
				{
					HOperatorSet.SetColor(window, color);
					HOperatorSet.SetLineWidth(window, lineWidth);
				}
				catch
				{
				}
				int i = 0;
				while (i < rows.Count && i < cols.Count)
				{
					double[] r = rows[i];
					double[] c = cols[i];
					bool flag2 = r == null || c == null || r.Length < 2 || r.Length != c.Length;
					if (!flag2)
					{
						HObject contour = null;
						try
						{
							HOperatorSet.GenContourPolygonXld(out contour, new HTuple(r), new HTuple(c));
							HOperatorSet.DispObj(contour, window);
						}
						catch
						{
						}
						finally
						{
							if (contour != null)
							{
								contour.Dispose();
							}
						}
					}
					i++;
				}
			}
		}

		// Token: 0x060012AD RID: 4781 RVA: 0x00056AA8 File Offset: 0x00054CA8
		private void DrawText(HWindow window, ToolVision tool, DeformableInspectionResult result, DeformableInspectionToolConfig config)
		{
			string color = string.IsNullOrWhiteSpace(config.TextColor) ? "lime" : config.TextColor;
			string status = result.IsSpecEnabled ? result.SpecStatus : "OK";
			string statusColor = string.Equals(status, "NG", StringComparison.OrdinalIgnoreCase) ? "red" : color;
			string text = string.Concat(new string[]
			{
				tool.Name ?? "Deformable",
				": ",
				status,
				"\nScore: ",
				result.Score.ToString("0.000"),
				"\nMax Def: ",
				result.MaxDeformation.ToString("0.00"),
				" px\nMean Def: ",
				result.MeanDeformation.ToString("0.00"),
				" px\nDefect Area: ",
				result.DefectArea.ToString("0"),
				" px"
			});
			int row = (int)((result.Row > 0.0) ? result.Row : 24.0);
			int column = (int)((result.Column > 0.0) ? result.Column : 24.0);
			try
			{
				HOperatorSet.SetColor(window, statusColor);
				HOperatorSet.SetTposition(window, row + 18, column + 18);
				HOperatorSet.WriteString(window, text);
			}
			catch
			{
			}
		}
	}
}
