﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x0200015D RID: 349
	public class DeformableInspectionToolConfig : ToolConfigBase
	{
		// Token: 0x170006BE RID: 1726
		// (get) Token: 0x060012AF RID: 4783 RVA: 0x00056C5C File Offset: 0x00054E5C
		// (set) Token: 0x060012B0 RID: 4784 RVA: 0x00056C8C File Offset: 0x00054E8C
		[Browsable(false)]
		public ImageInputLink InputLink
		{
			get
			{
				bool flag = this._inputLink == null;
				if (flag)
				{
					this._inputLink = new ImageInputLink();
				}
				return this._inputLink;
			}
			set
			{
				bool flag = this._inputLink != value;
				if (flag)
				{
					this._inputLink = (value ?? new ImageInputLink());
					base.OnPropertyChanged("InputLink");
				}
			}
		}

		// Token: 0x170006BF RID: 1727
		// (get) Token: 0x060012B1 RID: 4785 RVA: 0x00056CC8 File Offset: 0x00054EC8
		// (set) Token: 0x060012B2 RID: 4786 RVA: 0x00056CD0 File Offset: 0x00054ED0
		[Category("Search")]
		[DisplayName("Angle Start (deg)")]
		public double AngleStart
		{
			get
			{
				return this._angleStart;
			}
			set
			{
				bool flag = this._angleStart != value;
				if (flag)
				{
					this._angleStart = value;
					base.OnPropertyChanged("AngleStart");
				}
			}
		}

		// Token: 0x170006C0 RID: 1728
		// (get) Token: 0x060012B3 RID: 4787 RVA: 0x00056D03 File Offset: 0x00054F03
		// (set) Token: 0x060012B4 RID: 4788 RVA: 0x00056D0C File Offset: 0x00054F0C
		[Category("Search")]
		[DisplayName("Angle Extent (deg)")]
		public double AngleExtent
		{
			get
			{
				return this._angleExtent;
			}
			set
			{
				bool flag = this._angleExtent != value;
				if (flag)
				{
					this._angleExtent = value;
					base.OnPropertyChanged("AngleExtent");
				}
			}
		}

		// Token: 0x170006C1 RID: 1729
		// (get) Token: 0x060012B5 RID: 4789 RVA: 0x00056D3F File Offset: 0x00054F3F
		// (set) Token: 0x060012B6 RID: 4790 RVA: 0x00056D48 File Offset: 0x00054F48
		[Category("Search")]
		[DisplayName("Min Score")]
		public double MinScore
		{
			get
			{
				return this._minScore;
			}
			set
			{
				bool flag = this._minScore != value;
				if (flag)
				{
					this._minScore = value;
					base.OnPropertyChanged("MinScore");
				}
			}
		}

		// Token: 0x170006C2 RID: 1730
		// (get) Token: 0x060012B7 RID: 4791 RVA: 0x00056D7B File Offset: 0x00054F7B
		// (set) Token: 0x060012B8 RID: 4792 RVA: 0x00056D84 File Offset: 0x00054F84
		[Category("Search")]
		[DisplayName("Num Matches (0 = all)")]
		public int NumMatches
		{
			get
			{
				return this._numMatches;
			}
			set
			{
				bool flag = this._numMatches != value;
				if (flag)
				{
					this._numMatches = value;
					base.OnPropertyChanged("NumMatches");
				}
			}
		}

		// Token: 0x170006C3 RID: 1731
		// (get) Token: 0x060012B9 RID: 4793 RVA: 0x00056DB7 File Offset: 0x00054FB7
		// (set) Token: 0x060012BA RID: 4794 RVA: 0x00056DC0 File Offset: 0x00054FC0
		[Category("Search")]
		[DisplayName("Max Overlap")]
		public double MaxOverlap
		{
			get
			{
				return this._maxOverlap;
			}
			set
			{
				bool flag = this._maxOverlap != value;
				if (flag)
				{
					this._maxOverlap = value;
					base.OnPropertyChanged("MaxOverlap");
				}
			}
		}

		// Token: 0x170006C4 RID: 1732
		// (get) Token: 0x060012BB RID: 4795 RVA: 0x00056DF3 File Offset: 0x00054FF3
		// (set) Token: 0x060012BC RID: 4796 RVA: 0x00056DFC File Offset: 0x00054FFC
		[Category("Search")]
		[DisplayName("Num Levels (0 = auto)")]
		public int NumLevels
		{
			get
			{
				return this._numLevels;
			}
			set
			{
				bool flag = this._numLevels != value;
				if (flag)
				{
					this._numLevels = value;
					base.OnPropertyChanged("NumLevels");
				}
			}
		}

		// Token: 0x170006C5 RID: 1733
		// (get) Token: 0x060012BD RID: 4797 RVA: 0x00056E2F File Offset: 0x0005502F
		// (set) Token: 0x060012BE RID: 4798 RVA: 0x00056E38 File Offset: 0x00055038
		[Category("Search")]
		[DisplayName("Greediness")]
		public double Greediness
		{
			get
			{
				return this._greediness;
			}
			set
			{
				bool flag = this._greediness != value;
				if (flag)
				{
					this._greediness = value;
					base.OnPropertyChanged("Greediness");
				}
			}
		}

		// Token: 0x170006C6 RID: 1734
		// (get) Token: 0x060012BF RID: 4799 RVA: 0x00056E6B File Offset: 0x0005506B
		// (set) Token: 0x060012C0 RID: 4800 RVA: 0x00056E74 File Offset: 0x00055074
		[Category("Search")]
		[DisplayName("Deformation Smoothness")]
		public double Smoothness
		{
			get
			{
				return this._smoothness;
			}
			set
			{
				bool flag = this._smoothness != value;
				if (flag)
				{
					this._smoothness = value;
					base.OnPropertyChanged("Smoothness");
				}
			}
		}

		// Token: 0x170006C7 RID: 1735
		// (get) Token: 0x060012C1 RID: 4801 RVA: 0x00056EA7 File Offset: 0x000550A7
		// (set) Token: 0x060012C2 RID: 4802 RVA: 0x00056EB0 File Offset: 0x000550B0
		[Category("Defect")]
		[DisplayName("Defect Threshold (px)")]
		[Description("Pixels of the deformation magnitude above which a pixel is counted as defect area.")]
		public double DefectThreshold
		{
			get
			{
				return this._defectThreshold;
			}
			set
			{
				bool flag = this._defectThreshold != value;
				if (flag)
				{
					this._defectThreshold = value;
					base.OnPropertyChanged("DefectThreshold");
				}
			}
		}

		// Token: 0x170006C8 RID: 1736
		// (get) Token: 0x060012C3 RID: 4803 RVA: 0x00056EE3 File Offset: 0x000550E3
		// (set) Token: 0x060012C4 RID: 4804 RVA: 0x00056EEC File Offset: 0x000550EC
		[Category("Display")]
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				bool flag = this._showRoi != value;
				if (flag)
				{
					this._showRoi = value;
					base.OnPropertyChanged("ShowRoi");
				}
			}
		}

		// Token: 0x170006C9 RID: 1737
		// (get) Token: 0x060012C5 RID: 4805 RVA: 0x00056F1F File Offset: 0x0005511F
		// (set) Token: 0x060012C6 RID: 4806 RVA: 0x00056F28 File Offset: 0x00055128
		[Category("Display")]
		[DisplayName("Show Limit ROI")]
		public bool ShowLimitRoi
		{
			get
			{
				return this._showLimitRoi;
			}
			set
			{
				bool flag = this._showLimitRoi != value;
				if (flag)
				{
					this._showLimitRoi = value;
					base.OnPropertyChanged("ShowLimitRoi");
				}
			}
		}

		// Token: 0x170006CA RID: 1738
		// (get) Token: 0x060012C7 RID: 4807 RVA: 0x00056F5B File Offset: 0x0005515B
		// (set) Token: 0x060012C8 RID: 4808 RVA: 0x00056F64 File Offset: 0x00055164
		[Category("Display")]
		[DisplayName("Show Contours")]
		public bool ShowContours
		{
			get
			{
				return this._showContours;
			}
			set
			{
				bool flag = this._showContours != value;
				if (flag)
				{
					this._showContours = value;
					base.OnPropertyChanged("ShowContours");
				}
			}
		}

		// Token: 0x170006CB RID: 1739
		// (get) Token: 0x060012C9 RID: 4809 RVA: 0x00056F97 File Offset: 0x00055197
		// (set) Token: 0x060012CA RID: 4810 RVA: 0x00056FA0 File Offset: 0x000551A0
		[Browsable(false)]
		public bool ShowDefectRegion
		{
			get
			{
				return this._showDefectRegion;
			}
			set
			{
				bool flag = this._showDefectRegion != value;
				if (flag)
				{
					this._showDefectRegion = value;
					base.OnPropertyChanged("ShowDefectRegion");
				}
			}
		}

		// Token: 0x170006CC RID: 1740
		// (get) Token: 0x060012CB RID: 4811 RVA: 0x00056FD3 File Offset: 0x000551D3
		// (set) Token: 0x060012CC RID: 4812 RVA: 0x00056FDC File Offset: 0x000551DC
		[Category("Display")]
		[DisplayName("Show Warped Mesh")]
		public bool ShowWarpedMesh
		{
			get
			{
				return this._showWarpedMesh;
			}
			set
			{
				bool flag = this._showWarpedMesh != value;
				if (flag)
				{
					this._showWarpedMesh = value;
					base.OnPropertyChanged("ShowWarpedMesh");
				}
			}
		}

		// Token: 0x170006CD RID: 1741
		// (get) Token: 0x060012CD RID: 4813 RVA: 0x0005700F File Offset: 0x0005520F
		// (set) Token: 0x060012CE RID: 4814 RVA: 0x00057018 File Offset: 0x00055218
		[Category("Display")]
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				bool flag = this._showText != value;
				if (flag)
				{
					this._showText = value;
					base.OnPropertyChanged("ShowText");
				}
			}
		}

		// Token: 0x170006CE RID: 1742
		// (get) Token: 0x060012CF RID: 4815 RVA: 0x0005704B File Offset: 0x0005524B
		// (set) Token: 0x060012D0 RID: 4816 RVA: 0x00057054 File Offset: 0x00055254
		[Category("Display")]
		[DisplayName("Text Color")]
		public string TextColor
		{
			get
			{
				return this._textColor;
			}
			set
			{
				bool flag = this._textColor != value;
				if (flag)
				{
					this._textColor = value;
					base.OnPropertyChanged("TextColor");
				}
			}
		}

		// Token: 0x170006CF RID: 1743
		// (get) Token: 0x060012D1 RID: 4817 RVA: 0x00057087 File Offset: 0x00055287
		// (set) Token: 0x060012D2 RID: 4818 RVA: 0x00057090 File Offset: 0x00055290
		[Category("Display")]
		[DisplayName("Text Size")]
		public int TextSize
		{
			get
			{
				return this._textSize;
			}
			set
			{
				bool flag = this._textSize != value;
				if (flag)
				{
					this._textSize = value;
					base.OnPropertyChanged("TextSize");
				}
			}
		}

		// Token: 0x170006D0 RID: 1744
		// (get) Token: 0x060012D3 RID: 4819 RVA: 0x000570C3 File Offset: 0x000552C3
		// (set) Token: 0x060012D4 RID: 4820 RVA: 0x000570CC File Offset: 0x000552CC
		[Category("Display")]
		[DisplayName("Contour Color")]
		public string ContourColor
		{
			get
			{
				return this._contourColor;
			}
			set
			{
				bool flag = this._contourColor != value;
				if (flag)
				{
					this._contourColor = value;
					base.OnPropertyChanged("ContourColor");
				}
			}
		}

		// Token: 0x170006D1 RID: 1745
		// (get) Token: 0x060012D5 RID: 4821 RVA: 0x000570FF File Offset: 0x000552FF
		// (set) Token: 0x060012D6 RID: 4822 RVA: 0x00057108 File Offset: 0x00055308
		[Category("Display")]
		[DisplayName("Defect Color")]
		public string DefectColor
		{
			get
			{
				return this._defectColor;
			}
			set
			{
				bool flag = this._defectColor != value;
				if (flag)
				{
					this._defectColor = value;
					base.OnPropertyChanged("DefectColor");
				}
			}
		}

		// Token: 0x170006D2 RID: 1746
		// (get) Token: 0x060012D7 RID: 4823 RVA: 0x0005713B File Offset: 0x0005533B
		// (set) Token: 0x060012D8 RID: 4824 RVA: 0x00057144 File Offset: 0x00055344
		[Category("Display")]
		[DisplayName("Mesh Color")]
		public string MeshColor
		{
			get
			{
				return this._meshColor;
			}
			set
			{
				bool flag = this._meshColor != value;
				if (flag)
				{
					this._meshColor = value;
					base.OnPropertyChanged("MeshColor");
				}
			}
		}

		// Token: 0x170006D3 RID: 1747
		// (get) Token: 0x060012D9 RID: 4825 RVA: 0x00057177 File Offset: 0x00055377
		// (set) Token: 0x060012DA RID: 4826 RVA: 0x00057180 File Offset: 0x00055380
		[Category("Display")]
		[DisplayName("Mesh Line Width")]
		public int MeshLineWidth
		{
			get
			{
				return this._meshLineWidth;
			}
			set
			{
				int normalized = (value < 1) ? 1 : value;
				bool flag = this._meshLineWidth != normalized;
				if (flag)
				{
					this._meshLineWidth = normalized;
					base.OnPropertyChanged("MeshLineWidth");
				}
			}
		}

		// Token: 0x170006D4 RID: 1748
		// (get) Token: 0x060012DB RID: 4827 RVA: 0x000571BC File Offset: 0x000553BC
		// (set) Token: 0x060012DC RID: 4828 RVA: 0x000571C4 File Offset: 0x000553C4
		[Category("Display")]
		[DisplayName("Mesh Spacing")]
		public int MeshSpacing
		{
			get
			{
				return this._meshSpacing;
			}
			set
			{
				int normalized = (value < 4) ? 4 : value;
				bool flag = this._meshSpacing != normalized;
				if (flag)
				{
					this._meshSpacing = normalized;
					base.OnPropertyChanged("MeshSpacing");
				}
			}
		}

		// Token: 0x040007C6 RID: 1990
		private double _angleStart = -10.0;

		// Token: 0x040007C7 RID: 1991
		private double _angleExtent = 20.0;

		// Token: 0x040007C8 RID: 1992
		private double _minScore = 0.5;

		// Token: 0x040007C9 RID: 1993
		private int _numMatches = 1;

		// Token: 0x040007CA RID: 1994
		private double _maxOverlap = 0.5;

		// Token: 0x040007CB RID: 1995
		private int _numLevels = 0;

		// Token: 0x040007CC RID: 1996
		private double _greediness = 0.5;

		// Token: 0x040007CD RID: 1997
		private double _smoothness = 19.0;

		// Token: 0x040007CE RID: 1998
		private double _defectThreshold = 3.0;

		// Token: 0x040007CF RID: 1999
		private ImageInputLink _inputLink = new ImageInputLink();

		// Token: 0x040007D0 RID: 2000
		private bool _showRoi = false;

		// Token: 0x040007D1 RID: 2001
		private bool _showLimitRoi = false;

		// Token: 0x040007D2 RID: 2002
		private bool _showContours = true;

		// Token: 0x040007D3 RID: 2003
		private bool _showDefectRegion = false;

		// Token: 0x040007D4 RID: 2004
		private bool _showWarpedMesh = false;

		// Token: 0x040007D5 RID: 2005
		private bool _showText = true;

		// Token: 0x040007D6 RID: 2006
		private string _textColor = "lime";

		// Token: 0x040007D7 RID: 2007
		private int _textSize = 16;

		// Token: 0x040007D8 RID: 2008
		private string _contourColor = "green";

		// Token: 0x040007D9 RID: 2009
		private string _defectColor = "red";

		// Token: 0x040007DA RID: 2010
		private string _meshColor = "yellow";

		// Token: 0x040007DB RID: 2011
		private int _meshLineWidth = 1;

		// Token: 0x040007DC RID: 2012
		private int _meshSpacing = 19;
	}
}
