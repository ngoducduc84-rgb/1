﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x0200015E RID: 350
	public class DeformableInspectionToolSpec : ToolSpecBase
	{
		// Token: 0x170006D5 RID: 1749
		// (get) Token: 0x060012DE RID: 4830 RVA: 0x00057303 File Offset: 0x00055503
		// (set) Token: 0x060012DF RID: 4831 RVA: 0x0005730C File Offset: 0x0005550C
		[Category("Max Deformation")]
		[DisplayName("Check Max Deformation")]
		public bool MaxDeformationEnabled
		{
			get
			{
				return this._maxDeformationEnabled;
			}
			set
			{
				bool flag = this._maxDeformationEnabled != value;
				if (flag)
				{
					this._maxDeformationEnabled = value;
					base.OnPropertyChanged("MaxDeformationEnabled");
				}
			}
		}

		// Token: 0x170006D6 RID: 1750
		// (get) Token: 0x060012E0 RID: 4832 RVA: 0x0005733F File Offset: 0x0005553F
		// (set) Token: 0x060012E1 RID: 4833 RVA: 0x00057348 File Offset: 0x00055548
		[Category("Max Deformation")]
		[DisplayName("Max Deformation Min (px)")]
		public double MaxDeformationMin
		{
			get
			{
				return this._maxDeformationMin;
			}
			set
			{
				bool flag = this._maxDeformationMin != value;
				if (flag)
				{
					this._maxDeformationMin = value;
					base.OnPropertyChanged("MaxDeformationMin");
				}
			}
		}

		// Token: 0x170006D7 RID: 1751
		// (get) Token: 0x060012E2 RID: 4834 RVA: 0x0005737B File Offset: 0x0005557B
		// (set) Token: 0x060012E3 RID: 4835 RVA: 0x00057384 File Offset: 0x00055584
		[Category("Max Deformation")]
		[DisplayName("Max Deformation Max (px)")]
		public double MaxDeformationMax
		{
			get
			{
				return this._maxDeformationMax;
			}
			set
			{
				bool flag = this._maxDeformationMax != value;
				if (flag)
				{
					this._maxDeformationMax = value;
					base.OnPropertyChanged("MaxDeformationMax");
				}
			}
		}

		// Token: 0x170006D8 RID: 1752
		// (get) Token: 0x060012E4 RID: 4836 RVA: 0x000573B7 File Offset: 0x000555B7
		// (set) Token: 0x060012E5 RID: 4837 RVA: 0x000573C0 File Offset: 0x000555C0
		[Category("Mean Deformation")]
		[DisplayName("Check Mean Deformation")]
		public bool MeanDeformationEnabled
		{
			get
			{
				return this._meanDeformationEnabled;
			}
			set
			{
				bool flag = this._meanDeformationEnabled != value;
				if (flag)
				{
					this._meanDeformationEnabled = value;
					base.OnPropertyChanged("MeanDeformationEnabled");
				}
			}
		}

		// Token: 0x170006D9 RID: 1753
		// (get) Token: 0x060012E6 RID: 4838 RVA: 0x000573F3 File Offset: 0x000555F3
		// (set) Token: 0x060012E7 RID: 4839 RVA: 0x000573FC File Offset: 0x000555FC
		[Category("Mean Deformation")]
		[DisplayName("Mean Deformation Min (px)")]
		public double MeanDeformationMin
		{
			get
			{
				return this._meanDeformationMin;
			}
			set
			{
				bool flag = this._meanDeformationMin != value;
				if (flag)
				{
					this._meanDeformationMin = value;
					base.OnPropertyChanged("MeanDeformationMin");
				}
			}
		}

		// Token: 0x170006DA RID: 1754
		// (get) Token: 0x060012E8 RID: 4840 RVA: 0x0005742F File Offset: 0x0005562F
		// (set) Token: 0x060012E9 RID: 4841 RVA: 0x00057438 File Offset: 0x00055638
		[Category("Mean Deformation")]
		[DisplayName("Mean Deformation Max (px)")]
		public double MeanDeformationMax
		{
			get
			{
				return this._meanDeformationMax;
			}
			set
			{
				bool flag = this._meanDeformationMax != value;
				if (flag)
				{
					this._meanDeformationMax = value;
					base.OnPropertyChanged("MeanDeformationMax");
				}
			}
		}

		// Token: 0x170006DB RID: 1755
		// (get) Token: 0x060012EA RID: 4842 RVA: 0x0005746B File Offset: 0x0005566B
		// (set) Token: 0x060012EB RID: 4843 RVA: 0x00057474 File Offset: 0x00055674
		[Category("Defect Area")]
		[DisplayName("Check Defect Area")]
		public bool DefectAreaEnabled
		{
			get
			{
				return this._defectAreaEnabled;
			}
			set
			{
				bool flag = this._defectAreaEnabled != value;
				if (flag)
				{
					this._defectAreaEnabled = value;
					base.OnPropertyChanged("DefectAreaEnabled");
				}
			}
		}

		// Token: 0x170006DC RID: 1756
		// (get) Token: 0x060012EC RID: 4844 RVA: 0x000574A7 File Offset: 0x000556A7
		// (set) Token: 0x060012ED RID: 4845 RVA: 0x000574B0 File Offset: 0x000556B0
		[Category("Defect Area")]
		[DisplayName("Defect Area Min (px)")]
		public double DefectAreaMin
		{
			get
			{
				return this._defectAreaMin;
			}
			set
			{
				bool flag = this._defectAreaMin != value;
				if (flag)
				{
					this._defectAreaMin = value;
					base.OnPropertyChanged("DefectAreaMin");
				}
			}
		}

		// Token: 0x170006DD RID: 1757
		// (get) Token: 0x060012EE RID: 4846 RVA: 0x000574E3 File Offset: 0x000556E3
		// (set) Token: 0x060012EF RID: 4847 RVA: 0x000574EC File Offset: 0x000556EC
		[Category("Defect Area")]
		[DisplayName("Defect Area Max (px)")]
		public double DefectAreaMax
		{
			get
			{
				return this._defectAreaMax;
			}
			set
			{
				bool flag = this._defectAreaMax != value;
				if (flag)
				{
					this._defectAreaMax = value;
					base.OnPropertyChanged("DefectAreaMax");
				}
			}
		}

		// Token: 0x170006DE RID: 1758
		// (get) Token: 0x060012F0 RID: 4848 RVA: 0x0005751F File Offset: 0x0005571F
		// (set) Token: 0x060012F1 RID: 4849 RVA: 0x00057528 File Offset: 0x00055728
		[Category("Score")]
		[DisplayName("Check Score")]
		public bool ScoreEnabled
		{
			get
			{
				return this._scoreEnabled;
			}
			set
			{
				bool flag = this._scoreEnabled != value;
				if (flag)
				{
					this._scoreEnabled = value;
					base.OnPropertyChanged("ScoreEnabled");
				}
			}
		}

		// Token: 0x170006DF RID: 1759
		// (get) Token: 0x060012F2 RID: 4850 RVA: 0x0005755B File Offset: 0x0005575B
		// (set) Token: 0x060012F3 RID: 4851 RVA: 0x00057564 File Offset: 0x00055764
		[Category("Score")]
		[DisplayName("Score Min")]
		public double ScoreMin
		{
			get
			{
				return this._scoreMin;
			}
			set
			{
				bool flag = this._scoreMin != value;
				if (flag)
				{
					this._scoreMin = value;
					base.OnPropertyChanged("ScoreMin");
				}
			}
		}

		// Token: 0x170006E0 RID: 1760
		// (get) Token: 0x060012F4 RID: 4852 RVA: 0x00057597 File Offset: 0x00055797
		// (set) Token: 0x060012F5 RID: 4853 RVA: 0x000575A0 File Offset: 0x000557A0
		[Category("Score")]
		[DisplayName("Score Max")]
		public double ScoreMax
		{
			get
			{
				return this._scoreMax;
			}
			set
			{
				bool flag = this._scoreMax != value;
				if (flag)
				{
					this._scoreMax = value;
					base.OnPropertyChanged("ScoreMax");
				}
			}
		}

		// Token: 0x040007DD RID: 2013
		private bool _maxDeformationEnabled = true;

		// Token: 0x040007DE RID: 2014
		private double _maxDeformationMin;

		// Token: 0x040007DF RID: 2015
		private double _maxDeformationMax = 999999.0;

		// Token: 0x040007E0 RID: 2016
		private bool _meanDeformationEnabled = true;

		// Token: 0x040007E1 RID: 2017
		private double _meanDeformationMin;

		// Token: 0x040007E2 RID: 2018
		private double _meanDeformationMax = 999999.0;

		// Token: 0x040007E3 RID: 2019
		private bool _defectAreaEnabled = true;

		// Token: 0x040007E4 RID: 2020
		private double _defectAreaMin;

		// Token: 0x040007E5 RID: 2021
		private double _defectAreaMax = 999999.0;

		// Token: 0x040007E6 RID: 2022
		private bool _scoreEnabled = true;

		// Token: 0x040007E7 RID: 2023
		private double _scoreMin = 0.5;

		// Token: 0x040007E8 RID: 2024
		private double _scoreMax = 1.0;
	}
}
