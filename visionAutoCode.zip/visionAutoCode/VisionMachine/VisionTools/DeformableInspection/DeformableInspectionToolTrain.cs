﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x0200015F RID: 351
	public class DeformableInspectionToolTrain : ToolTrainBase
	{
		// Token: 0x170006E1 RID: 1761
		// (get) Token: 0x060012F7 RID: 4855 RVA: 0x0005764F File Offset: 0x0005584F
		// (set) Token: 0x060012F8 RID: 4856 RVA: 0x00057658 File Offset: 0x00055858
		[Category("Parameter")]
		[DisplayName("Contrast Min")]
		public double ContrastMin
		{
			get
			{
				return this._contrastMin;
			}
			set
			{
				bool flag = this._contrastMin != value;
				if (flag)
				{
					this._contrastMin = value;
					base.OnPropertyChanged("ContrastMin");
				}
			}
		}

		// Token: 0x170006E2 RID: 1762
		// (get) Token: 0x060012F9 RID: 4857 RVA: 0x0005768B File Offset: 0x0005588B
		// (set) Token: 0x060012FA RID: 4858 RVA: 0x00057694 File Offset: 0x00055894
		[Category("Parameter")]
		[DisplayName("Contrast Max")]
		public double ContrastMax
		{
			get
			{
				return this._contrastMax;
			}
			set
			{
				bool flag = this._contrastMax != value;
				if (flag)
				{
					this._contrastMax = value;
					base.OnPropertyChanged("ContrastMax");
				}
			}
		}

		// Token: 0x170006E3 RID: 1763
		// (get) Token: 0x060012FB RID: 4859 RVA: 0x000576C7 File Offset: 0x000558C7
		// (set) Token: 0x060012FC RID: 4860 RVA: 0x000576D0 File Offset: 0x000558D0
		[Category("Model")]
		[DisplayName("Model File")]
		public string ModelFileName
		{
			get
			{
				return this._modelFileName;
			}
			set
			{
				bool flag = this._modelFileName != value;
				if (flag)
				{
					this._modelFileName = value;
					base.OnPropertyChanged("ModelFileName");
				}
			}
		}

		// Token: 0x170006E4 RID: 1764
		// (get) Token: 0x060012FD RID: 4861 RVA: 0x00057703 File Offset: 0x00055903
		// (set) Token: 0x060012FE RID: 4862 RVA: 0x0005770C File Offset: 0x0005590C
		[Category("Model")]
		[DisplayName("Model Path")]
		public string ModelRelativePath
		{
			get
			{
				return this._modelRelativePath;
			}
			set
			{
				bool flag = this._modelRelativePath != value;
				if (flag)
				{
					this._modelRelativePath = value;
					base.OnPropertyChanged("ModelRelativePath");
				}
			}
		}

		// Token: 0x170006E5 RID: 1765
		// (get) Token: 0x060012FF RID: 4863 RVA: 0x0005773F File Offset: 0x0005593F
		// (set) Token: 0x06001300 RID: 4864 RVA: 0x00057748 File Offset: 0x00055948
		[Category("Model")]
		[DisplayName("Trained")]
		public bool IsTrained
		{
			get
			{
				return this._isTrained;
			}
			set
			{
				bool flag = this._isTrained != value;
				if (flag)
				{
					this._isTrained = value;
					base.OnPropertyChanged("IsTrained");
				}
			}
		}

		// Token: 0x040007E9 RID: 2025
		private double _contrastMin = 40.0;

		// Token: 0x040007EA RID: 2026
		private double _contrastMax = 60.0;

		// Token: 0x040007EB RID: 2027
		private string _modelFileName;

		// Token: 0x040007EC RID: 2028
		private string _modelRelativePath;

		// Token: 0x040007ED RID: 2029
		private bool _isTrained;
	}
}
