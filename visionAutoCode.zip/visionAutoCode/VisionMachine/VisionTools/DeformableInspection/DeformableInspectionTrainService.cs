﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Views.Setting.Services;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x02000160 RID: 352
	public class DeformableInspectionTrainService
	{
		// Token: 0x06001302 RID: 4866 RVA: 0x000577A4 File Offset: 0x000559A4
		public void TrainModel(ToolVision tool, HObject inputImage = null)
		{
			bool flag = tool == null || tool.ParentTurnSnap == null;
			if (!flag)
			{
				DeformableInspectionToolConfig config = tool.Config as DeformableInspectionToolConfig;
				DeformableInspectionToolTrain train = tool.TrainModel as DeformableInspectionToolTrain;
				bool flag2 = config == null || train == null;
				if (!flag2)
				{
					SettingMasterImageService masterService = new SettingMasterImageService();
					string turnSnapFolder = masterService.GetTurnSnapFolder(tool.ParentTurnSnap);
					string masterImagePath = masterService.GetMasterImagePath(tool.ParentTurnSnap);
					bool flag3 = string.IsNullOrWhiteSpace(turnSnapFolder);
					if (!flag3)
					{
						bool flag4 = (inputImage == null || !inputImage.IsInitialized()) && (string.IsNullOrWhiteSpace(masterImagePath) || !File.Exists(masterImagePath));
						if (!flag4)
						{
							ObservableCollection<RoiData> roiItems = tool.RoiItems;
							List<RoiData> list;
							if (roiItems == null)
							{
								list = null;
							}
							else
							{
								list = (from r in roiItems
								where r.IsEnabled
								select r).ToList<RoiData>();
							}
							List<RoiData> trainRois = list;
							bool flag5 = trainRois == null || trainRois.Count == 0;
							if (!flag5)
							{
								HObject image = null;
								HObject gray = null;
								HObject masked = null;
								HObject reduce = null;
								HObject modelImage = null;
								HObject modelRegion = null;
								HTuple modelId = null;
								try
								{
									bool flag6 = inputImage != null && inputImage.IsInitialized();
									if (flag6)
									{
										HOperatorSet.CopyImage(inputImage, out image);
									}
									else
									{
										HOperatorSet.ReadImage(out image, masterImagePath);
									}
									gray = this.ConvertToGray(image);
									masked = this._roiImageService.ApplyMaskRois(gray, tool);
									reduce = this._roiImageService.ReduceByRois(masked, trainRois, tool);
									try
									{
										HOperatorSet.InspectShapeModel(reduce, out modelImage, out modelRegion, 1, train.ContrastMax);
										HObject shapeModelPreviewRegion = tool.ShapeModelPreviewRegion;
										if (shapeModelPreviewRegion != null)
										{
											shapeModelPreviewRegion.Dispose();
										}
										tool.ShapeModelPreviewRegion = modelRegion;
										modelRegion = null;
									}
									catch
									{
										if (modelImage != null)
										{
											modelImage.Dispose();
										}
										modelImage = null;
										if (modelRegion != null)
										{
											modelRegion.Dispose();
										}
										modelRegion = null;
									}
									HTuple contrast = (train.ContrastMin > 0.0 && train.ContrastMax > 0.0) ? new HTuple(new int[]
									{
										(int)Math.Round(train.ContrastMin),
										(int)Math.Round(train.ContrastMax)
									}) : new HTuple("auto");
									HOperatorSet.CreateLocalDeformableModel(reduce, "auto", new HTuple(), new HTuple(), "auto", 1, new HTuple(), "auto", 1, new HTuple(), "auto", "none", "use_polarity", contrast, "auto", new HTuple(), new HTuple(), out modelId);
									string modelFullPath = this._pathService.GetModelFullPath(turnSnapFolder, tool);
									HOperatorSet.WriteDeformableModel(modelId, modelFullPath);
									train.ModelFileName = Path.GetFileName(modelFullPath);
									train.ModelRelativePath = this._pathService.GetModelRelativePath(tool);
									train.IsTrained = true;
								}
								finally
								{
									if (image != null)
									{
										image.Dispose();
									}
									if (gray != null)
									{
										gray.Dispose();
									}
									if (masked != null)
									{
										masked.Dispose();
									}
									if (reduce != null)
									{
										reduce.Dispose();
									}
									if (modelImage != null)
									{
										modelImage.Dispose();
									}
									if (modelRegion != null)
									{
										modelRegion.Dispose();
									}
									bool flag7 = modelId != null;
									if (flag7)
									{
										HOperatorSet.ClearDeformableModel(modelId);
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06001303 RID: 4867 RVA: 0x00057B40 File Offset: 0x00055D40
		private HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject grayImage;
			if (flag)
			{
				HOperatorSet.Rgb1ToGray(image, out grayImage);
			}
			else
			{
				HOperatorSet.CopyImage(image, out grayImage);
			}
			return grayImage;
		}

		// Token: 0x040007EE RID: 2030
		private readonly DeformableInspectionPathService _pathService = new DeformableInspectionPathService();

		// Token: 0x040007EF RID: 2031
		private readonly ShapeModelRoiImageService _roiImageService = new ShapeModelRoiImageService();
	}
}
