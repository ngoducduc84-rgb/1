﻿using System;

namespace VisionMachine.VisionTools.DeformableInspection
{
	// Token: 0x0200015A RID: 346
	public class DeformableMetricResult
	{
		// Token: 0x170006A1 RID: 1697
		// (get) Token: 0x06001276 RID: 4726 RVA: 0x00056646 File Offset: 0x00054846
		// (set) Token: 0x06001277 RID: 4727 RVA: 0x0005664E File Offset: 0x0005484E
		public string Name { get; set; }

		// Token: 0x170006A2 RID: 1698
		// (get) Token: 0x06001278 RID: 4728 RVA: 0x00056657 File Offset: 0x00054857
		// (set) Token: 0x06001279 RID: 4729 RVA: 0x0005665F File Offset: 0x0005485F
		public double Value { get; set; }

		// Token: 0x170006A3 RID: 1699
		// (get) Token: 0x0600127A RID: 4730 RVA: 0x00056668 File Offset: 0x00054868
		// (set) Token: 0x0600127B RID: 4731 RVA: 0x00056670 File Offset: 0x00054870
		public double SpecMin { get; set; }

		// Token: 0x170006A4 RID: 1700
		// (get) Token: 0x0600127C RID: 4732 RVA: 0x00056679 File Offset: 0x00054879
		// (set) Token: 0x0600127D RID: 4733 RVA: 0x00056681 File Offset: 0x00054881
		public double SpecMax { get; set; }

		// Token: 0x170006A5 RID: 1701
		// (get) Token: 0x0600127E RID: 4734 RVA: 0x0005668A File Offset: 0x0005488A
		// (set) Token: 0x0600127F RID: 4735 RVA: 0x00056692 File Offset: 0x00054892
		public bool SpecEnabled { get; set; }

		// Token: 0x170006A6 RID: 1702
		// (get) Token: 0x06001280 RID: 4736 RVA: 0x0005669B File Offset: 0x0005489B
		// (set) Token: 0x06001281 RID: 4737 RVA: 0x000566A3 File Offset: 0x000548A3
		public bool IsOk { get; set; }

		// Token: 0x170006A7 RID: 1703
		// (get) Token: 0x06001282 RID: 4738 RVA: 0x000566AC File Offset: 0x000548AC
		// (set) Token: 0x06001283 RID: 4739 RVA: 0x000566B4 File Offset: 0x000548B4
		public string Status { get; set; }
	}
}
