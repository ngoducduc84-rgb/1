﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.DeformableInspection.Views
{
	// Token: 0x02000161 RID: 353
	public partial class DeformableInspection_para : UserControl
	{
		// Token: 0x06001305 RID: 4869 RVA: 0x00057BB1 File Offset: 0x00055DB1
		public DeformableInspection_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06001306 RID: 4870 RVA: 0x00057BC4 File Offset: 0x00055DC4
		private void TrainModel_Click(object sender, RoutedEventArgs e)
		{
			DeformableInspectionParameterPanelViewModel vm = base.DataContext as DeformableInspectionParameterPanelViewModel;
			bool flag = vm != null;
			if (flag)
			{
				Form_setting instance = Form_setting.Instance;
				if (instance != null)
				{
					instance.DeformableInspectionTrain(vm.Tool);
				}
			}
		}

		// Token: 0x06001307 RID: 4871 RVA: 0x00057BFD File Offset: 0x00055DFD
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.DeformableInspectionTrialRun();
			}
		}
	}
}
