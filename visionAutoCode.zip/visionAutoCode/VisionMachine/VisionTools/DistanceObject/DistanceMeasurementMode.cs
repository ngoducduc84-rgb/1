﻿using System;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x02000095 RID: 149
	public enum DistanceMeasurementMode
	{
		// Token: 0x040002F9 RID: 761
		Auto,
		// Token: 0x040002FA RID: 762
		XOnly,
		// Token: 0x040002FB RID: 763
		YOnly,
		// Token: 0x040002FC RID: 764
		XYDistance,
		// Token: 0x040002FD RID: 765
		Perpendicular
	}
}
