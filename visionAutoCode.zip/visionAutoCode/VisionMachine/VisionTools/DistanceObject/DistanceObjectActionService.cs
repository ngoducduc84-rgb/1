﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using DevExpress.Xpf.Core;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x02000096 RID: 150
	public class DistanceObjectActionService : IToolActionService
	{
		// Token: 0x1700027D RID: 637
		// (get) Token: 0x0600074F RID: 1871 RVA: 0x00023720 File Offset: 0x00021920
		public ToolType ToolType
		{
			get
			{
				return ToolType.DistanceObject;
			}
		}

		// Token: 0x06000750 RID: 1872 RVA: 0x00023734 File Offset: 0x00021934
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						ToolActionFeedback.ReportError(context, "No original image is available.");
					}
					else
					{
						DistanceObjectToolConfig config = tool.Config as DistanceObjectToolConfig;
						bool flag3 = config == null;
						if (flag3)
						{
							DXMessageBox.Show("Distance Object config null.");
						}
						else
						{
							bufferStore = new ImageBufferStore();
							ToolProcessContext processContext = new ToolProcessContext
							{
								OriginalImage = original,
								InputImage = original,
								BufferStore = bufferStore
							};
							Dictionary<string, DistanceObjectSourceResult> sourceResultStore = new Dictionary<string, DistanceObjectSourceResult>();
							DistanceObjectSourceResult firstSourceResult = this.RunMeasureSource(processContext, tool, config.Parameter.FirstLineToolName, sourceResultStore);
							DistanceObjectSourceResult secondSourceResult = this.RunMeasureSource(processContext, tool, config.Parameter.SecondLineToolName, sourceResultStore);
							Stopwatch totalStopwatch = Stopwatch.StartNew();
							DistanceObjectResult result = this._processor.Run(tool, firstSourceResult, secondSourceResult);
							totalStopwatch.Stop();
							result.TotalProcessingTimeMs = totalStopwatch.Elapsed.TotalMilliseconds + ((firstSourceResult != null) ? firstSourceResult.ProcessingTimeMs : 0.0) + ((firstSourceResult != secondSourceResult && secondSourceResult != null) ? secondSourceResult.ProcessingTimeMs : 0.0);
							this.UpdateCalibrationRuntimeValues(config, result);
							Action<ToolVision, object> resultReporter = context.ResultReporter;
							if (resultReporter != null)
							{
								resultReporter(tool, result);
							}
							bool flag4 = !result.IsSuccess;
							if (flag4)
							{
								DXMessageBox.Show(result.Message);
							}
							context.DisplayController.DisplayImage(original);
							context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
							{
								this._drawer.Draw(window, tool, result);
							}, result);
							this.DisposeUnusedSourceResults(sourceResultStore);
						}
					}
				}
				catch (Exception ex)
				{
					DXMessageBox.Show("Distance Object trial run failed: " + ex.Message);
				}
				finally
				{
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					if (original != null)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x06000751 RID: 1873 RVA: 0x000239F4 File Offset: 0x00021BF4
		private void UpdateCalibrationRuntimeValues(DistanceObjectToolConfig config, DistanceObjectResult result)
		{
			bool flag = config == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				DistanceObjectCalibrationConfig calibration = config.Calibration;
				calibration.CalibrationPixelDistance = result.Distance;
				calibration.LastMeasuredPixelDistance = result.Distance;
				calibration.LastMeasuredDistanceMm = (result.IsCalibrationApplied ? result.CalibratedDistanceMm : 0.0);
			}
		}

		// Token: 0x06000752 RID: 1874 RVA: 0x00023A5C File Offset: 0x00021C5C
		private DistanceObjectSourceResult RunMeasureSource(ToolProcessContext context, ToolVision distanceTool, string sourceToolName, Dictionary<string, DistanceObjectSourceResult> resultStore)
		{
			bool flag = string.IsNullOrWhiteSpace(sourceToolName);
			DistanceObjectSourceResult result2;
			if (flag)
			{
				result2 = null;
			}
			else
			{
				bool flag2 = resultStore.ContainsKey(sourceToolName);
				if (flag2)
				{
					result2 = resultStore[sourceToolName];
				}
				else
				{
					TurnSnap parentTurnSnap = distanceTool.ParentTurnSnap;
					ToolVision sourceTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != distanceTool).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.FindLine || x.ToolType == ToolType.FindCircle || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.FindBoundingBox || x.ToolType == ToolType.FindMinArea) && x.Name == sourceToolName) : null;
					bool flag3 = sourceTool == null;
					if (flag3)
					{
						result2 = null;
					}
					else
					{
						HObject input = null;
						try
						{
							input = this._pipelineService.BuildInputImageForTool(context, sourceTool);
							bool flag4 = input == null || !input.IsInitialized();
							if (flag4)
							{
								result2 = null;
							}
							else
							{
								DistanceObjectSourceResult result = null;
								bool flag5 = sourceTool.ToolType == ToolType.FindLine;
								if (flag5)
								{
									result = new DistanceObjectSourceResult
									{
										ToolName = sourceTool.Name,
										ToolType = ToolType.FindLine,
										LineResult = new FindLineProcessor().Run(input, sourceTool)
									};
								}
								else
								{
									bool flag6 = sourceTool.ToolType == ToolType.FindCircle;
									if (flag6)
									{
										result = new DistanceObjectSourceResult
										{
											ToolName = sourceTool.Name,
											ToolType = ToolType.FindCircle,
											CircleResult = new FindCircleProcessor().Run(input, sourceTool)
										};
									}
									else
									{
										bool flag7 = sourceTool.ToolType == ToolType.CircleMaster;
										if (flag7)
										{
											CircleMasterResult circleMaster = new CircleMasterProcessor().Match(input, sourceTool);
											result = new DistanceObjectSourceResult
											{
												ToolName = sourceTool.Name,
												ToolType = ToolType.CircleMaster,
												CircleResult = circleMaster.CircleResult
											};
										}
										else
										{
											bool flag8 = sourceTool.ToolType == ToolType.FindBoundingBox;
											if (flag8)
											{
												result = new DistanceObjectSourceResult
												{
													ToolName = sourceTool.Name,
													ToolType = ToolType.FindBoundingBox,
													BoundingBoxResult = new FindBoundingBoxProcessor().Run(input, sourceTool)
												};
											}
											else
											{
												bool flag9 = sourceTool.ToolType == ToolType.FindMinArea;
												if (flag9)
												{
													result = new DistanceObjectSourceResult
													{
														ToolName = sourceTool.Name,
														ToolType = ToolType.FindMinArea,
														MinAreaResult = new FindMinAreaProcessor().Run(input, sourceTool)
													};
												}
											}
										}
									}
								}
								resultStore[sourceToolName] = result;
								result2 = result;
							}
						}
						finally
						{
							if (input != null)
							{
								input.Dispose();
							}
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x06000753 RID: 1875 RVA: 0x00023CDC File Offset: 0x00021EDC
		private void DisposeUnusedSourceResults(Dictionary<string, DistanceObjectSourceResult> resultStore)
		{
			bool flag = resultStore == null;
			if (!flag)
			{
				foreach (DistanceObjectSourceResult item in resultStore.Values)
				{
					if (item != null)
					{
						FindLineResult lineResult = item.LineResult;
						if (lineResult != null)
						{
							lineResult.Dispose();
						}
					}
					if (item != null)
					{
						FindCircleResult circleResult = item.CircleResult;
						if (circleResult != null)
						{
							circleResult.Dispose();
						}
					}
					if (item != null)
					{
						FindMinAreaResult minAreaResult = item.MinAreaResult;
						if (minAreaResult != null)
						{
							minAreaResult.Dispose();
						}
					}
				}
				resultStore.Clear();
			}
		}

		// Token: 0x040002FE RID: 766
		private readonly DistanceObjectProcessor _processor = new DistanceObjectProcessor();

		// Token: 0x040002FF RID: 767
		private readonly DistanceObjectResultDrawer _drawer = new DistanceObjectResultDrawer();

		// Token: 0x04000300 RID: 768
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();
	}
}
