﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x020000A0 RID: 160
	public class DistanceObjectCalibrationConfig : INotifyPropertyChanged
	{
		// Token: 0x170002DE RID: 734
		// (get) Token: 0x06000855 RID: 2133 RVA: 0x00026B18 File Offset: 0x00024D18
		// (set) Token: 0x06000856 RID: 2134 RVA: 0x00026B30 File Offset: 0x00024D30
		[DisplayName("Use Calibration")]
		public bool UseCalibration
		{
			get
			{
				return this._useCalibration;
			}
			set
			{
				bool flag = this._useCalibration != value;
				if (flag)
				{
					this._useCalibration = value;
					this.OnPropertyChanged("UseCalibration");
				}
			}
		}

		// Token: 0x170002DF RID: 735
		// (get) Token: 0x06000857 RID: 2135 RVA: 0x00026B64 File Offset: 0x00024D64
		// (set) Token: 0x06000858 RID: 2136 RVA: 0x00026B7C File Offset: 0x00024D7C
		[DisplayName("Pixel Distance")]
		public double CalibrationPixelDistance
		{
			get
			{
				return this._calibrationPixelDistance;
			}
			set
			{
				bool flag = this._calibrationPixelDistance != value;
				if (flag)
				{
					this._calibrationPixelDistance = value;
					this.OnPropertyChanged("CalibrationPixelDistance");
				}
			}
		}

		// Token: 0x170002E0 RID: 736
		// (get) Token: 0x06000859 RID: 2137 RVA: 0x00026BB0 File Offset: 0x00024DB0
		// (set) Token: 0x0600085A RID: 2138 RVA: 0x00026BC8 File Offset: 0x00024DC8
		[DisplayName("Actual Distance (mm)")]
		public double CalibrationActualDistanceMm
		{
			get
			{
				return this._calibrationActualDistanceMm;
			}
			set
			{
				bool flag = this._calibrationActualDistanceMm != value;
				if (flag)
				{
					this._calibrationActualDistanceMm = value;
					this.OnPropertyChanged("CalibrationActualDistanceMm");
				}
			}
		}

		// Token: 0x170002E1 RID: 737
		// (get) Token: 0x0600085B RID: 2139 RVA: 0x00026BFC File Offset: 0x00024DFC
		// (set) Token: 0x0600085C RID: 2140 RVA: 0x00026C14 File Offset: 0x00024E14
		[DisplayName("1 Pixel (mm)")]
		public double MillimetersPerPixel
		{
			get
			{
				return this._millimetersPerPixel;
			}
			set
			{
				double normalizedValue = (value <= 0.0) ? 1.0 : value;
				bool flag = this._millimetersPerPixel != normalizedValue;
				if (flag)
				{
					this._millimetersPerPixel = normalizedValue;
					this.OnPropertyChanged("MillimetersPerPixel");
				}
			}
		}

		// Token: 0x170002E2 RID: 738
		// (get) Token: 0x0600085D RID: 2141 RVA: 0x00026C60 File Offset: 0x00024E60
		// (set) Token: 0x0600085E RID: 2142 RVA: 0x00026C78 File Offset: 0x00024E78
		[DisplayName("Last Pixel Distance")]
		public double LastMeasuredPixelDistance
		{
			get
			{
				return this._lastMeasuredPixelDistance;
			}
			set
			{
				bool flag = this._lastMeasuredPixelDistance != value;
				if (flag)
				{
					this._lastMeasuredPixelDistance = value;
					this.OnPropertyChanged("LastMeasuredPixelDistance");
				}
			}
		}

		// Token: 0x170002E3 RID: 739
		// (get) Token: 0x0600085F RID: 2143 RVA: 0x00026CAC File Offset: 0x00024EAC
		// (set) Token: 0x06000860 RID: 2144 RVA: 0x00026CC4 File Offset: 0x00024EC4
		[DisplayName("Last Distance (mm)")]
		public double LastMeasuredDistanceMm
		{
			get
			{
				return this._lastMeasuredDistanceMm;
			}
			set
			{
				bool flag = this._lastMeasuredDistanceMm != value;
				if (flag)
				{
					this._lastMeasuredDistanceMm = value;
					this.OnPropertyChanged("LastMeasuredDistanceMm");
				}
			}
		}

		// Token: 0x14000012 RID: 18
		// (add) Token: 0x06000861 RID: 2145 RVA: 0x00026CF8 File Offset: 0x00024EF8
		// (remove) Token: 0x06000862 RID: 2146 RVA: 0x00026D30 File Offset: 0x00024F30
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000863 RID: 2147 RVA: 0x00026D65 File Offset: 0x00024F65
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000357 RID: 855
		private bool _useCalibration;

		// Token: 0x04000358 RID: 856
		private double _calibrationPixelDistance;

		// Token: 0x04000359 RID: 857
		private double _calibrationActualDistanceMm;

		// Token: 0x0400035A RID: 858
		private double _millimetersPerPixel = 1.0;

		// Token: 0x0400035B RID: 859
		private double _lastMeasuredPixelDistance;

		// Token: 0x0400035C RID: 860
		private double _lastMeasuredDistanceMm;
	}
}
