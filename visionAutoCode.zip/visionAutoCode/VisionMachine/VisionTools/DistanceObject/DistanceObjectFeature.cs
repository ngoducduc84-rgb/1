﻿using System;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x02000097 RID: 151
	public enum DistanceObjectFeature
	{
		// Token: 0x04000302 RID: 770
		CenterPoint,
		// Token: 0x04000303 RID: 771
		StartPoint,
		// Token: 0x04000304 RID: 772
		EndPoint,
		// Token: 0x04000305 RID: 773
		MidPoint,
		// Token: 0x04000306 RID: 774
		Line,
		// Token: 0x04000307 RID: 775
		TopLeft,
		// Token: 0x04000308 RID: 776
		TopRight,
		// Token: 0x04000309 RID: 777
		BottomRight,
		// Token: 0x0400030A RID: 778
		BottomLeft
	}
}
