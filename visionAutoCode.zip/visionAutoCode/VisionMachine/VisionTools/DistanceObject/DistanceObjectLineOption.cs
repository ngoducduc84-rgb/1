﻿using System;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x02000098 RID: 152
	public class DistanceObjectLineOption
	{
		// Token: 0x1700027E RID: 638
		// (get) Token: 0x06000755 RID: 1877 RVA: 0x00023DAE File Offset: 0x00021FAE
		// (set) Token: 0x06000756 RID: 1878 RVA: 0x00023DB6 File Offset: 0x00021FB6
		public string ToolName { get; set; }

		// Token: 0x1700027F RID: 639
		// (get) Token: 0x06000757 RID: 1879 RVA: 0x00023DBF File Offset: 0x00021FBF
		// (set) Token: 0x06000758 RID: 1880 RVA: 0x00023DC7 File Offset: 0x00021FC7
		public int Index { get; set; }

		// Token: 0x17000280 RID: 640
		// (get) Token: 0x06000759 RID: 1881 RVA: 0x00023DD0 File Offset: 0x00021FD0
		// (set) Token: 0x0600075A RID: 1882 RVA: 0x00023DD8 File Offset: 0x00021FD8
		public ToolType ToolType { get; set; }

		// Token: 0x17000281 RID: 641
		// (get) Token: 0x0600075B RID: 1883 RVA: 0x00023DE4 File Offset: 0x00021FE4
		public string DisplayText
		{
			get
			{
				return string.Concat(new string[]
				{
					this.Index.ToString(),
					" - ",
					this.ToolName,
					" (",
					this.ToolType.ToString(),
					")"
				});
			}
		}
	}
}
