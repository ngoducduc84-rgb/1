﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x0200009F RID: 159
	public class DistanceObjectParameterConfig : INotifyPropertyChanged
	{
		// Token: 0x170002D4 RID: 724
		// (get) Token: 0x0600083C RID: 2108 RVA: 0x00026724 File Offset: 0x00024924
		// (set) Token: 0x0600083D RID: 2109 RVA: 0x0002673C File Offset: 0x0002493C
		[DisplayName("Is Enabled")]
		public bool IsEnabled
		{
			get
			{
				return this._isEnabled;
			}
			set
			{
				bool flag = this._isEnabled != value;
				if (flag)
				{
					this._isEnabled = value;
					this.OnPropertyChanged("IsEnabled");
				}
			}
		}

		// Token: 0x0600083E RID: 2110 RVA: 0x00026770 File Offset: 0x00024970
		public bool ShouldSerializeIsEnabled()
		{
			return false;
		}

		// Token: 0x170002D5 RID: 725
		// (get) Token: 0x0600083F RID: 2111 RVA: 0x00026784 File Offset: 0x00024984
		// (set) Token: 0x06000840 RID: 2112 RVA: 0x0002679C File Offset: 0x0002499C
		[DisplayName("Object 1")]
		public string FirstLineToolName
		{
			get
			{
				return this._firstLineToolName;
			}
			set
			{
				bool flag = this._firstLineToolName != value;
				if (flag)
				{
					this._firstLineToolName = value;
					this.OnPropertyChanged("FirstLineToolName");
				}
			}
		}

		// Token: 0x170002D6 RID: 726
		// (get) Token: 0x06000841 RID: 2113 RVA: 0x000267D0 File Offset: 0x000249D0
		// (set) Token: 0x06000842 RID: 2114 RVA: 0x000267E8 File Offset: 0x000249E8
		[DisplayName("Object 2")]
		public string SecondLineToolName
		{
			get
			{
				return this._secondLineToolName;
			}
			set
			{
				bool flag = this._secondLineToolName != value;
				if (flag)
				{
					this._secondLineToolName = value;
					this.OnPropertyChanged("SecondLineToolName");
				}
			}
		}

		// Token: 0x170002D7 RID: 727
		// (get) Token: 0x06000843 RID: 2115 RVA: 0x0002681C File Offset: 0x00024A1C
		// (set) Token: 0x06000844 RID: 2116 RVA: 0x00026834 File Offset: 0x00024A34
		[DisplayName("Object 1 Feature")]
		public DistanceObjectFeature FirstFeature
		{
			get
			{
				return this._firstFeature;
			}
			set
			{
				bool flag = this._firstFeature != value;
				if (flag)
				{
					this._firstFeature = value;
					this.OnPropertyChanged("FirstFeature");
				}
			}
		}

		// Token: 0x170002D8 RID: 728
		// (get) Token: 0x06000845 RID: 2117 RVA: 0x00026868 File Offset: 0x00024A68
		// (set) Token: 0x06000846 RID: 2118 RVA: 0x00026880 File Offset: 0x00024A80
		[DisplayName("Object 2 Feature")]
		public DistanceObjectFeature SecondFeature
		{
			get
			{
				return this._secondFeature;
			}
			set
			{
				bool flag = this._secondFeature != value;
				if (flag)
				{
					this._secondFeature = value;
					this.OnPropertyChanged("SecondFeature");
				}
			}
		}

		// Token: 0x170002D9 RID: 729
		// (get) Token: 0x06000847 RID: 2119 RVA: 0x000268B4 File Offset: 0x00024AB4
		// (set) Token: 0x06000848 RID: 2120 RVA: 0x000268CC File Offset: 0x00024ACC
		[DisplayName("Measurement Mode")]
		public DistanceMeasurementMode MeasurementMode
		{
			get
			{
				return this._measurementMode;
			}
			set
			{
				bool flag = this._measurementMode != value;
				if (flag)
				{
					this._measurementMode = value;
					this.OnPropertyChanged("MeasurementMode");
				}
			}
		}

		// Token: 0x170002DA RID: 730
		// (get) Token: 0x06000849 RID: 2121 RVA: 0x00026900 File Offset: 0x00024B00
		// (set) Token: 0x0600084A RID: 2122 RVA: 0x00026918 File Offset: 0x00024B18
		[DisplayName("Show Arrow")]
		public bool ShowArrow
		{
			get
			{
				return this._showArrow;
			}
			set
			{
				bool flag = this._showArrow != value;
				if (flag)
				{
					this._showArrow = value;
					this.OnPropertyChanged("ShowArrow");
				}
			}
		}

		// Token: 0x170002DB RID: 731
		// (get) Token: 0x0600084B RID: 2123 RVA: 0x0002694C File Offset: 0x00024B4C
		// (set) Token: 0x0600084C RID: 2124 RVA: 0x00026964 File Offset: 0x00024B64
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				bool flag = this._showText != value;
				if (flag)
				{
					this._showText = value;
					this.OnPropertyChanged("ShowText");
				}
			}
		}

		// Token: 0x170002DC RID: 732
		// (get) Token: 0x0600084D RID: 2125 RVA: 0x00026998 File Offset: 0x00024B98
		// (set) Token: 0x0600084E RID: 2126 RVA: 0x000269B0 File Offset: 0x00024BB0
		[DisplayName("Text Size")]
		public int TextSize
		{
			get
			{
				return this._textSize;
			}
			set
			{
				int normalizedValue = (value < 1) ? 1 : value;
				bool flag = this._textSize != normalizedValue;
				if (flag)
				{
					this._textSize = normalizedValue;
					this.OnPropertyChanged("TextSize");
				}
			}
		}

		// Token: 0x170002DD RID: 733
		// (get) Token: 0x0600084F RID: 2127 RVA: 0x000269EC File Offset: 0x00024BEC
		// (set) Token: 0x06000850 RID: 2128 RVA: 0x00026A04 File Offset: 0x00024C04
		[DisplayName("Display Color")]
		public string DisplayColor
		{
			get
			{
				return this._displayColor;
			}
			set
			{
				bool flag = this._displayColor != value;
				if (flag)
				{
					this._displayColor = value;
					this.OnPropertyChanged("DisplayColor");
				}
			}
		}

		// Token: 0x14000011 RID: 17
		// (add) Token: 0x06000851 RID: 2129 RVA: 0x00026A38 File Offset: 0x00024C38
		// (remove) Token: 0x06000852 RID: 2130 RVA: 0x00026A70 File Offset: 0x00024C70
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000853 RID: 2131 RVA: 0x00026AA5 File Offset: 0x00024CA5
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x0400034C RID: 844
		private bool _isEnabled = true;

		// Token: 0x0400034D RID: 845
		private string _firstLineToolName;

		// Token: 0x0400034E RID: 846
		private string _secondLineToolName;

		// Token: 0x0400034F RID: 847
		private DistanceObjectFeature _firstFeature = DistanceObjectFeature.MidPoint;

		// Token: 0x04000350 RID: 848
		private DistanceObjectFeature _secondFeature = DistanceObjectFeature.Line;

		// Token: 0x04000351 RID: 849
		private DistanceMeasurementMode _measurementMode = DistanceMeasurementMode.Auto;

		// Token: 0x04000352 RID: 850
		private bool _showArrow = true;

		// Token: 0x04000353 RID: 851
		private bool _showText = true;

		// Token: 0x04000354 RID: 852
		private int _textSize = 14;

		// Token: 0x04000355 RID: 853
		private string _displayColor = "yellow";
	}
}
