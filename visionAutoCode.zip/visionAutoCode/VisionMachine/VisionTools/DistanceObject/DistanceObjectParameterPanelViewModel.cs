﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x02000099 RID: 153
	public class DistanceObjectParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x17000282 RID: 642
		// (get) Token: 0x0600075D RID: 1885 RVA: 0x00023E4A File Offset: 0x0002204A
		// (set) Token: 0x0600075E RID: 1886 RVA: 0x00023E52 File Offset: 0x00022052
		public ToolVision Tool { get; set; }

		// Token: 0x17000283 RID: 643
		// (get) Token: 0x0600075F RID: 1887 RVA: 0x00023E5C File Offset: 0x0002205C
		// (set) Token: 0x06000760 RID: 1888 RVA: 0x00023E74 File Offset: 0x00022074
		public DistanceObjectToolConfig Config
		{
			get
			{
				return this._config;
			}
			set
			{
				bool flag = this._config == value;
				if (!flag)
				{
					this.DetachParameterEvents(this._config);
					this._config = value;
					this.AttachParameterEvents(this._config);
					this.UpdateFeatureOptions();
					this.OnPropertyChanged("Config");
					this.OnPropertyChanged("ParameterConfig");
					this.OnPropertyChanged("CalibrationConfig");
				}
			}
		}

		// Token: 0x17000284 RID: 644
		// (get) Token: 0x06000761 RID: 1889 RVA: 0x00023EDD File Offset: 0x000220DD
		// (set) Token: 0x06000762 RID: 1890 RVA: 0x00023EE5 File Offset: 0x000220E5
		public DistanceObjectToolSpec Spec { get; set; }

		// Token: 0x17000285 RID: 645
		// (get) Token: 0x06000763 RID: 1891 RVA: 0x00023EF0 File Offset: 0x000220F0
		public DistanceObjectParameterConfig ParameterConfig
		{
			get
			{
				DistanceObjectToolConfig config = this.Config;
				return (config != null) ? config.Parameter : null;
			}
		}

		// Token: 0x17000286 RID: 646
		// (get) Token: 0x06000764 RID: 1892 RVA: 0x00023F14 File Offset: 0x00022114
		public DistanceObjectCalibrationConfig CalibrationConfig
		{
			get
			{
				DistanceObjectToolConfig config = this.Config;
				return (config != null) ? config.Calibration : null;
			}
		}

		// Token: 0x17000287 RID: 647
		// (get) Token: 0x06000765 RID: 1893 RVA: 0x00023F38 File Offset: 0x00022138
		public DistanceObjectToolSpec SpecConfig
		{
			get
			{
				return this.Spec;
			}
		}

		// Token: 0x17000288 RID: 648
		// (get) Token: 0x06000766 RID: 1894 RVA: 0x00023F50 File Offset: 0x00022150
		// (set) Token: 0x06000767 RID: 1895 RVA: 0x00023F58 File Offset: 0x00022158
		public ObservableCollection<DistanceObjectLineOption> AvailableFindLineTools { get; set; }

		// Token: 0x17000289 RID: 649
		// (get) Token: 0x06000768 RID: 1896 RVA: 0x00023F61 File Offset: 0x00022161
		public ObservableCollection<DistanceObjectFeature> FirstFeatureOptions { get; } = new ObservableCollection<DistanceObjectFeature>();

		// Token: 0x1700028A RID: 650
		// (get) Token: 0x06000769 RID: 1897 RVA: 0x00023F69 File Offset: 0x00022169
		public ObservableCollection<DistanceObjectFeature> SecondFeatureOptions { get; } = new ObservableCollection<DistanceObjectFeature>();

		// Token: 0x1700028B RID: 651
		// (get) Token: 0x0600076A RID: 1898 RVA: 0x00023F74 File Offset: 0x00022174
		public DistanceMeasurementMode[] MeasurementModes
		{
			get
			{
				return new DistanceMeasurementMode[]
				{
					DistanceMeasurementMode.Auto,
					DistanceMeasurementMode.XOnly,
					DistanceMeasurementMode.YOnly,
					DistanceMeasurementMode.XYDistance,
					DistanceMeasurementMode.Perpendicular
				};
			}
		}

		// Token: 0x1700028C RID: 652
		// (get) Token: 0x0600076B RID: 1899 RVA: 0x00023F98 File Offset: 0x00022198
		// (set) Token: 0x0600076C RID: 1900 RVA: 0x00023FB0 File Offset: 0x000221B0
		public DistanceObjectLineOption SelectedFirstLineTool
		{
			get
			{
				return this._selectedFirstLineTool;
			}
			set
			{
				bool flag = this._selectedFirstLineTool == value;
				if (!flag)
				{
					this._selectedFirstLineTool = value;
					bool flag2 = this.ParameterConfig != null;
					if (flag2)
					{
						this.ParameterConfig.FirstLineToolName = ((value != null) ? value.ToolName : null);
					}
					this.UpdateFeatureOptions();
					this.OnPropertyChanged("SelectedFirstLineTool");
				}
			}
		}

		// Token: 0x1700028D RID: 653
		// (get) Token: 0x0600076D RID: 1901 RVA: 0x0002400C File Offset: 0x0002220C
		// (set) Token: 0x0600076E RID: 1902 RVA: 0x00024024 File Offset: 0x00022224
		public DistanceObjectLineOption SelectedSecondLineTool
		{
			get
			{
				return this._selectedSecondLineTool;
			}
			set
			{
				bool flag = this._selectedSecondLineTool == value;
				if (!flag)
				{
					this._selectedSecondLineTool = value;
					bool flag2 = this.ParameterConfig != null;
					if (flag2)
					{
						this.ParameterConfig.SecondLineToolName = ((value != null) ? value.ToolName : null);
					}
					this.UpdateFeatureOptions();
					this.OnPropertyChanged("SelectedSecondLineTool");
				}
			}
		}

		// Token: 0x14000010 RID: 16
		// (add) Token: 0x0600076F RID: 1903 RVA: 0x00024080 File Offset: 0x00022280
		// (remove) Token: 0x06000770 RID: 1904 RVA: 0x000240B8 File Offset: 0x000222B8
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000771 RID: 1905 RVA: 0x000240F0 File Offset: 0x000222F0
		public void RestoreSelections()
		{
			bool flag = this.ParameterConfig == null || this.AvailableFindLineTools == null;
			if (!flag)
			{
				foreach (DistanceObjectLineOption item in this.AvailableFindLineTools)
				{
					bool flag2 = item.ToolName == this.ParameterConfig.FirstLineToolName;
					if (flag2)
					{
						this.SelectedFirstLineTool = item;
					}
					bool flag3 = item.ToolName == this.ParameterConfig.SecondLineToolName;
					if (flag3)
					{
						this.SelectedSecondLineTool = item;
					}
				}
				this.UpdateFeatureOptions();
			}
		}

		// Token: 0x06000772 RID: 1906 RVA: 0x000241A4 File Offset: 0x000223A4
		private void AttachParameterEvents(DistanceObjectToolConfig config)
		{
			bool flag = ((config != null) ? config.Parameter : null) != null;
			if (flag)
			{
				config.Parameter.PropertyChanged += this.Parameter_PropertyChanged;
			}
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x000241E0 File Offset: 0x000223E0
		private void DetachParameterEvents(DistanceObjectToolConfig config)
		{
			bool flag = ((config != null) ? config.Parameter : null) != null;
			if (flag)
			{
				config.Parameter.PropertyChanged -= this.Parameter_PropertyChanged;
			}
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x0002421C File Offset: 0x0002241C
		private void Parameter_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			bool flag = e.PropertyName == "FirstLineToolName" || e.PropertyName == "SecondLineToolName";
			if (flag)
			{
				this.RestoreSelectedToolObjects();
				this.UpdateFeatureOptions();
			}
		}

		// Token: 0x06000775 RID: 1909 RVA: 0x00024264 File Offset: 0x00022464
		private void RestoreSelectedToolObjects()
		{
			bool flag = this.ParameterConfig == null || this.AvailableFindLineTools == null;
			if (!flag)
			{
				this._selectedFirstLineTool = this.AvailableFindLineTools.FirstOrDefault((DistanceObjectLineOption x) => x.ToolName == this.ParameterConfig.FirstLineToolName);
				this._selectedSecondLineTool = this.AvailableFindLineTools.FirstOrDefault((DistanceObjectLineOption x) => x.ToolName == this.ParameterConfig.SecondLineToolName);
				this.OnPropertyChanged("SelectedFirstLineTool");
				this.OnPropertyChanged("SelectedSecondLineTool");
			}
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x000242E0 File Offset: 0x000224E0
		private void UpdateFeatureOptions()
		{
			bool flag = this.ParameterConfig == null;
			if (!flag)
			{
				this.UpdateFeatureOptionList(this.FirstFeatureOptions, this.GetSelectedToolType(this.ParameterConfig.FirstLineToolName), true);
				this.UpdateFeatureOptionList(this.SecondFeatureOptions, this.GetSelectedToolType(this.ParameterConfig.SecondLineToolName), false);
				this.OnPropertyChanged("FirstFeatureOptions");
				this.OnPropertyChanged("SecondFeatureOptions");
			}
		}

		// Token: 0x06000777 RID: 1911 RVA: 0x00024354 File Offset: 0x00022554
		private ToolType GetSelectedToolType(string toolName)
		{
			bool flag = this.AvailableFindLineTools == null || string.IsNullOrWhiteSpace(toolName);
			ToolType result;
			if (flag)
			{
				result = ToolType.FindLine;
			}
			else
			{
				DistanceObjectLineOption option = this.AvailableFindLineTools.FirstOrDefault((DistanceObjectLineOption x) => x.ToolName == toolName);
				result = ((option == null) ? ToolType.FindLine : option.ToolType);
			}
			return result;
		}

		// Token: 0x06000778 RID: 1912 RVA: 0x000243B8 File Offset: 0x000225B8
		private void UpdateFeatureOptionList(ObservableCollection<DistanceObjectFeature> target, ToolType selectedToolType, bool isFirstObject)
		{
			bool flag = target == null;
			if (!flag)
			{
				target.Clear();
				bool flag2 = selectedToolType == ToolType.FindCircle || selectedToolType == ToolType.CircleMaster;
				DistanceObjectFeature[] options;
				DistanceObjectFeature fallbackFeature;
				if (flag2)
				{
					options = new DistanceObjectFeature[1];
					fallbackFeature = DistanceObjectFeature.CenterPoint;
				}
				else
				{
					bool flag3 = selectedToolType == ToolType.FindBoundingBox || selectedToolType == ToolType.FindMinArea;
					if (flag3)
					{
						options = new DistanceObjectFeature[]
						{
							DistanceObjectFeature.CenterPoint,
							DistanceObjectFeature.TopLeft,
							DistanceObjectFeature.TopRight,
							DistanceObjectFeature.BottomRight,
							DistanceObjectFeature.BottomLeft
						};
						fallbackFeature = DistanceObjectFeature.CenterPoint;
					}
					else
					{
						options = new DistanceObjectFeature[]
						{
							DistanceObjectFeature.StartPoint,
							DistanceObjectFeature.EndPoint,
							DistanceObjectFeature.MidPoint,
							DistanceObjectFeature.Line
						};
						fallbackFeature = DistanceObjectFeature.MidPoint;
					}
				}
				foreach (DistanceObjectFeature option in options)
				{
					target.Add(option);
				}
				DistanceObjectFeature currentFeature = isFirstObject ? this.ParameterConfig.FirstFeature : this.ParameterConfig.SecondFeature;
				bool flag4 = !options.Contains(currentFeature);
				if (flag4)
				{
					if (isFirstObject)
					{
						this.ParameterConfig.FirstFeature = fallbackFeature;
					}
					else
					{
						this.ParameterConfig.SecondFeature = fallbackFeature;
					}
				}
			}
		}

		// Token: 0x06000779 RID: 1913 RVA: 0x000244B2 File Offset: 0x000226B2
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x0400030E RID: 782
		private DistanceObjectToolConfig _config;

		// Token: 0x0400030F RID: 783
		private DistanceObjectLineOption _selectedFirstLineTool;

		// Token: 0x04000310 RID: 784
		private DistanceObjectLineOption _selectedSecondLineTool;
	}
}
