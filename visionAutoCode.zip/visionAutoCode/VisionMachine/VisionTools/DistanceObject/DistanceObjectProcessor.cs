﻿using System;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x0200009A RID: 154
	public class DistanceObjectProcessor
	{
		// Token: 0x0600077D RID: 1917 RVA: 0x00024520 File Offset: 0x00022720
		public DistanceObjectResult Run(ToolVision tool, FindLineResult firstLine, FindLineResult secondLine)
		{
			return this.Run(tool, new DistanceObjectSourceResult
			{
				ToolType = ToolType.FindLine,
				LineResult = firstLine
			}, new DistanceObjectSourceResult
			{
				ToolType = ToolType.FindLine,
				LineResult = secondLine
			});
		}

		// Token: 0x0600077E RID: 1918 RVA: 0x00024564 File Offset: 0x00022764
		public DistanceObjectResult Run(ToolVision tool, DistanceObjectSourceResult firstObject, DistanceObjectSourceResult secondObject)
		{
			DistanceObjectResult result = new DistanceObjectResult();
			DistanceObjectToolConfig config = ((tool != null) ? tool.Config : null) as DistanceObjectToolConfig;
			DistanceObjectToolSpec spec = ((tool != null) ? tool.Spec : null) as DistanceObjectToolSpec;
			bool flag = config == null;
			DistanceObjectResult result2;
			if (flag)
			{
				result.Message = "Distance Object config null.";
				result2 = result;
			}
			else
			{
				bool flag2 = !config.IsEnabled;
				if (flag2)
				{
					result.Message = "Distance Object tool is disabled.";
					result2 = result;
				}
				else
				{
					DistanceObjectParameterConfig parameter = config.Parameter;
					DistanceObjectCalibrationConfig calibration = config.Calibration;
					bool flag3 = firstObject == null || !firstObject.IsSuccess;
					if (flag3)
					{
						result.Message = "Object 1 result is not available.";
						result2 = result;
					}
					else
					{
						bool flag4 = secondObject == null || !secondObject.IsSuccess;
						if (flag4)
						{
							result.Message = "Object 2 result is not available.";
							result2 = result;
						}
						else
						{
							result.Object1ToolName = parameter.FirstLineToolName;
							result.Object2ToolName = parameter.SecondLineToolName;
							result.Object1Feature = parameter.FirstFeature;
							result.Object2Feature = parameter.SecondFeature;
							this.CopySourceGeometry(firstObject, result, true);
							this.CopySourceGeometry(secondObject, result, false);
							result.MeasurementMode = this.ResolveMeasurementMode(parameter.MeasurementMode, firstObject, secondObject, parameter.FirstFeature, parameter.SecondFeature);
							result.Object1ProcessingTimeMs = firstObject.ProcessingTimeMs;
							result.Object2ProcessingTimeMs = ((firstObject == secondObject) ? 0.0 : secondObject.ProcessingTimeMs);
							DistanceObjectProcessor.DistanceGeometry firstGeometry = this.CreateGeometry(firstObject, parameter.FirstFeature);
							DistanceObjectProcessor.DistanceGeometry secondGeometry = this.CreateGeometry(secondObject, parameter.SecondFeature);
							double distance;
							double row;
							double column;
							double row2;
							double column2;
							string message;
							bool flag5 = !this.TryMeasure(firstGeometry, secondGeometry, result.MeasurementMode, out distance, out row, out column, out row2, out column2, out message);
							if (flag5)
							{
								result.Message = message;
								result2 = result;
							}
							else
							{
								result.Distance = distance;
								result.MillimetersPerPixel = calibration.MillimetersPerPixel;
								result.IsCalibrationApplied = (calibration.UseCalibration && calibration.MillimetersPerPixel > 0.0);
								result.CalibratedDistanceMm = (result.IsCalibrationApplied ? (distance * calibration.MillimetersPerPixel) : distance);
								this.ApplySpec(result, spec);
								result.MeasureRow1 = row;
								result.MeasureColumn1 = column;
								result.MeasureRow2 = row2;
								result.MeasureColumn2 = column2;
								result.IsSuccess = true;
								result.Message = (result.IsSpecEnabled ? ("Distance Object " + result.SpecStatus + ".") : "Distance Object OK.");
								result2 = result;
							}
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x0600077F RID: 1919 RVA: 0x000247EC File Offset: 0x000229EC
		private void CopySourceGeometry(DistanceObjectSourceResult source, DistanceObjectResult result, bool isFirstObject)
		{
			bool flag = source == null || !source.IsSuccess;
			if (!flag)
			{
				bool flag2 = source.ToolType == ToolType.FindLine;
				if (flag2)
				{
					this.CopySourceLineGeometry(source.LineResult, result, isFirstObject);
				}
				else
				{
					bool flag3 = source.ToolType == ToolType.FindCircle || source.ToolType == ToolType.CircleMaster;
					if (flag3)
					{
						this.CopySourceCircleGeometry(source.CircleResult, result, isFirstObject);
					}
					else
					{
						bool flag4 = source.ToolType == ToolType.FindBoundingBox;
						if (flag4)
						{
							this.CopySourceBoundingBoxGeometry(source.BoundingBoxResult, result, isFirstObject);
						}
						else
						{
							bool flag5 = source.ToolType == ToolType.FindMinArea;
							if (flag5)
							{
								this.CopySourceMinAreaGeometry(source.MinAreaResult, result, isFirstObject);
							}
						}
					}
				}
			}
		}

		// Token: 0x06000780 RID: 1920 RVA: 0x000248A0 File Offset: 0x00022AA0
		private void CopySourceLineGeometry(FindLineResult line, DistanceObjectResult result, bool isFirstObject)
		{
			bool flag = line == null || result == null || !line.IsSuccess;
			if (!flag)
			{
				if (isFirstObject)
				{
					result.Object1LineFound = true;
					result.Object1LineStartRow = line.StartRow;
					result.Object1LineStartColumn = line.StartColumn;
					result.Object1LineEndRow = line.EndRow;
					result.Object1LineEndColumn = line.EndColumn;
				}
				else
				{
					result.Object2LineFound = true;
					result.Object2LineStartRow = line.StartRow;
					result.Object2LineStartColumn = line.StartColumn;
					result.Object2LineEndRow = line.EndRow;
					result.Object2LineEndColumn = line.EndColumn;
				}
			}
		}

		// Token: 0x06000781 RID: 1921 RVA: 0x0002494C File Offset: 0x00022B4C
		private void CopySourceCircleGeometry(FindCircleResult circle, DistanceObjectResult result, bool isFirstObject)
		{
			bool flag = circle == null || result == null || !circle.IsSuccess;
			if (!flag)
			{
				if (isFirstObject)
				{
					result.Object1CircleFound = true;
					result.Object1CircleRow = circle.Row;
					result.Object1CircleColumn = circle.Column;
					result.Object1CircleRadius = circle.Radius;
				}
				else
				{
					result.Object2CircleFound = true;
					result.Object2CircleRow = circle.Row;
					result.Object2CircleColumn = circle.Column;
					result.Object2CircleRadius = circle.Radius;
				}
			}
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x000249DC File Offset: 0x00022BDC
		private void CopySourceBoundingBoxGeometry(FindBoundingBoxResult box, DistanceObjectResult result, bool isFirstObject)
		{
			bool flag = box == null || result == null || !box.IsSuccess || box.SelectedBox == null;
			if (!flag)
			{
				FindBoundingBoxPointSet points = box.SelectedBox.Points;
				if (isFirstObject)
				{
					result.Object1BoundingBoxResult = box;
					result.Object1CircleFound = true;
					result.Object1CircleRow = points.CenterRow;
					result.Object1CircleColumn = points.CenterColumn;
					result.Object1CircleRadius = 0.0;
				}
				else
				{
					result.Object2BoundingBoxResult = box;
					result.Object2CircleFound = true;
					result.Object2CircleRow = points.CenterRow;
					result.Object2CircleColumn = points.CenterColumn;
					result.Object2CircleRadius = 0.0;
				}
			}
		}

		// Token: 0x06000783 RID: 1923 RVA: 0x00024A98 File Offset: 0x00022C98
		private void CopySourceMinAreaGeometry(FindMinAreaResult minArea, DistanceObjectResult result, bool isFirstObject)
		{
			bool flag = minArea == null || result == null || !minArea.IsSuccess || minArea.SelectedBox == null;
			if (!flag)
			{
				FindMinAreaPointSet points = minArea.SelectedBox.Points;
				if (isFirstObject)
				{
					result.Object1MinAreaResult = minArea;
					result.Object1CircleFound = true;
					result.Object1CircleRow = points.CenterRow;
					result.Object1CircleColumn = points.CenterColumn;
					result.Object1CircleRadius = 0.0;
				}
				else
				{
					result.Object2MinAreaResult = minArea;
					result.Object2CircleFound = true;
					result.Object2CircleRow = points.CenterRow;
					result.Object2CircleColumn = points.CenterColumn;
					result.Object2CircleRadius = 0.0;
				}
			}
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x00024B54 File Offset: 0x00022D54
		private void ApplySpec(DistanceObjectResult result, DistanceObjectToolSpec spec)
		{
			bool flag = result == null || spec == null || !spec.IsEnabled;
			if (flag)
			{
				bool flag2 = result != null;
				if (flag2)
				{
					result.SpecStatus = string.Empty;
				}
			}
			else
			{
				result.IsSpecEnabled = true;
				result.SpecMinimumMm = spec.MinimumSize;
				result.SpecMaximumMm = spec.MaximumSize;
				bool flag3 = !result.IsCalibrationApplied;
				if (flag3)
				{
					result.IsSpecOk = false;
					result.SpecStatus = "No Calib";
				}
				else
				{
					result.IsSpecOk = (result.CalibratedDistanceMm >= spec.MinimumSize && result.CalibratedDistanceMm <= spec.MaximumSize);
					result.SpecStatus = (result.IsSpecOk ? "OK" : "NG");
				}
			}
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x00024C1C File Offset: 0x00022E1C
		private DistanceMeasurementMode ResolveMeasurementMode(DistanceMeasurementMode requestedMode, DistanceObjectSourceResult firstObject, DistanceObjectSourceResult secondObject, DistanceObjectFeature firstFeature, DistanceObjectFeature secondFeature)
		{
			bool flag = requestedMode > DistanceMeasurementMode.Auto;
			DistanceMeasurementMode result;
			if (flag)
			{
				result = requestedMode;
			}
			else
			{
				bool firstIsLine = firstObject != null && firstObject.ToolType == ToolType.FindLine && firstFeature == DistanceObjectFeature.Line;
				bool secondIsLine = secondObject != null && secondObject.ToolType == ToolType.FindLine && secondFeature == DistanceObjectFeature.Line;
				bool flag2 = firstIsLine || secondIsLine;
				if (flag2)
				{
					result = DistanceMeasurementMode.Perpendicular;
				}
				else
				{
					result = DistanceMeasurementMode.XYDistance;
				}
			}
			return result;
		}

		// Token: 0x06000786 RID: 1926 RVA: 0x00024C74 File Offset: 0x00022E74
		private DistanceObjectProcessor.DistanceGeometry CreateGeometry(DistanceObjectSourceResult source, DistanceObjectFeature feature)
		{
			bool flag = source.ToolType == ToolType.FindCircle || source.ToolType == ToolType.CircleMaster;
			DistanceObjectProcessor.DistanceGeometry result;
			if (flag)
			{
				result = this.CreateCircleGeometry(source.CircleResult);
			}
			else
			{
				bool flag2 = source.ToolType == ToolType.FindBoundingBox;
				if (flag2)
				{
					result = this.CreateBoundingBoxGeometry(source.BoundingBoxResult, feature);
				}
				else
				{
					bool flag3 = source.ToolType == ToolType.FindMinArea;
					if (flag3)
					{
						result = this.CreateMinAreaGeometry(source.MinAreaResult, feature);
					}
					else
					{
						result = this.CreateLineGeometry(source.LineResult, feature);
					}
				}
			}
			return result;
		}

		// Token: 0x06000787 RID: 1927 RVA: 0x00024CF8 File Offset: 0x00022EF8
		private DistanceObjectProcessor.DistanceGeometry CreateCircleGeometry(FindCircleResult circle)
		{
			return new DistanceObjectProcessor.DistanceGeometry
			{
				Feature = DistanceObjectFeature.CenterPoint,
				Row = circle.Row,
				Column = circle.Column,
				IsPoint = true
			};
		}

		// Token: 0x06000788 RID: 1928 RVA: 0x00024D3C File Offset: 0x00022F3C
		private DistanceObjectProcessor.DistanceGeometry CreateLineGeometry(FindLineResult line, DistanceObjectFeature feature)
		{
			DistanceObjectProcessor.DistanceGeometry geometry = new DistanceObjectProcessor.DistanceGeometry
			{
				Feature = feature,
				LineRow1 = line.StartRow,
				LineColumn1 = line.StartColumn,
				LineRow2 = line.EndRow,
				LineColumn2 = line.EndColumn
			};
			switch (feature)
			{
			case DistanceObjectFeature.CenterPoint:
			case DistanceObjectFeature.MidPoint:
				geometry.Row = (line.StartRow + line.EndRow) / 2.0;
				geometry.Column = (line.StartColumn + line.EndColumn) / 2.0;
				geometry.IsPoint = true;
				return geometry;
			case DistanceObjectFeature.StartPoint:
				geometry.Row = line.StartRow;
				geometry.Column = line.StartColumn;
				geometry.IsPoint = true;
				return geometry;
			case DistanceObjectFeature.EndPoint:
				geometry.Row = line.EndRow;
				geometry.Column = line.EndColumn;
				geometry.IsPoint = true;
				return geometry;
			}
			geometry.Row = (line.StartRow + line.EndRow) / 2.0;
			geometry.Column = (line.StartColumn + line.EndColumn) / 2.0;
			geometry.IsPoint = false;
			return geometry;
		}

		// Token: 0x06000789 RID: 1929 RVA: 0x00024E8C File Offset: 0x0002308C
		private DistanceObjectProcessor.DistanceGeometry CreateMinAreaGeometry(FindMinAreaResult minArea, DistanceObjectFeature feature)
		{
			FindMinAreaPointSet points = minArea.SelectedBox.Points;
			DistanceObjectProcessor.DistanceGeometry geometry = new DistanceObjectProcessor.DistanceGeometry
			{
				Feature = feature,
				IsPoint = true
			};
			switch (feature)
			{
			case DistanceObjectFeature.TopLeft:
				geometry.Row = points.TopLeftRow;
				geometry.Column = points.TopLeftColumn;
				return geometry;
			case DistanceObjectFeature.TopRight:
				geometry.Row = points.TopRightRow;
				geometry.Column = points.TopRightColumn;
				return geometry;
			case DistanceObjectFeature.BottomRight:
				geometry.Row = points.BottomRightRow;
				geometry.Column = points.BottomRightColumn;
				return geometry;
			case DistanceObjectFeature.BottomLeft:
				geometry.Row = points.BottomLeftRow;
				geometry.Column = points.BottomLeftColumn;
				return geometry;
			}
			geometry.Row = points.CenterRow;
			geometry.Column = points.CenterColumn;
			return geometry;
		}

		// Token: 0x0600078A RID: 1930 RVA: 0x00024F80 File Offset: 0x00023180
		private DistanceObjectProcessor.DistanceGeometry CreateBoundingBoxGeometry(FindBoundingBoxResult box, DistanceObjectFeature feature)
		{
			FindBoundingBoxPointSet points = box.SelectedBox.Points;
			DistanceObjectProcessor.DistanceGeometry geometry = new DistanceObjectProcessor.DistanceGeometry
			{
				Feature = feature,
				IsPoint = true
			};
			switch (feature)
			{
			case DistanceObjectFeature.TopLeft:
				geometry.Row = points.TopLeftRow;
				geometry.Column = points.TopLeftColumn;
				return geometry;
			case DistanceObjectFeature.TopRight:
				geometry.Row = points.TopRightRow;
				geometry.Column = points.TopRightColumn;
				return geometry;
			case DistanceObjectFeature.BottomRight:
				geometry.Row = points.BottomRightRow;
				geometry.Column = points.BottomRightColumn;
				return geometry;
			case DistanceObjectFeature.BottomLeft:
				geometry.Row = points.BottomLeftRow;
				geometry.Column = points.BottomLeftColumn;
				return geometry;
			}
			geometry.Row = points.CenterRow;
			geometry.Column = points.CenterColumn;
			return geometry;
		}

		// Token: 0x0600078B RID: 1931 RVA: 0x00025074 File Offset: 0x00023274
		private bool TryMeasure(DistanceObjectProcessor.DistanceGeometry first, DistanceObjectProcessor.DistanceGeometry second, DistanceMeasurementMode mode, out double distance, out double row1, out double column1, out double row2, out double column2, out string message)
		{
			distance = 0.0;
			row1 = (column1 = (row2 = (column2 = 0.0)));
			message = null;
			bool flag = first.IsPoint && second.IsPoint;
			bool result;
			if (flag)
			{
				row1 = first.Row;
				column1 = first.Column;
				row2 = second.Row;
				column2 = second.Column;
				double deltaRow = row2 - row1;
				double deltaColumn = column2 - column1;
				switch (mode)
				{
				case DistanceMeasurementMode.Auto:
				case DistanceMeasurementMode.XYDistance:
					distance = Math.Sqrt(deltaRow * deltaRow + deltaColumn * deltaColumn);
					break;
				case DistanceMeasurementMode.XOnly:
					distance = Math.Abs(deltaColumn);
					row2 = row1;
					break;
				case DistanceMeasurementMode.YOnly:
					distance = Math.Abs(deltaRow);
					column2 = column1;
					break;
				default:
					message = "The selected measurement mode is not valid for point-to-point measurement.";
					return false;
				}
				result = true;
			}
			else
			{
				bool flag2 = first.IsPoint && !second.IsPoint;
				if (flag2)
				{
					result = this.TryMeasurePointToLine(first.Row, first.Column, second, out distance, out row1, out column1, out row2, out column2, out message);
				}
				else
				{
					bool flag3 = !first.IsPoint && second.IsPoint;
					if (flag3)
					{
						bool ok = this.TryMeasurePointToLine(second.Row, second.Column, first, out distance, out row2, out column2, out row1, out column1, out message);
						result = ok;
					}
					else
					{
						result = this.TryMeasurePointToLine(first.Row, first.Column, second, out distance, out row1, out column1, out row2, out column2, out message);
					}
				}
			}
			return result;
		}

		// Token: 0x0600078C RID: 1932 RVA: 0x0002520C File Offset: 0x0002340C
		private bool TryMeasurePointToLine(double pointRow, double pointColumn, DistanceObjectProcessor.DistanceGeometry line, out double distance, out double row1, out double column1, out double row2, out double column2, out string message)
		{
			distance = 0.0;
			row1 = pointRow;
			column1 = pointColumn;
			row2 = 0.0;
			column2 = 0.0;
			message = null;
			double lineRowDelta = line.LineRow2 - line.LineRow1;
			double lineColumnDelta = line.LineColumn2 - line.LineColumn1;
			double denominator = lineRowDelta * lineRowDelta + lineColumnDelta * lineColumnDelta;
			bool flag = denominator <= 1E-06;
			bool result;
			if (flag)
			{
				message = "The selected line is too short for distance measurement.";
				result = false;
			}
			else
			{
				double t = ((pointRow - line.LineRow1) * lineRowDelta + (pointColumn - line.LineColumn1) * lineColumnDelta) / denominator;
				row2 = line.LineRow1 + t * lineRowDelta;
				column2 = line.LineColumn1 + t * lineColumnDelta;
				double deltaRow = pointRow - row2;
				double deltaColumn = pointColumn - column2;
				distance = Math.Sqrt(deltaRow * deltaRow + deltaColumn * deltaColumn);
				result = true;
			}
			return result;
		}

		// Token: 0x02000317 RID: 791
		private class DistanceGeometry
		{
			// Token: 0x17000B32 RID: 2866
			// (get) Token: 0x0600278F RID: 10127 RVA: 0x000E0978 File Offset: 0x000DEB78
			// (set) Token: 0x06002790 RID: 10128 RVA: 0x000E0980 File Offset: 0x000DEB80
			public DistanceObjectFeature Feature { get; set; }

			// Token: 0x17000B33 RID: 2867
			// (get) Token: 0x06002791 RID: 10129 RVA: 0x000E0989 File Offset: 0x000DEB89
			// (set) Token: 0x06002792 RID: 10130 RVA: 0x000E0991 File Offset: 0x000DEB91
			public bool IsPoint { get; set; }

			// Token: 0x17000B34 RID: 2868
			// (get) Token: 0x06002793 RID: 10131 RVA: 0x000E099A File Offset: 0x000DEB9A
			// (set) Token: 0x06002794 RID: 10132 RVA: 0x000E09A2 File Offset: 0x000DEBA2
			public double Row { get; set; }

			// Token: 0x17000B35 RID: 2869
			// (get) Token: 0x06002795 RID: 10133 RVA: 0x000E09AB File Offset: 0x000DEBAB
			// (set) Token: 0x06002796 RID: 10134 RVA: 0x000E09B3 File Offset: 0x000DEBB3
			public double Column { get; set; }

			// Token: 0x17000B36 RID: 2870
			// (get) Token: 0x06002797 RID: 10135 RVA: 0x000E09BC File Offset: 0x000DEBBC
			// (set) Token: 0x06002798 RID: 10136 RVA: 0x000E09C4 File Offset: 0x000DEBC4
			public double LineRow1 { get; set; }

			// Token: 0x17000B37 RID: 2871
			// (get) Token: 0x06002799 RID: 10137 RVA: 0x000E09CD File Offset: 0x000DEBCD
			// (set) Token: 0x0600279A RID: 10138 RVA: 0x000E09D5 File Offset: 0x000DEBD5
			public double LineColumn1 { get; set; }

			// Token: 0x17000B38 RID: 2872
			// (get) Token: 0x0600279B RID: 10139 RVA: 0x000E09DE File Offset: 0x000DEBDE
			// (set) Token: 0x0600279C RID: 10140 RVA: 0x000E09E6 File Offset: 0x000DEBE6
			public double LineRow2 { get; set; }

			// Token: 0x17000B39 RID: 2873
			// (get) Token: 0x0600279D RID: 10141 RVA: 0x000E09EF File Offset: 0x000DEBEF
			// (set) Token: 0x0600279E RID: 10142 RVA: 0x000E09F7 File Offset: 0x000DEBF7
			public double LineColumn2 { get; set; }
		}
	}
}
