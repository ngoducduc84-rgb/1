﻿using System;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindMinArea;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x0200009B RID: 155
	public class DistanceObjectResult : IDisposable
	{
		// Token: 0x1700028E RID: 654
		// (get) Token: 0x0600078E RID: 1934 RVA: 0x000252EB File Offset: 0x000234EB
		// (set) Token: 0x0600078F RID: 1935 RVA: 0x000252F3 File Offset: 0x000234F3
		public bool IsSuccess { get; set; }

		// Token: 0x1700028F RID: 655
		// (get) Token: 0x06000790 RID: 1936 RVA: 0x000252FC File Offset: 0x000234FC
		// (set) Token: 0x06000791 RID: 1937 RVA: 0x00025304 File Offset: 0x00023504
		public string Message { get; set; }

		// Token: 0x17000290 RID: 656
		// (get) Token: 0x06000792 RID: 1938 RVA: 0x0002530D File Offset: 0x0002350D
		// (set) Token: 0x06000793 RID: 1939 RVA: 0x00025315 File Offset: 0x00023515
		public string Object1ToolName { get; set; }

		// Token: 0x17000291 RID: 657
		// (get) Token: 0x06000794 RID: 1940 RVA: 0x0002531E File Offset: 0x0002351E
		// (set) Token: 0x06000795 RID: 1941 RVA: 0x00025326 File Offset: 0x00023526
		public string Object2ToolName { get; set; }

		// Token: 0x17000292 RID: 658
		// (get) Token: 0x06000796 RID: 1942 RVA: 0x0002532F File Offset: 0x0002352F
		// (set) Token: 0x06000797 RID: 1943 RVA: 0x00025337 File Offset: 0x00023537
		public DistanceObjectFeature Object1Feature { get; set; }

		// Token: 0x17000293 RID: 659
		// (get) Token: 0x06000798 RID: 1944 RVA: 0x00025340 File Offset: 0x00023540
		// (set) Token: 0x06000799 RID: 1945 RVA: 0x00025348 File Offset: 0x00023548
		public DistanceObjectFeature Object2Feature { get; set; }

		// Token: 0x17000294 RID: 660
		// (get) Token: 0x0600079A RID: 1946 RVA: 0x00025351 File Offset: 0x00023551
		// (set) Token: 0x0600079B RID: 1947 RVA: 0x00025359 File Offset: 0x00023559
		public DistanceMeasurementMode MeasurementMode { get; set; }

		// Token: 0x17000295 RID: 661
		// (get) Token: 0x0600079C RID: 1948 RVA: 0x00025362 File Offset: 0x00023562
		// (set) Token: 0x0600079D RID: 1949 RVA: 0x0002536A File Offset: 0x0002356A
		public bool Object1LineFound { get; set; }

		// Token: 0x17000296 RID: 662
		// (get) Token: 0x0600079E RID: 1950 RVA: 0x00025373 File Offset: 0x00023573
		// (set) Token: 0x0600079F RID: 1951 RVA: 0x0002537B File Offset: 0x0002357B
		public double Object1LineStartRow { get; set; }

		// Token: 0x17000297 RID: 663
		// (get) Token: 0x060007A0 RID: 1952 RVA: 0x00025384 File Offset: 0x00023584
		// (set) Token: 0x060007A1 RID: 1953 RVA: 0x0002538C File Offset: 0x0002358C
		public double Object1LineStartColumn { get; set; }

		// Token: 0x17000298 RID: 664
		// (get) Token: 0x060007A2 RID: 1954 RVA: 0x00025395 File Offset: 0x00023595
		// (set) Token: 0x060007A3 RID: 1955 RVA: 0x0002539D File Offset: 0x0002359D
		public double Object1LineEndRow { get; set; }

		// Token: 0x17000299 RID: 665
		// (get) Token: 0x060007A4 RID: 1956 RVA: 0x000253A6 File Offset: 0x000235A6
		// (set) Token: 0x060007A5 RID: 1957 RVA: 0x000253AE File Offset: 0x000235AE
		public double Object1LineEndColumn { get; set; }

		// Token: 0x1700029A RID: 666
		// (get) Token: 0x060007A6 RID: 1958 RVA: 0x000253B7 File Offset: 0x000235B7
		// (set) Token: 0x060007A7 RID: 1959 RVA: 0x000253BF File Offset: 0x000235BF
		public bool Object2LineFound { get; set; }

		// Token: 0x1700029B RID: 667
		// (get) Token: 0x060007A8 RID: 1960 RVA: 0x000253C8 File Offset: 0x000235C8
		// (set) Token: 0x060007A9 RID: 1961 RVA: 0x000253D0 File Offset: 0x000235D0
		public double Object2LineStartRow { get; set; }

		// Token: 0x1700029C RID: 668
		// (get) Token: 0x060007AA RID: 1962 RVA: 0x000253D9 File Offset: 0x000235D9
		// (set) Token: 0x060007AB RID: 1963 RVA: 0x000253E1 File Offset: 0x000235E1
		public double Object2LineStartColumn { get; set; }

		// Token: 0x1700029D RID: 669
		// (get) Token: 0x060007AC RID: 1964 RVA: 0x000253EA File Offset: 0x000235EA
		// (set) Token: 0x060007AD RID: 1965 RVA: 0x000253F2 File Offset: 0x000235F2
		public double Object2LineEndRow { get; set; }

		// Token: 0x1700029E RID: 670
		// (get) Token: 0x060007AE RID: 1966 RVA: 0x000253FB File Offset: 0x000235FB
		// (set) Token: 0x060007AF RID: 1967 RVA: 0x00025403 File Offset: 0x00023603
		public double Object2LineEndColumn { get; set; }

		// Token: 0x1700029F RID: 671
		// (get) Token: 0x060007B0 RID: 1968 RVA: 0x0002540C File Offset: 0x0002360C
		// (set) Token: 0x060007B1 RID: 1969 RVA: 0x00025414 File Offset: 0x00023614
		public bool Object1CircleFound { get; set; }

		// Token: 0x170002A0 RID: 672
		// (get) Token: 0x060007B2 RID: 1970 RVA: 0x0002541D File Offset: 0x0002361D
		// (set) Token: 0x060007B3 RID: 1971 RVA: 0x00025425 File Offset: 0x00023625
		public double Object1CircleRow { get; set; }

		// Token: 0x170002A1 RID: 673
		// (get) Token: 0x060007B4 RID: 1972 RVA: 0x0002542E File Offset: 0x0002362E
		// (set) Token: 0x060007B5 RID: 1973 RVA: 0x00025436 File Offset: 0x00023636
		public double Object1CircleColumn { get; set; }

		// Token: 0x170002A2 RID: 674
		// (get) Token: 0x060007B6 RID: 1974 RVA: 0x0002543F File Offset: 0x0002363F
		// (set) Token: 0x060007B7 RID: 1975 RVA: 0x00025447 File Offset: 0x00023647
		public double Object1CircleRadius { get; set; }

		// Token: 0x170002A3 RID: 675
		// (get) Token: 0x060007B8 RID: 1976 RVA: 0x00025450 File Offset: 0x00023650
		// (set) Token: 0x060007B9 RID: 1977 RVA: 0x00025458 File Offset: 0x00023658
		public bool Object2CircleFound { get; set; }

		// Token: 0x170002A4 RID: 676
		// (get) Token: 0x060007BA RID: 1978 RVA: 0x00025461 File Offset: 0x00023661
		// (set) Token: 0x060007BB RID: 1979 RVA: 0x00025469 File Offset: 0x00023669
		public double Object2CircleRow { get; set; }

		// Token: 0x170002A5 RID: 677
		// (get) Token: 0x060007BC RID: 1980 RVA: 0x00025472 File Offset: 0x00023672
		// (set) Token: 0x060007BD RID: 1981 RVA: 0x0002547A File Offset: 0x0002367A
		public double Object2CircleColumn { get; set; }

		// Token: 0x170002A6 RID: 678
		// (get) Token: 0x060007BE RID: 1982 RVA: 0x00025483 File Offset: 0x00023683
		// (set) Token: 0x060007BF RID: 1983 RVA: 0x0002548B File Offset: 0x0002368B
		public double Object2CircleRadius { get; set; }

		// Token: 0x170002A7 RID: 679
		// (get) Token: 0x060007C0 RID: 1984 RVA: 0x00025494 File Offset: 0x00023694
		// (set) Token: 0x060007C1 RID: 1985 RVA: 0x0002549C File Offset: 0x0002369C
		public FindBoundingBoxResult Object1BoundingBoxResult { get; set; }

		// Token: 0x170002A8 RID: 680
		// (get) Token: 0x060007C2 RID: 1986 RVA: 0x000254A5 File Offset: 0x000236A5
		// (set) Token: 0x060007C3 RID: 1987 RVA: 0x000254AD File Offset: 0x000236AD
		public FindBoundingBoxResult Object2BoundingBoxResult { get; set; }

		// Token: 0x170002A9 RID: 681
		// (get) Token: 0x060007C4 RID: 1988 RVA: 0x000254B6 File Offset: 0x000236B6
		// (set) Token: 0x060007C5 RID: 1989 RVA: 0x000254BE File Offset: 0x000236BE
		public FindMinAreaResult Object1MinAreaResult { get; set; }

		// Token: 0x170002AA RID: 682
		// (get) Token: 0x060007C6 RID: 1990 RVA: 0x000254C7 File Offset: 0x000236C7
		// (set) Token: 0x060007C7 RID: 1991 RVA: 0x000254CF File Offset: 0x000236CF
		public FindMinAreaResult Object2MinAreaResult { get; set; }

		// Token: 0x170002AB RID: 683
		// (get) Token: 0x060007C8 RID: 1992 RVA: 0x000254D8 File Offset: 0x000236D8
		// (set) Token: 0x060007C9 RID: 1993 RVA: 0x000254E0 File Offset: 0x000236E0
		public double Distance { get; set; }

		// Token: 0x170002AC RID: 684
		// (get) Token: 0x060007CA RID: 1994 RVA: 0x000254E9 File Offset: 0x000236E9
		// (set) Token: 0x060007CB RID: 1995 RVA: 0x000254F1 File Offset: 0x000236F1
		public double CalibratedDistanceMm { get; set; }

		// Token: 0x170002AD RID: 685
		// (get) Token: 0x060007CC RID: 1996 RVA: 0x000254FA File Offset: 0x000236FA
		// (set) Token: 0x060007CD RID: 1997 RVA: 0x00025502 File Offset: 0x00023702
		public bool IsCalibrationApplied { get; set; }

		// Token: 0x170002AE RID: 686
		// (get) Token: 0x060007CE RID: 1998 RVA: 0x0002550B File Offset: 0x0002370B
		// (set) Token: 0x060007CF RID: 1999 RVA: 0x00025513 File Offset: 0x00023713
		public double MillimetersPerPixel { get; set; }

		// Token: 0x170002AF RID: 687
		// (get) Token: 0x060007D0 RID: 2000 RVA: 0x0002551C File Offset: 0x0002371C
		// (set) Token: 0x060007D1 RID: 2001 RVA: 0x00025524 File Offset: 0x00023724
		public bool IsSpecEnabled { get; set; }

		// Token: 0x170002B0 RID: 688
		// (get) Token: 0x060007D2 RID: 2002 RVA: 0x0002552D File Offset: 0x0002372D
		// (set) Token: 0x060007D3 RID: 2003 RVA: 0x00025535 File Offset: 0x00023735
		public bool IsSpecOk { get; set; }

		// Token: 0x170002B1 RID: 689
		// (get) Token: 0x060007D4 RID: 2004 RVA: 0x0002553E File Offset: 0x0002373E
		// (set) Token: 0x060007D5 RID: 2005 RVA: 0x00025546 File Offset: 0x00023746
		public string SpecStatus { get; set; }

		// Token: 0x170002B2 RID: 690
		// (get) Token: 0x060007D6 RID: 2006 RVA: 0x0002554F File Offset: 0x0002374F
		// (set) Token: 0x060007D7 RID: 2007 RVA: 0x00025557 File Offset: 0x00023757
		public double SpecMinimumMm { get; set; }

		// Token: 0x170002B3 RID: 691
		// (get) Token: 0x060007D8 RID: 2008 RVA: 0x00025560 File Offset: 0x00023760
		// (set) Token: 0x060007D9 RID: 2009 RVA: 0x00025568 File Offset: 0x00023768
		public double SpecMaximumMm { get; set; }

		// Token: 0x170002B4 RID: 692
		// (get) Token: 0x060007DA RID: 2010 RVA: 0x00025571 File Offset: 0x00023771
		// (set) Token: 0x060007DB RID: 2011 RVA: 0x00025579 File Offset: 0x00023779
		public double MeasureRow1 { get; set; }

		// Token: 0x170002B5 RID: 693
		// (get) Token: 0x060007DC RID: 2012 RVA: 0x00025582 File Offset: 0x00023782
		// (set) Token: 0x060007DD RID: 2013 RVA: 0x0002558A File Offset: 0x0002378A
		public double MeasureColumn1 { get; set; }

		// Token: 0x170002B6 RID: 694
		// (get) Token: 0x060007DE RID: 2014 RVA: 0x00025593 File Offset: 0x00023793
		// (set) Token: 0x060007DF RID: 2015 RVA: 0x0002559B File Offset: 0x0002379B
		public double MeasureRow2 { get; set; }

		// Token: 0x170002B7 RID: 695
		// (get) Token: 0x060007E0 RID: 2016 RVA: 0x000255A4 File Offset: 0x000237A4
		// (set) Token: 0x060007E1 RID: 2017 RVA: 0x000255AC File Offset: 0x000237AC
		public double MeasureColumn2 { get; set; }

		// Token: 0x170002B8 RID: 696
		// (get) Token: 0x060007E2 RID: 2018 RVA: 0x000255B5 File Offset: 0x000237B5
		// (set) Token: 0x060007E3 RID: 2019 RVA: 0x000255BD File Offset: 0x000237BD
		public double Object1ProcessingTimeMs { get; set; }

		// Token: 0x170002B9 RID: 697
		// (get) Token: 0x060007E4 RID: 2020 RVA: 0x000255C6 File Offset: 0x000237C6
		// (set) Token: 0x060007E5 RID: 2021 RVA: 0x000255CE File Offset: 0x000237CE
		public double Object2ProcessingTimeMs { get; set; }

		// Token: 0x170002BA RID: 698
		// (get) Token: 0x060007E6 RID: 2022 RVA: 0x000255D7 File Offset: 0x000237D7
		// (set) Token: 0x060007E7 RID: 2023 RVA: 0x000255DF File Offset: 0x000237DF
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x060007E8 RID: 2024 RVA: 0x000255E8 File Offset: 0x000237E8
		public void Dispose()
		{
			FindBoundingBoxResult object1BoundingBoxResult = this.Object1BoundingBoxResult;
			if (object1BoundingBoxResult != null)
			{
				object1BoundingBoxResult.Dispose();
			}
			FindMinAreaResult object1MinAreaResult = this.Object1MinAreaResult;
			if (object1MinAreaResult != null)
			{
				object1MinAreaResult.Dispose();
			}
			bool flag = this.Object1BoundingBoxResult != this.Object2BoundingBoxResult;
			if (flag)
			{
				FindBoundingBoxResult object2BoundingBoxResult = this.Object2BoundingBoxResult;
				if (object2BoundingBoxResult != null)
				{
					object2BoundingBoxResult.Dispose();
				}
			}
			bool flag2 = this.Object1MinAreaResult != this.Object2MinAreaResult;
			if (flag2)
			{
				FindMinAreaResult object2MinAreaResult = this.Object2MinAreaResult;
				if (object2MinAreaResult != null)
				{
					object2MinAreaResult.Dispose();
				}
			}
		}
	}
}
