﻿using System;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindMinArea;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x0200009C RID: 156
	public class DistanceObjectResultDrawer
	{
		// Token: 0x060007EA RID: 2026 RVA: 0x00025668 File Offset: 0x00023868
		public void Draw(HWindow window, ToolVision tool, DistanceObjectResult result)
		{
			bool flag = window == null || tool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				DistanceObjectToolConfig config = tool.Config as DistanceObjectToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					DistanceObjectParameterConfig parameter = config.Parameter;
					this.DrawSourceBoundingBoxes(window, tool, result);
					this.DrawSourceMinAreas(window, tool, result);
					this.DrawSourceLines(window, result);
					HOperatorSet.SetColor(window, parameter.DisplayColor);
					HOperatorSet.SetLineWidth(window, 2);
					bool showArrow = parameter.ShowArrow;
					if (showArrow)
					{
						this.DrawDoubleArrow(window, result);
					}
					bool showText = parameter.ShowText;
					if (showText)
					{
						this.DrawText(window, tool, parameter, result);
					}
				}
			}
		}

		// Token: 0x060007EB RID: 2027 RVA: 0x00025724 File Offset: 0x00023924
		private void DrawSourceBoundingBoxes(HWindow window, ToolVision distanceTool, DistanceObjectResult result)
		{
			FindBoundingBoxResultDrawer drawer = new FindBoundingBoxResultDrawer();
			this.DrawSourceBoundingBox(window, distanceTool, result.Object1ToolName, result.Object1BoundingBoxResult, drawer);
			bool flag = !string.Equals(result.Object1ToolName, result.Object2ToolName, StringComparison.OrdinalIgnoreCase) || result.Object1BoundingBoxResult != result.Object2BoundingBoxResult;
			if (flag)
			{
				this.DrawSourceBoundingBox(window, distanceTool, result.Object2ToolName, result.Object2BoundingBoxResult, drawer);
			}
		}

		// Token: 0x060007EC RID: 2028 RVA: 0x00025794 File Offset: 0x00023994
		private void DrawSourceBoundingBox(HWindow window, ToolVision distanceTool, string sourceToolName, FindBoundingBoxResult boxResult, FindBoundingBoxResultDrawer drawer)
		{
			bool flag = boxResult == null || !boxResult.IsSuccess || string.IsNullOrWhiteSpace(sourceToolName);
			if (!flag)
			{
				TurnSnap parentTurnSnap = distanceTool.ParentTurnSnap;
				ToolVision sourceTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != distanceTool).FirstOrDefault((ToolVision x) => x.ToolType == ToolType.FindBoundingBox && string.Equals(x.Name, sourceToolName, StringComparison.OrdinalIgnoreCase)) : null;
				bool flag2 = sourceTool == null;
				if (!flag2)
				{
					drawer.Draw(window, sourceTool, boxResult);
				}
			}
		}

		// Token: 0x060007ED RID: 2029 RVA: 0x00025828 File Offset: 0x00023A28
		private void DrawSourceMinAreas(HWindow window, ToolVision distanceTool, DistanceObjectResult result)
		{
			FindMinAreaResultDrawer drawer = new FindMinAreaResultDrawer();
			this.DrawSourceMinArea(window, distanceTool, result.Object1ToolName, result.Object1MinAreaResult, drawer);
			bool flag = !string.Equals(result.Object1ToolName, result.Object2ToolName, StringComparison.OrdinalIgnoreCase) || result.Object1MinAreaResult != result.Object2MinAreaResult;
			if (flag)
			{
				this.DrawSourceMinArea(window, distanceTool, result.Object2ToolName, result.Object2MinAreaResult, drawer);
			}
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x00025898 File Offset: 0x00023A98
		private void DrawSourceMinArea(HWindow window, ToolVision distanceTool, string sourceToolName, FindMinAreaResult minAreaResult, FindMinAreaResultDrawer drawer)
		{
			bool flag = minAreaResult == null || !minAreaResult.IsSuccess || string.IsNullOrWhiteSpace(sourceToolName);
			if (!flag)
			{
				TurnSnap parentTurnSnap = distanceTool.ParentTurnSnap;
				ToolVision sourceTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != distanceTool).FirstOrDefault((ToolVision x) => x.ToolType == ToolType.FindMinArea && string.Equals(x.Name, sourceToolName, StringComparison.OrdinalIgnoreCase)) : null;
				bool flag2 = sourceTool == null;
				if (!flag2)
				{
					drawer.Draw(window, sourceTool, minAreaResult);
				}
			}
		}

		// Token: 0x060007EF RID: 2031 RVA: 0x0002592C File Offset: 0x00023B2C
		private void DrawSourceLines(HWindow window, DistanceObjectResult result)
		{
			HOperatorSet.SetColor(window, "yellow");
			HOperatorSet.SetLineWidth(window, 2);
			bool object1LineFound = result.Object1LineFound;
			if (object1LineFound)
			{
				HOperatorSet.DispLine(window, result.Object1LineStartRow, result.Object1LineStartColumn, result.Object1LineEndRow, result.Object1LineEndColumn);
			}
			bool flag = result.Object2LineFound && !this.IsSameLine(result.Object1LineStartRow, result.Object1LineStartColumn, result.Object1LineEndRow, result.Object1LineEndColumn, result.Object2LineStartRow, result.Object2LineStartColumn, result.Object2LineEndRow, result.Object2LineEndColumn);
			if (flag)
			{
				HOperatorSet.DispLine(window, result.Object2LineStartRow, result.Object2LineStartColumn, result.Object2LineEndRow, result.Object2LineEndColumn);
			}
			bool object1CircleFound = result.Object1CircleFound;
			if (object1CircleFound)
			{
				HOperatorSet.DispCircle(window, result.Object1CircleRow, result.Object1CircleColumn, result.Object1CircleRadius);
				HOperatorSet.DispCross(window, result.Object1CircleRow, result.Object1CircleColumn, 14, 0);
			}
			bool object2CircleFound = result.Object2CircleFound;
			if (object2CircleFound)
			{
				HOperatorSet.DispCircle(window, result.Object2CircleRow, result.Object2CircleColumn, result.Object2CircleRadius);
				HOperatorSet.DispCross(window, result.Object2CircleRow, result.Object2CircleColumn, 14, 0);
			}
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x00025AF8 File Offset: 0x00023CF8
		private bool IsSameLine(double row1, double column1, double row2, double column2, double otherRow1, double otherColumn1, double otherRow2, double otherColumn2)
		{
			return Math.Abs(row1 - otherRow1) <= 0.001 && Math.Abs(column1 - otherColumn1) <= 0.001 && Math.Abs(row2 - otherRow2) <= 0.001 && Math.Abs(column2 - otherColumn2) <= 0.001;
		}

		// Token: 0x060007F1 RID: 2033 RVA: 0x00025B64 File Offset: 0x00023D64
		private void DrawDoubleArrow(HWindow window, DistanceObjectResult result)
		{
			HOperatorSet.DispLine(window, result.MeasureRow1, result.MeasureColumn1, result.MeasureRow2, result.MeasureColumn2);
			this.DrawArrowHead(window, result.MeasureRow1, result.MeasureColumn1, result.MeasureRow2, result.MeasureColumn2);
			this.DrawArrowHead(window, result.MeasureRow2, result.MeasureColumn2, result.MeasureRow1, result.MeasureColumn1);
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x00025BEC File Offset: 0x00023DEC
		private void DrawArrowHead(HWindow window, double row, double column, double targetRow, double targetColumn)
		{
			double angle = Math.Atan2(targetRow - row, targetColumn - column);
			double headLength = 18.0;
			double headAngle = 0.4487989505128276;
			double rowA = row + headLength * Math.Sin(angle + headAngle);
			double colA = column + headLength * Math.Cos(angle + headAngle);
			double rowB = row + headLength * Math.Sin(angle - headAngle);
			double colB = column + headLength * Math.Cos(angle - headAngle);
			HOperatorSet.DispLine(window, row, column, rowA, colA);
			HOperatorSet.DispLine(window, row, column, rowB, colB);
		}

		// Token: 0x060007F3 RID: 2035 RVA: 0x00025CA0 File Offset: 0x00023EA0
		private void DrawText(HWindow window, ToolVision tool, DistanceObjectParameterConfig parameter, DistanceObjectResult result)
		{
			try
			{
				HOperatorSet.SetFont(window, "Arial-" + Math.Max(1, parameter.TextSize).ToString());
			}
			catch
			{
			}
			double row = (result.MeasureRow1 + result.MeasureRow2) / 2.0;
			double column = (result.MeasureColumn1 + result.MeasureColumn2) / 2.0;
			HOperatorSet.SetTposition(window, row, column);
			HOperatorSet.SetColor(window, this.GetTextColor(parameter, result));
			HOperatorSet.WriteString(window, this.CreateDistanceText(tool, result));
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x00025D78 File Offset: 0x00023F78
		private string CreateDistanceText(ToolVision tool, DistanceObjectResult result)
		{
			string toolName = string.IsNullOrWhiteSpace((tool != null) ? tool.Name : null) ? "Distance Object" : tool.Name;
			string valueText = toolName + " " + (result.IsCalibrationApplied ? ("Distance=" + result.CalibratedDistanceMm.ToString("0.000") + " mm") : ("Distance=" + result.Distance.ToString("0.000") + " px"));
			bool flag = !result.IsSpecEnabled;
			string result2;
			if (flag)
			{
				result2 = valueText;
			}
			else
			{
				result2 = valueText + " " + result.SpecStatus;
			}
			return result2;
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x00025E2C File Offset: 0x0002402C
		private string GetTextColor(DistanceObjectParameterConfig parameter, DistanceObjectResult result)
		{
			bool flag = result.IsSpecEnabled && string.Equals(result.SpecStatus, "OK", StringComparison.OrdinalIgnoreCase);
			string result2;
			if (flag)
			{
				result2 = "green";
			}
			else
			{
				bool flag2 = result.IsSpecEnabled && string.Equals(result.SpecStatus, "NG", StringComparison.OrdinalIgnoreCase);
				if (flag2)
				{
					result2 = "red";
				}
				else
				{
					result2 = parameter.DisplayColor;
				}
			}
			return result2;
		}
	}
}
