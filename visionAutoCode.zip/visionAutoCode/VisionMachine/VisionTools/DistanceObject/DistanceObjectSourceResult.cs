﻿using System;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.FindBoundingBox;
using VisionMachine.VisionTools.FindCircle;
using VisionMachine.VisionTools.FindLine;
using VisionMachine.VisionTools.FindMinArea;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x0200009D RID: 157
	public class DistanceObjectSourceResult
	{
		// Token: 0x170002BB RID: 699
		// (get) Token: 0x060007F7 RID: 2039 RVA: 0x00025E96 File Offset: 0x00024096
		// (set) Token: 0x060007F8 RID: 2040 RVA: 0x00025E9E File Offset: 0x0002409E
		public string ToolName { get; set; }

		// Token: 0x170002BC RID: 700
		// (get) Token: 0x060007F9 RID: 2041 RVA: 0x00025EA7 File Offset: 0x000240A7
		// (set) Token: 0x060007FA RID: 2042 RVA: 0x00025EAF File Offset: 0x000240AF
		public ToolType ToolType { get; set; }

		// Token: 0x170002BD RID: 701
		// (get) Token: 0x060007FB RID: 2043 RVA: 0x00025EB8 File Offset: 0x000240B8
		// (set) Token: 0x060007FC RID: 2044 RVA: 0x00025EC0 File Offset: 0x000240C0
		public FindLineResult LineResult { get; set; }

		// Token: 0x170002BE RID: 702
		// (get) Token: 0x060007FD RID: 2045 RVA: 0x00025EC9 File Offset: 0x000240C9
		// (set) Token: 0x060007FE RID: 2046 RVA: 0x00025ED1 File Offset: 0x000240D1
		public FindCircleResult CircleResult { get; set; }

		// Token: 0x170002BF RID: 703
		// (get) Token: 0x060007FF RID: 2047 RVA: 0x00025EDA File Offset: 0x000240DA
		// (set) Token: 0x06000800 RID: 2048 RVA: 0x00025EE2 File Offset: 0x000240E2
		public FindBoundingBoxResult BoundingBoxResult { get; set; }

		// Token: 0x170002C0 RID: 704
		// (get) Token: 0x06000801 RID: 2049 RVA: 0x00025EEB File Offset: 0x000240EB
		// (set) Token: 0x06000802 RID: 2050 RVA: 0x00025EF3 File Offset: 0x000240F3
		public FindMinAreaResult MinAreaResult { get; set; }

		// Token: 0x170002C1 RID: 705
		// (get) Token: 0x06000803 RID: 2051 RVA: 0x00025EFC File Offset: 0x000240FC
		public bool IsSuccess
		{
			get
			{
				bool flag = this.ToolType == ToolType.FindLine;
				bool result;
				if (flag)
				{
					result = (this.LineResult != null && this.LineResult.IsSuccess);
				}
				else
				{
					bool flag2 = this.ToolType == ToolType.FindCircle || this.ToolType == ToolType.CircleMaster;
					if (flag2)
					{
						result = (this.CircleResult != null && this.CircleResult.IsSuccess);
					}
					else
					{
						bool flag3 = this.ToolType == ToolType.FindBoundingBox;
						if (flag3)
						{
							result = (this.BoundingBoxResult != null && this.BoundingBoxResult.IsSuccess);
						}
						else
						{
							bool flag4 = this.ToolType == ToolType.FindMinArea;
							result = (flag4 && this.MinAreaResult != null && this.MinAreaResult.IsSuccess);
						}
					}
				}
				return result;
			}
		}

		// Token: 0x170002C2 RID: 706
		// (get) Token: 0x06000804 RID: 2052 RVA: 0x00025FBC File Offset: 0x000241BC
		public double ProcessingTimeMs
		{
			get
			{
				bool flag = this.ToolType == ToolType.FindLine && this.LineResult != null;
				double result;
				if (flag)
				{
					result = ((this.LineResult.TotalProcessingTimeMs > 0.0) ? this.LineResult.TotalProcessingTimeMs : this.LineResult.ProcessingTimeMs);
				}
				else
				{
					bool flag2 = (this.ToolType == ToolType.FindCircle || this.ToolType == ToolType.CircleMaster) && this.CircleResult != null;
					if (flag2)
					{
						result = ((this.CircleResult.TotalProcessingTimeMs > 0.0) ? this.CircleResult.TotalProcessingTimeMs : this.CircleResult.ProcessingTimeMs);
					}
					else
					{
						bool flag3 = this.ToolType == ToolType.FindBoundingBox && this.BoundingBoxResult != null;
						if (flag3)
						{
							result = ((this.BoundingBoxResult.TotalProcessingTimeMs > 0.0) ? this.BoundingBoxResult.TotalProcessingTimeMs : this.BoundingBoxResult.ProcessingTimeMs);
						}
						else
						{
							bool flag4 = this.ToolType == ToolType.FindMinArea && this.MinAreaResult != null;
							if (flag4)
							{
								result = ((this.MinAreaResult.TotalProcessingTimeMs > 0.0) ? this.MinAreaResult.TotalProcessingTimeMs : this.MinAreaResult.ProcessingTimeMs);
							}
							else
							{
								result = 0.0;
							}
						}
					}
				}
				return result;
			}
		}
	}
}
