﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x0200009E RID: 158
	public class DistanceObjectToolConfig : ToolConfigBase
	{
		// Token: 0x06000806 RID: 2054 RVA: 0x00026113 File Offset: 0x00024313
		public DistanceObjectToolConfig()
		{
			this.AttachParameterEvents(this._parameter);
			base.PropertyChanged += this.DistanceObjectToolConfig_PropertyChanged;
		}

		// Token: 0x170002C3 RID: 707
		// (get) Token: 0x06000807 RID: 2055 RVA: 0x00026154 File Offset: 0x00024354
		// (set) Token: 0x06000808 RID: 2056 RVA: 0x0002616C File Offset: 0x0002436C
		[Browsable(false)]
		public DistanceObjectParameterConfig Parameter
		{
			get
			{
				return this._parameter;
			}
			set
			{
				bool flag = this._parameter == value;
				if (!flag)
				{
					this.DetachParameterEvents(this._parameter);
					this._parameter = (value ?? new DistanceObjectParameterConfig());
					this._parameter.IsEnabled = base.IsEnabled;
					this.AttachParameterEvents(this._parameter);
					base.OnPropertyChanged("Parameter");
				}
			}
		}

		// Token: 0x170002C4 RID: 708
		// (get) Token: 0x06000809 RID: 2057 RVA: 0x000261D4 File Offset: 0x000243D4
		// (set) Token: 0x0600080A RID: 2058 RVA: 0x000261EC File Offset: 0x000243EC
		[Browsable(false)]
		public DistanceObjectCalibrationConfig Calibration
		{
			get
			{
				return this._calibration;
			}
			set
			{
				bool flag = this._calibration == value;
				if (!flag)
				{
					this._calibration = (value ?? new DistanceObjectCalibrationConfig());
					base.OnPropertyChanged("Calibration");
				}
			}
		}

		// Token: 0x0600080B RID: 2059 RVA: 0x00026228 File Offset: 0x00024428
		private void AttachParameterEvents(DistanceObjectParameterConfig parameter)
		{
			bool flag = parameter != null;
			if (flag)
			{
				parameter.PropertyChanged += this.Parameter_PropertyChanged;
			}
		}

		// Token: 0x0600080C RID: 2060 RVA: 0x00026254 File Offset: 0x00024454
		private void DetachParameterEvents(DistanceObjectParameterConfig parameter)
		{
			bool flag = parameter != null;
			if (flag)
			{
				parameter.PropertyChanged -= this.Parameter_PropertyChanged;
			}
		}

		// Token: 0x0600080D RID: 2061 RVA: 0x00026280 File Offset: 0x00024480
		private void Parameter_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			bool flag = e.PropertyName == "IsEnabled" && base.IsEnabled != this.Parameter.IsEnabled;
			if (flag)
			{
				base.IsEnabled = this.Parameter.IsEnabled;
			}
		}

		// Token: 0x0600080E RID: 2062 RVA: 0x000262D4 File Offset: 0x000244D4
		private void DistanceObjectToolConfig_PropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			bool flag = e.PropertyName == "IsEnabled" && this.Parameter.IsEnabled != base.IsEnabled;
			if (flag)
			{
				this.Parameter.IsEnabled = base.IsEnabled;
			}
		}

		// Token: 0x170002C5 RID: 709
		// (get) Token: 0x0600080F RID: 2063 RVA: 0x00026328 File Offset: 0x00024528
		// (set) Token: 0x06000810 RID: 2064 RVA: 0x00026345 File Offset: 0x00024545
		[Browsable(false)]
		public string FirstLineToolName
		{
			get
			{
				return this.Parameter.FirstLineToolName;
			}
			set
			{
				this.Parameter.FirstLineToolName = value;
			}
		}

		// Token: 0x06000811 RID: 2065 RVA: 0x00026358 File Offset: 0x00024558
		public bool ShouldSerializeFirstLineToolName()
		{
			return false;
		}

		// Token: 0x170002C6 RID: 710
		// (get) Token: 0x06000812 RID: 2066 RVA: 0x0002636C File Offset: 0x0002456C
		// (set) Token: 0x06000813 RID: 2067 RVA: 0x00026389 File Offset: 0x00024589
		[Browsable(false)]
		public string SecondLineToolName
		{
			get
			{
				return this.Parameter.SecondLineToolName;
			}
			set
			{
				this.Parameter.SecondLineToolName = value;
			}
		}

		// Token: 0x06000814 RID: 2068 RVA: 0x0002639C File Offset: 0x0002459C
		public bool ShouldSerializeSecondLineToolName()
		{
			return false;
		}

		// Token: 0x170002C7 RID: 711
		// (get) Token: 0x06000815 RID: 2069 RVA: 0x000263B0 File Offset: 0x000245B0
		// (set) Token: 0x06000816 RID: 2070 RVA: 0x000263CD File Offset: 0x000245CD
		[Browsable(false)]
		public DistanceObjectFeature FirstFeature
		{
			get
			{
				return this.Parameter.FirstFeature;
			}
			set
			{
				this.Parameter.FirstFeature = value;
			}
		}

		// Token: 0x06000817 RID: 2071 RVA: 0x000263E0 File Offset: 0x000245E0
		public bool ShouldSerializeFirstFeature()
		{
			return false;
		}

		// Token: 0x170002C8 RID: 712
		// (get) Token: 0x06000818 RID: 2072 RVA: 0x000263F4 File Offset: 0x000245F4
		// (set) Token: 0x06000819 RID: 2073 RVA: 0x00026411 File Offset: 0x00024611
		[Browsable(false)]
		public DistanceObjectFeature SecondFeature
		{
			get
			{
				return this.Parameter.SecondFeature;
			}
			set
			{
				this.Parameter.SecondFeature = value;
			}
		}

		// Token: 0x0600081A RID: 2074 RVA: 0x00026424 File Offset: 0x00024624
		public bool ShouldSerializeSecondFeature()
		{
			return false;
		}

		// Token: 0x170002C9 RID: 713
		// (get) Token: 0x0600081B RID: 2075 RVA: 0x00026438 File Offset: 0x00024638
		// (set) Token: 0x0600081C RID: 2076 RVA: 0x00026455 File Offset: 0x00024655
		[Browsable(false)]
		public DistanceMeasurementMode MeasurementMode
		{
			get
			{
				return this.Parameter.MeasurementMode;
			}
			set
			{
				this.Parameter.MeasurementMode = value;
			}
		}

		// Token: 0x0600081D RID: 2077 RVA: 0x00026468 File Offset: 0x00024668
		public bool ShouldSerializeMeasurementMode()
		{
			return false;
		}

		// Token: 0x170002CA RID: 714
		// (get) Token: 0x0600081E RID: 2078 RVA: 0x0002647C File Offset: 0x0002467C
		// (set) Token: 0x0600081F RID: 2079 RVA: 0x00026499 File Offset: 0x00024699
		[Browsable(false)]
		public bool ShowArrow
		{
			get
			{
				return this.Parameter.ShowArrow;
			}
			set
			{
				this.Parameter.ShowArrow = value;
			}
		}

		// Token: 0x06000820 RID: 2080 RVA: 0x000264AC File Offset: 0x000246AC
		public bool ShouldSerializeShowArrow()
		{
			return false;
		}

		// Token: 0x170002CB RID: 715
		// (get) Token: 0x06000821 RID: 2081 RVA: 0x000264C0 File Offset: 0x000246C0
		// (set) Token: 0x06000822 RID: 2082 RVA: 0x000264DD File Offset: 0x000246DD
		[Browsable(false)]
		public bool ShowText
		{
			get
			{
				return this.Parameter.ShowText;
			}
			set
			{
				this.Parameter.ShowText = value;
			}
		}

		// Token: 0x06000823 RID: 2083 RVA: 0x000264F0 File Offset: 0x000246F0
		public bool ShouldSerializeShowText()
		{
			return false;
		}

		// Token: 0x170002CC RID: 716
		// (get) Token: 0x06000824 RID: 2084 RVA: 0x00026504 File Offset: 0x00024704
		// (set) Token: 0x06000825 RID: 2085 RVA: 0x00026521 File Offset: 0x00024721
		[Browsable(false)]
		public int TextSize
		{
			get
			{
				return this.Parameter.TextSize;
			}
			set
			{
				this.Parameter.TextSize = value;
			}
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x00026534 File Offset: 0x00024734
		public bool ShouldSerializeTextSize()
		{
			return false;
		}

		// Token: 0x170002CD RID: 717
		// (get) Token: 0x06000827 RID: 2087 RVA: 0x00026548 File Offset: 0x00024748
		// (set) Token: 0x06000828 RID: 2088 RVA: 0x00026565 File Offset: 0x00024765
		[Browsable(false)]
		public string DisplayColor
		{
			get
			{
				return this.Parameter.DisplayColor;
			}
			set
			{
				this.Parameter.DisplayColor = value;
			}
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x00026578 File Offset: 0x00024778
		public bool ShouldSerializeDisplayColor()
		{
			return false;
		}

		// Token: 0x170002CE RID: 718
		// (get) Token: 0x0600082A RID: 2090 RVA: 0x0002658C File Offset: 0x0002478C
		// (set) Token: 0x0600082B RID: 2091 RVA: 0x000265A9 File Offset: 0x000247A9
		[Browsable(false)]
		public bool UseCalibration
		{
			get
			{
				return this.Calibration.UseCalibration;
			}
			set
			{
				this.Calibration.UseCalibration = value;
			}
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x000265BC File Offset: 0x000247BC
		public bool ShouldSerializeUseCalibration()
		{
			return false;
		}

		// Token: 0x170002CF RID: 719
		// (get) Token: 0x0600082D RID: 2093 RVA: 0x000265D0 File Offset: 0x000247D0
		// (set) Token: 0x0600082E RID: 2094 RVA: 0x000265ED File Offset: 0x000247ED
		[Browsable(false)]
		public double CalibrationPixelDistance
		{
			get
			{
				return this.Calibration.CalibrationPixelDistance;
			}
			set
			{
				this.Calibration.CalibrationPixelDistance = value;
			}
		}

		// Token: 0x0600082F RID: 2095 RVA: 0x00026600 File Offset: 0x00024800
		public bool ShouldSerializeCalibrationPixelDistance()
		{
			return false;
		}

		// Token: 0x170002D0 RID: 720
		// (get) Token: 0x06000830 RID: 2096 RVA: 0x00026614 File Offset: 0x00024814
		// (set) Token: 0x06000831 RID: 2097 RVA: 0x00026631 File Offset: 0x00024831
		[Browsable(false)]
		public double CalibrationActualDistanceMm
		{
			get
			{
				return this.Calibration.CalibrationActualDistanceMm;
			}
			set
			{
				this.Calibration.CalibrationActualDistanceMm = value;
			}
		}

		// Token: 0x06000832 RID: 2098 RVA: 0x00026644 File Offset: 0x00024844
		public bool ShouldSerializeCalibrationActualDistanceMm()
		{
			return false;
		}

		// Token: 0x170002D1 RID: 721
		// (get) Token: 0x06000833 RID: 2099 RVA: 0x00026658 File Offset: 0x00024858
		// (set) Token: 0x06000834 RID: 2100 RVA: 0x00026675 File Offset: 0x00024875
		[Browsable(false)]
		public double MillimetersPerPixel
		{
			get
			{
				return this.Calibration.MillimetersPerPixel;
			}
			set
			{
				this.Calibration.MillimetersPerPixel = value;
			}
		}

		// Token: 0x06000835 RID: 2101 RVA: 0x00026688 File Offset: 0x00024888
		public bool ShouldSerializeMillimetersPerPixel()
		{
			return false;
		}

		// Token: 0x170002D2 RID: 722
		// (get) Token: 0x06000836 RID: 2102 RVA: 0x0002669C File Offset: 0x0002489C
		// (set) Token: 0x06000837 RID: 2103 RVA: 0x000266B9 File Offset: 0x000248B9
		[Browsable(false)]
		public double LastMeasuredPixelDistance
		{
			get
			{
				return this.Calibration.LastMeasuredPixelDistance;
			}
			set
			{
				this.Calibration.LastMeasuredPixelDistance = value;
			}
		}

		// Token: 0x06000838 RID: 2104 RVA: 0x000266CC File Offset: 0x000248CC
		public bool ShouldSerializeLastMeasuredPixelDistance()
		{
			return false;
		}

		// Token: 0x170002D3 RID: 723
		// (get) Token: 0x06000839 RID: 2105 RVA: 0x000266E0 File Offset: 0x000248E0
		// (set) Token: 0x0600083A RID: 2106 RVA: 0x000266FD File Offset: 0x000248FD
		[Browsable(false)]
		public double LastMeasuredDistanceMm
		{
			get
			{
				return this.Calibration.LastMeasuredDistanceMm;
			}
			set
			{
				this.Calibration.LastMeasuredDistanceMm = value;
			}
		}

		// Token: 0x0600083B RID: 2107 RVA: 0x00026710 File Offset: 0x00024910
		public bool ShouldSerializeLastMeasuredDistanceMm()
		{
			return false;
		}

		// Token: 0x0400034A RID: 842
		private DistanceObjectParameterConfig _parameter = new DistanceObjectParameterConfig();

		// Token: 0x0400034B RID: 843
		private DistanceObjectCalibrationConfig _calibration = new DistanceObjectCalibrationConfig();
	}
}
