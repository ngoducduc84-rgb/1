﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.DistanceObject
{
	// Token: 0x020000A1 RID: 161
	public class DistanceObjectToolSpec : ToolSpecBase
	{
		// Token: 0x170002E4 RID: 740
		// (get) Token: 0x06000865 RID: 2149 RVA: 0x00026D9C File Offset: 0x00024F9C
		// (set) Token: 0x06000866 RID: 2150 RVA: 0x00026DB4 File Offset: 0x00024FB4
		[DisplayName("Normal Size (mm)")]
		public double NormalSize
		{
			get
			{
				return this._normalSize;
			}
			set
			{
				bool flag = this._normalSize != value;
				if (flag)
				{
					this._normalSize = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("NormalSize");
				}
			}
		}

		// Token: 0x170002E5 RID: 741
		// (get) Token: 0x06000867 RID: 2151 RVA: 0x00026DF0 File Offset: 0x00024FF0
		// (set) Token: 0x06000868 RID: 2152 RVA: 0x00026E08 File Offset: 0x00025008
		[DisplayName("Upper Deviation (mm)")]
		public double UpperDeviation
		{
			get
			{
				return this._upperDeviation;
			}
			set
			{
				bool flag = this._upperDeviation != value;
				if (flag)
				{
					this._upperDeviation = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("UpperDeviation");
				}
			}
		}

		// Token: 0x170002E6 RID: 742
		// (get) Token: 0x06000869 RID: 2153 RVA: 0x00026E44 File Offset: 0x00025044
		// (set) Token: 0x0600086A RID: 2154 RVA: 0x00026E5C File Offset: 0x0002505C
		[DisplayName("Lower Deviation (mm)")]
		public double LowerDeviation
		{
			get
			{
				return this._lowerDeviation;
			}
			set
			{
				bool flag = this._lowerDeviation != value;
				if (flag)
				{
					this._lowerDeviation = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("LowerDeviation");
				}
			}
		}

		// Token: 0x170002E7 RID: 743
		// (get) Token: 0x0600086B RID: 2155 RVA: 0x00026E98 File Offset: 0x00025098
		// (set) Token: 0x0600086C RID: 2156 RVA: 0x00026EB0 File Offset: 0x000250B0
		[DisplayName("Maximum Size (mm)")]
		[ReadOnly(true)]
		public double MaximumSize
		{
			get
			{
				return this._maximumSize;
			}
			set
			{
				bool flag = this._maximumSize != value;
				if (flag)
				{
					this._maximumSize = value;
					base.OnPropertyChanged("MaximumSize");
				}
			}
		}

		// Token: 0x170002E8 RID: 744
		// (get) Token: 0x0600086D RID: 2157 RVA: 0x00026EE4 File Offset: 0x000250E4
		// (set) Token: 0x0600086E RID: 2158 RVA: 0x00026EFC File Offset: 0x000250FC
		[DisplayName("Minimum Size (mm)")]
		[ReadOnly(true)]
		public double MinimumSize
		{
			get
			{
				return this._minimumSize;
			}
			set
			{
				bool flag = this._minimumSize != value;
				if (flag)
				{
					this._minimumSize = value;
					base.OnPropertyChanged("MinimumSize");
				}
			}
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x00026F2F File Offset: 0x0002512F
		private void RecalculateLimits()
		{
			this.MaximumSize = this.NormalSize + this.UpperDeviation;
			this.MinimumSize = this.NormalSize - this.LowerDeviation;
		}

		// Token: 0x0400035E RID: 862
		private double _normalSize;

		// Token: 0x0400035F RID: 863
		private double _upperDeviation;

		// Token: 0x04000360 RID: 864
		private double _lowerDeviation;

		// Token: 0x04000361 RID: 865
		private double _maximumSize;

		// Token: 0x04000362 RID: 866
		private double _minimumSize;
	}
}
