﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.DistanceObject.Views
{
	// Token: 0x020000A2 RID: 162
	public partial class DistanceObject_para : UserControl
	{
		// Token: 0x06000871 RID: 2161 RVA: 0x00026F5A File Offset: 0x0002515A
		public DistanceObject_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x00026F6C File Offset: 0x0002516C
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			DistanceObjectParameterPanelViewModel viewModel = base.DataContext as DistanceObjectParameterPanelViewModel;
			DistanceObjectCalibrationConfig calibration = (viewModel != null) ? viewModel.CalibrationConfig : null;
			DistanceObjectToolSpec spec = (viewModel != null) ? viewModel.SpecConfig : null;
			bool flag = calibration == null;
			if (flag)
			{
				Form_setting instance = Form_setting.Instance;
				if (instance != null)
				{
					instance.DistanceObjectTrialRun();
				}
			}
			else
			{
				bool previousUseCalibration = calibration.UseCalibration;
				bool previousSpecEnabled = spec != null && spec.IsEnabled;
				double previousLastMeasuredDistanceMm = calibration.LastMeasuredDistanceMm;
				try
				{
					calibration.UseCalibration = false;
					bool flag2 = spec != null;
					if (flag2)
					{
						spec.IsEnabled = false;
					}
					Form_setting instance2 = Form_setting.Instance;
					if (instance2 != null)
					{
						instance2.DistanceObjectTrialRun();
					}
				}
				finally
				{
					calibration.UseCalibration = previousUseCalibration;
					bool flag3 = spec != null;
					if (flag3)
					{
						spec.IsEnabled = previousSpecEnabled;
					}
					calibration.LastMeasuredDistanceMm = previousLastMeasuredDistanceMm;
				}
			}
		}

		// Token: 0x06000873 RID: 2163 RVA: 0x00027044 File Offset: 0x00025244
		private void BtnCalib_Click(object sender, RoutedEventArgs e)
		{
			DistanceObjectParameterPanelViewModel viewModel = base.DataContext as DistanceObjectParameterPanelViewModel;
			DistanceObjectCalibrationConfig calibration = (viewModel != null) ? viewModel.CalibrationConfig : null;
			bool flag = calibration == null;
			if (!flag)
			{
				bool flag2 = calibration.CalibrationPixelDistance <= 0.0;
				if (flag2)
				{
					DXMessageBox.Show("Pixel distance must be greater than zero. Run the tool first.");
				}
				else
				{
					bool flag3 = calibration.CalibrationActualDistanceMm <= 0.0;
					if (flag3)
					{
						DXMessageBox.Show("Actual distance must be greater than zero.");
					}
					else
					{
						calibration.MillimetersPerPixel = calibration.CalibrationActualDistanceMm / calibration.CalibrationPixelDistance;
						calibration.UseCalibration = true;
					}
				}
			}
		}

		// Token: 0x06000874 RID: 2164 RVA: 0x000270E0 File Offset: 0x000252E0
		private void BtnRunCalib_Click(object sender, RoutedEventArgs e)
		{
			DistanceObjectParameterPanelViewModel viewModel = base.DataContext as DistanceObjectParameterPanelViewModel;
			DistanceObjectCalibrationConfig calibration = (viewModel != null) ? viewModel.CalibrationConfig : null;
			bool flag = calibration != null;
			if (flag)
			{
				calibration.UseCalibration = true;
			}
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.DistanceObjectTrialRun();
			}
		}
	}
}
