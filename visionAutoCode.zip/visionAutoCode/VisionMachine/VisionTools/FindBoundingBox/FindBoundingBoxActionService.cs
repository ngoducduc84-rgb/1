﻿using System;
using System.Diagnostics;
using System.Linq;
using DevExpress.Xpf.Core;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.FindBoundingBox
{
	// Token: 0x02000081 RID: 129
	public class FindBoundingBoxActionService : IToolActionService
	{
		// Token: 0x1700020B RID: 523
		// (get) Token: 0x06000617 RID: 1559 RVA: 0x0001E1E4 File Offset: 0x0001C3E4
		public ToolType ToolType
		{
			get
			{
				return ToolType.FindBoundingBox;
			}
		}

		// Token: 0x06000618 RID: 1560 RVA: 0x0001E1F8 File Offset: 0x0001C3F8
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null;
			if (flag)
			{
				ToolActionFeedback.ReportError(context, "DisplayController null.");
			}
			else
			{
				bool flag2 = tool == null;
				if (flag2)
				{
					DXMessageBox.Show("No tool is selected.");
				}
				else
				{
					HObject original = null;
					HObject input = null;
					ImageBufferStore bufferStore = null;
					FindBoundingBoxResult result = null;
					try
					{
						original = context.DisplayController.GetOriginalImage();
						bool flag3 = original == null || !original.IsInitialized();
						if (flag3)
						{
							DXMessageBox.Show("No original image is available for Find Bounding Box testing.");
						}
						else
						{
							bufferStore = new ImageBufferStore();
							ToolProcessContext processContext = new ToolProcessContext
							{
								OriginalImage = original,
								InputImage = original,
								BufferStore = bufferStore
							};
							string inputSourceToolName = this.GetInputSourceToolName(tool);
							Stopwatch inputStopwatch = Stopwatch.StartNew();
							input = this._pipelineService.BuildInputImageForTool(processContext, tool);
							inputStopwatch.Stop();
							bool flag4 = input == null || !input.IsInitialized();
							if (flag4)
							{
								HOperatorSet.CopyImage(original, out input);
							}
							FindBoundingBoxToolConfig config = tool.Config as FindBoundingBoxToolConfig;
							bool flag5 = config != null && config.ShowInputImage;
							if (flag5)
							{
								context.DisplayController.DisplayImage(input);
							}
							else
							{
								result = this._processor.Run(input, tool);
								result.InputSourceToolName = inputSourceToolName;
								result.InputProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds;
								result.TotalProcessingTimeMs = result.InputProcessingTimeMs + result.ProcessingTimeMs;
								bool flag6 = !result.IsSuccess;
								if (flag6)
								{
									DXMessageBox.Show(result.Message);
								}
								Action<ToolVision, object> resultReporter = context.ResultReporter;
								if (resultReporter != null)
								{
									resultReporter(tool, result);
								}
								context.DisplayController.DisplayImage(input);
								FindBoundingBoxResult overlayResult = result;
								result = null;
								context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
								{
									this._drawer.Draw(window, tool, overlayResult);
								}, overlayResult);
							}
						}
					}
					finally
					{
						if (result != null)
						{
							result.Dispose();
						}
						if (input != null)
						{
							input.Dispose();
						}
						if (bufferStore != null)
						{
							bufferStore.Clear();
						}
						if (original != null)
						{
							original.Dispose();
						}
					}
				}
			}
		}

		// Token: 0x06000619 RID: 1561 RVA: 0x0001E488 File Offset: 0x0001C688
		private string GetInputSourceToolName(ToolVision tool)
		{
			ToolVision tool2 = tool;
			FindBoundingBoxToolConfig config = ((tool2 != null) ? tool2.Config : null) as FindBoundingBoxToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						TurnSnap parentTurnSnap = tool.ParentTurnSnap;
						ToolVision previousTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).LastOrDefault<ToolVision>() : null;
						result = ((previousTool == null) ? "PreviousToolOutput" : previousTool.Name);
					}
					else
					{
						result = "Unknown";
					}
				}
			}
			return result;
		}

		// Token: 0x04000271 RID: 625
		private readonly FindBoundingBoxProcessor _processor = new FindBoundingBoxProcessor();

		// Token: 0x04000272 RID: 626
		private readonly FindBoundingBoxResultDrawer _drawer = new FindBoundingBoxResultDrawer();

		// Token: 0x04000273 RID: 627
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();
	}
}
