﻿using System;

namespace VisionMachine.VisionTools.FindBoundingBox
{
	// Token: 0x02000087 RID: 135
	public class FindBoundingBoxCandidate
	{
		// Token: 0x17000220 RID: 544
		// (get) Token: 0x06000663 RID: 1635 RVA: 0x000207D0 File Offset: 0x0001E9D0
		// (set) Token: 0x06000664 RID: 1636 RVA: 0x000207D8 File Offset: 0x0001E9D8
		public int RegionIndex { get; set; }

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x06000665 RID: 1637 RVA: 0x000207E1 File Offset: 0x0001E9E1
		// (set) Token: 0x06000666 RID: 1638 RVA: 0x000207E9 File Offset: 0x0001E9E9
		public int GridRow { get; set; }

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000667 RID: 1639 RVA: 0x000207F2 File Offset: 0x0001E9F2
		// (set) Token: 0x06000668 RID: 1640 RVA: 0x000207FA File Offset: 0x0001E9FA
		public int GridColumn { get; set; }

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000669 RID: 1641 RVA: 0x00020803 File Offset: 0x0001EA03
		// (set) Token: 0x0600066A RID: 1642 RVA: 0x0002080B File Offset: 0x0001EA0B
		public double Row { get; set; }

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x0600066B RID: 1643 RVA: 0x00020814 File Offset: 0x0001EA14
		// (set) Token: 0x0600066C RID: 1644 RVA: 0x0002081C File Offset: 0x0001EA1C
		public double Column { get; set; }

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x0600066D RID: 1645 RVA: 0x00020825 File Offset: 0x0001EA25
		// (set) Token: 0x0600066E RID: 1646 RVA: 0x0002082D File Offset: 0x0001EA2D
		public double Row1 { get; set; }

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x0600066F RID: 1647 RVA: 0x00020836 File Offset: 0x0001EA36
		// (set) Token: 0x06000670 RID: 1648 RVA: 0x0002083E File Offset: 0x0001EA3E
		public double Column1 { get; set; }

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x06000671 RID: 1649 RVA: 0x00020847 File Offset: 0x0001EA47
		// (set) Token: 0x06000672 RID: 1650 RVA: 0x0002084F File Offset: 0x0001EA4F
		public double Row2 { get; set; }

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000673 RID: 1651 RVA: 0x00020858 File Offset: 0x0001EA58
		// (set) Token: 0x06000674 RID: 1652 RVA: 0x00020860 File Offset: 0x0001EA60
		public double Column2 { get; set; }

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x06000675 RID: 1653 RVA: 0x00020869 File Offset: 0x0001EA69
		// (set) Token: 0x06000676 RID: 1654 RVA: 0x00020871 File Offset: 0x0001EA71
		public double Width { get; set; }

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x06000677 RID: 1655 RVA: 0x0002087A File Offset: 0x0001EA7A
		// (set) Token: 0x06000678 RID: 1656 RVA: 0x00020882 File Offset: 0x0001EA82
		public double Height { get; set; }

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000679 RID: 1657 RVA: 0x0002088B File Offset: 0x0001EA8B
		// (set) Token: 0x0600067A RID: 1658 RVA: 0x00020893 File Offset: 0x0001EA93
		public double Area { get; set; }

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x0600067B RID: 1659 RVA: 0x0002089C File Offset: 0x0001EA9C
		// (set) Token: 0x0600067C RID: 1660 RVA: 0x000208A4 File Offset: 0x0001EAA4
		public FindBoundingBoxPointSet Points { get; set; } = new FindBoundingBoxPointSet();
	}
}
