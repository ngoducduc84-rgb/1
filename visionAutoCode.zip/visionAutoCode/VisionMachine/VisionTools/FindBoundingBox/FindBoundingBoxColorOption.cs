﻿using System;
using System.Windows.Media;

namespace VisionMachine.VisionTools.FindBoundingBox
{
	// Token: 0x02000083 RID: 131
	public class FindBoundingBoxColorOption
	{
		// Token: 0x17000212 RID: 530
		// (get) Token: 0x0600062A RID: 1578 RVA: 0x0001E9D3 File Offset: 0x0001CBD3
		// (set) Token: 0x0600062B RID: 1579 RVA: 0x0001E9DB File Offset: 0x0001CBDB
		public string Name { get; set; }

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x0600062C RID: 1580 RVA: 0x0001E9E4 File Offset: 0x0001CBE4
		// (set) Token: 0x0600062D RID: 1581 RVA: 0x0001E9EC File Offset: 0x0001CBEC
		public Color Color { get; set; }

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x0600062E RID: 1582 RVA: 0x0001E9F5 File Offset: 0x0001CBF5
		// (set) Token: 0x0600062F RID: 1583 RVA: 0x0001E9FD File Offset: 0x0001CBFD
		public string Value { get; set; }
	}
}
