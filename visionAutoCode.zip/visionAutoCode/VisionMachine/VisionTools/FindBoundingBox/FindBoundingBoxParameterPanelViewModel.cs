﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindBoundingBox
{
	// Token: 0x02000082 RID: 130
	public class FindBoundingBoxParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x1700020C RID: 524
		// (get) Token: 0x0600061B RID: 1563 RVA: 0x0001E5A0 File Offset: 0x0001C7A0
		// (set) Token: 0x0600061C RID: 1564 RVA: 0x0001E5A8 File Offset: 0x0001C7A8
		public ToolVision Tool { get; set; }

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x0600061D RID: 1565 RVA: 0x0001E5B1 File Offset: 0x0001C7B1
		// (set) Token: 0x0600061E RID: 1566 RVA: 0x0001E5B9 File Offset: 0x0001C7B9
		public FindBoundingBoxToolConfig Config { get; set; }

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x0600061F RID: 1567 RVA: 0x0001E5C2 File Offset: 0x0001C7C2
		// (set) Token: 0x06000620 RID: 1568 RVA: 0x0001E5CA File Offset: 0x0001C7CA
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x06000621 RID: 1569 RVA: 0x0001E5D3 File Offset: 0x0001C7D3
		public ObservableCollection<FindBoundingBoxColorOption> TextColorOptions { get; } = new ObservableCollection<FindBoundingBoxColorOption>
		{
			new FindBoundingBoxColorOption
			{
				Name = "White",
				Color = Colors.White,
				Value = "white"
			},
			new FindBoundingBoxColorOption
			{
				Name = "Black",
				Color = Colors.Black,
				Value = "black"
			},
			new FindBoundingBoxColorOption
			{
				Name = "Red",
				Color = Colors.Red,
				Value = "red"
			},
			new FindBoundingBoxColorOption
			{
				Name = "Green",
				Color = Colors.Lime,
				Value = "green"
			},
			new FindBoundingBoxColorOption
			{
				Name = "Blue",
				Color = Colors.DodgerBlue,
				Value = "blue"
			},
			new FindBoundingBoxColorOption
			{
				Name = "Yellow",
				Color = Colors.Yellow,
				Value = "yellow"
			},
			new FindBoundingBoxColorOption
			{
				Name = "Cyan",
				Color = Colors.Cyan,
				Value = "cyan"
			},
			new FindBoundingBoxColorOption
			{
				Name = "Magenta",
				Color = Colors.Magenta,
				Value = "magenta"
			},
			new FindBoundingBoxColorOption
			{
				Name = "Orange",
				Color = Colors.Orange,
				Value = "orange"
			}
		};

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06000622 RID: 1570 RVA: 0x0001E5DC File Offset: 0x0001C7DC
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x17000211 RID: 529
		// (get) Token: 0x06000623 RID: 1571 RVA: 0x0001E5F8 File Offset: 0x0001C7F8
		// (set) Token: 0x06000624 RID: 1572 RVA: 0x0001E610 File Offset: 0x0001C810
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool == value;
				if (!flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.Config != null && this.Config.InputLink != null;
					if (flag2)
					{
						this.Config.InputLink.SourceToolId = null;
						this.Config.InputLink.SourceToolName = ((this._selectedSourceTool == null) ? null : this._selectedSourceTool.ToolName);
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x06000625 RID: 1573 RVA: 0x0001E698 File Offset: 0x0001C898
		// (remove) Token: 0x06000626 RID: 1574 RVA: 0x0001E6D0 File Offset: 0x0001C8D0
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000627 RID: 1575 RVA: 0x0001E708 File Offset: 0x0001C908
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.Config == null || this.Config.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.Config.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.Config.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.Config.InputLink.SourceToolId = null;
				this.Config.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x06000628 RID: 1576 RVA: 0x0001E7E8 File Offset: 0x0001C9E8
		private void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x04000274 RID: 628
		private ToolImageSourceOption _selectedSourceTool;
	}
}
