﻿using System;

namespace VisionMachine.VisionTools.FindBoundingBox
{
	// Token: 0x02000086 RID: 134
	public class FindBoundingBoxPointSet
	{
		// Token: 0x17000216 RID: 534
		// (get) Token: 0x0600064E RID: 1614 RVA: 0x00020726 File Offset: 0x0001E926
		// (set) Token: 0x0600064F RID: 1615 RVA: 0x0002072E File Offset: 0x0001E92E
		public double TopLeftRow { get; set; }

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000650 RID: 1616 RVA: 0x00020737 File Offset: 0x0001E937
		// (set) Token: 0x06000651 RID: 1617 RVA: 0x0002073F File Offset: 0x0001E93F
		public double TopLeftColumn { get; set; }

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x06000652 RID: 1618 RVA: 0x00020748 File Offset: 0x0001E948
		// (set) Token: 0x06000653 RID: 1619 RVA: 0x00020750 File Offset: 0x0001E950
		public double TopRightRow { get; set; }

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06000654 RID: 1620 RVA: 0x00020759 File Offset: 0x0001E959
		// (set) Token: 0x06000655 RID: 1621 RVA: 0x00020761 File Offset: 0x0001E961
		public double TopRightColumn { get; set; }

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x06000656 RID: 1622 RVA: 0x0002076A File Offset: 0x0001E96A
		// (set) Token: 0x06000657 RID: 1623 RVA: 0x00020772 File Offset: 0x0001E972
		public double BottomRightRow { get; set; }

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000658 RID: 1624 RVA: 0x0002077B File Offset: 0x0001E97B
		// (set) Token: 0x06000659 RID: 1625 RVA: 0x00020783 File Offset: 0x0001E983
		public double BottomRightColumn { get; set; }

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x0600065A RID: 1626 RVA: 0x0002078C File Offset: 0x0001E98C
		// (set) Token: 0x0600065B RID: 1627 RVA: 0x00020794 File Offset: 0x0001E994
		public double BottomLeftRow { get; set; }

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x0600065C RID: 1628 RVA: 0x0002079D File Offset: 0x0001E99D
		// (set) Token: 0x0600065D RID: 1629 RVA: 0x000207A5 File Offset: 0x0001E9A5
		public double BottomLeftColumn { get; set; }

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x0600065E RID: 1630 RVA: 0x000207AE File Offset: 0x0001E9AE
		// (set) Token: 0x0600065F RID: 1631 RVA: 0x000207B6 File Offset: 0x0001E9B6
		public double CenterRow { get; set; }

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x06000660 RID: 1632 RVA: 0x000207BF File Offset: 0x0001E9BF
		// (set) Token: 0x06000661 RID: 1633 RVA: 0x000207C7 File Offset: 0x0001E9C7
		public double CenterColumn { get; set; }
	}
}
