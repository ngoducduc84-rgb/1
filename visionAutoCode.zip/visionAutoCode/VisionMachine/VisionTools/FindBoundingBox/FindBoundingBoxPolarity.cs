﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.FindBoundingBox
{
	// Token: 0x02000084 RID: 132
	public enum FindBoundingBoxPolarity
	{
		// Token: 0x0400027E RID: 638
		[Description("Dark to Light")]
		DarkToLight,
		// Token: 0x0400027F RID: 639
		[Description("Light to Dark")]
		LightToDark
	}
}
