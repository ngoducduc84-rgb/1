﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.FindBoundingBox
{
	// Token: 0x02000085 RID: 133
	public class FindBoundingBoxProcessor : IToolProcessor
	{
		// Token: 0x06000631 RID: 1585 RVA: 0x0001EA06 File Offset: 0x0001CC06
		public FindBoundingBoxProcessor() : this(null)
		{
		}

		// Token: 0x06000632 RID: 1586 RVA: 0x0001EA11 File Offset: 0x0001CC11
		public FindBoundingBoxProcessor(IDictionary<string, ShapeMatchResult> cachedMasterResults)
		{
			this._cachedMasterResults = cachedMasterResults;
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000633 RID: 1587 RVA: 0x0001EA24 File Offset: 0x0001CC24
		public ToolType ToolType
		{
			get
			{
				return ToolType.FindBoundingBox;
			}
		}

		// Token: 0x06000634 RID: 1588 RVA: 0x0001EA38 File Offset: 0x0001CC38
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			FindBoundingBoxResult boxResult = this.Run((context != null) ? context.InputImage : null, tool);
			return new ToolProcessResult
			{
				IsSuccess = boxResult.IsSuccess,
				Message = boxResult.Message,
				Data = boxResult
			};
		}

		// Token: 0x06000635 RID: 1589 RVA: 0x0001EA88 File Offset: 0x0001CC88
		public FindBoundingBoxResult Run(HObject image, ToolVision tool)
		{
			FindBoundingBoxResult result = new FindBoundingBoxResult();
			Stopwatch stopwatch = Stopwatch.StartNew();
			HObject grayImage = null;
			HObject roiRegion = null;
			HObject reducedImage = null;
			HObject thresholdRegion = null;
			HObject connected = null;
			HObject selectedRegions = null;
			FindBoundingBoxResult result2;
			try
			{
				bool flag = image == null || !image.IsInitialized();
				if (flag)
				{
					result.Message = "Input image null.";
					result2 = result;
				}
				else
				{
					FindBoundingBoxToolConfig config = ((tool != null) ? tool.Config : null) as FindBoundingBoxToolConfig;
					bool flag2 = config == null;
					if (flag2)
					{
						result.Message = "Find Bounding Box config null.";
						result2 = result;
					}
					else
					{
						bool flag3 = !config.IsEnabled;
						if (flag3)
						{
							result.Message = "Find Bounding Box tool is disabled.";
							result2 = result;
						}
						else
						{
							RoiData roi = tool.RoiItems.FirstOrDefault((RoiData x) => x.IsEnabled && x.RoiType != RoiType.Line);
							bool flag4 = roi == null;
							if (flag4)
							{
								result.Message = "Find Bounding Box requires one enabled non-line ROI.";
								result2 = result;
							}
							else
							{
								this._currentMasterProcessingTimes = this.UpdateMasterShapeModels(image, tool, roi);
								RoiData transformedRoi = this.CreateTransformedRoi(roi, tool);
								result.ToolName = tool.Name;
								result.RoiName = (string.IsNullOrWhiteSpace(transformedRoi.DisplayName) ? "ROI" : transformedRoi.DisplayName);
								result.Roi = transformedRoi;
								result.MasterPositionToolName = this.GetMasterPositionToolName(roi);
								result.MasterAngleToolName = this.GetMasterAngleToolName(roi);
								result.MasterProcessingTimeMs = this.GetMasterProcessingTime(result.MasterPositionToolName, result.MasterAngleToolName);
								grayImage = this.ConvertToGray(image);
								roiRegion = this.GenRegionFromRoi(transformedRoi, grayImage, true);
								bool flag5 = roiRegion == null || !roiRegion.IsInitialized();
								if (flag5)
								{
									result.Message = "ROI region is invalid.";
									result2 = result;
								}
								else
								{
									HObject roiRegionCopy;
									HOperatorSet.CopyObj(roiRegion, out roiRegionCopy, 1, -1);
									result.RoiRegion = roiRegionCopy;
									HOperatorSet.ReduceDomain(grayImage, roiRegion, out reducedImage);
									thresholdRegion = this.CreateThresholdRegion(reducedImage, roiRegion, config);
									HObject thresholdCopy;
									HOperatorSet.CopyObj(thresholdRegion, out thresholdCopy, 1, -1);
									result.ThresholdRegion = thresholdCopy;
									HOperatorSet.Connection(thresholdRegion, out connected);
									HOperatorSet.SelectShape(connected, out selectedRegions, "area", "and", config.MinArea, config.MaxArea);
									this.FillCandidates(selectedRegions, config, result.Candidates);
									this.AssignGrid(result.Candidates, config.RowSpacing, config.ColumnSpacing);
									result.SelectedBox = result.Candidates.FirstOrDefault((FindBoundingBoxCandidate x) => x.GridRow == config.PickRow && x.GridColumn == config.PickColumn);
									result.AllBoxRegions = this.CreateBoxRegions(result.Candidates);
									bool flag6 = result.SelectedBox == null;
									if (flag6)
									{
										result.Message = "Bounding box was not found at selected row/column.";
										result2 = result;
									}
									else
									{
										result.SelectedBoxRegion = this.CreateBoxRegion(result.SelectedBox);
										result.IsSuccess = true;
										result.Message = "Find Bounding Box OK.";
										result2 = result;
									}
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				result.Message = "Find Bounding Box failed: " + ex.Message;
				result2 = result;
			}
			finally
			{
				stopwatch.Stop();
				result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
				result.TotalProcessingTimeMs = result.InputProcessingTimeMs + result.ProcessingTimeMs;
				if (grayImage != null)
				{
					grayImage.Dispose();
				}
				if (roiRegion != null)
				{
					roiRegion.Dispose();
				}
				if (reducedImage != null)
				{
					reducedImage.Dispose();
				}
				if (thresholdRegion != null)
				{
					thresholdRegion.Dispose();
				}
				if (connected != null)
				{
					connected.Dispose();
				}
				if (selectedRegions != null)
				{
					selectedRegions.Dispose();
				}
			}
			return result2;
		}

		// Token: 0x06000636 RID: 1590 RVA: 0x0001EEA0 File Offset: 0x0001D0A0
		private HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject result;
			if (flag)
			{
				HObject grayImage;
				HOperatorSet.Rgb1ToGray(image, out grayImage);
				result = grayImage;
			}
			else
			{
				HObject gray;
				HOperatorSet.CopyImage(image, out gray);
				result = gray;
			}
			return result;
		}

		// Token: 0x06000637 RID: 1591 RVA: 0x0001EEF8 File Offset: 0x0001D0F8
		private HObject CreateThresholdRegion(HObject image, HObject roiRegion, FindBoundingBoxToolConfig config)
		{
			HObject threshold = null;
			HObject polarityRegion = null;
			HObject filled = null;
			HObject result2;
			try
			{
				HOperatorSet.Threshold(image, out threshold, config.ThresholdMin, config.ThresholdMax);
				bool flag = config.ThresholdPolarity == FindBoundingBoxPolarity.LightToDark;
				if (flag)
				{
					HOperatorSet.Difference(roiRegion, threshold, out polarityRegion);
				}
				else
				{
					HOperatorSet.CopyObj(threshold, out polarityRegion, 1, -1);
				}
				HOperatorSet.FillUp(polarityRegion, out filled);
				HObject result;
				HOperatorSet.CopyObj(filled, out result, 1, -1);
				result2 = result;
			}
			finally
			{
				if (threshold != null)
				{
					threshold.Dispose();
				}
				if (polarityRegion != null)
				{
					polarityRegion.Dispose();
				}
				if (filled != null)
				{
					filled.Dispose();
				}
			}
			return result2;
		}

		// Token: 0x06000638 RID: 1592 RVA: 0x0001EFBC File Offset: 0x0001D1BC
		private void FillCandidates(HObject selectedRegions, FindBoundingBoxToolConfig config, List<FindBoundingBoxCandidate> candidates)
		{
			HTuple count;
			HOperatorSet.CountObj(selectedRegions, out count);
			int i = 1;
			while (i <= count.I)
			{
				HObject region = null;
				try
				{
					HOperatorSet.SelectObj(selectedRegions, out region, i);
					HTuple area;
					HTuple areaRow;
					HTuple areaColumn;
					HOperatorSet.AreaCenter(region, out area, out areaRow, out areaColumn);
					bool flag = area.Length == 0 || area.D <= 0.0;
					if (!flag)
					{
						HTuple row;
						HTuple column;
						HTuple row2;
						HTuple column2;
						HOperatorSet.SmallestRectangle1(region, out row, out column, out row2, out column2);
						double width = column2.D - column.D + 1.0;
						double height = row2.D - row.D + 1.0;
						double centerRow = (row.D + row2.D) / 2.0;
						double centerColumn = (column.D + column2.D) / 2.0;
						bool flag2 = width < config.MinWidth || width > config.MaxWidth || height < config.MinHeight || height > config.MaxHeight;
						if (!flag2)
						{
							candidates.Add(new FindBoundingBoxCandidate
							{
								RegionIndex = i,
								Row = centerRow,
								Column = centerColumn,
								Row1 = row.D,
								Column1 = column.D,
								Row2 = row2.D,
								Column2 = column2.D,
								Width = width,
								Height = height,
								Area = area.D,
								Points = this.CalculatePoints(row.D, column.D, row2.D, column2.D)
							});
						}
					}
				}
				finally
				{
					if (region != null)
					{
						region.Dispose();
					}
				}
				IL_1C6:
				i++;
				continue;
				goto IL_1C6;
			}
		}

		// Token: 0x06000639 RID: 1593 RVA: 0x0001F1C4 File Offset: 0x0001D3C4
		private void AssignGrid(List<FindBoundingBoxCandidate> candidates, double rowSpacing, double columnSpacing)
		{
			List<FindBoundingBoxCandidate> sorted = (from x in candidates
			orderby x.Row, x.Column
			select x).ToList<FindBoundingBoxCandidate>();
			List<List<FindBoundingBoxCandidate>> rows = new List<List<FindBoundingBoxCandidate>>();
			List<FindBoundingBoxCandidate> current = new List<FindBoundingBoxCandidate>();
			foreach (FindBoundingBoxCandidate candidate in sorted)
			{
				bool flag = current.Count == 0;
				if (flag)
				{
					current.Add(candidate);
				}
				else
				{
					double meanRow = current.Average((FindBoundingBoxCandidate x) => x.Row);
					bool flag2 = Math.Abs(candidate.Row - meanRow) <= rowSpacing;
					if (flag2)
					{
						current.Add(candidate);
					}
					else
					{
						rows.Add(current);
						current = new List<FindBoundingBoxCandidate>
						{
							candidate
						};
					}
				}
			}
			bool flag3 = current.Count > 0;
			if (flag3)
			{
				rows.Add(current);
			}
			for (int rowIndex = 0; rowIndex < rows.Count; rowIndex++)
			{
				List<FindBoundingBoxCandidate> rowItems = (from x in rows[rowIndex]
				orderby x.Column
				select x).ToList<FindBoundingBoxCandidate>();
				for (int columnIndex = 0; columnIndex < rowItems.Count; columnIndex++)
				{
					rowItems[columnIndex].GridRow = rowIndex;
				}
				this.AssignColumns(rowItems, columnSpacing);
			}
		}

		// Token: 0x0600063A RID: 1594 RVA: 0x0001F398 File Offset: 0x0001D598
		private void AssignColumns(List<FindBoundingBoxCandidate> rowItems, double columnSpacing)
		{
			List<FindBoundingBoxCandidate> sorted = (from x in rowItems
			orderby x.Column
			select x).ToList<FindBoundingBoxCandidate>();
			List<List<FindBoundingBoxCandidate>> columns = new List<List<FindBoundingBoxCandidate>>();
			List<FindBoundingBoxCandidate> current = new List<FindBoundingBoxCandidate>();
			foreach (FindBoundingBoxCandidate candidate in sorted)
			{
				bool flag = current.Count == 0;
				if (flag)
				{
					current.Add(candidate);
				}
				else
				{
					double meanColumn = current.Average((FindBoundingBoxCandidate x) => x.Column);
					bool flag2 = Math.Abs(candidate.Column - meanColumn) <= columnSpacing;
					if (flag2)
					{
						current.Add(candidate);
					}
					else
					{
						columns.Add(current);
						current = new List<FindBoundingBoxCandidate>
						{
							candidate
						};
					}
				}
			}
			bool flag3 = current.Count > 0;
			if (flag3)
			{
				columns.Add(current);
			}
			for (int columnIndex = 0; columnIndex < columns.Count; columnIndex++)
			{
				foreach (FindBoundingBoxCandidate candidate2 in columns[columnIndex])
				{
					candidate2.GridColumn = columnIndex;
				}
			}
		}

		// Token: 0x0600063B RID: 1595 RVA: 0x0001F524 File Offset: 0x0001D724
		private HObject CreateBoxRegions(IEnumerable<FindBoundingBoxCandidate> candidates)
		{
			HObject boxes = null;
			HObject result;
			try
			{
				HOperatorSet.GenEmptyObj(out boxes);
				foreach (FindBoundingBoxCandidate candidate in candidates)
				{
					HObject box = null;
					HObject concat = null;
					try
					{
						box = this.CreateBoxRegion(candidate);
						HOperatorSet.ConcatObj(boxes, box, out concat);
						boxes.Dispose();
						boxes = concat;
						concat = null;
					}
					finally
					{
						if (box != null)
						{
							box.Dispose();
						}
						if (concat != null)
						{
							concat.Dispose();
						}
					}
				}
				result = boxes;
			}
			catch
			{
				if (boxes != null)
				{
					boxes.Dispose();
				}
				throw;
			}
			return result;
		}

		// Token: 0x0600063C RID: 1596 RVA: 0x0001F5EC File Offset: 0x0001D7EC
		private HObject CreateBoxRegion(FindBoundingBoxCandidate candidate)
		{
			HObject box;
			HOperatorSet.GenRectangle1(out box, candidate.Row1, candidate.Column1, candidate.Row2, candidate.Column2);
			return box;
		}

		// Token: 0x0600063D RID: 1597 RVA: 0x0001F634 File Offset: 0x0001D834
		private FindBoundingBoxPointSet CalculatePoints(double row1, double column1, double row2, double column2)
		{
			return new FindBoundingBoxPointSet
			{
				TopLeftRow = row1,
				TopLeftColumn = column1,
				TopRightRow = row1,
				TopRightColumn = column2,
				BottomRightRow = row2,
				BottomRightColumn = column2,
				BottomLeftRow = row2,
				BottomLeftColumn = column1,
				CenterRow = (row1 + row2) / 2.0,
				CenterColumn = (column1 + column2) / 2.0
			};
		}

		// Token: 0x0600063E RID: 1598 RVA: 0x0001F6B8 File Offset: 0x0001D8B8
		private HObject GenRegionFromRoi(RoiData roi, HObject image, bool applyMaskMode)
		{
			HObject region;
			switch (roi.RoiType)
			{
			case RoiType.Rectangle1:
				HOperatorSet.GenRectangle1(out region, Math.Min(roi.Row1, roi.Row2), Math.Min(roi.Col1, roi.Col2), Math.Max(roi.Row1, roi.Row2), Math.Max(roi.Col1, roi.Col2));
				goto IL_160;
			case RoiType.Rectangle2:
				HOperatorSet.GenRectangle2(out region, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
				goto IL_160;
			case RoiType.Circle:
				HOperatorSet.GenCircle(out region, roi.CenterRow, roi.CenterCol, roi.Radius);
				goto IL_160;
			case RoiType.Ellipse:
				HOperatorSet.GenEllipse(out region, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
				goto IL_160;
			case RoiType.Polygon:
			case RoiType.FreeDraw:
			case RoiType.DrawRegion:
				region = this.GenContourRegion(roi);
				goto IL_160;
			}
			HOperatorSet.GenEmptyObj(out region);
			IL_160:
			bool flag = !applyMaskMode || roi.MaskMode != RoiMaskMode.Outside;
			HObject result;
			if (flag)
			{
				result = region;
			}
			else
			{
				result = this.InvertRegionInImage(region, image);
			}
			return result;
		}

		// Token: 0x0600063F RID: 1599 RVA: 0x0001F850 File Offset: 0x0001DA50
		private HObject GenContourRegion(RoiData roi)
		{
			bool flag = roi.Rows == null || roi.Cols == null || roi.Rows.Count < 3 || roi.Rows.Count != roi.Cols.Count;
			HObject result;
			if (flag)
			{
				HObject empty;
				HOperatorSet.GenEmptyObj(out empty);
				result = empty;
			}
			else
			{
				HObject contour = null;
				try
				{
					HOperatorSet.GenContourPolygonXld(out contour, new HTuple(roi.Rows.ToArray()), new HTuple(roi.Cols.ToArray()));
					HObject region;
					HOperatorSet.GenRegionContourXld(contour, out region, "filled");
					result = region;
				}
				finally
				{
					if (contour != null)
					{
						contour.Dispose();
					}
				}
			}
			return result;
		}

		// Token: 0x06000640 RID: 1600 RVA: 0x0001F910 File Offset: 0x0001DB10
		private HObject InvertRegionInImage(HObject region, HObject image)
		{
			HObject fullRegion = null;
			HObject outside = null;
			HObject result;
			try
			{
				HTuple width;
				HTuple height;
				HOperatorSet.GetImageSize(image, out width, out height);
				HOperatorSet.GenRectangle1(out fullRegion, 0, 0, height.D - 1.0, width.D - 1.0);
				HOperatorSet.Difference(fullRegion, region, out outside);
				region.Dispose();
				region = null;
				result = outside;
			}
			finally
			{
				if (fullRegion != null)
				{
					fullRegion.Dispose();
				}
				if (region != null)
				{
					region.Dispose();
				}
			}
			return result;
		}

		// Token: 0x06000641 RID: 1601 RVA: 0x0001F9B4 File Offset: 0x0001DBB4
		private RoiData CreateTransformedRoi(RoiData roi, ToolVision tool)
		{
			bool flag = roi == null;
			RoiData result;
			if (flag)
			{
				result = null;
			}
			else
			{
				FindBoundingBoxProcessor.MasterTransform transform = this.GetMasterTransform(roi, tool);
				switch (roi.RoiType)
				{
				case RoiType.Rectangle1:
					return this.TransformRectangle1Roi(roi, transform);
				case RoiType.Rectangle2:
				{
					Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
					RoiData copy = this.CopyBaseRoi(roi);
					copy.CenterRow = center.Item1;
					copy.CenterCol = center.Item2;
					copy.Phi = roi.Phi + transform.Angle;
					return copy;
				}
				case RoiType.Circle:
				{
					Tuple<double, double> center2 = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
					RoiData copy2 = this.CopyBaseRoi(roi);
					copy2.CenterRow = center2.Item1;
					copy2.CenterCol = center2.Item2;
					return copy2;
				}
				case RoiType.Ellipse:
				{
					Tuple<double, double> center3 = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
					RoiData copy3 = this.CopyBaseRoi(roi);
					copy3.CenterRow = center3.Item1;
					copy3.CenterCol = center3.Item2;
					copy3.Phi = roi.Phi + transform.Angle;
					return copy3;
				}
				case RoiType.Polygon:
				case RoiType.FreeDraw:
				case RoiType.DrawRegion:
					return this.TransformPointListRoi(roi, transform);
				}
				result = this.CopyBaseRoi(roi);
			}
			return result;
		}

		// Token: 0x06000642 RID: 1602 RVA: 0x0001FB2C File Offset: 0x0001DD2C
		private RoiData TransformRectangle1Roi(RoiData roi, FindBoundingBoxProcessor.MasterTransform transform)
		{
			double row = Math.Min(roi.Row1, roi.Row2);
			double row2 = Math.Max(roi.Row1, roi.Row2);
			double col = Math.Min(roi.Col1, roi.Col2);
			double col2 = Math.Max(roi.Col1, roi.Col2);
			bool flag = transform == null || Math.Abs(transform.Angle) <= 1E-06;
			RoiData result;
			if (flag)
			{
				Tuple<double, double> topLeft = this.TransformPoint(row, col, transform);
				Tuple<double, double> bottomRight = this.TransformPoint(row2, col2, transform);
				RoiData rectangle = this.CopyBaseRoi(roi);
				rectangle.Row1 = topLeft.Item1;
				rectangle.Col1 = topLeft.Item2;
				rectangle.Row2 = bottomRight.Item1;
				rectangle.Col2 = bottomRight.Item2;
				result = rectangle;
			}
			else
			{
				Tuple<double, double>[] points = new Tuple<double, double>[]
				{
					this.TransformPoint(row, col, transform),
					this.TransformPoint(row, col2, transform),
					this.TransformPoint(row2, col2, transform),
					this.TransformPoint(row2, col, transform)
				};
				RoiData copy = this.CopyBaseRoi(roi);
				copy.RoiType = RoiType.Polygon;
				copy.Rows = (from x in points
				select x.Item1).ToList<double>();
				copy.Cols = (from x in points
				select x.Item2).ToList<double>();
				result = copy;
			}
			return result;
		}

		// Token: 0x06000643 RID: 1603 RVA: 0x0001FCC4 File Offset: 0x0001DEC4
		private RoiData TransformPointListRoi(RoiData roi, FindBoundingBoxProcessor.MasterTransform transform)
		{
			RoiData copy = this.CopyBaseRoi(roi);
			copy.Rows = new List<double>();
			copy.Cols = new List<double>();
			bool flag = roi.Rows == null || roi.Cols == null;
			RoiData result;
			if (flag)
			{
				result = copy;
			}
			else
			{
				int count = Math.Min(roi.Rows.Count, roi.Cols.Count);
				for (int i = 0; i < count; i++)
				{
					Tuple<double, double> point = this.TransformPoint(roi.Rows[i], roi.Cols[i], transform);
					copy.Rows.Add(point.Item1);
					copy.Cols.Add(point.Item2);
				}
				result = copy;
			}
			return result;
		}

		// Token: 0x06000644 RID: 1604 RVA: 0x0001FD94 File Offset: 0x0001DF94
		private RoiData CopyBaseRoi(RoiData roi)
		{
			return new RoiData
			{
				RoiType = roi.RoiType,
				Name = roi.Name,
				IsEnabled = roi.IsEnabled,
				MaskMode = roi.MaskMode,
				Polarity = roi.Polarity,
				Description = roi.Description,
				MasterToolName = roi.MasterToolName,
				MasterPositionToolName = roi.MasterPositionToolName,
				MasterAngleToolName = roi.MasterAngleToolName,
				Row1 = roi.Row1,
				Col1 = roi.Col1,
				Row2 = roi.Row2,
				Col2 = roi.Col2,
				CenterRow = roi.CenterRow,
				CenterCol = roi.CenterCol,
				Radius = roi.Radius,
				Phi = roi.Phi,
				Radius1 = roi.Radius1,
				Radius2 = roi.Radius2,
				Rows = ((roi.Rows == null) ? new List<double>() : roi.Rows.ToList<double>()),
				Cols = ((roi.Cols == null) ? new List<double>() : roi.Cols.ToList<double>())
			};
		}

		// Token: 0x06000645 RID: 1605 RVA: 0x0001FEE4 File Offset: 0x0001E0E4
		private FindBoundingBoxProcessor.MasterTransform GetMasterTransform(RoiData roi, ToolVision tool)
		{
			FindBoundingBoxProcessor.MasterTransform transform = new FindBoundingBoxProcessor.MasterTransform();
			bool flag = roi == null || ((tool != null) ? tool.ParentTurnSnap : null) == null;
			FindBoundingBoxProcessor.MasterTransform result;
			if (flag)
			{
				result = transform;
			}
			else
			{
				ShapeModelToolTrain positionTrain = this.GetMasterTrain(tool, this.GetMasterPositionToolName(roi), true);
				bool flag2 = positionTrain != null;
				if (flag2)
				{
					transform.Row = positionTrain.LastRow - positionTrain.MasterRow;
					transform.Column = positionTrain.LastColumn - positionTrain.MasterColumn;
				}
				ShapeModelToolTrain angleTrain = this.GetMasterTrain(tool, this.GetMasterAngleToolName(roi), false);
				bool flag3 = angleTrain != null;
				if (flag3)
				{
					transform.Angle = angleTrain.LastAngle - angleTrain.MasterAngle;
					transform.MasterRow = angleTrain.MasterRow;
					transform.MasterColumn = angleTrain.MasterColumn;
				}
				result = transform;
			}
			return result;
		}

		// Token: 0x06000646 RID: 1606 RVA: 0x0001FFB0 File Offset: 0x0001E1B0
		private ShapeModelToolTrain GetMasterTrain(ToolVision tool, string masterToolName, bool isPositionMaster)
		{
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || string.IsNullOrWhiteSpace(masterToolName) || masterToolName == "None";
			ShapeModelToolTrain result;
			if (flag)
			{
				result = null;
			}
			else
			{
				bool isMasterFound;
				bool flag2 = this._currentMasterMatchStates != null && this._currentMasterMatchStates.TryGetValue(masterToolName, out isMasterFound) && !isMasterFound;
				if (flag2)
				{
					result = null;
				}
				else
				{
					ToolVision masterTool = tool.ParentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || (isPositionMaster && x.ToolType == ToolType.CircleMaster) || (isPositionMaster && x.ToolType == ToolType.BoundingBoxMaster) || (x.ToolType == ToolType.MinAreaMaster || (isPositionMaster && x.ToolType == ToolType.IntersectingLines)) || (!isPositionMaster && x.ToolType == ToolType.AngleSelector)) && x.Name == masterToolName);
					ShapeModelToolTrain train = ((masterTool != null) ? masterTool.TrainModel : null) as ShapeModelToolTrain;
					bool flag3 = train == null || !train.HasMasterDefined;
					if (flag3)
					{
						result = null;
					}
					else
					{
						result = train;
					}
				}
			}
			return result;
		}

		// Token: 0x06000647 RID: 1607 RVA: 0x000200B4 File Offset: 0x0001E2B4
		private Dictionary<string, double> UpdateMasterShapeModels(HObject image, ToolVision tool, RoiData roi)
		{
			Dictionary<string, double> processingTimes = new Dictionary<string, double>();
			this._currentMasterMatchStates = new Dictionary<string, bool>();
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || roi == null;
			Dictionary<string, double> result;
			if (flag)
			{
				result = processingTimes;
			}
			else
			{
				List<string> masterNames = (from x in new string[]
				{
					this.GetMasterPositionToolName(roi),
					this.GetMasterAngleToolName(roi)
				}
				where !string.IsNullOrWhiteSpace(x) && x != "None"
				select x).Distinct<string>().ToList<string>();
				bool flag2 = masterNames.Count == 0;
				if (flag2)
				{
					result = processingTimes;
				}
				else
				{
					ShapeModelProcessor shapeProcessor = new ShapeModelProcessor();
					using (List<string>.Enumerator enumerator = masterNames.GetEnumerator())
					{
						Func<ToolVision, bool> <>9__1;
						while (enumerator.MoveNext())
						{
							string masterName = enumerator.Current;
							Stopwatch stopwatch = Stopwatch.StartNew();
							IEnumerable<ToolVision> tools = tool.ParentTurnSnap.Tools;
							Func<ToolVision, bool> predicate;
							if ((predicate = <>9__1) == null)
							{
								predicate = (<>9__1 = ((ToolVision x) => x != tool));
							}
							ToolVision masterTool = tools.TakeWhile(predicate).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.BoundingBoxMaster || x.ToolType == ToolType.MinAreaMaster || x.ToolType == ToolType.IntersectingLines || x.ToolType == ToolType.AngleSelector) && x.Name == masterName);
							bool flag3 = masterTool == null;
							if (flag3)
							{
								stopwatch.Stop();
								processingTimes[masterName] = stopwatch.Elapsed.TotalMilliseconds;
								this._currentMasterMatchStates[masterName] = false;
							}
							else
							{
								ShapeMatchResult matchResult;
								bool flag4 = this.TryGetCachedMasterResult(masterName, out matchResult);
								if (flag4)
								{
									this.ApplyMasterResultToTrain(masterTool, matchResult);
									stopwatch.Stop();
									processingTimes[masterName] = Math.Max(0.0, matchResult.ProcessingTimeMs);
									this._currentMasterMatchStates[masterName] = matchResult.IsSuccess;
								}
								else
								{
									bool flag5 = masterTool.ToolType == ToolType.CircleMaster;
									if (flag5)
									{
										matchResult = new CircleMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
									}
									else
									{
										bool flag6 = masterTool.ToolType == ToolType.BoundingBoxMaster;
										if (flag6)
										{
											matchResult = new BoundingBoxMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
										}
										else
										{
											bool flag7 = masterTool.ToolType == ToolType.MinAreaMaster;
											if (flag7)
											{
												matchResult = new MinAreaMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
											}
											else
											{
												bool flag8 = masterTool.ToolType == ToolType.IntersectingLines;
												if (flag8)
												{
													matchResult = new IntersectingLinesProcessor(null, this._cachedMasterResults).Match(image, masterTool);
												}
												else
												{
													bool flag9 = masterTool.ToolType == ToolType.AngleSelector;
													if (flag9)
													{
														matchResult = new AngleSelectorProcessor(null, this._cachedMasterResults).Match(image, masterTool);
													}
													else
													{
														matchResult = shapeProcessor.Match(image, masterTool);
													}
												}
											}
										}
									}
									stopwatch.Stop();
									processingTimes[masterName] = stopwatch.Elapsed.TotalMilliseconds;
									this._currentMasterMatchStates[masterName] = (matchResult != null && matchResult.IsSuccess);
								}
							}
						}
					}
					result = processingTimes;
				}
			}
			return result;
		}

		// Token: 0x06000648 RID: 1608 RVA: 0x0002040C File Offset: 0x0001E60C
		private bool TryGetCachedMasterResult(string masterName, out ShapeMatchResult result)
		{
			result = null;
			bool flag = this._cachedMasterResults == null || string.IsNullOrWhiteSpace(masterName);
			return !flag && this._cachedMasterResults.TryGetValue(masterName, out result) && result != null;
		}

		// Token: 0x06000649 RID: 1609 RVA: 0x00020454 File Offset: 0x0001E654
		private void ApplyMasterResultToTrain(ToolVision masterTool, ShapeMatchResult result)
		{
			bool flag = masterTool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				ShapeModelToolTrain train = masterTool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (!flag2)
				{
					train.LastRow = result.Row;
					train.LastColumn = result.Column;
					train.LastAngle = result.Angle;
					train.LastScore = result.Score;
				}
			}
		}

		// Token: 0x0600064A RID: 1610 RVA: 0x000204C8 File Offset: 0x0001E6C8
		private string GetMasterPositionToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && roi.MasterPositionToolName != "None";
				if (flag2)
				{
					result = roi.MasterPositionToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x0600064B RID: 1611 RVA: 0x00020558 File Offset: 0x0001E758
		private string GetMasterAngleToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && roi.MasterAngleToolName != "None";
				if (flag2)
				{
					result = roi.MasterAngleToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x0600064C RID: 1612 RVA: 0x000205E8 File Offset: 0x0001E7E8
		private double GetMasterProcessingTime(string masterPositionToolName, string masterAngleToolName)
		{
			double processingTime = 0.0;
			foreach (string masterName in (from x in new string[]
			{
				masterPositionToolName,
				masterAngleToolName
			}
			where !string.IsNullOrWhiteSpace(x) && x != "None"
			select x).Distinct<string>())
			{
				double time;
				bool flag = this._currentMasterProcessingTimes != null && this._currentMasterProcessingTimes.TryGetValue(masterName, out time);
				if (flag)
				{
					processingTime += time;
				}
			}
			return processingTime;
		}

		// Token: 0x0600064D RID: 1613 RVA: 0x0002069C File Offset: 0x0001E89C
		private Tuple<double, double> TransformPoint(double row, double column, FindBoundingBoxProcessor.MasterTransform transform)
		{
			bool flag = transform == null;
			Tuple<double, double> result;
			if (flag)
			{
				result = Tuple.Create<double, double>(row, column);
			}
			else
			{
				double cos = Math.Cos(transform.Angle);
				double sin = Math.Sin(transform.Angle);
				double relRow = row - transform.MasterRow;
				double relColumn = column - transform.MasterColumn;
				double newRow = transform.MasterRow + transform.Row + relRow * cos - relColumn * sin;
				double newColumn = transform.MasterColumn + transform.Column + relRow * sin + relColumn * cos;
				result = Tuple.Create<double, double>(newRow, newColumn);
			}
			return result;
		}

		// Token: 0x04000280 RID: 640
		private readonly IDictionary<string, ShapeMatchResult> _cachedMasterResults;

		// Token: 0x04000281 RID: 641
		private Dictionary<string, double> _currentMasterProcessingTimes;

		// Token: 0x04000282 RID: 642
		private Dictionary<string, bool> _currentMasterMatchStates;

		// Token: 0x02000305 RID: 773
		private class MasterTransform
		{
			// Token: 0x17000B28 RID: 2856
			// (get) Token: 0x0600274A RID: 10058 RVA: 0x000E0587 File Offset: 0x000DE787
			// (set) Token: 0x0600274B RID: 10059 RVA: 0x000E058F File Offset: 0x000DE78F
			public double Row { get; set; }

			// Token: 0x17000B29 RID: 2857
			// (get) Token: 0x0600274C RID: 10060 RVA: 0x000E0598 File Offset: 0x000DE798
			// (set) Token: 0x0600274D RID: 10061 RVA: 0x000E05A0 File Offset: 0x000DE7A0
			public double Column { get; set; }

			// Token: 0x17000B2A RID: 2858
			// (get) Token: 0x0600274E RID: 10062 RVA: 0x000E05A9 File Offset: 0x000DE7A9
			// (set) Token: 0x0600274F RID: 10063 RVA: 0x000E05B1 File Offset: 0x000DE7B1
			public double Angle { get; set; }

			// Token: 0x17000B2B RID: 2859
			// (get) Token: 0x06002750 RID: 10064 RVA: 0x000E05BA File Offset: 0x000DE7BA
			// (set) Token: 0x06002751 RID: 10065 RVA: 0x000E05C2 File Offset: 0x000DE7C2
			public double MasterRow { get; set; }

			// Token: 0x17000B2C RID: 2860
			// (get) Token: 0x06002752 RID: 10066 RVA: 0x000E05CB File Offset: 0x000DE7CB
			// (set) Token: 0x06002753 RID: 10067 RVA: 0x000E05D3 File Offset: 0x000DE7D3
			public double MasterColumn { get; set; }
		}
	}
}
