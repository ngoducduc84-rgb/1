﻿using System;
using System.Collections.Generic;
using HalconDotNet;
using VisionMachine.Models.Roi;

namespace VisionMachine.VisionTools.FindBoundingBox
{
	// Token: 0x02000088 RID: 136
	public class FindBoundingBoxResult : IDisposable
	{
		// Token: 0x1700022D RID: 557
		// (get) Token: 0x0600067E RID: 1662 RVA: 0x000208C1 File Offset: 0x0001EAC1
		// (set) Token: 0x0600067F RID: 1663 RVA: 0x000208C9 File Offset: 0x0001EAC9
		public bool IsSuccess { get; set; }

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x06000680 RID: 1664 RVA: 0x000208D2 File Offset: 0x0001EAD2
		// (set) Token: 0x06000681 RID: 1665 RVA: 0x000208DA File Offset: 0x0001EADA
		public string Message { get; set; }

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000682 RID: 1666 RVA: 0x000208E3 File Offset: 0x0001EAE3
		// (set) Token: 0x06000683 RID: 1667 RVA: 0x000208EB File Offset: 0x0001EAEB
		public string ToolName { get; set; }

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000684 RID: 1668 RVA: 0x000208F4 File Offset: 0x0001EAF4
		// (set) Token: 0x06000685 RID: 1669 RVA: 0x000208FC File Offset: 0x0001EAFC
		public string RoiName { get; set; }

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000686 RID: 1670 RVA: 0x00020905 File Offset: 0x0001EB05
		// (set) Token: 0x06000687 RID: 1671 RVA: 0x0002090D File Offset: 0x0001EB0D
		public RoiData Roi { get; set; }

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x06000688 RID: 1672 RVA: 0x00020916 File Offset: 0x0001EB16
		public List<FindBoundingBoxCandidate> Candidates { get; } = new List<FindBoundingBoxCandidate>();

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x06000689 RID: 1673 RVA: 0x0002091E File Offset: 0x0001EB1E
		// (set) Token: 0x0600068A RID: 1674 RVA: 0x00020926 File Offset: 0x0001EB26
		public FindBoundingBoxCandidate SelectedBox { get; set; }

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x0600068B RID: 1675 RVA: 0x0002092F File Offset: 0x0001EB2F
		// (set) Token: 0x0600068C RID: 1676 RVA: 0x00020937 File Offset: 0x0001EB37
		public HObject RoiRegion { get; set; }

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x0600068D RID: 1677 RVA: 0x00020940 File Offset: 0x0001EB40
		// (set) Token: 0x0600068E RID: 1678 RVA: 0x00020948 File Offset: 0x0001EB48
		public HObject ThresholdRegion { get; set; }

		// Token: 0x17000236 RID: 566
		// (get) Token: 0x0600068F RID: 1679 RVA: 0x00020951 File Offset: 0x0001EB51
		// (set) Token: 0x06000690 RID: 1680 RVA: 0x00020959 File Offset: 0x0001EB59
		public HObject AllBoxRegions { get; set; }

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000691 RID: 1681 RVA: 0x00020962 File Offset: 0x0001EB62
		// (set) Token: 0x06000692 RID: 1682 RVA: 0x0002096A File Offset: 0x0001EB6A
		public HObject SelectedBoxRegion { get; set; }

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000693 RID: 1683 RVA: 0x00020973 File Offset: 0x0001EB73
		// (set) Token: 0x06000694 RID: 1684 RVA: 0x0002097B File Offset: 0x0001EB7B
		public string MasterPositionToolName { get; set; }

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000695 RID: 1685 RVA: 0x00020984 File Offset: 0x0001EB84
		// (set) Token: 0x06000696 RID: 1686 RVA: 0x0002098C File Offset: 0x0001EB8C
		public string MasterAngleToolName { get; set; }

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000697 RID: 1687 RVA: 0x00020995 File Offset: 0x0001EB95
		// (set) Token: 0x06000698 RID: 1688 RVA: 0x0002099D File Offset: 0x0001EB9D
		public double MasterProcessingTimeMs { get; set; }

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x06000699 RID: 1689 RVA: 0x000209A6 File Offset: 0x0001EBA6
		// (set) Token: 0x0600069A RID: 1690 RVA: 0x000209AE File Offset: 0x0001EBAE
		public string InputSourceToolName { get; set; }

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x0600069B RID: 1691 RVA: 0x000209B7 File Offset: 0x0001EBB7
		// (set) Token: 0x0600069C RID: 1692 RVA: 0x000209BF File Offset: 0x0001EBBF
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x0600069D RID: 1693 RVA: 0x000209C8 File Offset: 0x0001EBC8
		// (set) Token: 0x0600069E RID: 1694 RVA: 0x000209D0 File Offset: 0x0001EBD0
		public double ProcessingTimeMs { get; set; }

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x0600069F RID: 1695 RVA: 0x000209D9 File Offset: 0x0001EBD9
		// (set) Token: 0x060006A0 RID: 1696 RVA: 0x000209E1 File Offset: 0x0001EBE1
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x060006A1 RID: 1697 RVA: 0x000209EC File Offset: 0x0001EBEC
		public void Dispose()
		{
			HObject roiRegion = this.RoiRegion;
			if (roiRegion != null)
			{
				roiRegion.Dispose();
			}
			HObject thresholdRegion = this.ThresholdRegion;
			if (thresholdRegion != null)
			{
				thresholdRegion.Dispose();
			}
			HObject allBoxRegions = this.AllBoxRegions;
			if (allBoxRegions != null)
			{
				allBoxRegions.Dispose();
			}
			HObject selectedBoxRegion = this.SelectedBoxRegion;
			if (selectedBoxRegion != null)
			{
				selectedBoxRegion.Dispose();
			}
		}
	}
}
