﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using Newtonsoft.Json;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindBoundingBox
{
	// Token: 0x0200008A RID: 138
	public class FindBoundingBoxToolConfig : ToolConfigBase
	{
		// Token: 0x1700023F RID: 575
		// (get) Token: 0x060006A8 RID: 1704 RVA: 0x00020F04 File Offset: 0x0001F104
		// (set) Token: 0x060006A9 RID: 1705 RVA: 0x00020F0C File Offset: 0x0001F10C
		public ImageInputLink InputLink { get; set; } = new ImageInputLink();

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x060006AA RID: 1706 RVA: 0x00020F18 File Offset: 0x0001F118
		// (set) Token: 0x060006AB RID: 1707 RVA: 0x00020F30 File Offset: 0x0001F130
		[DisplayName("Threshold Polarity")]
		public FindBoundingBoxPolarity ThresholdPolarity
		{
			get
			{
				return this._thresholdPolarity;
			}
			set
			{
				this.SetValue<FindBoundingBoxPolarity>(ref this._thresholdPolarity, value, "ThresholdPolarity");
			}
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x060006AC RID: 1708 RVA: 0x00020F48 File Offset: 0x0001F148
		// (set) Token: 0x060006AD RID: 1709 RVA: 0x00020F60 File Offset: 0x0001F160
		[DisplayName("Threshold Min")]
		public double ThresholdMin
		{
			get
			{
				return this._thresholdMin;
			}
			set
			{
				this.SetValue<double>(ref this._thresholdMin, value, "ThresholdMin");
			}
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x060006AE RID: 1710 RVA: 0x00020F78 File Offset: 0x0001F178
		// (set) Token: 0x060006AF RID: 1711 RVA: 0x00020F90 File Offset: 0x0001F190
		[DisplayName("Threshold Max")]
		public double ThresholdMax
		{
			get
			{
				return this._thresholdMax;
			}
			set
			{
				this.SetValue<double>(ref this._thresholdMax, value, "ThresholdMax");
			}
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x060006B0 RID: 1712 RVA: 0x00020FA8 File Offset: 0x0001F1A8
		// (set) Token: 0x060006B1 RID: 1713 RVA: 0x00020FC0 File Offset: 0x0001F1C0
		[DisplayName("Min Area")]
		public double MinArea
		{
			get
			{
				return this._minArea;
			}
			set
			{
				this.SetValue<double>(ref this._minArea, value, "MinArea");
			}
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x060006B2 RID: 1714 RVA: 0x00020FD8 File Offset: 0x0001F1D8
		// (set) Token: 0x060006B3 RID: 1715 RVA: 0x00020FF0 File Offset: 0x0001F1F0
		[DisplayName("Max Area")]
		public double MaxArea
		{
			get
			{
				return this._maxArea;
			}
			set
			{
				this.SetValue<double>(ref this._maxArea, value, "MaxArea");
			}
		}

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x060006B4 RID: 1716 RVA: 0x00021008 File Offset: 0x0001F208
		// (set) Token: 0x060006B5 RID: 1717 RVA: 0x00021020 File Offset: 0x0001F220
		[DisplayName("Min Width")]
		public double MinWidth
		{
			get
			{
				return this._minWidth;
			}
			set
			{
				this.SetValue<double>(ref this._minWidth, value, "MinWidth");
			}
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x060006B6 RID: 1718 RVA: 0x00021038 File Offset: 0x0001F238
		// (set) Token: 0x060006B7 RID: 1719 RVA: 0x00021050 File Offset: 0x0001F250
		[DisplayName("Max Width")]
		public double MaxWidth
		{
			get
			{
				return this._maxWidth;
			}
			set
			{
				this.SetValue<double>(ref this._maxWidth, value, "MaxWidth");
			}
		}

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x060006B8 RID: 1720 RVA: 0x00021068 File Offset: 0x0001F268
		// (set) Token: 0x060006B9 RID: 1721 RVA: 0x00021080 File Offset: 0x0001F280
		[DisplayName("Min Height")]
		public double MinHeight
		{
			get
			{
				return this._minHeight;
			}
			set
			{
				this.SetValue<double>(ref this._minHeight, value, "MinHeight");
			}
		}

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x060006BA RID: 1722 RVA: 0x00021098 File Offset: 0x0001F298
		// (set) Token: 0x060006BB RID: 1723 RVA: 0x000210B0 File Offset: 0x0001F2B0
		[DisplayName("Max Height")]
		public double MaxHeight
		{
			get
			{
				return this._maxHeight;
			}
			set
			{
				this.SetValue<double>(ref this._maxHeight, value, "MaxHeight");
			}
		}

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x060006BC RID: 1724 RVA: 0x000210C8 File Offset: 0x0001F2C8
		// (set) Token: 0x060006BD RID: 1725 RVA: 0x000210E0 File Offset: 0x0001F2E0
		[DisplayName("Pick Row")]
		public int PickRow
		{
			get
			{
				return this._pickRow;
			}
			set
			{
				this.SetValue<int>(ref this._pickRow, (value < 0) ? 0 : value, "PickRow");
			}
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x060006BE RID: 1726 RVA: 0x00021100 File Offset: 0x0001F300
		// (set) Token: 0x060006BF RID: 1727 RVA: 0x00021118 File Offset: 0x0001F318
		[DisplayName("Pick Column")]
		public int PickColumn
		{
			get
			{
				return this._pickColumn;
			}
			set
			{
				this.SetValue<int>(ref this._pickColumn, (value < 0) ? 0 : value, "PickColumn");
			}
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x060006C0 RID: 1728 RVA: 0x00021138 File Offset: 0x0001F338
		// (set) Token: 0x060006C1 RID: 1729 RVA: 0x00021150 File Offset: 0x0001F350
		[DisplayName("Row Spacing")]
		public double RowSpacing
		{
			get
			{
				return this._rowSpacing;
			}
			set
			{
				this.SetValue<double>(ref this._rowSpacing, (value < 0.0) ? 0.0 : value, "RowSpacing");
			}
		}

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x060006C2 RID: 1730 RVA: 0x00021180 File Offset: 0x0001F380
		// (set) Token: 0x060006C3 RID: 1731 RVA: 0x00021198 File Offset: 0x0001F398
		[DisplayName("Column Spacing")]
		public double ColumnSpacing
		{
			get
			{
				return this._columnSpacing;
			}
			set
			{
				this.SetValue<double>(ref this._columnSpacing, (value < 0.0) ? 0.0 : value, "ColumnSpacing");
			}
		}

		// Token: 0x1700024D RID: 589
		// (get) Token: 0x060006C4 RID: 1732 RVA: 0x000211C8 File Offset: 0x0001F3C8
		// (set) Token: 0x060006C5 RID: 1733 RVA: 0x000211E0 File Offset: 0x0001F3E0
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				this.SetValue<bool>(ref this._showRoi, value, "ShowRoi");
			}
		}

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x060006C6 RID: 1734 RVA: 0x000211F8 File Offset: 0x0001F3F8
		// (set) Token: 0x060006C7 RID: 1735 RVA: 0x00021210 File Offset: 0x0001F410
		[DisplayName("Show Threshold")]
		public bool ShowThreshold
		{
			get
			{
				return this._showThreshold;
			}
			set
			{
				this.SetValue<bool>(ref this._showThreshold, value, "ShowThreshold");
			}
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x060006C8 RID: 1736 RVA: 0x00021228 File Offset: 0x0001F428
		// (set) Token: 0x060006C9 RID: 1737 RVA: 0x00021240 File Offset: 0x0001F440
		[DisplayName("Show All Boxes")]
		public bool ShowAllBoxes
		{
			get
			{
				return this._showAllBoxes;
			}
			set
			{
				this.SetValue<bool>(ref this._showAllBoxes, value, "ShowAllBoxes");
			}
		}

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x060006CA RID: 1738 RVA: 0x00021258 File Offset: 0x0001F458
		// (set) Token: 0x060006CB RID: 1739 RVA: 0x00021270 File Offset: 0x0001F470
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				this.SetValue<bool>(ref this._showText, value, "ShowText");
			}
		}

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x060006CC RID: 1740 RVA: 0x00021288 File Offset: 0x0001F488
		// (set) Token: 0x060006CD RID: 1741 RVA: 0x000212A0 File Offset: 0x0001F4A0
		[DisplayName("Text Size")]
		public int TextSize
		{
			get
			{
				return this._textSize;
			}
			set
			{
				this.SetValue<int>(ref this._textSize, (value < 1) ? 1 : value, "TextSize");
			}
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x060006CE RID: 1742 RVA: 0x000212C0 File Offset: 0x0001F4C0
		// (set) Token: 0x060006CF RID: 1743 RVA: 0x000212D8 File Offset: 0x0001F4D8
		[DisplayName("Text Color")]
		public string TextColor
		{
			get
			{
				return this._textColor;
			}
			set
			{
				bool flag = object.Equals(this._textColor, value);
				if (!flag)
				{
					this._textColor = value;
					this._textColorValue = this.ParseColor(value);
					base.OnPropertyChanged("TextColor");
					base.OnPropertyChanged("TextColorValue");
				}
			}
		}

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x060006D0 RID: 1744 RVA: 0x00021324 File Offset: 0x0001F524
		// (set) Token: 0x060006D1 RID: 1745 RVA: 0x0002133C File Offset: 0x0001F53C
		[Browsable(false)]
		[JsonIgnore]
		public Color TextColorValue
		{
			get
			{
				return this._textColorValue;
			}
			set
			{
				bool flag = this._textColorValue == value;
				if (!flag)
				{
					this._textColorValue = value;
					this._textColor = this.ToHalconColor(value);
					base.OnPropertyChanged("TextColorValue");
					base.OnPropertyChanged("TextColor");
				}
			}
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x060006D2 RID: 1746 RVA: 0x00021388 File Offset: 0x0001F588
		// (set) Token: 0x060006D3 RID: 1747 RVA: 0x000213A0 File Offset: 0x0001F5A0
		[DisplayName("Show Input Image")]
		public bool ShowInputImage
		{
			get
			{
				return this._showInputImage;
			}
			set
			{
				this.SetValue<bool>(ref this._showInputImage, value, "ShowInputImage");
			}
		}

		// Token: 0x060006D4 RID: 1748 RVA: 0x000213B8 File Offset: 0x0001F5B8
		private Color ParseColor(string color)
		{
			bool flag = string.IsNullOrWhiteSpace(color);
			Color result;
			if (flag)
			{
				result = Colors.Lime;
			}
			else
			{
				try
				{
					result = (Color)ColorConverter.ConvertFromString(color);
				}
				catch
				{
					result = Colors.Lime;
				}
			}
			return result;
		}

		// Token: 0x060006D5 RID: 1749 RVA: 0x00021404 File Offset: 0x0001F604
		private string ToHalconColor(Color color)
		{
			return "#" + color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x0002145C File Offset: 0x0001F65C
		private void SetValue<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
		{
			bool flag = object.Equals(field, value);
			if (!flag)
			{
				field = value;
				base.OnPropertyChanged(propertyName);
			}
		}

		// Token: 0x040002AC RID: 684
		private FindBoundingBoxPolarity _thresholdPolarity = FindBoundingBoxPolarity.DarkToLight;

		// Token: 0x040002AD RID: 685
		private double _thresholdMin = 100.0;

		// Token: 0x040002AE RID: 686
		private double _thresholdMax = 255.0;

		// Token: 0x040002AF RID: 687
		private double _minArea = 10.0;

		// Token: 0x040002B0 RID: 688
		private double _maxArea = 999999.0;

		// Token: 0x040002B1 RID: 689
		private double _minWidth = 0.0;

		// Token: 0x040002B2 RID: 690
		private double _maxWidth = 999999.0;

		// Token: 0x040002B3 RID: 691
		private double _minHeight = 0.0;

		// Token: 0x040002B4 RID: 692
		private double _maxHeight = 999999.0;

		// Token: 0x040002B5 RID: 693
		private int _pickRow = 0;

		// Token: 0x040002B6 RID: 694
		private int _pickColumn = 0;

		// Token: 0x040002B7 RID: 695
		private double _rowSpacing = 20.0;

		// Token: 0x040002B8 RID: 696
		private double _columnSpacing = 20.0;

		// Token: 0x040002B9 RID: 697
		private bool _showRoi = true;

		// Token: 0x040002BA RID: 698
		private bool _showThreshold = false;

		// Token: 0x040002BB RID: 699
		private bool _showAllBoxes = false;

		// Token: 0x040002BC RID: 700
		private bool _showText = true;

		// Token: 0x040002BD RID: 701
		private bool _showInputImage = false;

		// Token: 0x040002BE RID: 702
		private int _textSize = 14;

		// Token: 0x040002BF RID: 703
		private string _textColor = "green";

		// Token: 0x040002C0 RID: 704
		private Color _textColorValue = Colors.Lime;
	}
}
