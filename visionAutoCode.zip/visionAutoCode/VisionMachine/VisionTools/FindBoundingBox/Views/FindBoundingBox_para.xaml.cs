﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Windows.Media;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.FindBoundingBox.Views
{
	// Token: 0x0200008B RID: 139
	public partial class FindBoundingBox_para : System.Windows.Controls.UserControl, IStyleConnector
	{
		// Token: 0x060006D8 RID: 1752 RVA: 0x000215A3 File Offset: 0x0001F7A3
		public FindBoundingBox_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x060006D9 RID: 1753 RVA: 0x000215B4 File Offset: 0x0001F7B4
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.FindBoundingBoxTrialRun();
			}
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x000215C8 File Offset: 0x0001F7C8
		private void BtnMoreColor_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement button = sender as FrameworkElement;
			object valueSource = (button != null) ? button.Tag : null;
			PropertyInfo valueProperty = (valueSource != null) ? valueSource.GetType().GetProperty("Value") : null;
			bool flag = valueSource == null || valueProperty == null;
			if (!flag)
			{
				ColorDialog dialog = new ColorDialog
				{
					FullOpen = true
				};
				object currentColor = valueProperty.GetValue(valueSource, null);
				string colorText = currentColor as string;
				System.Windows.Media.Color currentMediaColor;
				bool flag2 = colorText != null && this.TryParseColor(colorText, out currentMediaColor);
				if (flag2)
				{
					dialog.Color = System.Drawing.Color.FromArgb((int)currentMediaColor.A, (int)currentMediaColor.R, (int)currentMediaColor.G, (int)currentMediaColor.B);
				}
				bool flag3 = dialog.ShowDialog() != DialogResult.OK;
				if (!flag3)
				{
					System.Windows.Media.Color selectedColor = System.Windows.Media.Color.FromArgb(dialog.Color.A, dialog.Color.R, dialog.Color.G, dialog.Color.B);
					valueProperty.SetValue(valueSource, "#" + selectedColor.R.ToString("X2") + selectedColor.G.ToString("X2") + selectedColor.B.ToString("X2"), null);
				}
			}
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x00021728 File Offset: 0x0001F928
		private bool TryParseColor(string colorText, out System.Windows.Media.Color color)
		{
			color = Colors.Lime;
			bool flag = string.IsNullOrWhiteSpace(colorText);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(colorText);
					result = true;
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x000217F4 File Offset: 0x0001F9F4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((SimpleButton)target).Click += this.BtnMoreColor_Click;
			}
		}
	}
}
