﻿using System;
using System.Diagnostics;
using System.Linq;
using DevExpress.Xpf.Core;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.FindCircle
{
	// Token: 0x0200008C RID: 140
	public class FindCircleActionService : IToolActionService
	{
		// Token: 0x17000255 RID: 597
		// (get) Token: 0x060006DF RID: 1759 RVA: 0x00021828 File Offset: 0x0001FA28
		public ToolType ToolType
		{
			get
			{
				return ToolType.FindCircle;
			}
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x0002183C File Offset: 0x0001FA3C
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				FindCircleResult result = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						ToolActionFeedback.ReportError(context, "No original image is available.");
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						string inputSourceToolName = this.GetInputSourceToolName(tool);
						Stopwatch inputStopwatch = Stopwatch.StartNew();
						input = this._pipelineService.BuildInputImageForTool(processContext, tool);
						inputStopwatch.Stop();
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							ToolActionFeedback.ReportError(context, "Could not create the input image for the tool.");
						}
						else
						{
							result = this._processor.Run(input, tool);
							result.InputSourceToolName = inputSourceToolName;
							result.InputProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds;
							result.TotalProcessingTimeMs = result.InputProcessingTimeMs + result.MasterProcessingTimeMs + result.ProcessingTimeMs;
							Action<ToolVision, object> resultReporter = context.ResultReporter;
							if (resultReporter != null)
							{
								resultReporter(tool, result);
							}
							bool flag4 = !result.IsSuccess;
							if (flag4)
							{
								DXMessageBox.Show(result.Message);
							}
							context.DisplayController.DisplayImage(input);
							FindCircleResult overlayResult = result;
							result = null;
							context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
							{
								this._drawer.Draw(window, tool, overlayResult);
							}, overlayResult);
						}
					}
				}
				catch (Exception ex)
				{
					DXMessageBox.Show("Find Circle trial run failed: " + ex.Message);
				}
				finally
				{
					if (result != null)
					{
						result.Dispose();
					}
					if (input != null)
					{
						input.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					if (original != null)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x00021AB4 File Offset: 0x0001FCB4
		private string GetInputSourceToolName(ToolVision tool)
		{
			ToolVision tool2 = tool;
			FindCircleToolConfig config = ((tool2 != null) ? tool2.Config : null) as FindCircleToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						TurnSnap parentTurnSnap = tool.ParentTurnSnap;
						ToolVision previousTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).LastOrDefault<ToolVision>() : null;
						result = ((previousTool == null) ? "PreviousToolOutput" : previousTool.Name);
					}
					else
					{
						result = "Unknown";
					}
				}
			}
			return result;
		}

		// Token: 0x040002C3 RID: 707
		private readonly FindCircleProcessor _processor = new FindCircleProcessor();

		// Token: 0x040002C4 RID: 708
		private readonly FindCircleResultDrawer _drawer = new FindCircleResultDrawer();

		// Token: 0x040002C5 RID: 709
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();
	}
}
