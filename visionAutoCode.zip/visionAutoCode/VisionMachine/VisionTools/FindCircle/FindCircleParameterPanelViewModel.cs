﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindCircle
{
	// Token: 0x0200008D RID: 141
	public class FindCircleParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x17000256 RID: 598
		// (get) Token: 0x060006E3 RID: 1763 RVA: 0x00021BCA File Offset: 0x0001FDCA
		// (set) Token: 0x060006E4 RID: 1764 RVA: 0x00021BD2 File Offset: 0x0001FDD2
		public ToolVision Tool { get; set; }

		// Token: 0x17000257 RID: 599
		// (get) Token: 0x060006E5 RID: 1765 RVA: 0x00021BDB File Offset: 0x0001FDDB
		// (set) Token: 0x060006E6 RID: 1766 RVA: 0x00021BE3 File Offset: 0x0001FDE3
		public FindCircleToolConfig FindCircleConfig { get; set; }

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x060006E7 RID: 1767 RVA: 0x00021BEC File Offset: 0x0001FDEC
		// (set) Token: 0x060006E8 RID: 1768 RVA: 0x00021BF4 File Offset: 0x0001FDF4
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x060006E9 RID: 1769 RVA: 0x00021C00 File Offset: 0x0001FE00
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x060006EA RID: 1770 RVA: 0x00021C1C File Offset: 0x0001FE1C
		// (set) Token: 0x060006EB RID: 1771 RVA: 0x00021C34 File Offset: 0x0001FE34
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool == value;
				if (!flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.FindCircleConfig != null && this.FindCircleConfig.InputLink != null;
					if (flag2)
					{
						this.FindCircleConfig.InputLink.SourceToolId = null;
						this.FindCircleConfig.InputLink.SourceToolName = ((value == null) ? null : value.ToolName);
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x1400000F RID: 15
		// (add) Token: 0x060006EC RID: 1772 RVA: 0x00021CB4 File Offset: 0x0001FEB4
		// (remove) Token: 0x060006ED RID: 1773 RVA: 0x00021CEC File Offset: 0x0001FEEC
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060006EE RID: 1774 RVA: 0x00021D24 File Offset: 0x0001FF24
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.FindCircleConfig == null || this.FindCircleConfig.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.FindCircleConfig.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.FindCircleConfig.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.FindCircleConfig.InputLink.SourceToolId = null;
				this.FindCircleConfig.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x060006EF RID: 1775 RVA: 0x00021E04 File Offset: 0x00020004
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x040002C6 RID: 710
		private ToolImageSourceOption _selectedSourceTool;
	}
}
