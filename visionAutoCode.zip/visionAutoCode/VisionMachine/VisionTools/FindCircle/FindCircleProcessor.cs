﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.FindCircle
{
	// Token: 0x0200008E RID: 142
	public class FindCircleProcessor : IToolProcessor
	{
		// Token: 0x060006F1 RID: 1777 RVA: 0x00021E20 File Offset: 0x00020020
		public FindCircleProcessor() : this(null)
		{
		}

		// Token: 0x060006F2 RID: 1778 RVA: 0x00021E2B File Offset: 0x0002002B
		public FindCircleProcessor(IDictionary<string, ShapeMatchResult> cachedMasterResults)
		{
			this._cachedMasterResults = cachedMasterResults;
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x060006F3 RID: 1779 RVA: 0x00021E3C File Offset: 0x0002003C
		public ToolType ToolType
		{
			get
			{
				return ToolType.FindCircle;
			}
		}

		// Token: 0x060006F4 RID: 1780 RVA: 0x00021E50 File Offset: 0x00020050
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			FindCircleResult result = this.Run((context != null) ? context.InputImage : null, tool);
			return new ToolProcessResult
			{
				IsSuccess = result.IsSuccess,
				Message = result.Message,
				Data = result
			};
		}

		// Token: 0x060006F5 RID: 1781 RVA: 0x00021EA0 File Offset: 0x000200A0
		public FindCircleResult Run(HObject image, ToolVision tool)
		{
			FindCircleResult result = new FindCircleResult();
			bool flag = image == null || !image.IsInitialized();
			FindCircleResult result2;
			if (flag)
			{
				result.Message = "Input image null.";
				result2 = result;
			}
			else
			{
				FindCircleToolConfig config = ((tool != null) ? tool.Config : null) as FindCircleToolConfig;
				bool flag2 = config == null;
				if (flag2)
				{
					result.Message = "Find Circle config null.";
					result2 = result;
				}
				else
				{
					bool flag3 = !config.IsEnabled;
					if (flag3)
					{
						result.Message = "Find Circle tool is disabled.";
						result2 = result;
					}
					else
					{
						RoiData roi = tool.RoiItems.FirstOrDefault((RoiData x) => x.IsEnabled && x.RoiType == RoiType.Circle);
						bool flag4 = roi == null;
						if (flag4)
						{
							result.Message = "Find Circle requires one enabled Circle ROI.";
							result2 = result;
						}
						else
						{
							this._currentMasterProcessingTimes = this.UpdateMasterShapeModels(image, tool, roi);
							RoiData transformedRoi = this.CreateTransformedCircleRoi(roi, tool);
							result.ToolName = tool.Name;
							result.Roi = transformedRoi;
							result.RoiName = (string.IsNullOrWhiteSpace(transformedRoi.Name) ? "Circle ROI" : transformedRoi.Name);
							result.MasterPositionToolName = this.GetMasterPositionToolName(roi);
							result.MasterAngleToolName = this.GetMasterAngleToolName(roi);
							result.MasterProcessingTimeMs = this.GetMasterProcessingTime(result.MasterPositionToolName, result.MasterAngleToolName);
							HTuple metrologyHandle = null;
							HObject grayImage = null;
							HObject roiRegion = null;
							HObject reduceImage = null;
							HObject measureRegions = null;
							Stopwatch findCircleStopwatch = Stopwatch.StartNew();
							try
							{
								grayImage = this.ConvertToGray(image);
								HTuple width;
								HTuple height;
								HOperatorSet.GetImageSize(grayImage, out width, out height);
								HOperatorSet.GenCircle(out roiRegion, transformedRoi.CenterRow, transformedRoi.CenterCol, Math.Max(1.0, transformedRoi.Radius));
								HOperatorSet.ReduceDomain(grayImage, roiRegion, out reduceImage);
								HOperatorSet.CreateMetrologyModel(out metrologyHandle);
								HOperatorSet.SetMetrologyModelImageSize(metrologyHandle, width, height);
								HTuple index;
								HOperatorSet.AddMetrologyObjectCircleMeasure(metrologyHandle, transformedRoi.CenterRow, transformedRoi.CenterCol, Math.Max(1.0, transformedRoi.Radius), Math.Max(1.0, config.Length1), Math.Max(1.0, config.Length2), Math.Max(0.1, config.Sigma), Math.Max(1.0, config.MeasureThreshold), new HTuple("start_phi").TupleConcat("end_phi"), new HTuple(this.DegToRad(config.StartPhi)).TupleConcat(this.DegToRad(config.EndPhi)), out index);
								HOperatorSet.SetMetrologyObjectParam(metrologyHandle, index, "num_instances", Math.Max(1, config.NumInstances));
								HOperatorSet.SetMetrologyObjectParam(metrologyHandle, index, "measure_transition", this.GetTransition(config.Transition));
								HOperatorSet.SetMetrologyObjectParam(metrologyHandle, index, "measure_select", this.GetSelector(config.Selector));
								HOperatorSet.SetMetrologyObjectParam(metrologyHandle, index, "min_score", config.MinScore);
								HOperatorSet.ApplyMetrologyModel(reduceImage, metrologyHandle);
								HTuple circleParam;
								HOperatorSet.GetMetrologyObjectResult(metrologyHandle, index, "all", "result_type", "all_param", out circleParam);
								bool flag5 = circleParam == null || circleParam.Length < 3;
								if (flag5)
								{
									result.Message = "Circle was not found.";
									result2 = result;
								}
								else
								{
									result.Row = circleParam[0].D;
									result.Column = circleParam[1].D;
									result.Radius = circleParam[2].D;
									HTuple measureRows;
									HTuple measureColumns;
									HOperatorSet.GetMetrologyObjectMeasures(out measureRegions, metrologyHandle, "all", "all", out measureRows, out measureColumns);
									result.MeasureRegions = measureRegions;
									measureRegions = null;
									result.IsSuccess = true;
									result.Message = "Find Circle OK.";
									result2 = result;
								}
							}
							catch (Exception ex)
							{
								result.Message = "Find Circle failed: " + ex.Message;
								result2 = result;
							}
							finally
							{
								findCircleStopwatch.Stop();
								result.ProcessingTimeMs = findCircleStopwatch.Elapsed.TotalMilliseconds;
								result.TotalProcessingTimeMs = result.MasterProcessingTimeMs + result.ProcessingTimeMs;
								bool flag6 = metrologyHandle != null;
								if (flag6)
								{
									HOperatorSet.ClearMetrologyModel(metrologyHandle);
								}
								if (measureRegions != null)
								{
									measureRegions.Dispose();
								}
								if (reduceImage != null)
								{
									reduceImage.Dispose();
								}
								if (roiRegion != null)
								{
									roiRegion.Dispose();
								}
								if (grayImage != null)
								{
									grayImage.Dispose();
								}
								this._currentMasterProcessingTimes = null;
								this._currentMasterMatchStates = null;
							}
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x060006F6 RID: 1782 RVA: 0x000223BC File Offset: 0x000205BC
		private HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject result;
			if (flag)
			{
				HObject gray;
				HOperatorSet.Rgb1ToGray(image, out gray);
				result = gray;
			}
			else
			{
				HObject copy;
				HOperatorSet.CopyImage(image, out copy);
				result = copy;
			}
			return result;
		}

		// Token: 0x060006F7 RID: 1783 RVA: 0x00022414 File Offset: 0x00020614
		private double DegToRad(double degree)
		{
			return degree * 3.141592653589793 / 180.0;
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x0002243C File Offset: 0x0002063C
		private string GetTransition(FindCircleTransition transition)
		{
			switch (transition)
			{
			case FindCircleTransition.LightToDark:
				return "negative";
			case FindCircleTransition.All:
				return "all";
			}
			return "positive";
		}

		// Token: 0x060006F9 RID: 1785 RVA: 0x0002247C File Offset: 0x0002067C
		private string GetSelector(FindCircleSelector selector)
		{
			switch (selector)
			{
			case FindCircleSelector.First:
				return "first";
			case FindCircleSelector.Last:
				return "last";
			}
			return "all";
		}

		// Token: 0x060006FA RID: 1786 RVA: 0x000224BC File Offset: 0x000206BC
		private RoiData CreateTransformedCircleRoi(RoiData roi, ToolVision tool)
		{
			FindCircleProcessor.MasterTransform transform = this.GetMasterTransform(roi, tool);
			Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
			return new RoiData
			{
				RoiType = RoiType.Circle,
				Name = roi.Name,
				CenterRow = center.Item1,
				CenterCol = center.Item2,
				Radius = roi.Radius,
				IsEnabled = roi.IsEnabled,
				MaskMode = roi.MaskMode,
				Polarity = roi.Polarity,
				Description = roi.Description,
				MasterToolName = roi.MasterToolName,
				MasterPositionToolName = roi.MasterPositionToolName,
				MasterAngleToolName = roi.MasterAngleToolName
			};
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x00022588 File Offset: 0x00020788
		private FindCircleProcessor.MasterTransform GetMasterTransform(RoiData roi, ToolVision tool)
		{
			FindCircleProcessor.MasterTransform transform = new FindCircleProcessor.MasterTransform();
			bool flag = roi == null || ((tool != null) ? tool.ParentTurnSnap : null) == null;
			FindCircleProcessor.MasterTransform result;
			if (flag)
			{
				result = transform;
			}
			else
			{
				ShapeModelToolTrain positionTrain = this.GetMasterTrain(tool, this.GetMasterPositionToolName(roi), true);
				bool flag2 = positionTrain != null;
				if (flag2)
				{
					transform.Row = positionTrain.LastRow - positionTrain.MasterRow;
					transform.Column = positionTrain.LastColumn - positionTrain.MasterColumn;
				}
				ShapeModelToolTrain angleTrain = this.GetMasterTrain(tool, this.GetMasterAngleToolName(roi), false);
				bool flag3 = angleTrain != null;
				if (flag3)
				{
					transform.Angle = angleTrain.LastAngle - angleTrain.MasterAngle;
					transform.MasterRow = angleTrain.MasterRow;
					transform.MasterColumn = angleTrain.MasterColumn;
				}
				result = transform;
			}
			return result;
		}

		// Token: 0x060006FC RID: 1788 RVA: 0x00022654 File Offset: 0x00020854
		private ShapeModelToolTrain GetMasterTrain(ToolVision tool, string masterToolName, bool isPositionMaster)
		{
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || string.IsNullOrWhiteSpace(masterToolName) || masterToolName == "None";
			ShapeModelToolTrain result;
			if (flag)
			{
				result = null;
			}
			else
			{
				bool isMasterFound;
				bool flag2 = this._currentMasterMatchStates != null && this._currentMasterMatchStates.TryGetValue(masterToolName, out isMasterFound) && !isMasterFound;
				if (flag2)
				{
					result = null;
				}
				else
				{
					ToolVision masterTool = tool.ParentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || (isPositionMaster && x.ToolType == ToolType.CircleMaster) || (isPositionMaster && x.ToolType == ToolType.BoundingBoxMaster) || (x.ToolType == ToolType.MinAreaMaster || (isPositionMaster && x.ToolType == ToolType.IntersectingLines)) || (!isPositionMaster && x.ToolType == ToolType.AngleSelector)) && x.Name == masterToolName);
					ShapeModelToolTrain train = ((masterTool != null) ? masterTool.TrainModel : null) as ShapeModelToolTrain;
					bool flag3 = train == null || !train.HasMasterDefined;
					if (flag3)
					{
						result = null;
					}
					else
					{
						result = train;
					}
				}
			}
			return result;
		}

		// Token: 0x060006FD RID: 1789 RVA: 0x00022758 File Offset: 0x00020958
		private Dictionary<string, double> UpdateMasterShapeModels(HObject image, ToolVision tool, RoiData roi)
		{
			Dictionary<string, double> processingTimes = new Dictionary<string, double>();
			this._currentMasterMatchStates = new Dictionary<string, bool>();
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || roi == null;
			Dictionary<string, double> result;
			if (flag)
			{
				result = processingTimes;
			}
			else
			{
				List<string> masterNames = (from x in new string[]
				{
					this.GetMasterPositionToolName(roi),
					this.GetMasterAngleToolName(roi)
				}
				where !string.IsNullOrWhiteSpace(x) && x != "None"
				select x).Distinct<string>().ToList<string>();
				bool flag2 = masterNames.Count == 0;
				if (flag2)
				{
					result = processingTimes;
				}
				else
				{
					ShapeModelProcessor shapeProcessor = new ShapeModelProcessor();
					using (List<string>.Enumerator enumerator = masterNames.GetEnumerator())
					{
						Func<ToolVision, bool> <>9__1;
						while (enumerator.MoveNext())
						{
							string masterName = enumerator.Current;
							Stopwatch stopwatch = Stopwatch.StartNew();
							IEnumerable<ToolVision> tools = tool.ParentTurnSnap.Tools;
							Func<ToolVision, bool> predicate;
							if ((predicate = <>9__1) == null)
							{
								predicate = (<>9__1 = ((ToolVision x) => x != tool));
							}
							ToolVision masterTool = tools.TakeWhile(predicate).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.BoundingBoxMaster || x.ToolType == ToolType.MinAreaMaster || x.ToolType == ToolType.IntersectingLines || x.ToolType == ToolType.AngleSelector) && x.Name == masterName);
							bool flag3 = masterTool == null;
							if (flag3)
							{
								stopwatch.Stop();
								processingTimes[masterName] = stopwatch.Elapsed.TotalMilliseconds;
								this._currentMasterMatchStates[masterName] = false;
							}
							else
							{
								ShapeMatchResult matchResult;
								bool flag4 = this.TryGetCachedMasterResult(masterName, out matchResult);
								if (flag4)
								{
									this.ApplyMasterResultToTrain(masterTool, matchResult);
									stopwatch.Stop();
									processingTimes[masterName] = Math.Max(0.0, matchResult.ProcessingTimeMs);
									this._currentMasterMatchStates[masterName] = matchResult.IsSuccess;
								}
								else
								{
									bool flag5 = masterTool.ToolType == ToolType.CircleMaster;
									if (flag5)
									{
										matchResult = new CircleMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
									}
									else
									{
										bool flag6 = masterTool.ToolType == ToolType.BoundingBoxMaster;
										if (flag6)
										{
											matchResult = new BoundingBoxMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
										}
										else
										{
											bool flag7 = masterTool.ToolType == ToolType.MinAreaMaster;
											if (flag7)
											{
												matchResult = new MinAreaMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
											}
											else
											{
												bool flag8 = masterTool.ToolType == ToolType.IntersectingLines;
												if (flag8)
												{
													matchResult = new IntersectingLinesProcessor(null, this._cachedMasterResults).Match(image, masterTool);
												}
												else
												{
													bool flag9 = masterTool.ToolType == ToolType.AngleSelector;
													if (flag9)
													{
														matchResult = new AngleSelectorProcessor(null, this._cachedMasterResults).Match(image, masterTool);
													}
													else
													{
														matchResult = shapeProcessor.Match(image, masterTool);
													}
												}
											}
										}
									}
									stopwatch.Stop();
									processingTimes[masterName] = stopwatch.Elapsed.TotalMilliseconds;
									this._currentMasterMatchStates[masterName] = (matchResult != null && matchResult.IsSuccess);
								}
							}
						}
					}
					result = processingTimes;
				}
			}
			return result;
		}

		// Token: 0x060006FE RID: 1790 RVA: 0x00022AB0 File Offset: 0x00020CB0
		private bool TryGetCachedMasterResult(string masterName, out ShapeMatchResult result)
		{
			result = null;
			bool flag = this._cachedMasterResults == null || string.IsNullOrWhiteSpace(masterName);
			return !flag && this._cachedMasterResults.TryGetValue(masterName, out result) && result != null;
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x00022AF8 File Offset: 0x00020CF8
		private void ApplyMasterResultToTrain(ToolVision masterTool, ShapeMatchResult result)
		{
			bool flag = masterTool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				ShapeModelToolTrain train = masterTool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (!flag2)
				{
					train.LastRow = result.Row;
					train.LastColumn = result.Column;
					train.LastAngle = result.Angle;
					train.LastScore = result.Score;
				}
			}
		}

		// Token: 0x06000700 RID: 1792 RVA: 0x00022B6C File Offset: 0x00020D6C
		private string GetMasterPositionToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && roi.MasterPositionToolName != "None";
				if (flag2)
				{
					result = roi.MasterPositionToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x06000701 RID: 1793 RVA: 0x00022BFC File Offset: 0x00020DFC
		private string GetMasterAngleToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && roi.MasterAngleToolName != "None";
				if (flag2)
				{
					result = roi.MasterAngleToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x06000702 RID: 1794 RVA: 0x00022C8C File Offset: 0x00020E8C
		private double GetMasterProcessingTime(string masterPositionToolName, string masterAngleToolName)
		{
			double processingTime = 0.0;
			foreach (string masterName in (from x in new string[]
			{
				masterPositionToolName,
				masterAngleToolName
			}
			where !string.IsNullOrWhiteSpace(x) && x != "None"
			select x).Distinct<string>())
			{
				double time;
				bool flag = this._currentMasterProcessingTimes != null && this._currentMasterProcessingTimes.TryGetValue(masterName, out time);
				if (flag)
				{
					processingTime += time;
				}
			}
			return processingTime;
		}

		// Token: 0x06000703 RID: 1795 RVA: 0x00022D40 File Offset: 0x00020F40
		private Tuple<double, double> TransformPoint(double row, double column, FindCircleProcessor.MasterTransform transform)
		{
			bool flag = transform == null;
			Tuple<double, double> result;
			if (flag)
			{
				result = Tuple.Create<double, double>(row, column);
			}
			else
			{
				double cos = Math.Cos(transform.Angle);
				double sin = Math.Sin(transform.Angle);
				double relRow = row - transform.MasterRow;
				double relColumn = column - transform.MasterColumn;
				double newRow = transform.MasterRow + transform.Row + relRow * cos - relColumn * sin;
				double newColumn = transform.MasterColumn + transform.Column + relRow * sin + relColumn * cos;
				result = Tuple.Create<double, double>(newRow, newColumn);
			}
			return result;
		}

		// Token: 0x040002CB RID: 715
		private readonly IDictionary<string, ShapeMatchResult> _cachedMasterResults;

		// Token: 0x040002CC RID: 716
		private Dictionary<string, double> _currentMasterProcessingTimes;

		// Token: 0x040002CD RID: 717
		private Dictionary<string, bool> _currentMasterMatchStates;

		// Token: 0x0200030E RID: 782
		private class MasterTransform
		{
			// Token: 0x17000B2D RID: 2861
			// (get) Token: 0x06002770 RID: 10096 RVA: 0x000E076B File Offset: 0x000DE96B
			// (set) Token: 0x06002771 RID: 10097 RVA: 0x000E0773 File Offset: 0x000DE973
			public double Row { get; set; }

			// Token: 0x17000B2E RID: 2862
			// (get) Token: 0x06002772 RID: 10098 RVA: 0x000E077C File Offset: 0x000DE97C
			// (set) Token: 0x06002773 RID: 10099 RVA: 0x000E0784 File Offset: 0x000DE984
			public double Column { get; set; }

			// Token: 0x17000B2F RID: 2863
			// (get) Token: 0x06002774 RID: 10100 RVA: 0x000E078D File Offset: 0x000DE98D
			// (set) Token: 0x06002775 RID: 10101 RVA: 0x000E0795 File Offset: 0x000DE995
			public double Angle { get; set; }

			// Token: 0x17000B30 RID: 2864
			// (get) Token: 0x06002776 RID: 10102 RVA: 0x000E079E File Offset: 0x000DE99E
			// (set) Token: 0x06002777 RID: 10103 RVA: 0x000E07A6 File Offset: 0x000DE9A6
			public double MasterRow { get; set; }

			// Token: 0x17000B31 RID: 2865
			// (get) Token: 0x06002778 RID: 10104 RVA: 0x000E07AF File Offset: 0x000DE9AF
			// (set) Token: 0x06002779 RID: 10105 RVA: 0x000E07B7 File Offset: 0x000DE9B7
			public double MasterColumn { get; set; }
		}
	}
}
