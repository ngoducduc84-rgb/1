﻿using System;
using HalconDotNet;
using VisionMachine.Models.Roi;

namespace VisionMachine.VisionTools.FindCircle
{
	// Token: 0x0200008F RID: 143
	public class FindCircleResult : IDisposable
	{
		// Token: 0x1700025C RID: 604
		// (get) Token: 0x06000704 RID: 1796 RVA: 0x00022DCA File Offset: 0x00020FCA
		// (set) Token: 0x06000705 RID: 1797 RVA: 0x00022DD2 File Offset: 0x00020FD2
		public bool IsSuccess { get; set; }

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x06000706 RID: 1798 RVA: 0x00022DDB File Offset: 0x00020FDB
		// (set) Token: 0x06000707 RID: 1799 RVA: 0x00022DE3 File Offset: 0x00020FE3
		public string Message { get; set; }

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x06000708 RID: 1800 RVA: 0x00022DEC File Offset: 0x00020FEC
		// (set) Token: 0x06000709 RID: 1801 RVA: 0x00022DF4 File Offset: 0x00020FF4
		public string ToolName { get; set; }

		// Token: 0x1700025F RID: 607
		// (get) Token: 0x0600070A RID: 1802 RVA: 0x00022DFD File Offset: 0x00020FFD
		// (set) Token: 0x0600070B RID: 1803 RVA: 0x00022E05 File Offset: 0x00021005
		public string RoiName { get; set; }

		// Token: 0x17000260 RID: 608
		// (get) Token: 0x0600070C RID: 1804 RVA: 0x00022E0E File Offset: 0x0002100E
		// (set) Token: 0x0600070D RID: 1805 RVA: 0x00022E16 File Offset: 0x00021016
		public RoiData Roi { get; set; }

		// Token: 0x17000261 RID: 609
		// (get) Token: 0x0600070E RID: 1806 RVA: 0x00022E1F File Offset: 0x0002101F
		// (set) Token: 0x0600070F RID: 1807 RVA: 0x00022E27 File Offset: 0x00021027
		public HObject MeasureRegions { get; set; }

		// Token: 0x17000262 RID: 610
		// (get) Token: 0x06000710 RID: 1808 RVA: 0x00022E30 File Offset: 0x00021030
		// (set) Token: 0x06000711 RID: 1809 RVA: 0x00022E38 File Offset: 0x00021038
		public double Row { get; set; }

		// Token: 0x17000263 RID: 611
		// (get) Token: 0x06000712 RID: 1810 RVA: 0x00022E41 File Offset: 0x00021041
		// (set) Token: 0x06000713 RID: 1811 RVA: 0x00022E49 File Offset: 0x00021049
		public double Column { get; set; }

		// Token: 0x17000264 RID: 612
		// (get) Token: 0x06000714 RID: 1812 RVA: 0x00022E52 File Offset: 0x00021052
		// (set) Token: 0x06000715 RID: 1813 RVA: 0x00022E5A File Offset: 0x0002105A
		public double Radius { get; set; }

		// Token: 0x17000265 RID: 613
		// (get) Token: 0x06000716 RID: 1814 RVA: 0x00022E63 File Offset: 0x00021063
		// (set) Token: 0x06000717 RID: 1815 RVA: 0x00022E6B File Offset: 0x0002106B
		public string MasterPositionToolName { get; set; }

		// Token: 0x17000266 RID: 614
		// (get) Token: 0x06000718 RID: 1816 RVA: 0x00022E74 File Offset: 0x00021074
		// (set) Token: 0x06000719 RID: 1817 RVA: 0x00022E7C File Offset: 0x0002107C
		public string MasterAngleToolName { get; set; }

		// Token: 0x17000267 RID: 615
		// (get) Token: 0x0600071A RID: 1818 RVA: 0x00022E85 File Offset: 0x00021085
		// (set) Token: 0x0600071B RID: 1819 RVA: 0x00022E8D File Offset: 0x0002108D
		public double MasterProcessingTimeMs { get; set; }

		// Token: 0x17000268 RID: 616
		// (get) Token: 0x0600071C RID: 1820 RVA: 0x00022E96 File Offset: 0x00021096
		// (set) Token: 0x0600071D RID: 1821 RVA: 0x00022E9E File Offset: 0x0002109E
		public string InputSourceToolName { get; set; }

		// Token: 0x17000269 RID: 617
		// (get) Token: 0x0600071E RID: 1822 RVA: 0x00022EA7 File Offset: 0x000210A7
		// (set) Token: 0x0600071F RID: 1823 RVA: 0x00022EAF File Offset: 0x000210AF
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x1700026A RID: 618
		// (get) Token: 0x06000720 RID: 1824 RVA: 0x00022EB8 File Offset: 0x000210B8
		// (set) Token: 0x06000721 RID: 1825 RVA: 0x00022EC0 File Offset: 0x000210C0
		public double ProcessingTimeMs { get; set; }

		// Token: 0x1700026B RID: 619
		// (get) Token: 0x06000722 RID: 1826 RVA: 0x00022EC9 File Offset: 0x000210C9
		// (set) Token: 0x06000723 RID: 1827 RVA: 0x00022ED1 File Offset: 0x000210D1
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x06000724 RID: 1828 RVA: 0x00022EDA File Offset: 0x000210DA
		public void Dispose()
		{
			HObject measureRegions = this.MeasureRegions;
			if (measureRegions != null)
			{
				measureRegions.Dispose();
			}
		}
	}
}
