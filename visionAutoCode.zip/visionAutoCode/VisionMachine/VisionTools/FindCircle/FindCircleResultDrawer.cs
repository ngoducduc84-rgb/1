﻿using System;
using HalconDotNet;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.FindCircle
{
	// Token: 0x02000090 RID: 144
	public class FindCircleResultDrawer
	{
		// Token: 0x06000726 RID: 1830 RVA: 0x00022EF0 File Offset: 0x000210F0
		public void Draw(HWindow window, ToolVision tool, FindCircleResult result)
		{
			bool flag = window == null || tool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				FindCircleToolConfig config = tool.Config as FindCircleToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					bool flag3 = config.ShowSearchOutline && result.MeasureRegions != null && result.MeasureRegions.IsInitialized();
					if (flag3)
					{
						HOperatorSet.SetColor(window, "cyan");
						HOperatorSet.SetLineWidth(window, 1);
						HOperatorSet.DispObj(result.MeasureRegions, window);
					}
					bool flag4 = config.ShowRoi && result.Roi != null;
					if (flag4)
					{
						HOperatorSet.SetColor(window, "orange");
						HOperatorSet.SetDraw(window, "margin");
						HOperatorSet.SetLineWidth(window, 2);
						HOperatorSet.DispCircle(window, result.Roi.CenterRow, result.Roi.CenterCol, result.Roi.Radius);
					}
					bool showFoundCircle = config.ShowFoundCircle;
					if (showFoundCircle)
					{
						HOperatorSet.SetColor(window, config.DisplayColor);
						HOperatorSet.SetDraw(window, "margin");
						HOperatorSet.SetLineWidth(window, 2);
						HOperatorSet.DispCircle(window, result.Row, result.Column, result.Radius);
						HOperatorSet.DispCross(window, result.Row, result.Column, 16, 0);
					}
					bool showText = config.ShowText;
					if (showText)
					{
						try
						{
							HOperatorSet.SetFont(window, "Arial-" + Math.Max(1, config.TextSize).ToString());
						}
						catch
						{
						}
						HOperatorSet.SetColor(window, config.DisplayColor);
						HOperatorSet.SetTposition(window, result.Row, result.Column);
						HOperatorSet.WriteString(window, string.Concat(new string[]
						{
							tool.Name,
							" Center=(",
							result.Row.ToString("0.000"),
							", ",
							result.Column.ToString("0.000"),
							")"
						}));
					}
				}
			}
		}
	}
}
