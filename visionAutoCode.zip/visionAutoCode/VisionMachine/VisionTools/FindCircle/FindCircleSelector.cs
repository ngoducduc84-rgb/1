﻿using System;

namespace VisionMachine.VisionTools.FindCircle
{
	// Token: 0x02000091 RID: 145
	public enum FindCircleSelector
	{
		// Token: 0x040002DF RID: 735
		All,
		// Token: 0x040002E0 RID: 736
		First,
		// Token: 0x040002E1 RID: 737
		Last
	}
}
