﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindCircle
{
	// Token: 0x02000092 RID: 146
	public class FindCircleToolConfig : ToolConfigBase
	{
		// Token: 0x1700026C RID: 620
		// (get) Token: 0x06000728 RID: 1832 RVA: 0x000231D4 File Offset: 0x000213D4
		// (set) Token: 0x06000729 RID: 1833 RVA: 0x000231DC File Offset: 0x000213DC
		public ImageInputLink InputLink { get; set; } = new ImageInputLink();

		// Token: 0x1700026D RID: 621
		// (get) Token: 0x0600072A RID: 1834 RVA: 0x000231E5 File Offset: 0x000213E5
		// (set) Token: 0x0600072B RID: 1835 RVA: 0x000231F0 File Offset: 0x000213F0
		[DisplayName("Sigma")]
		public double Sigma
		{
			get
			{
				return this._sigma;
			}
			set
			{
				bool flag = this._sigma != value;
				if (flag)
				{
					this._sigma = value;
					base.OnPropertyChanged("Sigma");
				}
			}
		}

		// Token: 0x1700026E RID: 622
		// (get) Token: 0x0600072C RID: 1836 RVA: 0x00023223 File Offset: 0x00021423
		// (set) Token: 0x0600072D RID: 1837 RVA: 0x0002322C File Offset: 0x0002142C
		[DisplayName("Measure Threshold")]
		public double MeasureThreshold
		{
			get
			{
				return this._measureThreshold;
			}
			set
			{
				bool flag = this._measureThreshold != value;
				if (flag)
				{
					this._measureThreshold = value;
					base.OnPropertyChanged("MeasureThreshold");
				}
			}
		}

		// Token: 0x1700026F RID: 623
		// (get) Token: 0x0600072E RID: 1838 RVA: 0x0002325F File Offset: 0x0002145F
		// (set) Token: 0x0600072F RID: 1839 RVA: 0x00023268 File Offset: 0x00021468
		[DisplayName("Length 1")]
		public double Length1
		{
			get
			{
				return this._length1;
			}
			set
			{
				bool flag = this._length1 != value;
				if (flag)
				{
					this._length1 = value;
					base.OnPropertyChanged("Length1");
				}
			}
		}

		// Token: 0x17000270 RID: 624
		// (get) Token: 0x06000730 RID: 1840 RVA: 0x0002329B File Offset: 0x0002149B
		// (set) Token: 0x06000731 RID: 1841 RVA: 0x000232A4 File Offset: 0x000214A4
		[DisplayName("Length 2")]
		public double Length2
		{
			get
			{
				return this._length2;
			}
			set
			{
				bool flag = this._length2 != value;
				if (flag)
				{
					this._length2 = value;
					base.OnPropertyChanged("Length2");
				}
			}
		}

		// Token: 0x17000271 RID: 625
		// (get) Token: 0x06000732 RID: 1842 RVA: 0x000232D7 File Offset: 0x000214D7
		// (set) Token: 0x06000733 RID: 1843 RVA: 0x000232E0 File Offset: 0x000214E0
		[DisplayName("Start Phi (deg)")]
		public double StartPhi
		{
			get
			{
				return this._startPhi;
			}
			set
			{
				bool flag = this._startPhi != value;
				if (flag)
				{
					this._startPhi = value;
					base.OnPropertyChanged("StartPhi");
				}
			}
		}

		// Token: 0x17000272 RID: 626
		// (get) Token: 0x06000734 RID: 1844 RVA: 0x00023313 File Offset: 0x00021513
		// (set) Token: 0x06000735 RID: 1845 RVA: 0x0002331C File Offset: 0x0002151C
		[DisplayName("End Phi (deg)")]
		public double EndPhi
		{
			get
			{
				return this._endPhi;
			}
			set
			{
				bool flag = this._endPhi != value;
				if (flag)
				{
					this._endPhi = value;
					base.OnPropertyChanged("EndPhi");
				}
			}
		}

		// Token: 0x17000273 RID: 627
		// (get) Token: 0x06000736 RID: 1846 RVA: 0x0002334F File Offset: 0x0002154F
		// (set) Token: 0x06000737 RID: 1847 RVA: 0x00023358 File Offset: 0x00021558
		[DisplayName("Min Score")]
		public double MinScore
		{
			get
			{
				return this._minScore;
			}
			set
			{
				bool flag = this._minScore != value;
				if (flag)
				{
					this._minScore = value;
					base.OnPropertyChanged("MinScore");
				}
			}
		}

		// Token: 0x17000274 RID: 628
		// (get) Token: 0x06000738 RID: 1848 RVA: 0x0002338B File Offset: 0x0002158B
		// (set) Token: 0x06000739 RID: 1849 RVA: 0x00023394 File Offset: 0x00021594
		[DisplayName("Num Instances")]
		public int NumInstances
		{
			get
			{
				return this._numInstances;
			}
			set
			{
				int normalized = (value < 1) ? 1 : value;
				bool flag = this._numInstances != normalized;
				if (flag)
				{
					this._numInstances = normalized;
					base.OnPropertyChanged("NumInstances");
				}
			}
		}

		// Token: 0x17000275 RID: 629
		// (get) Token: 0x0600073A RID: 1850 RVA: 0x000233D0 File Offset: 0x000215D0
		// (set) Token: 0x0600073B RID: 1851 RVA: 0x000233D8 File Offset: 0x000215D8
		[DisplayName("Transition")]
		public FindCircleTransition Transition
		{
			get
			{
				return this._transition;
			}
			set
			{
				bool flag = this._transition != value;
				if (flag)
				{
					this._transition = value;
					base.OnPropertyChanged("Transition");
				}
			}
		}

		// Token: 0x17000276 RID: 630
		// (get) Token: 0x0600073C RID: 1852 RVA: 0x0002340B File Offset: 0x0002160B
		// (set) Token: 0x0600073D RID: 1853 RVA: 0x00023414 File Offset: 0x00021614
		[DisplayName("Selector")]
		public FindCircleSelector Selector
		{
			get
			{
				return this._selector;
			}
			set
			{
				bool flag = this._selector != value;
				if (flag)
				{
					this._selector = value;
					base.OnPropertyChanged("Selector");
				}
			}
		}

		// Token: 0x17000277 RID: 631
		// (get) Token: 0x0600073E RID: 1854 RVA: 0x00023447 File Offset: 0x00021647
		// (set) Token: 0x0600073F RID: 1855 RVA: 0x00023450 File Offset: 0x00021650
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				bool flag = this._showRoi != value;
				if (flag)
				{
					this._showRoi = value;
					base.OnPropertyChanged("ShowRoi");
				}
			}
		}

		// Token: 0x17000278 RID: 632
		// (get) Token: 0x06000740 RID: 1856 RVA: 0x00023483 File Offset: 0x00021683
		// (set) Token: 0x06000741 RID: 1857 RVA: 0x0002348C File Offset: 0x0002168C
		[DisplayName("Show Found Circle")]
		public bool ShowFoundCircle
		{
			get
			{
				return this._showFoundCircle;
			}
			set
			{
				bool flag = this._showFoundCircle != value;
				if (flag)
				{
					this._showFoundCircle = value;
					base.OnPropertyChanged("ShowFoundCircle");
				}
			}
		}

		// Token: 0x17000279 RID: 633
		// (get) Token: 0x06000742 RID: 1858 RVA: 0x000234BF File Offset: 0x000216BF
		// (set) Token: 0x06000743 RID: 1859 RVA: 0x000234C8 File Offset: 0x000216C8
		[DisplayName("Show Search Outline")]
		public bool ShowSearchOutline
		{
			get
			{
				return this._showSearchOutline;
			}
			set
			{
				bool flag = this._showSearchOutline != value;
				if (flag)
				{
					this._showSearchOutline = value;
					base.OnPropertyChanged("ShowSearchOutline");
				}
			}
		}

		// Token: 0x1700027A RID: 634
		// (get) Token: 0x06000744 RID: 1860 RVA: 0x000234FB File Offset: 0x000216FB
		// (set) Token: 0x06000745 RID: 1861 RVA: 0x00023504 File Offset: 0x00021704
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				bool flag = this._showText != value;
				if (flag)
				{
					this._showText = value;
					base.OnPropertyChanged("ShowText");
				}
			}
		}

		// Token: 0x1700027B RID: 635
		// (get) Token: 0x06000746 RID: 1862 RVA: 0x00023537 File Offset: 0x00021737
		// (set) Token: 0x06000747 RID: 1863 RVA: 0x00023540 File Offset: 0x00021740
		[DisplayName("Text Size")]
		public int TextSize
		{
			get
			{
				return this._textSize;
			}
			set
			{
				int normalized = (value < 1) ? 1 : value;
				bool flag = this._textSize != normalized;
				if (flag)
				{
					this._textSize = normalized;
					base.OnPropertyChanged("TextSize");
				}
			}
		}

		// Token: 0x1700027C RID: 636
		// (get) Token: 0x06000748 RID: 1864 RVA: 0x0002357C File Offset: 0x0002177C
		// (set) Token: 0x06000749 RID: 1865 RVA: 0x00023584 File Offset: 0x00021784
		[DisplayName("Display Color")]
		public string DisplayColor
		{
			get
			{
				return this._displayColor;
			}
			set
			{
				bool flag = this._displayColor != value;
				if (flag)
				{
					this._displayColor = value;
					base.OnPropertyChanged("DisplayColor");
				}
			}
		}

		// Token: 0x040002E2 RID: 738
		private double _sigma = 2.0;

		// Token: 0x040002E3 RID: 739
		private double _measureThreshold = 10.0;

		// Token: 0x040002E4 RID: 740
		private double _length1 = 30.0;

		// Token: 0x040002E5 RID: 741
		private double _length2 = 5.0;

		// Token: 0x040002E6 RID: 742
		private double _startPhi = 0.0;

		// Token: 0x040002E7 RID: 743
		private double _endPhi = 360.0;

		// Token: 0x040002E8 RID: 744
		private double _minScore = 0.3;

		// Token: 0x040002E9 RID: 745
		private int _numInstances = 1;

		// Token: 0x040002EA RID: 746
		private FindCircleTransition _transition = FindCircleTransition.DarkToLight;

		// Token: 0x040002EB RID: 747
		private FindCircleSelector _selector = FindCircleSelector.All;

		// Token: 0x040002EC RID: 748
		private bool _showRoi = true;

		// Token: 0x040002ED RID: 749
		private bool _showFoundCircle = true;

		// Token: 0x040002EE RID: 750
		private bool _showSearchOutline = true;

		// Token: 0x040002EF RID: 751
		private bool _showText = true;

		// Token: 0x040002F0 RID: 752
		private int _textSize = 14;

		// Token: 0x040002F1 RID: 753
		private string _displayColor = "yellow";
	}
}
