﻿using System;

namespace VisionMachine.VisionTools.FindCircle
{
	// Token: 0x02000093 RID: 147
	public enum FindCircleTransition
	{
		// Token: 0x040002F4 RID: 756
		DarkToLight,
		// Token: 0x040002F5 RID: 757
		LightToDark,
		// Token: 0x040002F6 RID: 758
		All
	}
}
