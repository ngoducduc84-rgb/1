﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.FindCircle.Views
{
	// Token: 0x02000094 RID: 148
	public partial class FindCircle_para : UserControl
	{
		// Token: 0x0600074B RID: 1867 RVA: 0x00023684 File Offset: 0x00021884
		public FindCircle_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x0600074C RID: 1868 RVA: 0x00023695 File Offset: 0x00021895
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.FindCircleTrialRun();
			}
		}
	}
}
