﻿using System;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.FindLine
{
	// Token: 0x02000064 RID: 100
	public class FindLineActionService : IToolActionService
	{
		// Token: 0x17000184 RID: 388
		// (get) Token: 0x0600048E RID: 1166 RVA: 0x00017448 File Offset: 0x00015648
		public ToolType ToolType
		{
			get
			{
				return ToolType.FindLine;
			}
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x0001745C File Offset: 0x0001565C
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null;
			if (flag)
			{
				ToolActionFeedback.ReportError(context, "DisplayController null.");
			}
			else
			{
				bool flag2 = tool == null;
				if (flag2)
				{
					ToolActionFeedback.ReportError(context, "No tool is selected.");
				}
				else
				{
					HObject original = null;
					HObject input = null;
					ImageBufferStore bufferStore = null;
					FindLineResult lineResult = null;
					try
					{
						original = context.DisplayController.GetOriginalImage();
						bool flag3 = original == null || !original.IsInitialized();
						if (flag3)
						{
							ToolActionFeedback.ReportError(context, "No original image is available for Find Line testing.");
						}
						else
						{
							bufferStore = new ImageBufferStore();
							ToolProcessContext buildContext = new ToolProcessContext
							{
								OriginalImage = original,
								InputImage = original,
								BufferStore = bufferStore
							};
							string inputSourceToolName = this.GetInputSourceToolName(tool);
							Stopwatch inputStopwatch = Stopwatch.StartNew();
							input = this._pipelineService.BuildInputImageForTool(buildContext, tool);
							inputStopwatch.Stop();
							double inputProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds;
							bool flag4 = input == null || !input.IsInitialized();
							if (flag4)
							{
								ToolActionFeedback.ReportError(context, "Could not create the input image for the tool.");
							}
							else
							{
								Stopwatch processStopwatch = Stopwatch.StartNew();
								lineResult = this._processor.Run(input, tool);
								processStopwatch.Stop();
								lineResult.InputSourceToolName = inputSourceToolName;
								lineResult.InputProcessingTimeMs = inputProcessingTimeMs;
								lineResult.TotalProcessingTimeMs = processStopwatch.Elapsed.TotalMilliseconds;
								bool flag5 = !lineResult.IsSuccess;
								if (flag5)
								{
									ToolActionFeedback.ReportError(context, lineResult.Message);
								}
								Action<ToolVision, object> resultReporter = context.ResultReporter;
								if (resultReporter != null)
								{
									resultReporter(tool, lineResult);
								}
								context.DisplayController.DisplayImage(input);
								FindLineResult overlayResult = lineResult;
								lineResult = null;
								context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
								{
									this._drawer.Draw(window, tool, overlayResult);
								}, overlayResult);
							}
						}
					}
					catch (Exception ex)
					{
						ToolActionFeedback.ReportError(context, "Find Line trial run failed: " + ex.Message);
					}
					finally
					{
						bool flag6 = lineResult != null;
						if (flag6)
						{
							lineResult.Dispose();
						}
						bool flag7 = input != null;
						if (flag7)
						{
							input.Dispose();
						}
						bool flag8 = bufferStore != null;
						if (flag8)
						{
							bufferStore.Clear();
						}
						bool flag9 = original != null;
						if (flag9)
						{
							original.Dispose();
						}
					}
				}
			}
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x00017730 File Offset: 0x00015930
		private string GetInputSourceToolName(ToolVision tool)
		{
			ToolVision tool2 = tool;
			FindLineToolConfig config = ((tool2 != null) ? tool2.Config : null) as FindLineToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						TurnSnap parentTurnSnap = tool.ParentTurnSnap;
						ToolVision previousTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).LastOrDefault<ToolVision>() : null;
						result = ((previousTool == null) ? "PreviousToolOutput" : previousTool.Name);
					}
					else
					{
						result = "Unknown";
					}
				}
			}
			return result;
		}

		// Token: 0x040001D4 RID: 468
		private readonly FindLineProcessor _processor = new FindLineProcessor();

		// Token: 0x040001D5 RID: 469
		private readonly FindLineResultDrawer _drawer = new FindLineResultDrawer();

		// Token: 0x040001D6 RID: 470
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();
	}
}
