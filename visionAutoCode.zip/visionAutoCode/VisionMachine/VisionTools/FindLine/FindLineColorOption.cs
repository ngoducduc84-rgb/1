﻿using System;
using System.Windows.Media;

namespace VisionMachine.VisionTools.FindLine
{
	// Token: 0x02000067 RID: 103
	public class FindLineColorOption
	{
		// Token: 0x17000185 RID: 389
		// (get) Token: 0x06000492 RID: 1170 RVA: 0x00017848 File Offset: 0x00015A48
		// (set) Token: 0x06000493 RID: 1171 RVA: 0x00017850 File Offset: 0x00015A50
		public string Name { get; set; }

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x06000494 RID: 1172 RVA: 0x00017859 File Offset: 0x00015A59
		// (set) Token: 0x06000495 RID: 1173 RVA: 0x00017861 File Offset: 0x00015A61
		public Color Color { get; set; }

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x06000496 RID: 1174 RVA: 0x0001786A File Offset: 0x00015A6A
		// (set) Token: 0x06000497 RID: 1175 RVA: 0x00017872 File Offset: 0x00015A72
		public string Value { get; set; }
	}
}
