﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.FindLine
{
	// Token: 0x02000065 RID: 101
	public enum FindLineEdgeTransition
	{
		// Token: 0x040001D8 RID: 472
		[Description("Dark to Light")]
		DarkToLight,
		// Token: 0x040001D9 RID: 473
		[Description("Light to Dark")]
		LightToDark
	}
}
