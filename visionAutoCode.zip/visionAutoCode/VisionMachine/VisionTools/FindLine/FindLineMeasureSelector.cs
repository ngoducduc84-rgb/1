﻿using System;

namespace VisionMachine.VisionTools.FindLine
{
	// Token: 0x02000066 RID: 102
	public enum FindLineMeasureSelector
	{
		// Token: 0x040001DB RID: 475
		All,
		// Token: 0x040001DC RID: 476
		First,
		// Token: 0x040001DD RID: 477
		Last
	}
}
