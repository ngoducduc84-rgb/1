﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindLine
{
	// Token: 0x02000068 RID: 104
	public class FindLineParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x17000188 RID: 392
		// (get) Token: 0x06000499 RID: 1177 RVA: 0x0001787B File Offset: 0x00015A7B
		// (set) Token: 0x0600049A RID: 1178 RVA: 0x00017883 File Offset: 0x00015A83
		public ToolVision Tool { get; set; }

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x0600049B RID: 1179 RVA: 0x0001788C File Offset: 0x00015A8C
		// (set) Token: 0x0600049C RID: 1180 RVA: 0x00017894 File Offset: 0x00015A94
		public FindLineToolConfig FindLineConfig { get; set; }

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x0600049D RID: 1181 RVA: 0x0001789D File Offset: 0x00015A9D
		// (set) Token: 0x0600049E RID: 1182 RVA: 0x000178A5 File Offset: 0x00015AA5
		public FindLineToolSpec FindLineSpec { get; set; }

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x0600049F RID: 1183 RVA: 0x000178AE File Offset: 0x00015AAE
		// (set) Token: 0x060004A0 RID: 1184 RVA: 0x000178B6 File Offset: 0x00015AB6
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x060004A1 RID: 1185 RVA: 0x000178BF File Offset: 0x00015ABF
		public ObservableCollection<FindLineColorOption> CoordinateTextColorOptions { get; } = new ObservableCollection<FindLineColorOption>
		{
			new FindLineColorOption
			{
				Name = "White",
				Color = Colors.White,
				Value = "white"
			},
			new FindLineColorOption
			{
				Name = "Black",
				Color = Colors.Black,
				Value = "black"
			},
			new FindLineColorOption
			{
				Name = "Red",
				Color = Colors.Red,
				Value = "red"
			},
			new FindLineColorOption
			{
				Name = "Green",
				Color = Colors.Lime,
				Value = "green"
			},
			new FindLineColorOption
			{
				Name = "Blue",
				Color = Colors.DodgerBlue,
				Value = "blue"
			},
			new FindLineColorOption
			{
				Name = "Yellow",
				Color = Colors.Yellow,
				Value = "yellow"
			},
			new FindLineColorOption
			{
				Name = "Cyan",
				Color = Colors.Cyan,
				Value = "cyan"
			},
			new FindLineColorOption
			{
				Name = "Magenta",
				Color = Colors.Magenta,
				Value = "magenta"
			},
			new FindLineColorOption
			{
				Name = "Orange",
				Color = Colors.Orange,
				Value = "orange"
			}
		};

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x060004A2 RID: 1186 RVA: 0x000178C8 File Offset: 0x00015AC8
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x060004A3 RID: 1187 RVA: 0x000178E4 File Offset: 0x00015AE4
		// (set) Token: 0x060004A4 RID: 1188 RVA: 0x000178FC File Offset: 0x00015AFC
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool != value;
				if (flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.FindLineConfig != null && this.FindLineConfig.InputLink != null;
					if (flag2)
					{
						bool flag3 = this._selectedSourceTool != null;
						if (flag3)
						{
							this.FindLineConfig.InputLink.SourceToolId = null;
							this.FindLineConfig.InputLink.SourceToolName = this._selectedSourceTool.ToolName;
						}
						else
						{
							this.FindLineConfig.InputLink.SourceToolId = null;
							this.FindLineConfig.InputLink.SourceToolName = null;
						}
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x060004A5 RID: 1189 RVA: 0x000179B8 File Offset: 0x00015BB8
		// (remove) Token: 0x060004A6 RID: 1190 RVA: 0x000179F0 File Offset: 0x00015BF0
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x060004A7 RID: 1191 RVA: 0x00017A25 File Offset: 0x00015C25
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x00017A44 File Offset: 0x00015C44
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.FindLineConfig == null || this.FindLineConfig.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.FindLineConfig.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.FindLineConfig.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.FindLineConfig.InputLink.SourceToolId = null;
				this.FindLineConfig.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x040001E1 RID: 481
		private ToolImageSourceOption _selectedSourceTool;
	}
}
