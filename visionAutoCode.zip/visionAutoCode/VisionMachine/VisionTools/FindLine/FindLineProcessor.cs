﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.FindLine
{
	// Token: 0x02000069 RID: 105
	public class FindLineProcessor : IToolProcessor
	{
		// Token: 0x060004AA RID: 1194 RVA: 0x00017CF3 File Offset: 0x00015EF3
		public FindLineProcessor() : this(null)
		{
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x00017CFE File Offset: 0x00015EFE
		public FindLineProcessor(IDictionary<string, ShapeMatchResult> cachedMasterResults)
		{
			this._cachedMasterResults = cachedMasterResults;
		}

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x060004AC RID: 1196 RVA: 0x00017D10 File Offset: 0x00015F10
		public ToolType ToolType
		{
			get
			{
				return ToolType.FindLine;
			}
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x00017D24 File Offset: 0x00015F24
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			ToolProcessResult result = new ToolProcessResult();
			FindLineResult lineResult = this.Run((context != null) ? context.InputImage : null, tool);
			result.IsSuccess = lineResult.IsSuccess;
			result.Message = lineResult.Message;
			result.Data = lineResult;
			return result;
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x00017D74 File Offset: 0x00015F74
		public FindLineResult Run(HObject image, ToolVision tool)
		{
			FindLineResult result = new FindLineResult();
			bool flag = image == null || !image.IsInitialized();
			FindLineResult result2;
			if (flag)
			{
				result.Message = "Input image null.";
				result2 = result;
			}
			else
			{
				FindLineToolConfig config = ((tool != null) ? tool.Config : null) as FindLineToolConfig;
				bool flag2 = config == null;
				if (flag2)
				{
					result.Message = "Find Line config null.";
					result2 = result;
				}
				else
				{
					bool flag3 = !config.IsEnabled;
					if (flag3)
					{
						result.Message = "Find Line tool is disabled.";
						result2 = result;
					}
					else
					{
						this._currentMasterProcessingTimes = this.UpdateMasterShapeModels(image, tool);
						RoiData roi = tool.RoiItems.FirstOrDefault((RoiData x) => x.IsEnabled && x.RoiType == RoiType.Line);
						bool flag4 = roi == null;
						if (flag4)
						{
							result.Message = "Find Line requires one enabled Line ROI.";
							result2 = result;
						}
						else
						{
							RoiData transformedRoi = this.CreateTransformedLineRoi(roi, tool);
							result.Roi = transformedRoi;
							result.ToolName = tool.Name;
							result.MasterPositionToolName = this.GetMasterPositionToolName(roi);
							result.MasterAngleToolName = this.GetMasterAngleToolName(roi);
							result.MasterProcessingTimeMs = this.GetMasterProcessingTime(result.MasterPositionToolName, result.MasterAngleToolName);
							HTuple metrologyHandle = null;
							HObject grayImage = null;
							Stopwatch findLineStopwatch = Stopwatch.StartNew();
							try
							{
								grayImage = this.ConvertToGray(image);
								HTuple width;
								HTuple height;
								HOperatorSet.GetImageSize(grayImage, out width, out height);
								HOperatorSet.CreateMetrologyModel(out metrologyHandle);
								HOperatorSet.SetMetrologyModelImageSize(metrologyHandle, width, height);
								HTuple index;
								HOperatorSet.AddMetrologyObjectLineMeasure(metrologyHandle, transformedRoi.Row1, transformedRoi.Col1, transformedRoi.Row2, transformedRoi.Col2, Math.Max(1, config.Length1), Math.Max(1, config.Length2), Math.Max(1, config.Sigma), Math.Max(1, config.MeasureThreshold), new HTuple(), new HTuple(), out index);
								HOperatorSet.SetMetrologyObjectParam(metrologyHandle, "all", "measure_transition", this.GetTransition(config.EdgeTransition));
								HOperatorSet.SetMetrologyObjectParam(metrologyHandle, "all", "measure_select", this.GetSelector(config.Selector));
								HOperatorSet.ApplyMetrologyModel(grayImage, metrologyHandle);
								HTuple lineParam;
								HOperatorSet.GetMetrologyObjectResult(metrologyHandle, "all", "all", "result_type", "all_param", out lineParam);
								bool flag5 = lineParam == null || lineParam.Length < 4;
								if (flag5)
								{
									result.Message = "Line was not found.";
									result2 = result;
								}
								else
								{
									result.StartRow = lineParam[0].D;
									result.StartColumn = lineParam[1].D;
									result.EndRow = lineParam[2].D;
									result.EndColumn = lineParam[3].D;
									HTuple centerRow;
									HTuple centerColumn;
									HTuple length;
									HTuple phi;
									HOperatorSet.LinePosition(result.StartRow, result.StartColumn, result.EndRow, result.EndColumn, out centerRow, out centerColumn, out length, out phi);
									result.CenterRow = centerRow.D;
									result.CenterColumn = centerColumn.D;
									result.Length = length.D;
									result.Phi = phi.D;
									HObject measureRegions;
									HTuple measureRows;
									HTuple measureColumns;
									HOperatorSet.GetMetrologyObjectMeasures(out measureRegions, metrologyHandle, "all", "all", out measureRows, out measureColumns);
									result.MeasureRegions = measureRegions;
									result.IsSuccess = true;
									result.Message = "Find Line OK.";
									result2 = result;
								}
							}
							catch (Exception ex)
							{
								result.Message = "Find Line failed: " + ex.Message;
								result2 = result;
							}
							finally
							{
								findLineStopwatch.Stop();
								result.ProcessingTimeMs = findLineStopwatch.Elapsed.TotalMilliseconds;
								result.TotalProcessingTimeMs = result.MasterProcessingTimeMs + result.ProcessingTimeMs;
								bool flag6 = metrologyHandle != null;
								if (flag6)
								{
									HOperatorSet.ClearMetrologyModel(metrologyHandle);
								}
								bool flag7 = grayImage != null;
								if (flag7)
								{
									grayImage.Dispose();
								}
								this._currentMasterProcessingTimes = null;
								this._currentMasterMatchStates = null;
							}
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x000181F8 File Offset: 0x000163F8
		private HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.I == 1;
			HObject result;
			if (flag)
			{
				HObject gray;
				HOperatorSet.CopyImage(image, out gray);
				result = gray;
			}
			else
			{
				HObject grayImage;
				HOperatorSet.Rgb1ToGray(image, out grayImage);
				result = grayImage;
			}
			return result;
		}

		// Token: 0x060004B0 RID: 1200 RVA: 0x0001823C File Offset: 0x0001643C
		private string GetTransition(FindLineEdgeTransition transition)
		{
			return (transition == FindLineEdgeTransition.LightToDark) ? "negative" : "positive";
		}

		// Token: 0x060004B1 RID: 1201 RVA: 0x00018260 File Offset: 0x00016460
		private string GetSelector(FindLineMeasureSelector selector)
		{
			switch (selector)
			{
			case FindLineMeasureSelector.First:
				return "first";
			case FindLineMeasureSelector.Last:
				return "last";
			}
			return "all";
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x000182A0 File Offset: 0x000164A0
		private RoiData CreateTransformedLineRoi(RoiData roi, ToolVision tool)
		{
			FindLineProcessor.MasterTransform transform = this.GetMasterTransform(roi, tool);
			Tuple<double, double> p = this.TransformPoint(roi.Row1, roi.Col1, transform);
			Tuple<double, double> p2 = this.TransformPoint(roi.Row2, roi.Col2, transform);
			return new RoiData
			{
				RoiType = RoiType.Line,
				Name = roi.Name,
				Row1 = p.Item1,
				Col1 = p.Item2,
				Row2 = p2.Item1,
				Col2 = p2.Item2,
				IsEnabled = roi.IsEnabled,
				MaskMode = roi.MaskMode,
				Polarity = roi.Polarity,
				Description = roi.Description,
				MasterToolName = roi.MasterToolName,
				MasterPositionToolName = roi.MasterPositionToolName,
				MasterAngleToolName = roi.MasterAngleToolName
			};
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x0001838C File Offset: 0x0001658C
		private FindLineProcessor.MasterTransform GetMasterTransform(RoiData roi, ToolVision tool)
		{
			FindLineProcessor.MasterTransform transform = new FindLineProcessor.MasterTransform();
			bool flag = roi == null || ((tool != null) ? tool.ParentTurnSnap : null) == null;
			FindLineProcessor.MasterTransform result;
			if (flag)
			{
				result = transform;
			}
			else
			{
				ShapeModelToolTrain positionTrain = this.GetMasterTrain(tool, this.GetMasterPositionToolName(roi), true);
				bool flag2 = positionTrain != null;
				if (flag2)
				{
					transform.Row = positionTrain.LastRow - positionTrain.MasterRow;
					transform.Column = positionTrain.LastColumn - positionTrain.MasterColumn;
				}
				ShapeModelToolTrain angleTrain = this.GetMasterTrain(tool, this.GetMasterAngleToolName(roi), false);
				bool flag3 = angleTrain != null;
				if (flag3)
				{
					transform.Angle = angleTrain.LastAngle - angleTrain.MasterAngle;
					transform.MasterRow = angleTrain.MasterRow;
					transform.MasterColumn = angleTrain.MasterColumn;
				}
				result = transform;
			}
			return result;
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x00018458 File Offset: 0x00016658
		private ShapeModelToolTrain GetMasterTrain(ToolVision tool, string masterToolName, bool isPositionMaster)
		{
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || string.IsNullOrWhiteSpace(masterToolName) || masterToolName == "None";
			ShapeModelToolTrain result;
			if (flag)
			{
				result = null;
			}
			else
			{
				ToolVision masterTool = tool.ParentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || (isPositionMaster && x.ToolType == ToolType.CircleMaster) || (isPositionMaster && x.ToolType == ToolType.BoundingBoxMaster) || (x.ToolType == ToolType.MinAreaMaster || (isPositionMaster && x.ToolType == ToolType.IntersectingLines)) || (!isPositionMaster && x.ToolType == ToolType.AngleSelector)) && x.Name == masterToolName);
				ShapeModelToolTrain train = ((masterTool != null) ? masterTool.TrainModel : null) as ShapeModelToolTrain;
				bool flag2 = train == null || !train.HasMasterDefined;
				if (flag2)
				{
					result = null;
				}
				else
				{
					bool isMasterFound;
					bool flag3 = this._currentMasterMatchStates != null && this._currentMasterMatchStates.TryGetValue(masterToolName, out isMasterFound) && !isMasterFound;
					if (flag3)
					{
						result = null;
					}
					else
					{
						result = train;
					}
				}
			}
			return result;
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x0001855C File Offset: 0x0001675C
		private string GetMasterPositionToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && roi.MasterPositionToolName != "None";
				if (flag2)
				{
					result = roi.MasterPositionToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x000185EC File Offset: 0x000167EC
		private string GetMasterAngleToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && roi.MasterAngleToolName != "None";
				if (flag2)
				{
					result = roi.MasterAngleToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x0001867C File Offset: 0x0001687C
		private Tuple<double, double> TransformPoint(double row, double column, FindLineProcessor.MasterTransform transform)
		{
			bool flag = transform == null;
			Tuple<double, double> result;
			if (flag)
			{
				result = Tuple.Create<double, double>(row, column);
			}
			else
			{
				double cos = Math.Cos(transform.Angle);
				double sin = Math.Sin(transform.Angle);
				double relRow = row - transform.MasterRow;
				double relColumn = column - transform.MasterColumn;
				double newRow = transform.MasterRow + transform.Row + relRow * cos - relColumn * sin;
				double newColumn = transform.MasterColumn + transform.Column + relRow * sin + relColumn * cos;
				result = Tuple.Create<double, double>(newRow, newColumn);
			}
			return result;
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x00018708 File Offset: 0x00016908
		private Dictionary<string, double> UpdateMasterShapeModels(HObject image, ToolVision tool)
		{
			Dictionary<string, double> processingTimes = new Dictionary<string, double>();
			this._currentMasterMatchStates = new Dictionary<string, bool>();
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || tool.RoiItems == null;
			Dictionary<string, double> result;
			if (flag)
			{
				result = processingTimes;
			}
			else
			{
				List<string> masterNames = (from x in (from x in tool.RoiItems
				where x.IsEnabled && x.RoiType == RoiType.Line
				select x).SelectMany((RoiData x) => new string[]
				{
					this.GetMasterPositionToolName(x),
					this.GetMasterAngleToolName(x)
				})
				where !string.IsNullOrWhiteSpace(x) && x != "None"
				select x).Distinct<string>().ToList<string>();
				bool flag2 = masterNames.Count == 0;
				if (flag2)
				{
					result = processingTimes;
				}
				else
				{
					ShapeModelProcessor shapeProcessor = new ShapeModelProcessor();
					using (List<string>.Enumerator enumerator = masterNames.GetEnumerator())
					{
						Func<ToolVision, bool> <>9__3;
						while (enumerator.MoveNext())
						{
							string masterName = enumerator.Current;
							Stopwatch stopwatch = Stopwatch.StartNew();
							IEnumerable<ToolVision> tools = tool.ParentTurnSnap.Tools;
							Func<ToolVision, bool> predicate;
							if ((predicate = <>9__3) == null)
							{
								predicate = (<>9__3 = ((ToolVision x) => x != tool));
							}
							ToolVision masterTool = tools.TakeWhile(predicate).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.BoundingBoxMaster || x.ToolType == ToolType.MinAreaMaster || x.ToolType == ToolType.IntersectingLines || x.ToolType == ToolType.AngleSelector) && x.Name == masterName);
							bool flag3 = masterTool == null;
							if (flag3)
							{
								stopwatch.Stop();
								processingTimes[masterName] = stopwatch.Elapsed.TotalMilliseconds;
								this._currentMasterMatchStates[masterName] = false;
							}
							else
							{
								ShapeMatchResult matchResult;
								bool flag4 = this.TryGetCachedMasterResult(masterName, out matchResult);
								if (flag4)
								{
									this.ApplyMasterResultToTrain(masterTool, matchResult);
									stopwatch.Stop();
									processingTimes[masterName] = Math.Max(0.0, matchResult.ProcessingTimeMs);
									this._currentMasterMatchStates[masterName] = matchResult.IsSuccess;
								}
								else
								{
									bool flag5 = masterTool.ToolType == ToolType.CircleMaster;
									if (flag5)
									{
										matchResult = new CircleMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
									}
									else
									{
										bool flag6 = masterTool.ToolType == ToolType.BoundingBoxMaster;
										if (flag6)
										{
											matchResult = new BoundingBoxMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
										}
										else
										{
											bool flag7 = masterTool.ToolType == ToolType.MinAreaMaster;
											if (flag7)
											{
												matchResult = new MinAreaMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
											}
											else
											{
												bool flag8 = masterTool.ToolType == ToolType.IntersectingLines;
												if (flag8)
												{
													matchResult = new IntersectingLinesProcessor(null, this._cachedMasterResults).Match(image, masterTool);
												}
												else
												{
													bool flag9 = masterTool.ToolType == ToolType.AngleSelector;
													if (flag9)
													{
														matchResult = new AngleSelectorProcessor(null, this._cachedMasterResults).Match(image, masterTool);
													}
													else
													{
														matchResult = shapeProcessor.Match(image, masterTool);
													}
												}
											}
										}
									}
									stopwatch.Stop();
									processingTimes[masterName] = stopwatch.Elapsed.TotalMilliseconds;
									this._currentMasterMatchStates[masterName] = (matchResult != null && matchResult.IsSuccess);
								}
							}
						}
					}
					result = processingTimes;
				}
			}
			return result;
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x00018A98 File Offset: 0x00016C98
		private bool TryGetCachedMasterResult(string masterName, out ShapeMatchResult result)
		{
			result = null;
			bool flag = this._cachedMasterResults == null || string.IsNullOrWhiteSpace(masterName);
			return !flag && this._cachedMasterResults.TryGetValue(masterName, out result) && result != null;
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x00018AE0 File Offset: 0x00016CE0
		private void ApplyMasterResultToTrain(ToolVision masterTool, ShapeMatchResult result)
		{
			bool flag = masterTool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				ShapeModelToolTrain train = masterTool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (!flag2)
				{
					train.LastRow = result.Row;
					train.LastColumn = result.Column;
					train.LastAngle = result.Angle;
					train.LastScore = result.Score;
				}
			}
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x00018B54 File Offset: 0x00016D54
		private double GetMasterProcessingTime(string masterPositionToolName, string masterAngleToolName)
		{
			double processingTime = 0.0;
			foreach (string masterName in (from x in new string[]
			{
				masterPositionToolName,
				masterAngleToolName
			}
			where !string.IsNullOrWhiteSpace(x) && x != "None"
			select x).Distinct<string>())
			{
				double time;
				bool flag = this._currentMasterProcessingTimes != null && this._currentMasterProcessingTimes.TryGetValue(masterName, out time);
				if (flag)
				{
					processingTime += time;
				}
			}
			return processingTime;
		}

		// Token: 0x040001E8 RID: 488
		private readonly IDictionary<string, ShapeMatchResult> _cachedMasterResults;

		// Token: 0x040001E9 RID: 489
		private Dictionary<string, double> _currentMasterProcessingTimes;

		// Token: 0x040001EA RID: 490
		private Dictionary<string, bool> _currentMasterMatchStates;

		// Token: 0x020002F0 RID: 752
		private class MasterTransform
		{
			// Token: 0x17000B1E RID: 2846
			// (get) Token: 0x06002701 RID: 9985 RVA: 0x000E01A8 File Offset: 0x000DE3A8
			// (set) Token: 0x06002702 RID: 9986 RVA: 0x000E01B0 File Offset: 0x000DE3B0
			public double Row { get; set; }

			// Token: 0x17000B1F RID: 2847
			// (get) Token: 0x06002703 RID: 9987 RVA: 0x000E01B9 File Offset: 0x000DE3B9
			// (set) Token: 0x06002704 RID: 9988 RVA: 0x000E01C1 File Offset: 0x000DE3C1
			public double Column { get; set; }

			// Token: 0x17000B20 RID: 2848
			// (get) Token: 0x06002705 RID: 9989 RVA: 0x000E01CA File Offset: 0x000DE3CA
			// (set) Token: 0x06002706 RID: 9990 RVA: 0x000E01D2 File Offset: 0x000DE3D2
			public double Angle { get; set; }

			// Token: 0x17000B21 RID: 2849
			// (get) Token: 0x06002707 RID: 9991 RVA: 0x000E01DB File Offset: 0x000DE3DB
			// (set) Token: 0x06002708 RID: 9992 RVA: 0x000E01E3 File Offset: 0x000DE3E3
			public double MasterRow { get; set; }

			// Token: 0x17000B22 RID: 2850
			// (get) Token: 0x06002709 RID: 9993 RVA: 0x000E01EC File Offset: 0x000DE3EC
			// (set) Token: 0x0600270A RID: 9994 RVA: 0x000E01F4 File Offset: 0x000DE3F4
			public double MasterColumn { get; set; }
		}
	}
}
