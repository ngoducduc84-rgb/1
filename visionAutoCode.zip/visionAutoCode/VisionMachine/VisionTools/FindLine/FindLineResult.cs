﻿using System;
using HalconDotNet;
using VisionMachine.Models.Roi;

namespace VisionMachine.VisionTools.FindLine
{
	// Token: 0x0200006A RID: 106
	public class FindLineResult : IDisposable
	{
		// Token: 0x17000190 RID: 400
		// (get) Token: 0x060004BC RID: 1212 RVA: 0x00018C08 File Offset: 0x00016E08
		// (set) Token: 0x060004BD RID: 1213 RVA: 0x00018C10 File Offset: 0x00016E10
		public bool IsSuccess { get; set; }

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x060004BE RID: 1214 RVA: 0x00018C19 File Offset: 0x00016E19
		// (set) Token: 0x060004BF RID: 1215 RVA: 0x00018C21 File Offset: 0x00016E21
		public string Message { get; set; }

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x060004C0 RID: 1216 RVA: 0x00018C2A File Offset: 0x00016E2A
		// (set) Token: 0x060004C1 RID: 1217 RVA: 0x00018C32 File Offset: 0x00016E32
		public RoiData Roi { get; set; }

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x060004C2 RID: 1218 RVA: 0x00018C3B File Offset: 0x00016E3B
		// (set) Token: 0x060004C3 RID: 1219 RVA: 0x00018C43 File Offset: 0x00016E43
		public double StartRow { get; set; }

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x060004C4 RID: 1220 RVA: 0x00018C4C File Offset: 0x00016E4C
		// (set) Token: 0x060004C5 RID: 1221 RVA: 0x00018C54 File Offset: 0x00016E54
		public double StartColumn { get; set; }

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x060004C6 RID: 1222 RVA: 0x00018C5D File Offset: 0x00016E5D
		// (set) Token: 0x060004C7 RID: 1223 RVA: 0x00018C65 File Offset: 0x00016E65
		public double EndRow { get; set; }

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x060004C8 RID: 1224 RVA: 0x00018C6E File Offset: 0x00016E6E
		// (set) Token: 0x060004C9 RID: 1225 RVA: 0x00018C76 File Offset: 0x00016E76
		public double EndColumn { get; set; }

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x060004CA RID: 1226 RVA: 0x00018C7F File Offset: 0x00016E7F
		// (set) Token: 0x060004CB RID: 1227 RVA: 0x00018C87 File Offset: 0x00016E87
		public double CenterRow { get; set; }

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x060004CC RID: 1228 RVA: 0x00018C90 File Offset: 0x00016E90
		// (set) Token: 0x060004CD RID: 1229 RVA: 0x00018C98 File Offset: 0x00016E98
		public double CenterColumn { get; set; }

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x060004CE RID: 1230 RVA: 0x00018CA1 File Offset: 0x00016EA1
		// (set) Token: 0x060004CF RID: 1231 RVA: 0x00018CA9 File Offset: 0x00016EA9
		public double Length { get; set; }

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x060004D0 RID: 1232 RVA: 0x00018CB2 File Offset: 0x00016EB2
		// (set) Token: 0x060004D1 RID: 1233 RVA: 0x00018CBA File Offset: 0x00016EBA
		public double Phi { get; set; }

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x060004D2 RID: 1234 RVA: 0x00018CC3 File Offset: 0x00016EC3
		// (set) Token: 0x060004D3 RID: 1235 RVA: 0x00018CCB File Offset: 0x00016ECB
		public HObject MeasureRegions { get; set; }

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x060004D4 RID: 1236 RVA: 0x00018CD4 File Offset: 0x00016ED4
		// (set) Token: 0x060004D5 RID: 1237 RVA: 0x00018CDC File Offset: 0x00016EDC
		public string ToolName { get; set; }

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x060004D6 RID: 1238 RVA: 0x00018CE5 File Offset: 0x00016EE5
		// (set) Token: 0x060004D7 RID: 1239 RVA: 0x00018CED File Offset: 0x00016EED
		public string MasterPositionToolName { get; set; }

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x060004D8 RID: 1240 RVA: 0x00018CF6 File Offset: 0x00016EF6
		// (set) Token: 0x060004D9 RID: 1241 RVA: 0x00018CFE File Offset: 0x00016EFE
		public string MasterAngleToolName { get; set; }

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x060004DA RID: 1242 RVA: 0x00018D07 File Offset: 0x00016F07
		// (set) Token: 0x060004DB RID: 1243 RVA: 0x00018D0F File Offset: 0x00016F0F
		public double MasterProcessingTimeMs { get; set; }

		// Token: 0x170001A0 RID: 416
		// (get) Token: 0x060004DC RID: 1244 RVA: 0x00018D18 File Offset: 0x00016F18
		// (set) Token: 0x060004DD RID: 1245 RVA: 0x00018D20 File Offset: 0x00016F20
		public string InputSourceToolName { get; set; }

		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x060004DE RID: 1246 RVA: 0x00018D29 File Offset: 0x00016F29
		// (set) Token: 0x060004DF RID: 1247 RVA: 0x00018D31 File Offset: 0x00016F31
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x060004E0 RID: 1248 RVA: 0x00018D3A File Offset: 0x00016F3A
		// (set) Token: 0x060004E1 RID: 1249 RVA: 0x00018D42 File Offset: 0x00016F42
		public double ProcessingTimeMs { get; set; }

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x060004E2 RID: 1250 RVA: 0x00018D4B File Offset: 0x00016F4B
		// (set) Token: 0x060004E3 RID: 1251 RVA: 0x00018D53 File Offset: 0x00016F53
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x060004E4 RID: 1252 RVA: 0x00018D5C File Offset: 0x00016F5C
		public void Dispose()
		{
			bool flag = this.MeasureRegions != null;
			if (flag)
			{
				this.MeasureRegions.Dispose();
				this.MeasureRegions = null;
			}
		}
	}
}
