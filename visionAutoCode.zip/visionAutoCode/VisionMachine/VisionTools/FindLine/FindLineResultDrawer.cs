﻿using System;
using System.Windows.Media;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.FindLine
{
	// Token: 0x0200006B RID: 107
	public class FindLineResultDrawer
	{
		// Token: 0x060004E6 RID: 1254 RVA: 0x00018D90 File Offset: 0x00016F90
		public void Draw(HWindow window, ToolVision tool, FindLineResult result)
		{
			bool flag = window == null || result == null;
			if (!flag)
			{
				FindLineToolConfig config = ((tool != null) ? tool.Config : null) as FindLineToolConfig;
				bool flag2 = config == null || config.ShowRoi;
				if (flag2)
				{
					this.DrawRoi(window, result.Roi);
				}
				bool flag3 = !result.IsSuccess;
				if (!flag3)
				{
					bool flag4 = (config == null || config.ShowSearchOutline) && result.MeasureRegions != null && result.MeasureRegions.IsInitialized();
					if (flag4)
					{
						HOperatorSet.SetColor(window, "yellow");
						HOperatorSet.SetDraw(window, "margin");
						HOperatorSet.SetLineWidth(window, 1);
						HOperatorSet.DispObj(result.MeasureRegions, window);
					}
					bool flag5 = config == null || config.ShowFoundLine;
					if (flag5)
					{
						HOperatorSet.SetColor(window, "yellow");
						HOperatorSet.SetLineWidth(window, 2);
						HOperatorSet.DispLine(window, result.StartRow, result.StartColumn, result.EndRow, result.EndColumn);
					}
					bool flag6 = config == null || !config.ShowCoordinateText;
					if (!flag6)
					{
						this.SetTextColor(window, config.CoordinateTextColorValue, config.CoordinateTextColor);
						this.SetTextSize(window, config.CoordinateTextSize);
						string toolName = this.GetToolName(tool, result);
						HOperatorSet.SetTposition(window, result.StartRow, result.StartColumn);
						HOperatorSet.WriteString(window, string.Concat(new string[]
						{
							toolName,
							" P1(",
							result.StartRow.ToString("0.0"),
							", ",
							result.StartColumn.ToString("0.0"),
							")"
						}));
						HOperatorSet.SetTposition(window, result.EndRow, result.EndColumn);
						HOperatorSet.WriteString(window, string.Concat(new string[]
						{
							toolName,
							" P2(",
							result.EndRow.ToString("0.0"),
							", ",
							result.EndColumn.ToString("0.0"),
							")"
						}));
					}
				}
			}
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x00019038 File Offset: 0x00017238
		private string GetToolName(ToolVision tool, FindLineResult result)
		{
			bool flag = !string.IsNullOrWhiteSpace((tool != null) ? tool.Name : null);
			string result2;
			if (flag)
			{
				result2 = tool.Name;
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace((result != null) ? result.ToolName : null);
				if (flag2)
				{
					result2 = result.ToolName;
				}
				else
				{
					result2 = "Find Line";
				}
			}
			return result2;
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x00019094 File Offset: 0x00017294
		private void DrawRoi(HWindow window, RoiData roi)
		{
			bool flag = window == null || roi == null || roi.RoiType != RoiType.Line;
			if (!flag)
			{
				HOperatorSet.SetColor(window, "cyan");
				HOperatorSet.SetLineWidth(window, 1);
				HOperatorSet.DispLine(window, roi.Row1, roi.Col1, roi.Row2, roi.Col2);
			}
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x00019120 File Offset: 0x00017320
		private void SetTextColor(HWindow window, Color color, string fallbackColor)
		{
			try
			{
				HOperatorSet.SetColor(window, this.ToHalconColor(color));
			}
			catch
			{
				try
				{
					HOperatorSet.SetColor(window, string.IsNullOrWhiteSpace(fallbackColor) ? "white" : fallbackColor);
				}
				catch
				{
					HOperatorSet.SetColor(window, "white");
				}
			}
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x000191AC File Offset: 0x000173AC
		private string ToHalconColor(Color color)
		{
			return "#" + color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x00019204 File Offset: 0x00017404
		private void SetTextSize(HWindow window, int textSize)
		{
			int normalizedSize = (textSize < 1) ? 1 : textSize;
			try
			{
				HOperatorSet.SetFont(window, "Arial-" + normalizedSize.ToString());
			}
			catch
			{
			}
		}
	}
}
