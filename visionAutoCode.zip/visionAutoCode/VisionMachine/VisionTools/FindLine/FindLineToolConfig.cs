﻿using System;
using System.ComponentModel;
using System.Windows.Media;
using Newtonsoft.Json;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindLine
{
	// Token: 0x0200006C RID: 108
	public class FindLineToolConfig : ToolConfigBase
	{
		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x060004ED RID: 1261 RVA: 0x00019258 File Offset: 0x00017458
		// (set) Token: 0x060004EE RID: 1262 RVA: 0x00019260 File Offset: 0x00017460
		public ImageInputLink InputLink { get; set; } = new ImageInputLink();

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x060004EF RID: 1263 RVA: 0x0001926C File Offset: 0x0001746C
		// (set) Token: 0x060004F0 RID: 1264 RVA: 0x00019284 File Offset: 0x00017484
		[DisplayName("Sigma")]
		public int Sigma
		{
			get
			{
				return this._sigma;
			}
			set
			{
				bool flag = this._sigma != value;
				if (flag)
				{
					this._sigma = value;
					base.OnPropertyChanged("Sigma");
				}
			}
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x060004F1 RID: 1265 RVA: 0x000192B8 File Offset: 0x000174B8
		// (set) Token: 0x060004F2 RID: 1266 RVA: 0x000192D0 File Offset: 0x000174D0
		[DisplayName("Measure Threshold")]
		public int MeasureThreshold
		{
			get
			{
				return this._measureThreshold;
			}
			set
			{
				bool flag = this._measureThreshold != value;
				if (flag)
				{
					this._measureThreshold = value;
					base.OnPropertyChanged("MeasureThreshold");
				}
			}
		}

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x060004F3 RID: 1267 RVA: 0x00019304 File Offset: 0x00017504
		// (set) Token: 0x060004F4 RID: 1268 RVA: 0x0001931C File Offset: 0x0001751C
		[DisplayName("Threshold Min")]
		public int ThresholdMin
		{
			get
			{
				return this._thresholdMin;
			}
			set
			{
				bool flag = this._thresholdMin != value;
				if (flag)
				{
					this._thresholdMin = value;
					base.OnPropertyChanged("ThresholdMin");
				}
			}
		}

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x060004F5 RID: 1269 RVA: 0x00019350 File Offset: 0x00017550
		// (set) Token: 0x060004F6 RID: 1270 RVA: 0x00019368 File Offset: 0x00017568
		[DisplayName("Threshold Max")]
		public int ThresholdMax
		{
			get
			{
				return this._thresholdMax;
			}
			set
			{
				bool flag = this._thresholdMax != value;
				if (flag)
				{
					this._thresholdMax = value;
					base.OnPropertyChanged("ThresholdMax");
				}
			}
		}

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x060004F7 RID: 1271 RVA: 0x0001939C File Offset: 0x0001759C
		// (set) Token: 0x060004F8 RID: 1272 RVA: 0x000193B4 File Offset: 0x000175B4
		[DisplayName("Length 1")]
		public int Length1
		{
			get
			{
				return this._length1;
			}
			set
			{
				bool flag = this._length1 != value;
				if (flag)
				{
					this._length1 = value;
					base.OnPropertyChanged("Length1");
				}
			}
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x060004F9 RID: 1273 RVA: 0x000193E8 File Offset: 0x000175E8
		// (set) Token: 0x060004FA RID: 1274 RVA: 0x00019400 File Offset: 0x00017600
		[DisplayName("Length 2")]
		public int Length2
		{
			get
			{
				return this._length2;
			}
			set
			{
				bool flag = this._length2 != value;
				if (flag)
				{
					this._length2 = value;
					base.OnPropertyChanged("Length2");
				}
			}
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x060004FB RID: 1275 RVA: 0x00019434 File Offset: 0x00017634
		// (set) Token: 0x060004FC RID: 1276 RVA: 0x0001944C File Offset: 0x0001764C
		[DisplayName("Transition")]
		public FindLineEdgeTransition EdgeTransition
		{
			get
			{
				return this._edgeTransition;
			}
			set
			{
				bool flag = this._edgeTransition != value;
				if (flag)
				{
					this._edgeTransition = value;
					base.OnPropertyChanged("EdgeTransition");
				}
			}
		}

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x060004FD RID: 1277 RVA: 0x00019480 File Offset: 0x00017680
		// (set) Token: 0x060004FE RID: 1278 RVA: 0x00019498 File Offset: 0x00017698
		[DisplayName("Selector")]
		public FindLineMeasureSelector Selector
		{
			get
			{
				return this._selector;
			}
			set
			{
				bool flag = this._selector != value;
				if (flag)
				{
					this._selector = value;
					base.OnPropertyChanged("Selector");
				}
			}
		}

		// Token: 0x170001AD RID: 429
		// (get) Token: 0x060004FF RID: 1279 RVA: 0x000194CC File Offset: 0x000176CC
		// (set) Token: 0x06000500 RID: 1280 RVA: 0x000194E4 File Offset: 0x000176E4
		[DisplayName("Show Coordinate Text")]
		public bool ShowCoordinateText
		{
			get
			{
				return this._showCoordinateText;
			}
			set
			{
				bool flag = this._showCoordinateText != value;
				if (flag)
				{
					this._showCoordinateText = value;
					base.OnPropertyChanged("ShowCoordinateText");
				}
			}
		}

		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000501 RID: 1281 RVA: 0x00019518 File Offset: 0x00017718
		// (set) Token: 0x06000502 RID: 1282 RVA: 0x00019530 File Offset: 0x00017730
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				bool flag = this._showRoi != value;
				if (flag)
				{
					this._showRoi = value;
					base.OnPropertyChanged("ShowRoi");
				}
			}
		}

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x06000503 RID: 1283 RVA: 0x00019564 File Offset: 0x00017764
		// (set) Token: 0x06000504 RID: 1284 RVA: 0x0001957C File Offset: 0x0001777C
		[DisplayName("Show Found Line")]
		public bool ShowFoundLine
		{
			get
			{
				return this._showFoundLine;
			}
			set
			{
				bool flag = this._showFoundLine != value;
				if (flag)
				{
					this._showFoundLine = value;
					base.OnPropertyChanged("ShowFoundLine");
				}
			}
		}

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x06000505 RID: 1285 RVA: 0x000195B0 File Offset: 0x000177B0
		// (set) Token: 0x06000506 RID: 1286 RVA: 0x000195C8 File Offset: 0x000177C8
		[DisplayName("Show Search Outline")]
		public bool ShowSearchOutline
		{
			get
			{
				return this._showSearchOutline;
			}
			set
			{
				bool flag = this._showSearchOutline != value;
				if (flag)
				{
					this._showSearchOutline = value;
					base.OnPropertyChanged("ShowSearchOutline");
				}
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x06000507 RID: 1287 RVA: 0x000195FC File Offset: 0x000177FC
		// (set) Token: 0x06000508 RID: 1288 RVA: 0x00019614 File Offset: 0x00017814
		[DisplayName("Coordinate Text Color")]
		public string CoordinateTextColor
		{
			get
			{
				return this._coordinateTextColor;
			}
			set
			{
				bool flag = this._coordinateTextColor != value;
				if (flag)
				{
					this._coordinateTextColor = value;
					this._coordinateTextColorValue = this.ParseColor(value);
					base.OnPropertyChanged("CoordinateTextColor");
					base.OnPropertyChanged("CoordinateTextColorValue");
				}
			}
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x06000509 RID: 1289 RVA: 0x00019660 File Offset: 0x00017860
		// (set) Token: 0x0600050A RID: 1290 RVA: 0x00019678 File Offset: 0x00017878
		[Browsable(false)]
		[JsonIgnore]
		public Color CoordinateTextColorValue
		{
			get
			{
				return this._coordinateTextColorValue;
			}
			set
			{
				bool flag = this._coordinateTextColorValue != value;
				if (flag)
				{
					this._coordinateTextColorValue = value;
					this._coordinateTextColor = this.ToHalconColor(value);
					base.OnPropertyChanged("CoordinateTextColorValue");
					base.OnPropertyChanged("CoordinateTextColor");
				}
			}
		}

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x0600050B RID: 1291 RVA: 0x000196C4 File Offset: 0x000178C4
		// (set) Token: 0x0600050C RID: 1292 RVA: 0x000196DC File Offset: 0x000178DC
		[DisplayName("Coordinate Text Size")]
		public int CoordinateTextSize
		{
			get
			{
				return this._coordinateTextSize;
			}
			set
			{
				int normalizedValue = (value < 1) ? 1 : value;
				bool flag = this._coordinateTextSize != normalizedValue;
				if (flag)
				{
					this._coordinateTextSize = normalizedValue;
					base.OnPropertyChanged("CoordinateTextSize");
				}
			}
		}

		// Token: 0x0600050D RID: 1293 RVA: 0x00019718 File Offset: 0x00017918
		private Color ParseColor(string color)
		{
			bool flag = string.IsNullOrWhiteSpace(color);
			Color result;
			if (flag)
			{
				result = Colors.White;
			}
			else
			{
				try
				{
					result = (Color)ColorConverter.ConvertFromString(color);
				}
				catch
				{
					result = Colors.White;
				}
			}
			return result;
		}

		// Token: 0x0600050E RID: 1294 RVA: 0x00019764 File Offset: 0x00017964
		private string ToHalconColor(Color color)
		{
			return "#" + color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
		}

		// Token: 0x040001FF RID: 511
		private int _sigma = 5;

		// Token: 0x04000200 RID: 512
		private int _measureThreshold = 10;

		// Token: 0x04000201 RID: 513
		private int _thresholdMin = 0;

		// Token: 0x04000202 RID: 514
		private int _thresholdMax = 255;

		// Token: 0x04000203 RID: 515
		private int _length1 = 70;

		// Token: 0x04000204 RID: 516
		private int _length2 = 50;

		// Token: 0x04000205 RID: 517
		private FindLineEdgeTransition _edgeTransition = FindLineEdgeTransition.DarkToLight;

		// Token: 0x04000206 RID: 518
		private FindLineMeasureSelector _selector = FindLineMeasureSelector.All;

		// Token: 0x04000207 RID: 519
		private bool _showRoi = true;

		// Token: 0x04000208 RID: 520
		private bool _showFoundLine = true;

		// Token: 0x04000209 RID: 521
		private bool _showSearchOutline = true;

		// Token: 0x0400020A RID: 522
		private bool _showCoordinateText = true;

		// Token: 0x0400020B RID: 523
		private int _coordinateTextSize = 14;

		// Token: 0x0400020C RID: 524
		private string _coordinateTextColor = "white";

		// Token: 0x0400020D RID: 525
		private Color _coordinateTextColorValue = Colors.White;
	}
}
