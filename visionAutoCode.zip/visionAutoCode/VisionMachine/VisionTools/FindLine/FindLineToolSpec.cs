﻿using System;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.FindLine
{
	// Token: 0x0200006D RID: 109
	public class FindLineToolSpec : ToolSpecBase
	{
	}
}
