﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Windows.Media;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.FindLine.Views
{
	// Token: 0x0200006E RID: 110
	public partial class FindLine_para : System.Windows.Controls.UserControl, IStyleConnector
	{
		// Token: 0x06000511 RID: 1297 RVA: 0x00019854 File Offset: 0x00017A54
		public FindLine_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000512 RID: 1298 RVA: 0x00019865 File Offset: 0x00017A65
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.FindLineTrialRun();
			}
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x0001987C File Offset: 0x00017A7C
		private void BtnMoreColor_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement button = sender as FrameworkElement;
			object valueSource = (button != null) ? button.Tag : null;
			PropertyInfo valueProperty = (valueSource != null) ? valueSource.GetType().GetProperty("Value") : null;
			bool flag = valueSource == null || valueProperty == null;
			if (!flag)
			{
				ColorDialog dialog = new ColorDialog
				{
					FullOpen = true
				};
				object currentColor = valueProperty.GetValue(valueSource, null);
				string colorText = currentColor as string;
				System.Windows.Media.Color mediaColor;
				bool flag2 = colorText != null && this.TryParseColor(colorText, out mediaColor);
				if (flag2)
				{
					dialog.Color = System.Drawing.Color.FromArgb((int)mediaColor.A, (int)mediaColor.R, (int)mediaColor.G, (int)mediaColor.B);
				}
				bool flag3 = dialog.ShowDialog() != DialogResult.OK;
				if (!flag3)
				{
					System.Windows.Media.Color selectedColor = System.Windows.Media.Color.FromArgb(dialog.Color.A, dialog.Color.R, dialog.Color.G, dialog.Color.B);
					valueProperty.SetValue(valueSource, "#" + selectedColor.R.ToString("X2") + selectedColor.G.ToString("X2") + selectedColor.B.ToString("X2"), null);
				}
			}
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x000199DC File Offset: 0x00017BDC
		private bool TryParseColor(string colorText, out System.Windows.Media.Color color)
		{
			color = Colors.White;
			bool flag = string.IsNullOrWhiteSpace(colorText);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(colorText);
					result = true;
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x00019AA8 File Offset: 0x00017CA8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((SimpleButton)target).Click += this.BtnMoreColor_Click;
			}
		}
	}
}
