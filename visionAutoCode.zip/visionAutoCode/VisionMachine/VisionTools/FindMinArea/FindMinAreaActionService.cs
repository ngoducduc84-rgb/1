﻿using System;
using System.Diagnostics;
using System.Linq;
using DevExpress.Xpf.Core;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.FindMinArea
{
	// Token: 0x02000076 RID: 118
	public class FindMinAreaActionService : IToolActionService
	{
		// Token: 0x170001BD RID: 445
		// (get) Token: 0x06000547 RID: 1351 RVA: 0x0001AAD4 File Offset: 0x00018CD4
		public ToolType ToolType
		{
			get
			{
				return ToolType.FindMinArea;
			}
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x0001AAE8 File Offset: 0x00018CE8
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null;
			if (flag)
			{
				ToolActionFeedback.ReportError(context, "DisplayController null.");
			}
			else
			{
				bool flag2 = tool == null;
				if (flag2)
				{
					ToolActionFeedback.ReportError(context, "No tool is selected.");
				}
				else
				{
					HObject original = null;
					HObject input = null;
					ImageBufferStore bufferStore = null;
					FindMinAreaResult result = null;
					try
					{
						original = context.DisplayController.GetOriginalImage();
						bool flag3 = original == null || !original.IsInitialized();
						if (flag3)
						{
							DXMessageBox.Show("No original image is available for Find Min Area testing.");
						}
						else
						{
							bufferStore = new ImageBufferStore();
							ToolProcessContext processContext = new ToolProcessContext
							{
								OriginalImage = original,
								InputImage = original,
								BufferStore = bufferStore
							};
							string inputSourceToolName = this.GetInputSourceToolName(tool);
							Stopwatch inputStopwatch = Stopwatch.StartNew();
							input = this._pipelineService.BuildInputImageForTool(processContext, tool);
							inputStopwatch.Stop();
							bool flag4 = input == null || !input.IsInitialized();
							if (flag4)
							{
								HOperatorSet.CopyImage(original, out input);
							}
							FindMinAreaToolConfig config = tool.Config as FindMinAreaToolConfig;
							bool flag5 = config != null && config.ShowInputImage;
							if (flag5)
							{
								context.DisplayController.DisplayImage(input);
							}
							else
							{
								result = this._processor.Run(input, tool);
								result.InputSourceToolName = inputSourceToolName;
								result.InputProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds;
								result.TotalProcessingTimeMs = result.InputProcessingTimeMs + result.ProcessingTimeMs;
								bool flag6 = !result.IsSuccess;
								if (flag6)
								{
									DXMessageBox.Show(result.Message);
								}
								Action<ToolVision, object> resultReporter = context.ResultReporter;
								if (resultReporter != null)
								{
									resultReporter(tool, result);
								}
								context.DisplayController.DisplayImage(input);
								FindMinAreaResult overlayResult = result;
								result = null;
								context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
								{
									this._drawer.Draw(window, tool, overlayResult);
								}, overlayResult);
							}
						}
					}
					finally
					{
						if (result != null)
						{
							result.Dispose();
						}
						if (input != null)
						{
							input.Dispose();
						}
						if (bufferStore != null)
						{
							bufferStore.Clear();
						}
						if (original != null)
						{
							original.Dispose();
						}
					}
				}
			}
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x0001AD7C File Offset: 0x00018F7C
		private string GetInputSourceToolName(ToolVision tool)
		{
			ToolVision tool2 = tool;
			FindMinAreaToolConfig config = ((tool2 != null) ? tool2.Config : null) as FindMinAreaToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						TurnSnap parentTurnSnap = tool.ParentTurnSnap;
						ToolVision previousTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).LastOrDefault<ToolVision>() : null;
						result = ((previousTool == null) ? "PreviousToolOutput" : previousTool.Name);
					}
					else
					{
						result = "Unknown";
					}
				}
			}
			return result;
		}

		// Token: 0x0400021B RID: 539
		private readonly FindMinAreaProcessor _processor = new FindMinAreaProcessor();

		// Token: 0x0400021C RID: 540
		private readonly FindMinAreaResultDrawer _drawer = new FindMinAreaResultDrawer();

		// Token: 0x0400021D RID: 541
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();
	}
}
