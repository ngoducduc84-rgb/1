﻿using System;

namespace VisionMachine.VisionTools.FindMinArea
{
	// Token: 0x0200007C RID: 124
	public class FindMinAreaCandidate
	{
		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x06000593 RID: 1427 RVA: 0x0001D124 File Offset: 0x0001B324
		// (set) Token: 0x06000594 RID: 1428 RVA: 0x0001D12C File Offset: 0x0001B32C
		public int RegionIndex { get; set; }

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x06000595 RID: 1429 RVA: 0x0001D135 File Offset: 0x0001B335
		// (set) Token: 0x06000596 RID: 1430 RVA: 0x0001D13D File Offset: 0x0001B33D
		public int GridRow { get; set; }

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x06000597 RID: 1431 RVA: 0x0001D146 File Offset: 0x0001B346
		// (set) Token: 0x06000598 RID: 1432 RVA: 0x0001D14E File Offset: 0x0001B34E
		public int GridColumn { get; set; }

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x06000599 RID: 1433 RVA: 0x0001D157 File Offset: 0x0001B357
		// (set) Token: 0x0600059A RID: 1434 RVA: 0x0001D15F File Offset: 0x0001B35F
		public double Row { get; set; }

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x0600059B RID: 1435 RVA: 0x0001D168 File Offset: 0x0001B368
		// (set) Token: 0x0600059C RID: 1436 RVA: 0x0001D170 File Offset: 0x0001B370
		public double Column { get; set; }

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x0600059D RID: 1437 RVA: 0x0001D179 File Offset: 0x0001B379
		// (set) Token: 0x0600059E RID: 1438 RVA: 0x0001D181 File Offset: 0x0001B381
		public double Row1 { get; set; }

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x0600059F RID: 1439 RVA: 0x0001D18A File Offset: 0x0001B38A
		// (set) Token: 0x060005A0 RID: 1440 RVA: 0x0001D192 File Offset: 0x0001B392
		public double Column1 { get; set; }

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x060005A1 RID: 1441 RVA: 0x0001D19B File Offset: 0x0001B39B
		// (set) Token: 0x060005A2 RID: 1442 RVA: 0x0001D1A3 File Offset: 0x0001B3A3
		public double Row2 { get; set; }

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x060005A3 RID: 1443 RVA: 0x0001D1AC File Offset: 0x0001B3AC
		// (set) Token: 0x060005A4 RID: 1444 RVA: 0x0001D1B4 File Offset: 0x0001B3B4
		public double Column2 { get; set; }

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x060005A5 RID: 1445 RVA: 0x0001D1BD File Offset: 0x0001B3BD
		// (set) Token: 0x060005A6 RID: 1446 RVA: 0x0001D1C5 File Offset: 0x0001B3C5
		public double Phi { get; set; }

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x060005A7 RID: 1447 RVA: 0x0001D1CE File Offset: 0x0001B3CE
		// (set) Token: 0x060005A8 RID: 1448 RVA: 0x0001D1D6 File Offset: 0x0001B3D6
		public double AngleDegree { get; set; }

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x060005A9 RID: 1449 RVA: 0x0001D1DF File Offset: 0x0001B3DF
		// (set) Token: 0x060005AA RID: 1450 RVA: 0x0001D1E7 File Offset: 0x0001B3E7
		public double Length1 { get; set; }

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x060005AB RID: 1451 RVA: 0x0001D1F0 File Offset: 0x0001B3F0
		// (set) Token: 0x060005AC RID: 1452 RVA: 0x0001D1F8 File Offset: 0x0001B3F8
		public double Length2 { get; set; }

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x060005AD RID: 1453 RVA: 0x0001D201 File Offset: 0x0001B401
		// (set) Token: 0x060005AE RID: 1454 RVA: 0x0001D209 File Offset: 0x0001B409
		public double Width { get; set; }

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x060005AF RID: 1455 RVA: 0x0001D212 File Offset: 0x0001B412
		// (set) Token: 0x060005B0 RID: 1456 RVA: 0x0001D21A File Offset: 0x0001B41A
		public double Height { get; set; }

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x060005B1 RID: 1457 RVA: 0x0001D223 File Offset: 0x0001B423
		// (set) Token: 0x060005B2 RID: 1458 RVA: 0x0001D22B File Offset: 0x0001B42B
		public double Area { get; set; }

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x060005B3 RID: 1459 RVA: 0x0001D234 File Offset: 0x0001B434
		// (set) Token: 0x060005B4 RID: 1460 RVA: 0x0001D23C File Offset: 0x0001B43C
		public FindMinAreaPointSet Points { get; set; } = new FindMinAreaPointSet();
	}
}
