﻿using System;
using System.Windows.Media;

namespace VisionMachine.VisionTools.FindMinArea
{
	// Token: 0x02000078 RID: 120
	public class FindMinAreaColorOption
	{
		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x0600055A RID: 1370 RVA: 0x0001B2C7 File Offset: 0x000194C7
		// (set) Token: 0x0600055B RID: 1371 RVA: 0x0001B2CF File Offset: 0x000194CF
		public string Name { get; set; }

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x0600055C RID: 1372 RVA: 0x0001B2D8 File Offset: 0x000194D8
		// (set) Token: 0x0600055D RID: 1373 RVA: 0x0001B2E0 File Offset: 0x000194E0
		public Color Color { get; set; }

		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x0600055E RID: 1374 RVA: 0x0001B2E9 File Offset: 0x000194E9
		// (set) Token: 0x0600055F RID: 1375 RVA: 0x0001B2F1 File Offset: 0x000194F1
		public string Value { get; set; }
	}
}
