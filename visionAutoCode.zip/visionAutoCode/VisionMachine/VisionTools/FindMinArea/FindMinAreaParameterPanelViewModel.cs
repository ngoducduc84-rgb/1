﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindMinArea
{
	// Token: 0x02000077 RID: 119
	public class FindMinAreaParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x170001BE RID: 446
		// (get) Token: 0x0600054B RID: 1355 RVA: 0x0001AE94 File Offset: 0x00019094
		// (set) Token: 0x0600054C RID: 1356 RVA: 0x0001AE9C File Offset: 0x0001909C
		public ToolVision Tool { get; set; }

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x0600054D RID: 1357 RVA: 0x0001AEA5 File Offset: 0x000190A5
		// (set) Token: 0x0600054E RID: 1358 RVA: 0x0001AEAD File Offset: 0x000190AD
		public FindMinAreaToolConfig Config { get; set; }

		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x0600054F RID: 1359 RVA: 0x0001AEB6 File Offset: 0x000190B6
		// (set) Token: 0x06000550 RID: 1360 RVA: 0x0001AEBE File Offset: 0x000190BE
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x06000551 RID: 1361 RVA: 0x0001AEC7 File Offset: 0x000190C7
		public ObservableCollection<FindMinAreaColorOption> TextColorOptions { get; } = new ObservableCollection<FindMinAreaColorOption>
		{
			new FindMinAreaColorOption
			{
				Name = "White",
				Color = Colors.White,
				Value = "white"
			},
			new FindMinAreaColorOption
			{
				Name = "Black",
				Color = Colors.Black,
				Value = "black"
			},
			new FindMinAreaColorOption
			{
				Name = "Red",
				Color = Colors.Red,
				Value = "red"
			},
			new FindMinAreaColorOption
			{
				Name = "Green",
				Color = Colors.Lime,
				Value = "green"
			},
			new FindMinAreaColorOption
			{
				Name = "Blue",
				Color = Colors.DodgerBlue,
				Value = "blue"
			},
			new FindMinAreaColorOption
			{
				Name = "Yellow",
				Color = Colors.Yellow,
				Value = "yellow"
			},
			new FindMinAreaColorOption
			{
				Name = "Cyan",
				Color = Colors.Cyan,
				Value = "cyan"
			},
			new FindMinAreaColorOption
			{
				Name = "Magenta",
				Color = Colors.Magenta,
				Value = "magenta"
			},
			new FindMinAreaColorOption
			{
				Name = "Orange",
				Color = Colors.Orange,
				Value = "orange"
			}
		};

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x06000552 RID: 1362 RVA: 0x0001AED0 File Offset: 0x000190D0
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x06000553 RID: 1363 RVA: 0x0001AEEC File Offset: 0x000190EC
		// (set) Token: 0x06000554 RID: 1364 RVA: 0x0001AF04 File Offset: 0x00019104
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool == value;
				if (!flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.Config != null && this.Config.InputLink != null;
					if (flag2)
					{
						this.Config.InputLink.SourceToolId = null;
						this.Config.InputLink.SourceToolName = ((this._selectedSourceTool == null) ? null : this._selectedSourceTool.ToolName);
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x06000555 RID: 1365 RVA: 0x0001AF8C File Offset: 0x0001918C
		// (remove) Token: 0x06000556 RID: 1366 RVA: 0x0001AFC4 File Offset: 0x000191C4
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000557 RID: 1367 RVA: 0x0001AFFC File Offset: 0x000191FC
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.Config == null || this.Config.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.Config.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.Config.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.Config.InputLink.SourceToolId = null;
				this.Config.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x0001B0DC File Offset: 0x000192DC
		private void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x0400021E RID: 542
		private ToolImageSourceOption _selectedSourceTool;
	}
}
