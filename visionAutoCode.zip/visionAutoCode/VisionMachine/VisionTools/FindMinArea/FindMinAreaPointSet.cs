﻿using System;

namespace VisionMachine.VisionTools.FindMinArea
{
	// Token: 0x0200007B RID: 123
	public class FindMinAreaPointSet
	{
		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x0600057E RID: 1406 RVA: 0x0001D07A File Offset: 0x0001B27A
		// (set) Token: 0x0600057F RID: 1407 RVA: 0x0001D082 File Offset: 0x0001B282
		public double TopLeftRow { get; set; }

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x06000580 RID: 1408 RVA: 0x0001D08B File Offset: 0x0001B28B
		// (set) Token: 0x06000581 RID: 1409 RVA: 0x0001D093 File Offset: 0x0001B293
		public double TopLeftColumn { get; set; }

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x06000582 RID: 1410 RVA: 0x0001D09C File Offset: 0x0001B29C
		// (set) Token: 0x06000583 RID: 1411 RVA: 0x0001D0A4 File Offset: 0x0001B2A4
		public double TopRightRow { get; set; }

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x06000584 RID: 1412 RVA: 0x0001D0AD File Offset: 0x0001B2AD
		// (set) Token: 0x06000585 RID: 1413 RVA: 0x0001D0B5 File Offset: 0x0001B2B5
		public double TopRightColumn { get; set; }

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x06000586 RID: 1414 RVA: 0x0001D0BE File Offset: 0x0001B2BE
		// (set) Token: 0x06000587 RID: 1415 RVA: 0x0001D0C6 File Offset: 0x0001B2C6
		public double BottomRightRow { get; set; }

		// Token: 0x170001CD RID: 461
		// (get) Token: 0x06000588 RID: 1416 RVA: 0x0001D0CF File Offset: 0x0001B2CF
		// (set) Token: 0x06000589 RID: 1417 RVA: 0x0001D0D7 File Offset: 0x0001B2D7
		public double BottomRightColumn { get; set; }

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x0600058A RID: 1418 RVA: 0x0001D0E0 File Offset: 0x0001B2E0
		// (set) Token: 0x0600058B RID: 1419 RVA: 0x0001D0E8 File Offset: 0x0001B2E8
		public double BottomLeftRow { get; set; }

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x0600058C RID: 1420 RVA: 0x0001D0F1 File Offset: 0x0001B2F1
		// (set) Token: 0x0600058D RID: 1421 RVA: 0x0001D0F9 File Offset: 0x0001B2F9
		public double BottomLeftColumn { get; set; }

		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x0600058E RID: 1422 RVA: 0x0001D102 File Offset: 0x0001B302
		// (set) Token: 0x0600058F RID: 1423 RVA: 0x0001D10A File Offset: 0x0001B30A
		public double CenterRow { get; set; }

		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x06000590 RID: 1424 RVA: 0x0001D113 File Offset: 0x0001B313
		// (set) Token: 0x06000591 RID: 1425 RVA: 0x0001D11B File Offset: 0x0001B31B
		public double CenterColumn { get; set; }
	}
}
