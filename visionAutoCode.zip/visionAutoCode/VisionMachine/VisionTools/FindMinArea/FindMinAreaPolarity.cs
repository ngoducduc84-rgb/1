﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.FindMinArea
{
	// Token: 0x02000079 RID: 121
	public enum FindMinAreaPolarity
	{
		// Token: 0x04000228 RID: 552
		[Description("Dark to Light")]
		DarkToLight,
		// Token: 0x04000229 RID: 553
		[Description("Light to Dark")]
		LightToDark
	}
}
