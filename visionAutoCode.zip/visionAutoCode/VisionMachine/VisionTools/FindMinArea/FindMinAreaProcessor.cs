﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.FindMinArea
{
	// Token: 0x0200007A RID: 122
	public class FindMinAreaProcessor : IToolProcessor
	{
		// Token: 0x06000561 RID: 1377 RVA: 0x0001B2FA File Offset: 0x000194FA
		public FindMinAreaProcessor() : this(null)
		{
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x0001B305 File Offset: 0x00019505
		public FindMinAreaProcessor(IDictionary<string, ShapeMatchResult> cachedMasterResults)
		{
			this._cachedMasterResults = cachedMasterResults;
		}

		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x06000563 RID: 1379 RVA: 0x0001B318 File Offset: 0x00019518
		public ToolType ToolType
		{
			get
			{
				return ToolType.FindMinArea;
			}
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x0001B32C File Offset: 0x0001952C
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			FindMinAreaResult boxResult = this.Run((context != null) ? context.InputImage : null, tool);
			return new ToolProcessResult
			{
				IsSuccess = boxResult.IsSuccess,
				Message = boxResult.Message,
				Data = boxResult
			};
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x0001B37C File Offset: 0x0001957C
		public FindMinAreaResult Run(HObject image, ToolVision tool)
		{
			FindMinAreaResult result = new FindMinAreaResult();
			Stopwatch stopwatch = Stopwatch.StartNew();
			HObject grayImage = null;
			HObject roiRegion = null;
			HObject reducedImage = null;
			HObject thresholdRegion = null;
			HObject connected = null;
			HObject selectedRegions = null;
			FindMinAreaResult result2;
			try
			{
				bool flag = image == null || !image.IsInitialized();
				if (flag)
				{
					result.Message = "Input image null.";
					result2 = result;
				}
				else
				{
					FindMinAreaToolConfig config = ((tool != null) ? tool.Config : null) as FindMinAreaToolConfig;
					bool flag2 = config == null;
					if (flag2)
					{
						result.Message = "Find Min Area config null.";
						result2 = result;
					}
					else
					{
						bool flag3 = !config.IsEnabled;
						if (flag3)
						{
							result.Message = "Find Min Area tool is disabled.";
							result2 = result;
						}
						else
						{
							RoiData roi = tool.RoiItems.FirstOrDefault((RoiData x) => x.IsEnabled && x.RoiType != RoiType.Line);
							bool flag4 = roi == null;
							if (flag4)
							{
								result.Message = "Find Min Area requires one enabled non-line ROI.";
								result2 = result;
							}
							else
							{
								this._currentMasterProcessingTimes = this.UpdateMasterShapeModels(image, tool, roi);
								RoiData transformedRoi = this.CreateTransformedRoi(roi, tool);
								result.ToolName = tool.Name;
								result.RoiName = (string.IsNullOrWhiteSpace(transformedRoi.DisplayName) ? "ROI" : transformedRoi.DisplayName);
								result.Roi = transformedRoi;
								result.MasterPositionToolName = this.GetMasterPositionToolName(roi);
								result.MasterAngleToolName = this.GetMasterAngleToolName(roi);
								result.MasterProcessingTimeMs = this.GetMasterProcessingTime(result.MasterPositionToolName, result.MasterAngleToolName);
								grayImage = this.ConvertToGray(image);
								roiRegion = this.GenRegionFromRoi(transformedRoi, grayImage, true);
								bool flag5 = roiRegion == null || !roiRegion.IsInitialized();
								if (flag5)
								{
									result.Message = "ROI region is invalid.";
									result2 = result;
								}
								else
								{
									HObject roiRegionCopy;
									HOperatorSet.CopyObj(roiRegion, out roiRegionCopy, 1, -1);
									result.RoiRegion = roiRegionCopy;
									HOperatorSet.ReduceDomain(grayImage, roiRegion, out reducedImage);
									thresholdRegion = this.CreateThresholdRegion(reducedImage, roiRegion, config);
									HObject thresholdCopy;
									HOperatorSet.CopyObj(thresholdRegion, out thresholdCopy, 1, -1);
									result.ThresholdRegion = thresholdCopy;
									HOperatorSet.Connection(thresholdRegion, out connected);
									HOperatorSet.SelectShape(connected, out selectedRegions, "area", "and", config.MinArea, config.MaxArea);
									this.FillCandidates(selectedRegions, config, result.Candidates);
									this.AssignGrid(result.Candidates, config.RowSpacing, config.ColumnSpacing);
									result.SelectedBox = result.Candidates.FirstOrDefault((FindMinAreaCandidate x) => x.GridRow == config.PickRow && x.GridColumn == config.PickColumn);
									result.AllBoxRegions = this.CreateBoxRegions(result.Candidates);
									bool flag6 = result.SelectedBox == null;
									if (flag6)
									{
										result.Message = "Min area was not found at selected row/column.";
										result2 = result;
									}
									else
									{
										result.SelectedBoxRegion = this.CreateBoxRegion(result.SelectedBox);
										result.IsSuccess = true;
										result.Message = "Find Min Area OK.";
										result2 = result;
									}
								}
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				result.Message = "Find Min Area failed: " + ex.Message;
				result2 = result;
			}
			finally
			{
				stopwatch.Stop();
				result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
				result.TotalProcessingTimeMs = result.InputProcessingTimeMs + result.ProcessingTimeMs;
				if (grayImage != null)
				{
					grayImage.Dispose();
				}
				if (roiRegion != null)
				{
					roiRegion.Dispose();
				}
				if (reducedImage != null)
				{
					reducedImage.Dispose();
				}
				if (thresholdRegion != null)
				{
					thresholdRegion.Dispose();
				}
				if (connected != null)
				{
					connected.Dispose();
				}
				if (selectedRegions != null)
				{
					selectedRegions.Dispose();
				}
			}
			return result2;
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x0001B794 File Offset: 0x00019994
		private HObject ConvertToGray(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject result;
			if (flag)
			{
				HObject grayImage;
				HOperatorSet.Rgb1ToGray(image, out grayImage);
				result = grayImage;
			}
			else
			{
				HObject gray;
				HOperatorSet.CopyImage(image, out gray);
				result = gray;
			}
			return result;
		}

		// Token: 0x06000567 RID: 1383 RVA: 0x0001B7EC File Offset: 0x000199EC
		private HObject CreateThresholdRegion(HObject image, HObject roiRegion, FindMinAreaToolConfig config)
		{
			HObject threshold = null;
			HObject polarityRegion = null;
			HObject filled = null;
			HObject result2;
			try
			{
				HOperatorSet.Threshold(image, out threshold, config.ThresholdMin, config.ThresholdMax);
				bool flag = config.ThresholdPolarity == FindMinAreaPolarity.LightToDark;
				if (flag)
				{
					HOperatorSet.Difference(roiRegion, threshold, out polarityRegion);
				}
				else
				{
					HOperatorSet.CopyObj(threshold, out polarityRegion, 1, -1);
				}
				HOperatorSet.FillUp(polarityRegion, out filled);
				HObject result;
				HOperatorSet.CopyObj(filled, out result, 1, -1);
				result2 = result;
			}
			finally
			{
				if (threshold != null)
				{
					threshold.Dispose();
				}
				if (polarityRegion != null)
				{
					polarityRegion.Dispose();
				}
				if (filled != null)
				{
					filled.Dispose();
				}
			}
			return result2;
		}

		// Token: 0x06000568 RID: 1384 RVA: 0x0001B8B0 File Offset: 0x00019AB0
		private void FillCandidates(HObject selectedRegions, FindMinAreaToolConfig config, List<FindMinAreaCandidate> candidates)
		{
			HTuple count;
			HOperatorSet.CountObj(selectedRegions, out count);
			int i = 1;
			while (i <= count.I)
			{
				HObject region = null;
				try
				{
					HOperatorSet.SelectObj(selectedRegions, out region, i);
					HTuple area;
					HTuple areaRow;
					HTuple areaColumn;
					HOperatorSet.AreaCenter(region, out area, out areaRow, out areaColumn);
					bool flag = area.Length == 0 || area.D <= 0.0;
					if (!flag)
					{
						HTuple centerRowTuple;
						HTuple centerColumnTuple;
						HTuple phi;
						HTuple length;
						HTuple length2;
						HOperatorSet.SmallestRectangle2(region, out centerRowTuple, out centerColumnTuple, out phi, out length, out length2);
						double centerRow = centerRowTuple.D;
						double centerColumn = centerColumnTuple.D;
						double width = length.D * 2.0;
						double height = length2.D * 2.0;
						bool flag2 = width < config.MinWidth || width > config.MaxWidth || height < config.MinHeight || height > config.MaxHeight;
						if (!flag2)
						{
							candidates.Add(new FindMinAreaCandidate
							{
								RegionIndex = i,
								Row = centerRow,
								Column = centerColumn,
								Row1 = centerRow - length2.D,
								Column1 = centerColumn - length.D,
								Row2 = centerRow + length2.D,
								Column2 = centerColumn + length.D,
								Phi = phi.D,
								AngleDegree = phi.D * 180.0 / 3.141592653589793,
								Length1 = length.D,
								Length2 = length2.D,
								Width = width,
								Height = height,
								Area = area.D,
								Points = this.CalculatePoints(centerRow, centerColumn, phi.D, length.D, length2.D)
							});
						}
					}
				}
				finally
				{
					if (region != null)
					{
						region.Dispose();
					}
				}
				IL_1E9:
				i++;
				continue;
				goto IL_1E9;
			}
		}

		// Token: 0x06000569 RID: 1385 RVA: 0x0001BADC File Offset: 0x00019CDC
		private void AssignGrid(List<FindMinAreaCandidate> candidates, double rowSpacing, double columnSpacing)
		{
			List<FindMinAreaCandidate> sorted = (from x in candidates
			orderby x.Row, x.Column
			select x).ToList<FindMinAreaCandidate>();
			List<List<FindMinAreaCandidate>> rows = new List<List<FindMinAreaCandidate>>();
			List<FindMinAreaCandidate> current = new List<FindMinAreaCandidate>();
			foreach (FindMinAreaCandidate candidate in sorted)
			{
				bool flag = current.Count == 0;
				if (flag)
				{
					current.Add(candidate);
				}
				else
				{
					double meanRow = current.Average((FindMinAreaCandidate x) => x.Row);
					bool flag2 = Math.Abs(candidate.Row - meanRow) <= rowSpacing;
					if (flag2)
					{
						current.Add(candidate);
					}
					else
					{
						rows.Add(current);
						current = new List<FindMinAreaCandidate>
						{
							candidate
						};
					}
				}
			}
			bool flag3 = current.Count > 0;
			if (flag3)
			{
				rows.Add(current);
			}
			for (int rowIndex = 0; rowIndex < rows.Count; rowIndex++)
			{
				List<FindMinAreaCandidate> rowItems = (from x in rows[rowIndex]
				orderby x.Column
				select x).ToList<FindMinAreaCandidate>();
				for (int columnIndex = 0; columnIndex < rowItems.Count; columnIndex++)
				{
					rowItems[columnIndex].GridRow = rowIndex;
				}
				this.AssignColumns(rowItems, columnSpacing);
			}
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x0001BCB0 File Offset: 0x00019EB0
		private void AssignColumns(List<FindMinAreaCandidate> rowItems, double columnSpacing)
		{
			List<FindMinAreaCandidate> sorted = (from x in rowItems
			orderby x.Column
			select x).ToList<FindMinAreaCandidate>();
			List<List<FindMinAreaCandidate>> columns = new List<List<FindMinAreaCandidate>>();
			List<FindMinAreaCandidate> current = new List<FindMinAreaCandidate>();
			foreach (FindMinAreaCandidate candidate in sorted)
			{
				bool flag = current.Count == 0;
				if (flag)
				{
					current.Add(candidate);
				}
				else
				{
					double meanColumn = current.Average((FindMinAreaCandidate x) => x.Column);
					bool flag2 = Math.Abs(candidate.Column - meanColumn) <= columnSpacing;
					if (flag2)
					{
						current.Add(candidate);
					}
					else
					{
						columns.Add(current);
						current = new List<FindMinAreaCandidate>
						{
							candidate
						};
					}
				}
			}
			bool flag3 = current.Count > 0;
			if (flag3)
			{
				columns.Add(current);
			}
			for (int columnIndex = 0; columnIndex < columns.Count; columnIndex++)
			{
				foreach (FindMinAreaCandidate candidate2 in columns[columnIndex])
				{
					candidate2.GridColumn = columnIndex;
				}
			}
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x0001BE3C File Offset: 0x0001A03C
		private HObject CreateBoxRegions(IEnumerable<FindMinAreaCandidate> candidates)
		{
			HObject boxes = null;
			HObject result;
			try
			{
				HOperatorSet.GenEmptyObj(out boxes);
				foreach (FindMinAreaCandidate candidate in candidates)
				{
					HObject box = null;
					HObject concat = null;
					try
					{
						box = this.CreateBoxRegion(candidate);
						HOperatorSet.ConcatObj(boxes, box, out concat);
						boxes.Dispose();
						boxes = concat;
						concat = null;
					}
					finally
					{
						if (box != null)
						{
							box.Dispose();
						}
						if (concat != null)
						{
							concat.Dispose();
						}
					}
				}
				result = boxes;
			}
			catch
			{
				if (boxes != null)
				{
					boxes.Dispose();
				}
				throw;
			}
			return result;
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x0001BF04 File Offset: 0x0001A104
		private HObject CreateBoxRegion(FindMinAreaCandidate candidate)
		{
			HObject box;
			HOperatorSet.GenRectangle2(out box, candidate.Row, candidate.Column, candidate.Phi, candidate.Length1, candidate.Length2);
			return box;
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x0001BF58 File Offset: 0x0001A158
		private FindMinAreaPointSet CalculatePoints(double row, double column, double phi, double length1, double length2)
		{
			double axis1Row = -Math.Sin(phi) * length1;
			double axis1Column = Math.Cos(phi) * length1;
			double axis2Row = -Math.Cos(phi) * length2;
			double axis2Column = -Math.Sin(phi) * length2;
			return new FindMinAreaPointSet
			{
				TopLeftRow = row - axis1Row + axis2Row,
				TopLeftColumn = column - axis1Column + axis2Column,
				TopRightRow = row + axis1Row + axis2Row,
				TopRightColumn = column + axis1Column + axis2Column,
				BottomRightRow = row + axis1Row - axis2Row,
				BottomRightColumn = column + axis1Column - axis2Column,
				BottomLeftRow = row - axis1Row - axis2Row,
				BottomLeftColumn = column - axis1Column - axis2Column,
				CenterRow = row,
				CenterColumn = column
			};
		}

		// Token: 0x0600056E RID: 1390 RVA: 0x0001C00C File Offset: 0x0001A20C
		private HObject GenRegionFromRoi(RoiData roi, HObject image, bool applyMaskMode)
		{
			HObject region;
			switch (roi.RoiType)
			{
			case RoiType.Rectangle1:
				HOperatorSet.GenRectangle1(out region, Math.Min(roi.Row1, roi.Row2), Math.Min(roi.Col1, roi.Col2), Math.Max(roi.Row1, roi.Row2), Math.Max(roi.Col1, roi.Col2));
				goto IL_160;
			case RoiType.Rectangle2:
				HOperatorSet.GenRectangle2(out region, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
				goto IL_160;
			case RoiType.Circle:
				HOperatorSet.GenCircle(out region, roi.CenterRow, roi.CenterCol, roi.Radius);
				goto IL_160;
			case RoiType.Ellipse:
				HOperatorSet.GenEllipse(out region, roi.CenterRow, roi.CenterCol, roi.Phi, roi.Radius1, roi.Radius2);
				goto IL_160;
			case RoiType.Polygon:
			case RoiType.FreeDraw:
			case RoiType.DrawRegion:
				region = this.GenContourRegion(roi);
				goto IL_160;
			}
			HOperatorSet.GenEmptyObj(out region);
			IL_160:
			bool flag = !applyMaskMode || roi.MaskMode != RoiMaskMode.Outside;
			HObject result;
			if (flag)
			{
				result = region;
			}
			else
			{
				result = this.InvertRegionInImage(region, image);
			}
			return result;
		}

		// Token: 0x0600056F RID: 1391 RVA: 0x0001C1A4 File Offset: 0x0001A3A4
		private HObject GenContourRegion(RoiData roi)
		{
			bool flag = roi.Rows == null || roi.Cols == null || roi.Rows.Count < 3 || roi.Rows.Count != roi.Cols.Count;
			HObject result;
			if (flag)
			{
				HObject empty;
				HOperatorSet.GenEmptyObj(out empty);
				result = empty;
			}
			else
			{
				HObject contour = null;
				try
				{
					HOperatorSet.GenContourPolygonXld(out contour, new HTuple(roi.Rows.ToArray()), new HTuple(roi.Cols.ToArray()));
					HObject region;
					HOperatorSet.GenRegionContourXld(contour, out region, "filled");
					result = region;
				}
				finally
				{
					if (contour != null)
					{
						contour.Dispose();
					}
				}
			}
			return result;
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x0001C264 File Offset: 0x0001A464
		private HObject InvertRegionInImage(HObject region, HObject image)
		{
			HObject fullRegion = null;
			HObject outside = null;
			HObject result;
			try
			{
				HTuple width;
				HTuple height;
				HOperatorSet.GetImageSize(image, out width, out height);
				HOperatorSet.GenRectangle1(out fullRegion, 0, 0, height.D - 1.0, width.D - 1.0);
				HOperatorSet.Difference(fullRegion, region, out outside);
				region.Dispose();
				region = null;
				result = outside;
			}
			finally
			{
				if (fullRegion != null)
				{
					fullRegion.Dispose();
				}
				if (region != null)
				{
					region.Dispose();
				}
			}
			return result;
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x0001C308 File Offset: 0x0001A508
		private RoiData CreateTransformedRoi(RoiData roi, ToolVision tool)
		{
			bool flag = roi == null;
			RoiData result;
			if (flag)
			{
				result = null;
			}
			else
			{
				FindMinAreaProcessor.MasterTransform transform = this.GetMasterTransform(roi, tool);
				switch (roi.RoiType)
				{
				case RoiType.Rectangle1:
					return this.TransformRectangle1Roi(roi, transform);
				case RoiType.Rectangle2:
				{
					Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
					RoiData copy = this.CopyBaseRoi(roi);
					copy.CenterRow = center.Item1;
					copy.CenterCol = center.Item2;
					copy.Phi = roi.Phi + transform.Angle;
					return copy;
				}
				case RoiType.Circle:
				{
					Tuple<double, double> center2 = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
					RoiData copy2 = this.CopyBaseRoi(roi);
					copy2.CenterRow = center2.Item1;
					copy2.CenterCol = center2.Item2;
					return copy2;
				}
				case RoiType.Ellipse:
				{
					Tuple<double, double> center3 = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
					RoiData copy3 = this.CopyBaseRoi(roi);
					copy3.CenterRow = center3.Item1;
					copy3.CenterCol = center3.Item2;
					copy3.Phi = roi.Phi + transform.Angle;
					return copy3;
				}
				case RoiType.Polygon:
				case RoiType.FreeDraw:
				case RoiType.DrawRegion:
					return this.TransformPointListRoi(roi, transform);
				}
				result = this.CopyBaseRoi(roi);
			}
			return result;
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x0001C480 File Offset: 0x0001A680
		private RoiData TransformRectangle1Roi(RoiData roi, FindMinAreaProcessor.MasterTransform transform)
		{
			double row = Math.Min(roi.Row1, roi.Row2);
			double row2 = Math.Max(roi.Row1, roi.Row2);
			double col = Math.Min(roi.Col1, roi.Col2);
			double col2 = Math.Max(roi.Col1, roi.Col2);
			bool flag = transform == null || Math.Abs(transform.Angle) <= 1E-06;
			RoiData result;
			if (flag)
			{
				Tuple<double, double> topLeft = this.TransformPoint(row, col, transform);
				Tuple<double, double> bottomRight = this.TransformPoint(row2, col2, transform);
				RoiData rectangle = this.CopyBaseRoi(roi);
				rectangle.Row1 = topLeft.Item1;
				rectangle.Col1 = topLeft.Item2;
				rectangle.Row2 = bottomRight.Item1;
				rectangle.Col2 = bottomRight.Item2;
				result = rectangle;
			}
			else
			{
				Tuple<double, double>[] points = new Tuple<double, double>[]
				{
					this.TransformPoint(row, col, transform),
					this.TransformPoint(row, col2, transform),
					this.TransformPoint(row2, col2, transform),
					this.TransformPoint(row2, col, transform)
				};
				RoiData copy = this.CopyBaseRoi(roi);
				copy.RoiType = RoiType.Polygon;
				copy.Rows = (from x in points
				select x.Item1).ToList<double>();
				copy.Cols = (from x in points
				select x.Item2).ToList<double>();
				result = copy;
			}
			return result;
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x0001C618 File Offset: 0x0001A818
		private RoiData TransformPointListRoi(RoiData roi, FindMinAreaProcessor.MasterTransform transform)
		{
			RoiData copy = this.CopyBaseRoi(roi);
			copy.Rows = new List<double>();
			copy.Cols = new List<double>();
			bool flag = roi.Rows == null || roi.Cols == null;
			RoiData result;
			if (flag)
			{
				result = copy;
			}
			else
			{
				int count = Math.Min(roi.Rows.Count, roi.Cols.Count);
				for (int i = 0; i < count; i++)
				{
					Tuple<double, double> point = this.TransformPoint(roi.Rows[i], roi.Cols[i], transform);
					copy.Rows.Add(point.Item1);
					copy.Cols.Add(point.Item2);
				}
				result = copy;
			}
			return result;
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x0001C6E8 File Offset: 0x0001A8E8
		private RoiData CopyBaseRoi(RoiData roi)
		{
			return new RoiData
			{
				RoiType = roi.RoiType,
				Name = roi.Name,
				IsEnabled = roi.IsEnabled,
				MaskMode = roi.MaskMode,
				Polarity = roi.Polarity,
				Description = roi.Description,
				MasterToolName = roi.MasterToolName,
				MasterPositionToolName = roi.MasterPositionToolName,
				MasterAngleToolName = roi.MasterAngleToolName,
				Row1 = roi.Row1,
				Col1 = roi.Col1,
				Row2 = roi.Row2,
				Col2 = roi.Col2,
				CenterRow = roi.CenterRow,
				CenterCol = roi.CenterCol,
				Radius = roi.Radius,
				Phi = roi.Phi,
				Radius1 = roi.Radius1,
				Radius2 = roi.Radius2,
				Rows = ((roi.Rows == null) ? new List<double>() : roi.Rows.ToList<double>()),
				Cols = ((roi.Cols == null) ? new List<double>() : roi.Cols.ToList<double>())
			};
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x0001C838 File Offset: 0x0001AA38
		private FindMinAreaProcessor.MasterTransform GetMasterTransform(RoiData roi, ToolVision tool)
		{
			FindMinAreaProcessor.MasterTransform transform = new FindMinAreaProcessor.MasterTransform();
			bool flag = roi == null || ((tool != null) ? tool.ParentTurnSnap : null) == null;
			FindMinAreaProcessor.MasterTransform result;
			if (flag)
			{
				result = transform;
			}
			else
			{
				ShapeModelToolTrain positionTrain = this.GetMasterTrain(tool, this.GetMasterPositionToolName(roi), true);
				bool flag2 = positionTrain != null;
				if (flag2)
				{
					transform.Row = positionTrain.LastRow - positionTrain.MasterRow;
					transform.Column = positionTrain.LastColumn - positionTrain.MasterColumn;
				}
				ShapeModelToolTrain angleTrain = this.GetMasterTrain(tool, this.GetMasterAngleToolName(roi), false);
				bool flag3 = angleTrain != null;
				if (flag3)
				{
					transform.Angle = angleTrain.LastAngle - angleTrain.MasterAngle;
					transform.MasterRow = angleTrain.MasterRow;
					transform.MasterColumn = angleTrain.MasterColumn;
				}
				result = transform;
			}
			return result;
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x0001C904 File Offset: 0x0001AB04
		private ShapeModelToolTrain GetMasterTrain(ToolVision tool, string masterToolName, bool isPositionMaster)
		{
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || string.IsNullOrWhiteSpace(masterToolName) || masterToolName == "None";
			ShapeModelToolTrain result;
			if (flag)
			{
				result = null;
			}
			else
			{
				bool isMasterFound;
				bool flag2 = this._currentMasterMatchStates != null && this._currentMasterMatchStates.TryGetValue(masterToolName, out isMasterFound) && !isMasterFound;
				if (flag2)
				{
					result = null;
				}
				else
				{
					ToolVision masterTool = tool.ParentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || (isPositionMaster && x.ToolType == ToolType.CircleMaster) || (isPositionMaster && x.ToolType == ToolType.BoundingBoxMaster) || (x.ToolType == ToolType.MinAreaMaster || (isPositionMaster && x.ToolType == ToolType.IntersectingLines)) || (!isPositionMaster && x.ToolType == ToolType.AngleSelector)) && x.Name == masterToolName);
					ShapeModelToolTrain train = ((masterTool != null) ? masterTool.TrainModel : null) as ShapeModelToolTrain;
					bool flag3 = train == null || !train.HasMasterDefined;
					if (flag3)
					{
						result = null;
					}
					else
					{
						result = train;
					}
				}
			}
			return result;
		}

		// Token: 0x06000577 RID: 1399 RVA: 0x0001CA08 File Offset: 0x0001AC08
		private Dictionary<string, double> UpdateMasterShapeModels(HObject image, ToolVision tool, RoiData roi)
		{
			Dictionary<string, double> processingTimes = new Dictionary<string, double>();
			this._currentMasterMatchStates = new Dictionary<string, bool>();
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || roi == null;
			Dictionary<string, double> result;
			if (flag)
			{
				result = processingTimes;
			}
			else
			{
				List<string> masterNames = (from x in new string[]
				{
					this.GetMasterPositionToolName(roi),
					this.GetMasterAngleToolName(roi)
				}
				where !string.IsNullOrWhiteSpace(x) && x != "None"
				select x).Distinct<string>().ToList<string>();
				bool flag2 = masterNames.Count == 0;
				if (flag2)
				{
					result = processingTimes;
				}
				else
				{
					ShapeModelProcessor shapeProcessor = new ShapeModelProcessor();
					using (List<string>.Enumerator enumerator = masterNames.GetEnumerator())
					{
						Func<ToolVision, bool> <>9__1;
						while (enumerator.MoveNext())
						{
							string masterName = enumerator.Current;
							Stopwatch stopwatch = Stopwatch.StartNew();
							IEnumerable<ToolVision> tools = tool.ParentTurnSnap.Tools;
							Func<ToolVision, bool> predicate;
							if ((predicate = <>9__1) == null)
							{
								predicate = (<>9__1 = ((ToolVision x) => x != tool));
							}
							ToolVision masterTool = tools.TakeWhile(predicate).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.BoundingBoxMaster || x.ToolType == ToolType.MinAreaMaster || x.ToolType == ToolType.IntersectingLines || x.ToolType == ToolType.AngleSelector) && x.Name == masterName);
							bool flag3 = masterTool == null;
							if (flag3)
							{
								stopwatch.Stop();
								processingTimes[masterName] = stopwatch.Elapsed.TotalMilliseconds;
								this._currentMasterMatchStates[masterName] = false;
							}
							else
							{
								ShapeMatchResult matchResult;
								bool flag4 = this.TryGetCachedMasterResult(masterName, out matchResult);
								if (flag4)
								{
									this.ApplyMasterResultToTrain(masterTool, matchResult);
									stopwatch.Stop();
									processingTimes[masterName] = Math.Max(0.0, matchResult.ProcessingTimeMs);
									this._currentMasterMatchStates[masterName] = matchResult.IsSuccess;
								}
								else
								{
									bool flag5 = masterTool.ToolType == ToolType.CircleMaster;
									if (flag5)
									{
										matchResult = new CircleMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
									}
									else
									{
										bool flag6 = masterTool.ToolType == ToolType.BoundingBoxMaster;
										if (flag6)
										{
											matchResult = new BoundingBoxMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
										}
										else
										{
											bool flag7 = masterTool.ToolType == ToolType.MinAreaMaster;
											if (flag7)
											{
												matchResult = new MinAreaMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
											}
											else
											{
												bool flag8 = masterTool.ToolType == ToolType.IntersectingLines;
												if (flag8)
												{
													matchResult = new IntersectingLinesProcessor(null, this._cachedMasterResults).Match(image, masterTool);
												}
												else
												{
													bool flag9 = masterTool.ToolType == ToolType.AngleSelector;
													if (flag9)
													{
														matchResult = new AngleSelectorProcessor(null, this._cachedMasterResults).Match(image, masterTool);
													}
													else
													{
														matchResult = shapeProcessor.Match(image, masterTool);
													}
												}
											}
										}
									}
									stopwatch.Stop();
									processingTimes[masterName] = stopwatch.Elapsed.TotalMilliseconds;
									this._currentMasterMatchStates[masterName] = (matchResult != null && matchResult.IsSuccess);
								}
							}
						}
					}
					result = processingTimes;
				}
			}
			return result;
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x0001CD60 File Offset: 0x0001AF60
		private bool TryGetCachedMasterResult(string masterName, out ShapeMatchResult result)
		{
			result = null;
			bool flag = this._cachedMasterResults == null || string.IsNullOrWhiteSpace(masterName);
			return !flag && this._cachedMasterResults.TryGetValue(masterName, out result) && result != null;
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x0001CDA8 File Offset: 0x0001AFA8
		private void ApplyMasterResultToTrain(ToolVision masterTool, ShapeMatchResult result)
		{
			bool flag = masterTool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				ShapeModelToolTrain train = masterTool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (!flag2)
				{
					train.LastRow = result.Row;
					train.LastColumn = result.Column;
					train.LastAngle = result.Angle;
					train.LastScore = result.Score;
				}
			}
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x0001CE1C File Offset: 0x0001B01C
		private string GetMasterPositionToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && roi.MasterPositionToolName != "None";
				if (flag2)
				{
					result = roi.MasterPositionToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x0001CEAC File Offset: 0x0001B0AC
		private string GetMasterAngleToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && roi.MasterAngleToolName != "None";
				if (flag2)
				{
					result = roi.MasterAngleToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x0001CF3C File Offset: 0x0001B13C
		private double GetMasterProcessingTime(string masterPositionToolName, string masterAngleToolName)
		{
			double processingTime = 0.0;
			foreach (string masterName in (from x in new string[]
			{
				masterPositionToolName,
				masterAngleToolName
			}
			where !string.IsNullOrWhiteSpace(x) && x != "None"
			select x).Distinct<string>())
			{
				double time;
				bool flag = this._currentMasterProcessingTimes != null && this._currentMasterProcessingTimes.TryGetValue(masterName, out time);
				if (flag)
				{
					processingTime += time;
				}
			}
			return processingTime;
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x0001CFF0 File Offset: 0x0001B1F0
		private Tuple<double, double> TransformPoint(double row, double column, FindMinAreaProcessor.MasterTransform transform)
		{
			bool flag = transform == null;
			Tuple<double, double> result;
			if (flag)
			{
				result = Tuple.Create<double, double>(row, column);
			}
			else
			{
				double cos = Math.Cos(transform.Angle);
				double sin = Math.Sin(transform.Angle);
				double relRow = row - transform.MasterRow;
				double relColumn = column - transform.MasterColumn;
				double newRow = transform.MasterRow + transform.Row + relRow * cos - relColumn * sin;
				double newColumn = transform.MasterColumn + transform.Column + relRow * sin + relColumn * cos;
				result = Tuple.Create<double, double>(newRow, newColumn);
			}
			return result;
		}

		// Token: 0x0400022A RID: 554
		private readonly IDictionary<string, ShapeMatchResult> _cachedMasterResults;

		// Token: 0x0400022B RID: 555
		private Dictionary<string, double> _currentMasterProcessingTimes;

		// Token: 0x0400022C RID: 556
		private Dictionary<string, bool> _currentMasterMatchStates;

		// Token: 0x020002FC RID: 764
		private class MasterTransform
		{
			// Token: 0x17000B23 RID: 2851
			// (get) Token: 0x06002724 RID: 10020 RVA: 0x000E03AC File Offset: 0x000DE5AC
			// (set) Token: 0x06002725 RID: 10021 RVA: 0x000E03B4 File Offset: 0x000DE5B4
			public double Row { get; set; }

			// Token: 0x17000B24 RID: 2852
			// (get) Token: 0x06002726 RID: 10022 RVA: 0x000E03BD File Offset: 0x000DE5BD
			// (set) Token: 0x06002727 RID: 10023 RVA: 0x000E03C5 File Offset: 0x000DE5C5
			public double Column { get; set; }

			// Token: 0x17000B25 RID: 2853
			// (get) Token: 0x06002728 RID: 10024 RVA: 0x000E03CE File Offset: 0x000DE5CE
			// (set) Token: 0x06002729 RID: 10025 RVA: 0x000E03D6 File Offset: 0x000DE5D6
			public double Angle { get; set; }

			// Token: 0x17000B26 RID: 2854
			// (get) Token: 0x0600272A RID: 10026 RVA: 0x000E03DF File Offset: 0x000DE5DF
			// (set) Token: 0x0600272B RID: 10027 RVA: 0x000E03E7 File Offset: 0x000DE5E7
			public double MasterRow { get; set; }

			// Token: 0x17000B27 RID: 2855
			// (get) Token: 0x0600272C RID: 10028 RVA: 0x000E03F0 File Offset: 0x000DE5F0
			// (set) Token: 0x0600272D RID: 10029 RVA: 0x000E03F8 File Offset: 0x000DE5F8
			public double MasterColumn { get; set; }
		}
	}
}
