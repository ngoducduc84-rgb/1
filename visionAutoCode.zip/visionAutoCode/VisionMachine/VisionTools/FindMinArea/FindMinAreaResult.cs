﻿using System;
using System.Collections.Generic;
using HalconDotNet;
using VisionMachine.Models.Roi;

namespace VisionMachine.VisionTools.FindMinArea
{
	// Token: 0x0200007D RID: 125
	public class FindMinAreaResult : IDisposable
	{
		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x060005B6 RID: 1462 RVA: 0x0001D259 File Offset: 0x0001B459
		// (set) Token: 0x060005B7 RID: 1463 RVA: 0x0001D261 File Offset: 0x0001B461
		public bool IsSuccess { get; set; }

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x060005B8 RID: 1464 RVA: 0x0001D26A File Offset: 0x0001B46A
		// (set) Token: 0x060005B9 RID: 1465 RVA: 0x0001D272 File Offset: 0x0001B472
		public string Message { get; set; }

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x060005BA RID: 1466 RVA: 0x0001D27B File Offset: 0x0001B47B
		// (set) Token: 0x060005BB RID: 1467 RVA: 0x0001D283 File Offset: 0x0001B483
		public string ToolName { get; set; }

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x060005BC RID: 1468 RVA: 0x0001D28C File Offset: 0x0001B48C
		// (set) Token: 0x060005BD RID: 1469 RVA: 0x0001D294 File Offset: 0x0001B494
		public string RoiName { get; set; }

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x060005BE RID: 1470 RVA: 0x0001D29D File Offset: 0x0001B49D
		// (set) Token: 0x060005BF RID: 1471 RVA: 0x0001D2A5 File Offset: 0x0001B4A5
		public RoiData Roi { get; set; }

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x060005C0 RID: 1472 RVA: 0x0001D2AE File Offset: 0x0001B4AE
		public List<FindMinAreaCandidate> Candidates { get; } = new List<FindMinAreaCandidate>();

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x060005C1 RID: 1473 RVA: 0x0001D2B6 File Offset: 0x0001B4B6
		// (set) Token: 0x060005C2 RID: 1474 RVA: 0x0001D2BE File Offset: 0x0001B4BE
		public FindMinAreaCandidate SelectedBox { get; set; }

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x060005C3 RID: 1475 RVA: 0x0001D2C7 File Offset: 0x0001B4C7
		// (set) Token: 0x060005C4 RID: 1476 RVA: 0x0001D2CF File Offset: 0x0001B4CF
		public HObject RoiRegion { get; set; }

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x060005C5 RID: 1477 RVA: 0x0001D2D8 File Offset: 0x0001B4D8
		// (set) Token: 0x060005C6 RID: 1478 RVA: 0x0001D2E0 File Offset: 0x0001B4E0
		public HObject ThresholdRegion { get; set; }

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x060005C7 RID: 1479 RVA: 0x0001D2E9 File Offset: 0x0001B4E9
		// (set) Token: 0x060005C8 RID: 1480 RVA: 0x0001D2F1 File Offset: 0x0001B4F1
		public HObject AllBoxRegions { get; set; }

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x060005C9 RID: 1481 RVA: 0x0001D2FA File Offset: 0x0001B4FA
		// (set) Token: 0x060005CA RID: 1482 RVA: 0x0001D302 File Offset: 0x0001B502
		public HObject SelectedBoxRegion { get; set; }

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x060005CB RID: 1483 RVA: 0x0001D30B File Offset: 0x0001B50B
		// (set) Token: 0x060005CC RID: 1484 RVA: 0x0001D313 File Offset: 0x0001B513
		public string MasterPositionToolName { get; set; }

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x060005CD RID: 1485 RVA: 0x0001D31C File Offset: 0x0001B51C
		// (set) Token: 0x060005CE RID: 1486 RVA: 0x0001D324 File Offset: 0x0001B524
		public string MasterAngleToolName { get; set; }

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x060005CF RID: 1487 RVA: 0x0001D32D File Offset: 0x0001B52D
		// (set) Token: 0x060005D0 RID: 1488 RVA: 0x0001D335 File Offset: 0x0001B535
		public double MasterProcessingTimeMs { get; set; }

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x060005D1 RID: 1489 RVA: 0x0001D33E File Offset: 0x0001B53E
		// (set) Token: 0x060005D2 RID: 1490 RVA: 0x0001D346 File Offset: 0x0001B546
		public string InputSourceToolName { get; set; }

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x060005D3 RID: 1491 RVA: 0x0001D34F File Offset: 0x0001B54F
		// (set) Token: 0x060005D4 RID: 1492 RVA: 0x0001D357 File Offset: 0x0001B557
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x060005D5 RID: 1493 RVA: 0x0001D360 File Offset: 0x0001B560
		// (set) Token: 0x060005D6 RID: 1494 RVA: 0x0001D368 File Offset: 0x0001B568
		public double ProcessingTimeMs { get; set; }

		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x060005D7 RID: 1495 RVA: 0x0001D371 File Offset: 0x0001B571
		// (set) Token: 0x060005D8 RID: 1496 RVA: 0x0001D379 File Offset: 0x0001B579
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x060005D9 RID: 1497 RVA: 0x0001D384 File Offset: 0x0001B584
		public void Dispose()
		{
			HObject roiRegion = this.RoiRegion;
			if (roiRegion != null)
			{
				roiRegion.Dispose();
			}
			HObject thresholdRegion = this.ThresholdRegion;
			if (thresholdRegion != null)
			{
				thresholdRegion.Dispose();
			}
			HObject allBoxRegions = this.AllBoxRegions;
			if (allBoxRegions != null)
			{
				allBoxRegions.Dispose();
			}
			HObject selectedBoxRegion = this.SelectedBoxRegion;
			if (selectedBoxRegion != null)
			{
				selectedBoxRegion.Dispose();
			}
		}
	}
}
