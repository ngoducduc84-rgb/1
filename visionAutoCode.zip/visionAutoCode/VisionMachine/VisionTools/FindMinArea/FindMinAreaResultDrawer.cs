﻿using System;
using System.Windows.Media;
using HalconDotNet;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.FindMinArea
{
	// Token: 0x0200007E RID: 126
	public class FindMinAreaResultDrawer
	{
		// Token: 0x060005DB RID: 1499 RVA: 0x0001D3EE File Offset: 0x0001B5EE
		public void Draw(HWindow window, ToolVision tool, FindMinAreaResult result)
		{
			this.Draw(window, tool, result, true);
		}

		// Token: 0x060005DC RID: 1500 RVA: 0x0001D3FC File Offset: 0x0001B5FC
		public void Draw(HWindow window, ToolVision tool, FindMinAreaResult result, bool fillThreshold)
		{
			bool flag = window == null || tool == null || result == null;
			if (!flag)
			{
				FindMinAreaToolConfig config = tool.Config as FindMinAreaToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					bool flag3 = config.ShowThreshold && result.ThresholdRegion != null && result.ThresholdRegion.IsInitialized();
					if (flag3)
					{
						HOperatorSet.SetDraw(window, fillThreshold ? "fill" : "margin");
						HOperatorSet.SetLineWidth(window, 1);
						HOperatorSet.SetColor(window, "orange");
						HOperatorSet.DispObj(result.ThresholdRegion, window);
					}
					bool flag4 = config.ShowRoi && result.RoiRegion != null && result.RoiRegion.IsInitialized();
					if (flag4)
					{
						HOperatorSet.SetDraw(window, "margin");
						HOperatorSet.SetLineWidth(window, 2);
						HOperatorSet.SetColor(window, "cyan");
						HOperatorSet.DispObj(result.RoiRegion, window);
					}
					bool flag5 = config.ShowAllBoxes && result.AllBoxRegions != null && result.AllBoxRegions.IsInitialized();
					if (flag5)
					{
						HOperatorSet.SetDraw(window, "margin");
						HOperatorSet.SetLineWidth(window, 1);
						HOperatorSet.SetColor(window, "gray");
						HOperatorSet.DispObj(result.AllBoxRegions, window);
					}
					bool flag6 = !result.IsSuccess || result.SelectedBoxRegion == null || !result.SelectedBoxRegion.IsInitialized();
					if (!flag6)
					{
						HOperatorSet.SetDraw(window, "margin");
						HOperatorSet.SetLineWidth(window, 2);
						HOperatorSet.SetColor(window, "green");
						HOperatorSet.DispObj(result.SelectedBoxRegion, window);
						HOperatorSet.SetColor(window, "green");
						HOperatorSet.DispCross(window, result.SelectedBox.Row, result.SelectedBox.Column, 12, 0);
						bool flag7 = !config.ShowText;
						if (!flag7)
						{
							this.SetTextSize(window, config.TextSize);
							this.SetTextColor(window, config.TextColorValue, config.TextColor);
							HOperatorSet.SetTposition(window, result.SelectedBox.Row, result.SelectedBox.Column);
							HOperatorSet.WriteString(window, string.Concat(new string[]
							{
								string.IsNullOrWhiteSpace(tool.Name) ? "Find Min Area" : tool.Name,
								" ",
								result.RoiName,
								" R",
								result.SelectedBox.GridRow.ToString(),
								" C",
								result.SelectedBox.GridColumn.ToString(),
								" W=",
								result.SelectedBox.Width.ToString("0.0"),
								" H=",
								result.SelectedBox.Height.ToString("0.0"),
								" A=",
								result.SelectedBox.AngleDegree.ToString("0.0")
							}));
						}
					}
				}
			}
		}

		// Token: 0x060005DD RID: 1501 RVA: 0x0001D7CC File Offset: 0x0001B9CC
		private void SetTextSize(HWindow window, int textSize)
		{
			try
			{
				HOperatorSet.SetFont(window, "Arial-" + Math.Max(1, textSize).ToString());
			}
			catch
			{
			}
		}

		// Token: 0x060005DE RID: 1502 RVA: 0x0001D820 File Offset: 0x0001BA20
		private void SetTextColor(HWindow window, Color color, string fallbackColor)
		{
			try
			{
				HOperatorSet.SetColor(window, "#" + color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2"));
			}
			catch
			{
				HOperatorSet.SetColor(window, string.IsNullOrWhiteSpace(fallbackColor) ? "green" : fallbackColor);
			}
		}
	}
}
