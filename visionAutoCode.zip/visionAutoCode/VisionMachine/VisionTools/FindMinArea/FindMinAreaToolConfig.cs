﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using Newtonsoft.Json;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindMinArea
{
	// Token: 0x0200007F RID: 127
	public class FindMinAreaToolConfig : ToolConfigBase
	{
		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x060005E0 RID: 1504 RVA: 0x0001D8C0 File Offset: 0x0001BAC0
		// (set) Token: 0x060005E1 RID: 1505 RVA: 0x0001D8C8 File Offset: 0x0001BAC8
		public ImageInputLink InputLink { get; set; } = new ImageInputLink();

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x060005E2 RID: 1506 RVA: 0x0001D8D4 File Offset: 0x0001BAD4
		// (set) Token: 0x060005E3 RID: 1507 RVA: 0x0001D8EC File Offset: 0x0001BAEC
		[DisplayName("Threshold Polarity")]
		public FindMinAreaPolarity ThresholdPolarity
		{
			get
			{
				return this._thresholdPolarity;
			}
			set
			{
				this.SetValue<FindMinAreaPolarity>(ref this._thresholdPolarity, value, "ThresholdPolarity");
			}
		}

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x060005E4 RID: 1508 RVA: 0x0001D904 File Offset: 0x0001BB04
		// (set) Token: 0x060005E5 RID: 1509 RVA: 0x0001D91C File Offset: 0x0001BB1C
		[DisplayName("Threshold Min")]
		public double ThresholdMin
		{
			get
			{
				return this._thresholdMin;
			}
			set
			{
				this.SetValue<double>(ref this._thresholdMin, value, "ThresholdMin");
			}
		}

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x060005E6 RID: 1510 RVA: 0x0001D934 File Offset: 0x0001BB34
		// (set) Token: 0x060005E7 RID: 1511 RVA: 0x0001D94C File Offset: 0x0001BB4C
		[DisplayName("Threshold Max")]
		public double ThresholdMax
		{
			get
			{
				return this._thresholdMax;
			}
			set
			{
				this.SetValue<double>(ref this._thresholdMax, value, "ThresholdMax");
			}
		}

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x060005E8 RID: 1512 RVA: 0x0001D964 File Offset: 0x0001BB64
		// (set) Token: 0x060005E9 RID: 1513 RVA: 0x0001D97C File Offset: 0x0001BB7C
		[DisplayName("Min Area")]
		public double MinArea
		{
			get
			{
				return this._minArea;
			}
			set
			{
				this.SetValue<double>(ref this._minArea, value, "MinArea");
			}
		}

		// Token: 0x170001FA RID: 506
		// (get) Token: 0x060005EA RID: 1514 RVA: 0x0001D994 File Offset: 0x0001BB94
		// (set) Token: 0x060005EB RID: 1515 RVA: 0x0001D9AC File Offset: 0x0001BBAC
		[DisplayName("Max Area")]
		public double MaxArea
		{
			get
			{
				return this._maxArea;
			}
			set
			{
				this.SetValue<double>(ref this._maxArea, value, "MaxArea");
			}
		}

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x060005EC RID: 1516 RVA: 0x0001D9C4 File Offset: 0x0001BBC4
		// (set) Token: 0x060005ED RID: 1517 RVA: 0x0001D9DC File Offset: 0x0001BBDC
		[DisplayName("Min Width")]
		public double MinWidth
		{
			get
			{
				return this._minWidth;
			}
			set
			{
				this.SetValue<double>(ref this._minWidth, value, "MinWidth");
			}
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x060005EE RID: 1518 RVA: 0x0001D9F4 File Offset: 0x0001BBF4
		// (set) Token: 0x060005EF RID: 1519 RVA: 0x0001DA0C File Offset: 0x0001BC0C
		[DisplayName("Max Width")]
		public double MaxWidth
		{
			get
			{
				return this._maxWidth;
			}
			set
			{
				this.SetValue<double>(ref this._maxWidth, value, "MaxWidth");
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x060005F0 RID: 1520 RVA: 0x0001DA24 File Offset: 0x0001BC24
		// (set) Token: 0x060005F1 RID: 1521 RVA: 0x0001DA3C File Offset: 0x0001BC3C
		[DisplayName("Min Height")]
		public double MinHeight
		{
			get
			{
				return this._minHeight;
			}
			set
			{
				this.SetValue<double>(ref this._minHeight, value, "MinHeight");
			}
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x060005F2 RID: 1522 RVA: 0x0001DA54 File Offset: 0x0001BC54
		// (set) Token: 0x060005F3 RID: 1523 RVA: 0x0001DA6C File Offset: 0x0001BC6C
		[DisplayName("Max Height")]
		public double MaxHeight
		{
			get
			{
				return this._maxHeight;
			}
			set
			{
				this.SetValue<double>(ref this._maxHeight, value, "MaxHeight");
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x060005F4 RID: 1524 RVA: 0x0001DA84 File Offset: 0x0001BC84
		// (set) Token: 0x060005F5 RID: 1525 RVA: 0x0001DA9C File Offset: 0x0001BC9C
		[DisplayName("Pick Row")]
		public int PickRow
		{
			get
			{
				return this._pickRow;
			}
			set
			{
				this.SetValue<int>(ref this._pickRow, (value < 0) ? 0 : value, "PickRow");
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x060005F6 RID: 1526 RVA: 0x0001DABC File Offset: 0x0001BCBC
		// (set) Token: 0x060005F7 RID: 1527 RVA: 0x0001DAD4 File Offset: 0x0001BCD4
		[DisplayName("Pick Column")]
		public int PickColumn
		{
			get
			{
				return this._pickColumn;
			}
			set
			{
				this.SetValue<int>(ref this._pickColumn, (value < 0) ? 0 : value, "PickColumn");
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x060005F8 RID: 1528 RVA: 0x0001DAF4 File Offset: 0x0001BCF4
		// (set) Token: 0x060005F9 RID: 1529 RVA: 0x0001DB0C File Offset: 0x0001BD0C
		[DisplayName("Row Spacing")]
		public double RowSpacing
		{
			get
			{
				return this._rowSpacing;
			}
			set
			{
				this.SetValue<double>(ref this._rowSpacing, (value < 0.0) ? 0.0 : value, "RowSpacing");
			}
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x060005FA RID: 1530 RVA: 0x0001DB3C File Offset: 0x0001BD3C
		// (set) Token: 0x060005FB RID: 1531 RVA: 0x0001DB54 File Offset: 0x0001BD54
		[DisplayName("Column Spacing")]
		public double ColumnSpacing
		{
			get
			{
				return this._columnSpacing;
			}
			set
			{
				this.SetValue<double>(ref this._columnSpacing, (value < 0.0) ? 0.0 : value, "ColumnSpacing");
			}
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x060005FC RID: 1532 RVA: 0x0001DB84 File Offset: 0x0001BD84
		// (set) Token: 0x060005FD RID: 1533 RVA: 0x0001DB9C File Offset: 0x0001BD9C
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				this.SetValue<bool>(ref this._showRoi, value, "ShowRoi");
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x060005FE RID: 1534 RVA: 0x0001DBB4 File Offset: 0x0001BDB4
		// (set) Token: 0x060005FF RID: 1535 RVA: 0x0001DBCC File Offset: 0x0001BDCC
		[DisplayName("Show Threshold")]
		public bool ShowThreshold
		{
			get
			{
				return this._showThreshold;
			}
			set
			{
				this.SetValue<bool>(ref this._showThreshold, value, "ShowThreshold");
			}
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x06000600 RID: 1536 RVA: 0x0001DBE4 File Offset: 0x0001BDE4
		// (set) Token: 0x06000601 RID: 1537 RVA: 0x0001DBFC File Offset: 0x0001BDFC
		[DisplayName("Show All Boxes")]
		public bool ShowAllBoxes
		{
			get
			{
				return this._showAllBoxes;
			}
			set
			{
				this.SetValue<bool>(ref this._showAllBoxes, value, "ShowAllBoxes");
			}
		}

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000602 RID: 1538 RVA: 0x0001DC14 File Offset: 0x0001BE14
		// (set) Token: 0x06000603 RID: 1539 RVA: 0x0001DC2C File Offset: 0x0001BE2C
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				this.SetValue<bool>(ref this._showText, value, "ShowText");
			}
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x06000604 RID: 1540 RVA: 0x0001DC44 File Offset: 0x0001BE44
		// (set) Token: 0x06000605 RID: 1541 RVA: 0x0001DC5C File Offset: 0x0001BE5C
		[DisplayName("Text Size")]
		public int TextSize
		{
			get
			{
				return this._textSize;
			}
			set
			{
				this.SetValue<int>(ref this._textSize, (value < 1) ? 1 : value, "TextSize");
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x06000606 RID: 1542 RVA: 0x0001DC7C File Offset: 0x0001BE7C
		// (set) Token: 0x06000607 RID: 1543 RVA: 0x0001DC94 File Offset: 0x0001BE94
		[DisplayName("Text Color")]
		public string TextColor
		{
			get
			{
				return this._textColor;
			}
			set
			{
				bool flag = object.Equals(this._textColor, value);
				if (!flag)
				{
					this._textColor = value;
					this._textColorValue = this.ParseColor(value);
					base.OnPropertyChanged("TextColor");
					base.OnPropertyChanged("TextColorValue");
				}
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x06000608 RID: 1544 RVA: 0x0001DCE0 File Offset: 0x0001BEE0
		// (set) Token: 0x06000609 RID: 1545 RVA: 0x0001DCF8 File Offset: 0x0001BEF8
		[Browsable(false)]
		[JsonIgnore]
		public Color TextColorValue
		{
			get
			{
				return this._textColorValue;
			}
			set
			{
				bool flag = this._textColorValue == value;
				if (!flag)
				{
					this._textColorValue = value;
					this._textColor = this.ToHalconColor(value);
					base.OnPropertyChanged("TextColorValue");
					base.OnPropertyChanged("TextColor");
				}
			}
		}

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x0600060A RID: 1546 RVA: 0x0001DD44 File Offset: 0x0001BF44
		// (set) Token: 0x0600060B RID: 1547 RVA: 0x0001DD5C File Offset: 0x0001BF5C
		[DisplayName("Show Input Image")]
		public bool ShowInputImage
		{
			get
			{
				return this._showInputImage;
			}
			set
			{
				this.SetValue<bool>(ref this._showInputImage, value, "ShowInputImage");
			}
		}

		// Token: 0x0600060C RID: 1548 RVA: 0x0001DD74 File Offset: 0x0001BF74
		private Color ParseColor(string color)
		{
			bool flag = string.IsNullOrWhiteSpace(color);
			Color result;
			if (flag)
			{
				result = Colors.Lime;
			}
			else
			{
				try
				{
					result = (Color)ColorConverter.ConvertFromString(color);
				}
				catch
				{
					result = Colors.Lime;
				}
			}
			return result;
		}

		// Token: 0x0600060D RID: 1549 RVA: 0x0001DDC0 File Offset: 0x0001BFC0
		private string ToHalconColor(Color color)
		{
			return "#" + color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
		}

		// Token: 0x0600060E RID: 1550 RVA: 0x0001DE18 File Offset: 0x0001C018
		private void SetValue<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
		{
			bool flag = object.Equals(field, value);
			if (!flag)
			{
				field = value;
				base.OnPropertyChanged(propertyName);
			}
		}

		// Token: 0x0400025A RID: 602
		private FindMinAreaPolarity _thresholdPolarity = FindMinAreaPolarity.DarkToLight;

		// Token: 0x0400025B RID: 603
		private double _thresholdMin = 100.0;

		// Token: 0x0400025C RID: 604
		private double _thresholdMax = 255.0;

		// Token: 0x0400025D RID: 605
		private double _minArea = 10.0;

		// Token: 0x0400025E RID: 606
		private double _maxArea = 999999.0;

		// Token: 0x0400025F RID: 607
		private double _minWidth = 0.0;

		// Token: 0x04000260 RID: 608
		private double _maxWidth = 999999.0;

		// Token: 0x04000261 RID: 609
		private double _minHeight = 0.0;

		// Token: 0x04000262 RID: 610
		private double _maxHeight = 999999.0;

		// Token: 0x04000263 RID: 611
		private int _pickRow = 0;

		// Token: 0x04000264 RID: 612
		private int _pickColumn = 0;

		// Token: 0x04000265 RID: 613
		private double _rowSpacing = 20.0;

		// Token: 0x04000266 RID: 614
		private double _columnSpacing = 20.0;

		// Token: 0x04000267 RID: 615
		private bool _showRoi = true;

		// Token: 0x04000268 RID: 616
		private bool _showThreshold = false;

		// Token: 0x04000269 RID: 617
		private bool _showAllBoxes = false;

		// Token: 0x0400026A RID: 618
		private bool _showText = true;

		// Token: 0x0400026B RID: 619
		private bool _showInputImage = false;

		// Token: 0x0400026C RID: 620
		private int _textSize = 14;

		// Token: 0x0400026D RID: 621
		private string _textColor = "green";

		// Token: 0x0400026E RID: 622
		private Color _textColorValue = Colors.Lime;
	}
}
