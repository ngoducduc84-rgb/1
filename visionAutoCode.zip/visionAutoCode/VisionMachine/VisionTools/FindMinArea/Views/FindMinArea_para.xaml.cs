﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Windows.Media;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.FindMinArea.Views
{
	// Token: 0x02000080 RID: 128
	public partial class FindMinArea_para : System.Windows.Controls.UserControl, IStyleConnector
	{
		// Token: 0x06000610 RID: 1552 RVA: 0x0001DF5F File Offset: 0x0001C15F
		public FindMinArea_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000611 RID: 1553 RVA: 0x0001DF70 File Offset: 0x0001C170
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.FindMinAreaTrialRun();
			}
		}

		// Token: 0x06000612 RID: 1554 RVA: 0x0001DF84 File Offset: 0x0001C184
		private void BtnMoreColor_Click(object sender, RoutedEventArgs e)
		{
			FrameworkElement button = sender as FrameworkElement;
			object valueSource = (button != null) ? button.Tag : null;
			PropertyInfo valueProperty = (valueSource != null) ? valueSource.GetType().GetProperty("Value") : null;
			bool flag = valueSource == null || valueProperty == null;
			if (!flag)
			{
				ColorDialog dialog = new ColorDialog
				{
					FullOpen = true
				};
				object currentColor = valueProperty.GetValue(valueSource, null);
				string colorText = currentColor as string;
				System.Windows.Media.Color currentMediaColor;
				bool flag2 = colorText != null && this.TryParseColor(colorText, out currentMediaColor);
				if (flag2)
				{
					dialog.Color = System.Drawing.Color.FromArgb((int)currentMediaColor.A, (int)currentMediaColor.R, (int)currentMediaColor.G, (int)currentMediaColor.B);
				}
				bool flag3 = dialog.ShowDialog() != DialogResult.OK;
				if (!flag3)
				{
					System.Windows.Media.Color selectedColor = System.Windows.Media.Color.FromArgb(dialog.Color.A, dialog.Color.R, dialog.Color.G, dialog.Color.B);
					valueProperty.SetValue(valueSource, "#" + selectedColor.R.ToString("X2") + selectedColor.G.ToString("X2") + selectedColor.B.ToString("X2"), null);
				}
			}
		}

		// Token: 0x06000613 RID: 1555 RVA: 0x0001E0E4 File Offset: 0x0001C2E4
		private bool TryParseColor(string colorText, out System.Windows.Media.Color color)
		{
			color = Colors.Lime;
			bool flag = string.IsNullOrWhiteSpace(colorText);
			bool result;
			if (flag)
			{
				result = false;
			}
			else
			{
				try
				{
					color = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(colorText);
					result = true;
				}
				catch
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x06000616 RID: 1558 RVA: 0x0001E1B0 File Offset: 0x0001C3B0
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				((SimpleButton)target).Click += this.BtnMoreColor_Click;
			}
		}
	}
}
