﻿using System;
using System.Diagnostics;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.ResultInspection;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.FindRedArrow
{
	// Token: 0x02000108 RID: 264
	public class FindRedArrowActionService : IToolActionService
	{
		// Token: 0x170004BE RID: 1214
		// (get) Token: 0x06000D7A RID: 3450 RVA: 0x0003E818 File Offset: 0x0003CA18
		public ToolType ToolType
		{
			get
			{
				return ToolType.FindRedArrow;
			}
		}

		// Token: 0x06000D7B RID: 3451 RVA: 0x0003E82C File Offset: 0x0003CA2C
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				HObject redness = null;
				ImageBufferStore bufferStore = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (flag2)
					{
						ToolActionFeedback.ReportError(context, "No original image is available.");
					}
					else
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext buildContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						string inputSourceToolName = this.GetInputSourceToolName(tool);
						input = this._pipelineService.BuildInputImageForTool(buildContext, tool);
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							if (input != null)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						Stopwatch stopwatch = Stopwatch.StartNew();
						FindRedArrowResult result = this._processor.Run(input, tool);
						stopwatch.Stop();
						bool flag4 = result.ProcessingTimeMs <= 0.0;
						if (flag4)
						{
							result.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
						}
						bool flag5 = result.TotalProcessingTimeMs <= 0.0;
						if (flag5)
						{
							result.TotalProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
						}
						result.InputSourceToolName = inputSourceToolName;
						InspectionResultStore.Record(tool.Name, result);
						Action<ToolVision, object> resultReporter = context.ResultReporter;
						if (resultReporter != null)
						{
							resultReporter(tool, result);
						}
						FindRedArrowToolConfig config = tool.Config as FindRedArrowToolConfig;
						bool flag6 = config != null && config.ShowRednessImage;
						if (flag6)
						{
							redness = FindRedArrowProcessor.BuildRednessImage(input);
						}
						context.DisplayController.DisplayImage((redness != null && redness.IsInitialized()) ? redness : input);
						context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
						{
							this._drawer.Draw(window, tool, result);
						}, null);
						bool flag7 = !result.IsSuccess && !string.IsNullOrWhiteSpace(result.Message);
						if (flag7)
						{
							ToolActionFeedback.ReportError(context, result.Message);
						}
					}
				}
				finally
				{
					if (redness != null)
					{
						redness.Dispose();
					}
					if (input != null)
					{
						input.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					if (original != null)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x06000D7C RID: 3452 RVA: 0x0003EB34 File Offset: 0x0003CD34
		private string GetInputSourceToolName(ToolVision tool)
		{
			FindRedArrowToolConfig config = ((tool != null) ? tool.Config : null) as FindRedArrowToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						result = "PreviousToolOutput";
					}
					else
					{
						result = "OriginalImage";
					}
				}
			}
			return result;
		}

		// Token: 0x04000579 RID: 1401
		private readonly FindRedArrowProcessor _processor = new FindRedArrowProcessor();

		// Token: 0x0400057A RID: 1402
		private readonly FindRedArrowResultDrawer _drawer = new FindRedArrowResultDrawer();

		// Token: 0x0400057B RID: 1403
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();
	}
}
