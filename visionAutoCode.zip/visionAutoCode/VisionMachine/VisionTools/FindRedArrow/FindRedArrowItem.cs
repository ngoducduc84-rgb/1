﻿using System;

namespace VisionMachine.VisionTools.FindRedArrow
{
	// Token: 0x0200010B RID: 267
	public class FindRedArrowItem
	{
		// Token: 0x170004C6 RID: 1222
		// (get) Token: 0x06000D97 RID: 3479 RVA: 0x0003FB58 File Offset: 0x0003DD58
		// (set) Token: 0x06000D98 RID: 3480 RVA: 0x0003FB60 File Offset: 0x0003DD60
		public int Index { get; set; }

		// Token: 0x170004C7 RID: 1223
		// (get) Token: 0x06000D99 RID: 3481 RVA: 0x0003FB69 File Offset: 0x0003DD69
		// (set) Token: 0x06000D9A RID: 3482 RVA: 0x0003FB71 File Offset: 0x0003DD71
		public double Area { get; set; }

		// Token: 0x170004C8 RID: 1224
		// (get) Token: 0x06000D9B RID: 3483 RVA: 0x0003FB7A File Offset: 0x0003DD7A
		// (set) Token: 0x06000D9C RID: 3484 RVA: 0x0003FB82 File Offset: 0x0003DD82
		public double Row { get; set; }

		// Token: 0x170004C9 RID: 1225
		// (get) Token: 0x06000D9D RID: 3485 RVA: 0x0003FB8B File Offset: 0x0003DD8B
		// (set) Token: 0x06000D9E RID: 3486 RVA: 0x0003FB93 File Offset: 0x0003DD93
		public double Column { get; set; }

		// Token: 0x170004CA RID: 1226
		// (get) Token: 0x06000D9F RID: 3487 RVA: 0x0003FB9C File Offset: 0x0003DD9C
		// (set) Token: 0x06000DA0 RID: 3488 RVA: 0x0003FBA4 File Offset: 0x0003DDA4
		public double MeanRedness { get; set; }

		// Token: 0x170004CB RID: 1227
		// (get) Token: 0x06000DA1 RID: 3489 RVA: 0x0003FBAD File Offset: 0x0003DDAD
		// (set) Token: 0x06000DA2 RID: 3490 RVA: 0x0003FBB5 File Offset: 0x0003DDB5
		public double Anisometry { get; set; }

		// Token: 0x170004CC RID: 1228
		// (get) Token: 0x06000DA3 RID: 3491 RVA: 0x0003FBBE File Offset: 0x0003DDBE
		// (set) Token: 0x06000DA4 RID: 3492 RVA: 0x0003FBC6 File Offset: 0x0003DDC6
		public bool IsAreaOutOfSpec { get; set; }

		// Token: 0x170004CD RID: 1229
		// (get) Token: 0x06000DA5 RID: 3493 RVA: 0x0003FBCF File Offset: 0x0003DDCF
		// (set) Token: 0x06000DA6 RID: 3494 RVA: 0x0003FBD7 File Offset: 0x0003DDD7
		public double BoxRow1 { get; set; }

		// Token: 0x170004CE RID: 1230
		// (get) Token: 0x06000DA7 RID: 3495 RVA: 0x0003FBE0 File Offset: 0x0003DDE0
		// (set) Token: 0x06000DA8 RID: 3496 RVA: 0x0003FBE8 File Offset: 0x0003DDE8
		public double BoxColumn1 { get; set; }

		// Token: 0x170004CF RID: 1231
		// (get) Token: 0x06000DA9 RID: 3497 RVA: 0x0003FBF1 File Offset: 0x0003DDF1
		// (set) Token: 0x06000DAA RID: 3498 RVA: 0x0003FBF9 File Offset: 0x0003DDF9
		public double BoxRow2 { get; set; }

		// Token: 0x170004D0 RID: 1232
		// (get) Token: 0x06000DAB RID: 3499 RVA: 0x0003FC02 File Offset: 0x0003DE02
		// (set) Token: 0x06000DAC RID: 3500 RVA: 0x0003FC0A File Offset: 0x0003DE0A
		public double BoxColumn2 { get; set; }
	}
}
