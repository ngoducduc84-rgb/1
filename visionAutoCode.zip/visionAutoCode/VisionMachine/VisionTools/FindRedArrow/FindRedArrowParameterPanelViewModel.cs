﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindRedArrow
{
	// Token: 0x02000109 RID: 265
	public class FindRedArrowParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x170004BF RID: 1215
		// (get) Token: 0x06000D7E RID: 3454 RVA: 0x0003EBF3 File Offset: 0x0003CDF3
		// (set) Token: 0x06000D7F RID: 3455 RVA: 0x0003EBFB File Offset: 0x0003CDFB
		public ToolVision Tool { get; set; }

		// Token: 0x170004C0 RID: 1216
		// (get) Token: 0x06000D80 RID: 3456 RVA: 0x0003EC04 File Offset: 0x0003CE04
		// (set) Token: 0x06000D81 RID: 3457 RVA: 0x0003EC0C File Offset: 0x0003CE0C
		public FindRedArrowToolConfig Config { get; set; }

		// Token: 0x170004C1 RID: 1217
		// (get) Token: 0x06000D82 RID: 3458 RVA: 0x0003EC15 File Offset: 0x0003CE15
		// (set) Token: 0x06000D83 RID: 3459 RVA: 0x0003EC1D File Offset: 0x0003CE1D
		public FindRedArrowToolSpec Spec { get; set; }

		// Token: 0x170004C2 RID: 1218
		// (get) Token: 0x06000D84 RID: 3460 RVA: 0x0003EC26 File Offset: 0x0003CE26
		// (set) Token: 0x06000D85 RID: 3461 RVA: 0x0003EC2E File Offset: 0x0003CE2E
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x170004C3 RID: 1219
		// (get) Token: 0x06000D86 RID: 3462 RVA: 0x0003EC38 File Offset: 0x0003CE38
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x170004C4 RID: 1220
		// (get) Token: 0x06000D87 RID: 3463 RVA: 0x0003EC54 File Offset: 0x0003CE54
		// (set) Token: 0x06000D88 RID: 3464 RVA: 0x0003EC6C File Offset: 0x0003CE6C
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool == value;
				if (!flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.Config != null && this.Config.InputLink != null;
					if (flag2)
					{
						this.Config.InputLink.SourceToolId = null;
						this.Config.InputLink.SourceToolName = ((this._selectedSourceTool == null) ? null : this._selectedSourceTool.ToolName);
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x1400001B RID: 27
		// (add) Token: 0x06000D89 RID: 3465 RVA: 0x0003ECF4 File Offset: 0x0003CEF4
		// (remove) Token: 0x06000D8A RID: 3466 RVA: 0x0003ED2C File Offset: 0x0003CF2C
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000D8B RID: 3467 RVA: 0x0003ED61 File Offset: 0x0003CF61
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x06000D8C RID: 3468 RVA: 0x0003ED80 File Offset: 0x0003CF80
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.Config == null || this.Config.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.Config.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.Config.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.Config.InputLink.SourceToolId = null;
				this.Config.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x0400057C RID: 1404
		private ToolImageSourceOption _selectedSourceTool;
	}
}
