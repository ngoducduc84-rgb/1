﻿using System;
using System.Collections.Generic;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.FindRedArrow
{
	// Token: 0x0200010A RID: 266
	public class FindRedArrowProcessor : IToolProcessor
	{
		// Token: 0x170004C5 RID: 1221
		// (get) Token: 0x06000D8E RID: 3470 RVA: 0x0003EE60 File Offset: 0x0003D060
		public ToolType ToolType
		{
			get
			{
				return ToolType.FindRedArrow;
			}
		}

		// Token: 0x06000D8F RID: 3471 RVA: 0x0003EE74 File Offset: 0x0003D074
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			ToolProcessResult processResult = new ToolProcessResult();
			bool flag = context == null || context.InputImage == null;
			ToolProcessResult result2;
			if (flag)
			{
				processResult.IsSuccess = false;
				processResult.Message = "Input image null.";
				result2 = processResult;
			}
			else
			{
				FindRedArrowResult result = this.Run(context.InputImage, tool);
				processResult.IsSuccess = result.IsSuccess;
				processResult.Message = result.Message;
				processResult.Data = result;
				HObject copy;
				HOperatorSet.CopyImage(context.InputImage, out copy);
				context.OutputImage = copy;
				result2 = processResult;
			}
			return result2;
		}

		// Token: 0x06000D90 RID: 3472 RVA: 0x0003EF04 File Offset: 0x0003D104
		public static HObject BuildRednessImage(HObject image)
		{
			bool flag = image == null || !image.IsInitialized();
			HObject result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HTuple channels;
				HOperatorSet.CountChannels(image, out channels);
				bool flag2 = channels.Length == 0 || channels[0].I < 3;
				if (flag2)
				{
					result = null;
				}
				else
				{
					HObject red = null;
					HObject green = null;
					HObject blue = null;
					HObject maxGreenBlue = null;
					try
					{
						HOperatorSet.AccessChannel(image, out red, 1);
						HOperatorSet.AccessChannel(image, out green, 2);
						HOperatorSet.AccessChannel(image, out blue, 3);
						HOperatorSet.MaxImage(green, blue, out maxGreenBlue);
						HObject redness;
						HOperatorSet.SubImage(red, maxGreenBlue, out redness, 1, 0);
						result = redness;
					}
					catch (HOperatorException)
					{
						result = null;
					}
					finally
					{
						if (red != null)
						{
							red.Dispose();
						}
						if (green != null)
						{
							green.Dispose();
						}
						if (blue != null)
						{
							blue.Dispose();
						}
						if (maxGreenBlue != null)
						{
							maxGreenBlue.Dispose();
						}
					}
				}
			}
			return result;
		}

		// Token: 0x06000D91 RID: 3473 RVA: 0x0003F018 File Offset: 0x0003D218
		public FindRedArrowResult Run(HObject image, ToolVision tool)
		{
			FindRedArrowResult result = new FindRedArrowResult();
			bool flag = tool == null;
			FindRedArrowResult result2;
			if (flag)
			{
				result.Message = "Tool null.";
				result2 = result;
			}
			else
			{
				bool flag2 = image == null || !image.IsInitialized();
				if (flag2)
				{
					result.Message = "No image is available for inspection.";
					result2 = result;
				}
				else
				{
					FindRedArrowToolConfig config = tool.Config as FindRedArrowToolConfig;
					FindRedArrowToolSpec spec = tool.Spec as FindRedArrowToolSpec;
					bool flag3 = config == null;
					if (flag3)
					{
						result.Message = "The selected tool is not a Find Red Arrow tool.";
						result2 = result;
					}
					else
					{
						HObject redness = null;
						HObject searchImage = null;
						HObject searchRegion = null;
						HObject reduced = null;
						HObject thresholded = null;
						HObject closed = null;
						HObject opened = null;
						HObject candidates = null;
						HObject byShape = null;
						try
						{
							redness = FindRedArrowProcessor.BuildRednessImage(image);
							bool flag4 = redness == null;
							if (flag4)
							{
								result.IsSuccess = false;
								result.IsColorImage = false;
								result.IsOk = false;
								result.SpecStatus = "NG";
								result.Message = "This image has fewer than 3 channels, so red cannot be separated from gray. Feed the tool a colour image.";
								result2 = result;
							}
							else
							{
								result.IsColorImage = true;
								searchImage = this._roiImageService.ReduceByRois(redness, tool.RoiItems, tool);
								HOperatorSet.GetDomain(searchImage, out searchRegion);
								HTuple searchArea;
								HTuple htuple;
								HTuple __;
								HOperatorSet.AreaCenter(searchRegion, out searchArea, out htuple, out __);
								result.SearchArea = ((searchArea.Length > 0) ? searchArea.TupleSum().D : 0.0);
								HOperatorSet.ReduceDomain(redness, searchRegion, out reduced);
								HOperatorSet.Threshold(reduced, out thresholded, config.RedThreshold, 255);
								HOperatorSet.ClosingCircle(thresholded, out closed, config.CloseRadius);
								HOperatorSet.OpeningCircle(closed, out opened, config.OpenRadius);
								HOperatorSet.Connection(opened, out candidates);
								HTuple candidateCount;
								HOperatorSet.CountObj(candidates, out candidateCount);
								result.CandidateCount = ((candidateCount.Length > 0) ? candidateCount.I : 0);
								bool showThresholdRegion = config.ShowThresholdRegion;
								if (showThresholdRegion)
								{
									FindRedArrowProcessor.CollectThresholdContours(candidates, result);
								}
								HOperatorSet.SelectShape(candidates, out byShape, new HTuple("area").TupleConcat("anisometry"), "and", new HTuple(config.MinArea).TupleConcat(0.0), new HTuple(config.MaxArea).TupleConcat(config.MaxAnisometry));
								this.CollectArrows(byShape, redness, config, result, image);
								FindRedArrowProcessor.ApplySpecAndJudge(spec, result);
								result.IsSuccess = true;
								result.Message = string.Concat(new string[]
								{
									"Red arrow check completed. ",
									result.SpecStatus,
									", arrows=",
									result.ArrowCount.ToString(),
									", largest=",
									result.MaxArea.ToString("0"),
									" px (from ",
									result.CandidateCount.ToString(),
									" red patch(es) over threshold)"
								});
								result2 = result;
							}
						}
						catch (Exception ex)
						{
							result.IsSuccess = false;
							result.IsOk = false;
							result.SpecStatus = "NG";
							result.Message = "Find Red Arrow failed: " + ex.Message;
							result2 = result;
						}
						finally
						{
							if (redness != null)
							{
								redness.Dispose();
							}
							if (searchImage != null)
							{
								searchImage.Dispose();
							}
							if (searchRegion != null)
							{
								searchRegion.Dispose();
							}
							if (reduced != null)
							{
								reduced.Dispose();
							}
							if (thresholded != null)
							{
								thresholded.Dispose();
							}
							if (closed != null)
							{
								closed.Dispose();
							}
							if (opened != null)
							{
								opened.Dispose();
							}
							if (candidates != null)
							{
								candidates.Dispose();
							}
							if (byShape != null)
							{
								byShape.Dispose();
							}
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x06000D92 RID: 3474 RVA: 0x0003F404 File Offset: 0x0003D604
		private void CollectArrows(HObject byShape, HObject redness, FindRedArrowToolConfig config, FindRedArrowResult result, HObject image)
		{
			HTuple count;
			HOperatorSet.CountObj(byShape, out count);
			bool flag = count.Length == 0 || count.I <= 0;
			if (!flag)
			{
				HTuple width;
				HTuple height;
				HOperatorSet.GetImageSize(image, out width, out height);
				int i = 1;
				while (i <= count.I)
				{
					HObject single = null;
					try
					{
						HOperatorSet.SelectObj(byShape, out single, i);
						HTuple mean;
						HTuple deviation;
						HOperatorSet.Intensity(single, redness, out mean, out deviation);
						double meanRedness = (mean.Length > 0) ? mean.D : 0.0;
						bool flag2 = meanRedness < config.MinMeanRedness;
						if (!flag2)
						{
							HTuple area;
							HTuple row;
							HTuple column;
							HOperatorSet.AreaCenter(single, out area, out row, out column);
							HTuple anisometry;
							HTuple htuple;
							HTuple __;
							HOperatorSet.Eccentricity(single, out anisometry, out htuple, out __);
							HTuple row2;
							HTuple column2;
							HTuple row3;
							HTuple column3;
							HOperatorSet.SmallestRectangle1(single, out row2, out column2, out row3, out column3);
							FindRedArrowItem arrow = new FindRedArrowItem
							{
								Index = result.Arrows.Count + 1,
								Area = ((area.Length > 0) ? area.D : 0.0),
								Row = ((row.Length > 0) ? row.D : 0.0),
								Column = ((column.Length > 0) ? column.D : 0.0),
								MeanRedness = meanRedness,
								Anisometry = ((anisometry.Length > 0) ? anisometry.D : 0.0),
								BoxRow1 = Math.Max(row2.D - config.BoxMargin, 0.0),
								BoxColumn1 = Math.Max(column2.D - config.BoxMargin, 0.0),
								BoxRow2 = Math.Min(row3.D + config.BoxMargin, (double)(height.I - 1)),
								BoxColumn2 = Math.Min(column3.D + config.BoxMargin, (double)(width.I - 1))
							};
							result.Arrows.Add(arrow);
							result.TotalArea += arrow.Area;
							result.MaxArea = Math.Max(result.MaxArea, arrow.Area);
							bool showArrows = config.ShowArrows;
							if (showArrows)
							{
								FindRedArrowProcessor.CollectContours(single, result.ArrowContourRows, result.ArrowContourColumns);
							}
						}
					}
					catch (HOperatorException)
					{
					}
					finally
					{
						if (single != null)
						{
							single.Dispose();
						}
					}
					IL_27C:
					i++;
					continue;
					goto IL_27C;
				}
				result.ArrowCount = result.Arrows.Count;
			}
		}

		// Token: 0x06000D93 RID: 3475 RVA: 0x0003F6F4 File Offset: 0x0003D8F4
		private static void CollectThresholdContours(HObject candidates, FindRedArrowResult result)
		{
			using (null)
			{
				try
				{
					HTuple count;
					HOperatorSet.CountObj(candidates, out count);
					bool flag = count.Length == 0 || count.I <= 0;
					if (!flag)
					{
						int take = Math.Min(count.I, 400);
						for (int i = 1; i <= take; i++)
						{
							HObject single = null;
							try
							{
								HOperatorSet.SelectObj(candidates, out single, i);
								FindRedArrowProcessor.CollectContours(single, result.ThresholdContourRows, result.ThresholdContourColumns);
							}
							catch (HOperatorException)
							{
							}
							finally
							{
								if (single != null)
								{
									single.Dispose();
								}
							}
						}
					}
				}
				catch (HOperatorException)
				{
				}
			}
		}

		// Token: 0x06000D94 RID: 3476 RVA: 0x0003F7EC File Offset: 0x0003D9EC
		private static void CollectContours(HObject region, List<double[]> rowsOut, List<double[]> columnsOut)
		{
			HObject contours = null;
			try
			{
				HOperatorSet.GenContourRegionXld(region, out contours, "border");
				HTuple count;
				HOperatorSet.CountObj(contours, out count);
				for (int i = 1; i <= ((count.Length > 0) ? count.I : 0); i++)
				{
					HObject single = null;
					try
					{
						HOperatorSet.SelectObj(contours, out single, i);
						HTuple rows;
						HTuple columns;
						HOperatorSet.GetContourXld(single, out rows, out columns);
						bool flag = rows.Length > 1;
						if (flag)
						{
							rowsOut.Add(rows.ToDArr());
							columnsOut.Add(columns.ToDArr());
						}
					}
					catch (HOperatorException)
					{
					}
					finally
					{
						if (single != null)
						{
							single.Dispose();
						}
					}
				}
			}
			catch (HOperatorException)
			{
			}
			finally
			{
				if (contours != null)
				{
					contours.Dispose();
				}
			}
		}

		// Token: 0x06000D95 RID: 3477 RVA: 0x0003F8F8 File Offset: 0x0003DAF8
		private static void ApplySpecAndJudge(FindRedArrowToolSpec spec, FindRedArrowResult result)
		{
			bool flag = spec == null || !spec.IsEnabled;
			if (flag)
			{
				result.IsSpecEnabled = false;
				result.IsOk = true;
				result.SpecStatus = "OK";
			}
			else
			{
				result.IsSpecEnabled = true;
				bool flag2 = spec.CountEnabled && ((double)result.ArrowCount < spec.CountMin || (double)result.ArrowCount > spec.CountMax);
				if (flag2)
				{
					result.SpecFailures.Add(string.Concat(new string[]
					{
						"Red arrow count ",
						result.ArrowCount.ToString(),
						" outside [",
						spec.CountMin.ToString("0"),
						", ",
						spec.CountMax.ToString("0"),
						"]"
					}));
				}
				bool areaEnabled = spec.AreaEnabled;
				if (areaEnabled)
				{
					foreach (FindRedArrowItem arrow in result.Arrows)
					{
						bool flag3 = arrow.Area >= spec.AreaMin && arrow.Area <= spec.AreaMax;
						if (!flag3)
						{
							arrow.IsAreaOutOfSpec = true;
							result.SpecFailures.Add(string.Concat(new string[]
							{
								"Arrow #",
								arrow.Index.ToString(),
								" area ",
								arrow.Area.ToString("0"),
								" px outside [",
								spec.AreaMin.ToString("0"),
								", ",
								spec.AreaMax.ToString("0"),
								"]"
							}));
						}
					}
				}
				result.IsOk = (result.SpecFailures.Count == 0);
				result.SpecStatus = (result.IsOk ? "OK" : "NG");
			}
		}

		// Token: 0x04000582 RID: 1410
		private readonly ShapeModelRoiImageService _roiImageService = new ShapeModelRoiImageService();

		// Token: 0x04000583 RID: 1411
		private const int MaxThresholdContours = 400;
	}
}
