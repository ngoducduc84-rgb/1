﻿using System;
using System.Collections.Generic;

namespace VisionMachine.VisionTools.FindRedArrow
{
	// Token: 0x0200010C RID: 268
	public class FindRedArrowResult
	{
		// Token: 0x170004D1 RID: 1233
		// (get) Token: 0x06000DAE RID: 3502 RVA: 0x0003FC13 File Offset: 0x0003DE13
		// (set) Token: 0x06000DAF RID: 3503 RVA: 0x0003FC1B File Offset: 0x0003DE1B
		public bool IsSuccess { get; set; }

		// Token: 0x170004D2 RID: 1234
		// (get) Token: 0x06000DB0 RID: 3504 RVA: 0x0003FC24 File Offset: 0x0003DE24
		// (set) Token: 0x06000DB1 RID: 3505 RVA: 0x0003FC2C File Offset: 0x0003DE2C
		public string Message { get; set; }

		// Token: 0x170004D3 RID: 1235
		// (get) Token: 0x06000DB2 RID: 3506 RVA: 0x0003FC35 File Offset: 0x0003DE35
		// (set) Token: 0x06000DB3 RID: 3507 RVA: 0x0003FC3D File Offset: 0x0003DE3D
		public bool IsColorImage { get; set; }

		// Token: 0x170004D4 RID: 1236
		// (get) Token: 0x06000DB4 RID: 3508 RVA: 0x0003FC46 File Offset: 0x0003DE46
		// (set) Token: 0x06000DB5 RID: 3509 RVA: 0x0003FC4E File Offset: 0x0003DE4E
		public int ArrowCount { get; set; }

		// Token: 0x170004D5 RID: 1237
		// (get) Token: 0x06000DB6 RID: 3510 RVA: 0x0003FC57 File Offset: 0x0003DE57
		// (set) Token: 0x06000DB7 RID: 3511 RVA: 0x0003FC5F File Offset: 0x0003DE5F
		public double TotalArea { get; set; }

		// Token: 0x170004D6 RID: 1238
		// (get) Token: 0x06000DB8 RID: 3512 RVA: 0x0003FC68 File Offset: 0x0003DE68
		// (set) Token: 0x06000DB9 RID: 3513 RVA: 0x0003FC70 File Offset: 0x0003DE70
		public double MaxArea { get; set; }

		// Token: 0x170004D7 RID: 1239
		// (get) Token: 0x06000DBA RID: 3514 RVA: 0x0003FC79 File Offset: 0x0003DE79
		public List<FindRedArrowItem> Arrows { get; } = new List<FindRedArrowItem>();

		// Token: 0x170004D8 RID: 1240
		// (get) Token: 0x06000DBB RID: 3515 RVA: 0x0003FC81 File Offset: 0x0003DE81
		// (set) Token: 0x06000DBC RID: 3516 RVA: 0x0003FC89 File Offset: 0x0003DE89
		public int CandidateCount { get; set; }

		// Token: 0x170004D9 RID: 1241
		// (get) Token: 0x06000DBD RID: 3517 RVA: 0x0003FC92 File Offset: 0x0003DE92
		// (set) Token: 0x06000DBE RID: 3518 RVA: 0x0003FC9A File Offset: 0x0003DE9A
		public double SearchArea { get; set; }

		// Token: 0x170004DA RID: 1242
		// (get) Token: 0x06000DBF RID: 3519 RVA: 0x0003FCA3 File Offset: 0x0003DEA3
		// (set) Token: 0x06000DC0 RID: 3520 RVA: 0x0003FCAB File Offset: 0x0003DEAB
		public bool IsSpecEnabled { get; set; }

		// Token: 0x170004DB RID: 1243
		// (get) Token: 0x06000DC1 RID: 3521 RVA: 0x0003FCB4 File Offset: 0x0003DEB4
		// (set) Token: 0x06000DC2 RID: 3522 RVA: 0x0003FCBC File Offset: 0x0003DEBC
		public bool IsOk { get; set; } = true;

		// Token: 0x170004DC RID: 1244
		// (get) Token: 0x06000DC3 RID: 3523 RVA: 0x0003FCC5 File Offset: 0x0003DEC5
		// (set) Token: 0x06000DC4 RID: 3524 RVA: 0x0003FCCD File Offset: 0x0003DECD
		public string SpecStatus { get; set; } = "OK";

		// Token: 0x170004DD RID: 1245
		// (get) Token: 0x06000DC5 RID: 3525 RVA: 0x0003FCD6 File Offset: 0x0003DED6
		public List<string> SpecFailures { get; } = new List<string>();

		// Token: 0x170004DE RID: 1246
		// (get) Token: 0x06000DC6 RID: 3526 RVA: 0x0003FCDE File Offset: 0x0003DEDE
		public List<double[]> ArrowContourRows { get; } = new List<double[]>();

		// Token: 0x170004DF RID: 1247
		// (get) Token: 0x06000DC7 RID: 3527 RVA: 0x0003FCE6 File Offset: 0x0003DEE6
		public List<double[]> ArrowContourColumns { get; } = new List<double[]>();

		// Token: 0x170004E0 RID: 1248
		// (get) Token: 0x06000DC8 RID: 3528 RVA: 0x0003FCEE File Offset: 0x0003DEEE
		public List<double[]> ThresholdContourRows { get; } = new List<double[]>();

		// Token: 0x170004E1 RID: 1249
		// (get) Token: 0x06000DC9 RID: 3529 RVA: 0x0003FCF6 File Offset: 0x0003DEF6
		public List<double[]> ThresholdContourColumns { get; } = new List<double[]>();

		// Token: 0x170004E2 RID: 1250
		// (get) Token: 0x06000DCA RID: 3530 RVA: 0x0003FCFE File Offset: 0x0003DEFE
		// (set) Token: 0x06000DCB RID: 3531 RVA: 0x0003FD06 File Offset: 0x0003DF06
		public double ProcessingTimeMs { get; set; }

		// Token: 0x170004E3 RID: 1251
		// (get) Token: 0x06000DCC RID: 3532 RVA: 0x0003FD0F File Offset: 0x0003DF0F
		// (set) Token: 0x06000DCD RID: 3533 RVA: 0x0003FD17 File Offset: 0x0003DF17
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x170004E4 RID: 1252
		// (get) Token: 0x06000DCE RID: 3534 RVA: 0x0003FD20 File Offset: 0x0003DF20
		// (set) Token: 0x06000DCF RID: 3535 RVA: 0x0003FD28 File Offset: 0x0003DF28
		public string InputSourceToolName { get; set; }

		// Token: 0x170004E5 RID: 1253
		// (get) Token: 0x06000DD0 RID: 3536 RVA: 0x0003FD31 File Offset: 0x0003DF31
		// (set) Token: 0x06000DD1 RID: 3537 RVA: 0x0003FD39 File Offset: 0x0003DF39
		public double InputProcessingTimeMs { get; set; }
	}
}
