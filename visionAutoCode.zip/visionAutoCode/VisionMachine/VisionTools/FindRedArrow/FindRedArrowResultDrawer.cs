﻿using System;
using System.Collections.Generic;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindRedArrow
{
	// Token: 0x0200010D RID: 269
	public class FindRedArrowResultDrawer
	{
		// Token: 0x06000DD3 RID: 3539 RVA: 0x0003FDAC File Offset: 0x0003DFAC
		public void Draw(HWindow window, ToolVision tool, FindRedArrowResult result)
		{
			bool flag = window == null || tool == null || result == null;
			if (!flag)
			{
				FindRedArrowToolConfig config = tool.Config as FindRedArrowToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					bool showRoi = config.ShowRoi;
					if (showRoi)
					{
						ToolRoiOverlayDrawer.DrawRoiList(window, tool, tool.RoiItems, "cyan", 2);
					}
					bool showThresholdRegion = config.ShowThresholdRegion;
					if (showThresholdRegion)
					{
						this.DrawContours(window, result.ThresholdContourRows, result.ThresholdContourColumns, string.IsNullOrWhiteSpace(config.ThresholdColor) ? "yellow" : config.ThresholdColor, 1);
					}
					bool showArrows = config.ShowArrows;
					if (showArrows)
					{
						string arrowColor = string.IsNullOrWhiteSpace(config.ArrowColor) ? "red" : config.ArrowColor;
						this.DrawContours(window, result.ArrowContourRows, result.ArrowContourColumns, arrowColor, 3);
						this.DrawArrowBoxes(window, result, config, arrowColor);
					}
					bool showText = config.ShowText;
					if (showText)
					{
						this.DrawText(window, tool, result, config);
					}
				}
			}
		}

		// Token: 0x06000DD4 RID: 3540 RVA: 0x0003FEA8 File Offset: 0x0003E0A8
		private void DrawArrowBoxes(HWindow window, FindRedArrowResult result, FindRedArrowToolConfig config, string color)
		{
			bool flag = result.Arrows.Count == 0;
			if (!flag)
			{
				try
				{
					HOperatorSet.SetDraw(window, "margin");
					HOperatorSet.SetLineWidth(window, 5);
					HOperatorSet.SetFont(window, "Arial-" + Math.Max(8, config.TextSize).ToString());
				}
				catch (HOperatorException)
				{
					return;
				}
				foreach (FindRedArrowItem arrow in result.Arrows)
				{
					HObject box = null;
					try
					{
						HOperatorSet.SetColor(window, arrow.IsAreaOutOfSpec ? "magenta" : color);
						HOperatorSet.GenRectangle1(out box, arrow.BoxRow1, arrow.BoxColumn1, arrow.BoxRow2, arrow.BoxColumn2);
						HOperatorSet.DispObj(box, window);
						HOperatorSet.SetTposition(window, Math.Max(arrow.BoxRow1 - 55.0, 0.0), arrow.BoxColumn1);
						HOperatorSet.WriteString(window, string.Concat(new string[]
						{
							"RED ARROW ",
							arrow.Index.ToString(),
							"  Area=",
							arrow.Area.ToString("0"),
							arrow.IsAreaOutOfSpec ? "  OUT OF SPEC" : string.Empty
						}));
					}
					catch (HOperatorException)
					{
					}
					finally
					{
						if (box != null)
						{
							box.Dispose();
						}
					}
				}
			}
		}

		// Token: 0x06000DD5 RID: 3541 RVA: 0x000400F8 File Offset: 0x0003E2F8
		private void DrawContours(HWindow window, List<double[]> rows, List<double[]> columns, string color, int lineWidth)
		{
			bool flag = rows == null || columns == null || rows.Count == 0;
			if (!flag)
			{
				try
				{
					HOperatorSet.SetDraw(window, "margin");
					HOperatorSet.SetColor(window, color);
					HOperatorSet.SetLineWidth(window, lineWidth);
				}
				catch (HOperatorException)
				{
					return;
				}
				int i = 0;
				while (i < rows.Count && i < columns.Count)
				{
					double[] r = rows[i];
					double[] c = columns[i];
					bool flag2 = r == null || c == null || r.Length < 2 || r.Length != c.Length;
					if (!flag2)
					{
						HObject contour = null;
						try
						{
							HOperatorSet.GenContourPolygonXld(out contour, new HTuple(r), new HTuple(c));
							HOperatorSet.DispObj(contour, window);
						}
						catch (HOperatorException)
						{
						}
						finally
						{
							if (contour != null)
							{
								contour.Dispose();
							}
						}
					}
					i++;
				}
			}
		}

		// Token: 0x06000DD6 RID: 3542 RVA: 0x0004022C File Offset: 0x0003E42C
		private void DrawText(HWindow window, ToolVision tool, FindRedArrowResult result, FindRedArrowToolConfig config)
		{
			string status = (!result.IsSuccess) ? "ERROR" : (result.IsSpecEnabled ? result.SpecStatus : "OK");
			bool bad = !result.IsSuccess || string.Equals(status, "NG", StringComparison.OrdinalIgnoreCase);
			string text = string.Concat(new string[]
			{
				tool.Name ?? "Find Red Arrow",
				": ",
				status,
				"\nRed arrows: ",
				result.ArrowCount.ToString()
			});
			bool flag = result.ArrowCount > 0;
			if (flag)
			{
				text = string.Concat(new string[]
				{
					text,
					"\nLargest: ",
					result.MaxArea.ToString("0"),
					" px\nTotal: ",
					result.TotalArea.ToString("0"),
					" px"
				});
			}
			foreach (FindRedArrowItem arrow in result.Arrows)
			{
				text = string.Concat(new string[]
				{
					text,
					"\n  #",
					arrow.Index.ToString(),
					"  Row=",
					arrow.Row.ToString("0"),
					"  Col=",
					arrow.Column.ToString("0"),
					"  Area=",
					arrow.Area.ToString("0"),
					"  Mean=",
					arrow.MeanRedness.ToString("0")
				});
			}
			bool showThresholdRegion = config.ShowThresholdRegion;
			if (showThresholdRegion)
			{
				text = text + "\nPatches over threshold: " + result.CandidateCount.ToString();
			}
			foreach (string failure in result.SpecFailures)
			{
				text = text + "\n" + failure;
			}
			bool flag2 = !result.IsSuccess && !string.IsNullOrWhiteSpace(result.Message);
			if (flag2)
			{
				text = text + "\n" + result.Message;
			}
			try
			{
				HOperatorSet.SetFont(window, "Arial-" + Math.Max(8, config.TextSize).ToString());
			}
			catch (HOperatorException)
			{
			}
			try
			{
				HOperatorSet.SetColor(window, bad ? (string.IsNullOrWhiteSpace(config.ArrowColor) ? "red" : config.ArrowColor) : (string.IsNullOrWhiteSpace(config.TextColor) ? "lime" : config.TextColor));
				HOperatorSet.SetTposition(window, 24, 24);
				HOperatorSet.WriteString(window, text);
			}
			catch (HOperatorException)
			{
			}
		}
	}
}
