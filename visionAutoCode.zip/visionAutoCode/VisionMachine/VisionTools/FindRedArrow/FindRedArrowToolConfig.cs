﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.FindRedArrow
{
	// Token: 0x0200010E RID: 270
	public class FindRedArrowToolConfig : ToolConfigBase
	{
		// Token: 0x170004E6 RID: 1254
		// (get) Token: 0x06000DD8 RID: 3544 RVA: 0x00040594 File Offset: 0x0003E794
		// (set) Token: 0x06000DD9 RID: 3545 RVA: 0x000405C4 File Offset: 0x0003E7C4
		[Browsable(false)]
		public ImageInputLink InputLink
		{
			get
			{
				bool flag = this._inputLink == null;
				if (flag)
				{
					this._inputLink = new ImageInputLink();
				}
				return this._inputLink;
			}
			set
			{
				bool flag = this._inputLink != value;
				if (flag)
				{
					this._inputLink = (value ?? new ImageInputLink());
					base.OnPropertyChanged("InputLink");
				}
			}
		}

		// Token: 0x170004E7 RID: 1255
		// (get) Token: 0x06000DDA RID: 3546 RVA: 0x00040600 File Offset: 0x0003E800
		// (set) Token: 0x06000DDB RID: 3547 RVA: 0x00040608 File Offset: 0x0003E808
		[Category("Red Detection")]
		[DisplayName("Redness Threshold")]
		[Description("How much more red than green and blue a pixel must be to count as red: R - max(G, B). Lower it when a pale arrow is missed, raise it when a connector edge or a reflection is caught. Turn on Show Redness Image to see the values this is compared against.")]
		public double RedThreshold
		{
			get
			{
				return this._redThreshold;
			}
			set
			{
				double v = (value < 1.0) ? 1.0 : ((value > 255.0) ? 255.0 : value);
				bool flag = this._redThreshold != v;
				if (flag)
				{
					this._redThreshold = v;
					base.OnPropertyChanged("RedThreshold");
				}
			}
		}

		// Token: 0x170004E8 RID: 1256
		// (get) Token: 0x06000DDC RID: 3548 RVA: 0x0004066B File Offset: 0x0003E86B
		// (set) Token: 0x06000DDD RID: 3549 RVA: 0x00040674 File Offset: 0x0003E874
		[Category("Red Detection")]
		[DisplayName("Min Area (px)")]
		[Description("Smallest red patch that can be an arrow. This is the noise filter that separates the arrow from the colour fringe along a sharp edge - the fringe measured 746 px against the arrow's 2690 px. The size that decides OK from NG belongs in the Spec tab, not here.")]
		public double MinArea
		{
			get
			{
				return this._minArea;
			}
			set
			{
				double v = (value < 1.0) ? 1.0 : value;
				bool flag = this._minArea != v;
				if (flag)
				{
					this._minArea = v;
					base.OnPropertyChanged("MinArea");
				}
			}
		}

		// Token: 0x170004E9 RID: 1257
		// (get) Token: 0x06000DDE RID: 3550 RVA: 0x000406C0 File Offset: 0x0003E8C0
		// (set) Token: 0x06000DDF RID: 3551 RVA: 0x000406C8 File Offset: 0x0003E8C8
		[Category("Red Detection")]
		[DisplayName("Max Area (px)")]
		[Description("Largest red patch that can still be an arrow. Catches a whole red object, or a red-tinted background, that would otherwise be reported as one enormous arrow.")]
		public double MaxArea
		{
			get
			{
				return this._maxArea;
			}
			set
			{
				bool flag = this._maxArea != value;
				if (flag)
				{
					this._maxArea = value;
					base.OnPropertyChanged("MaxArea");
				}
			}
		}

		// Token: 0x170004EA RID: 1258
		// (get) Token: 0x06000DE0 RID: 3552 RVA: 0x000406FB File Offset: 0x0003E8FB
		// (set) Token: 0x06000DE1 RID: 3553 RVA: 0x00040704 File Offset: 0x0003E904
		[Category("Red Detection")]
		[DisplayName("Max Anisometry")]
		[Description("How long and thin a patch may be before it is dropped. An arrow is compact; a colour fringe running along an edge is a long thin streak, and this is what rejects it on shape alone.")]
		public double MaxAnisometry
		{
			get
			{
				return this._maxAnisometry;
			}
			set
			{
				double v = (value < 1.0) ? 1.0 : value;
				bool flag = this._maxAnisometry != v;
				if (flag)
				{
					this._maxAnisometry = v;
					base.OnPropertyChanged("MaxAnisometry");
				}
			}
		}

		// Token: 0x170004EB RID: 1259
		// (get) Token: 0x06000DE2 RID: 3554 RVA: 0x00040750 File Offset: 0x0003E950
		// (set) Token: 0x06000DE3 RID: 3555 RVA: 0x00040758 File Offset: 0x0003E958
		[Category("Red Detection")]
		[DisplayName("Min Mean Redness")]
		[Description("Average redness the whole patch must reach. The threshold alone only asks whether a pixel is red ENOUGH; this asks whether the patch is red THROUGHOUT. A fringe scrapes past the threshold on a few pixels but averages far lower, which is what makes this the most reliable of the filters. Set to 0 to switch it off.")]
		public double MinMeanRedness
		{
			get
			{
				return this._minMeanRedness;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._minMeanRedness != v;
				if (flag)
				{
					this._minMeanRedness = v;
					base.OnPropertyChanged("MinMeanRedness");
				}
			}
		}

		// Token: 0x170004EC RID: 1260
		// (get) Token: 0x06000DE4 RID: 3556 RVA: 0x000407A4 File Offset: 0x0003E9A4
		// (set) Token: 0x06000DE5 RID: 3557 RVA: 0x000407AC File Offset: 0x0003E9AC
		[Category("Red Detection")]
		[DisplayName("Close Radius (px)")]
		[Description("Fills the holes inside a patch, so an arrow broken up by a highlight is measured as one object rather than several small ones.")]
		public double CloseRadius
		{
			get
			{
				return this._closeRadius;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._closeRadius != v;
				if (flag)
				{
					this._closeRadius = v;
					base.OnPropertyChanged("CloseRadius");
				}
			}
		}

		// Token: 0x170004ED RID: 1261
		// (get) Token: 0x06000DE6 RID: 3558 RVA: 0x000407F8 File Offset: 0x0003E9F8
		// (set) Token: 0x06000DE7 RID: 3559 RVA: 0x00040800 File Offset: 0x0003EA00
		[Category("Red Detection")]
		[DisplayName("Open Radius (px)")]
		[Description("Removes isolated red specks left by sensor noise and JPEG artefacts before the patches are measured.")]
		public double OpenRadius
		{
			get
			{
				return this._openRadius;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._openRadius != v;
				if (flag)
				{
					this._openRadius = v;
					base.OnPropertyChanged("OpenRadius");
				}
			}
		}

		// Token: 0x170004EE RID: 1262
		// (get) Token: 0x06000DE8 RID: 3560 RVA: 0x0004084C File Offset: 0x0003EA4C
		// (set) Token: 0x06000DE9 RID: 3561 RVA: 0x00040854 File Offset: 0x0003EA54
		[Category("Display")]
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				bool flag = this._showRoi != value;
				if (flag)
				{
					this._showRoi = value;
					base.OnPropertyChanged("ShowRoi");
				}
			}
		}

		// Token: 0x170004EF RID: 1263
		// (get) Token: 0x06000DEA RID: 3562 RVA: 0x00040887 File Offset: 0x0003EA87
		// (set) Token: 0x06000DEB RID: 3563 RVA: 0x00040890 File Offset: 0x0003EA90
		[Category("Display")]
		[DisplayName("Show Redness Image")]
		[Description("Shows the redness image instead of the photo on a Trial Run: red areas appear bright, everything else near black. This is how the threshold is set - read the brightness of the arrow off the picture and put the threshold below it. Affects the Trial Run view only; the image passed to the next tool never changes.")]
		public bool ShowRednessImage
		{
			get
			{
				return this._showRednessImage;
			}
			set
			{
				bool flag = this._showRednessImage != value;
				if (flag)
				{
					this._showRednessImage = value;
					base.OnPropertyChanged("ShowRednessImage");
				}
			}
		}

		// Token: 0x170004F0 RID: 1264
		// (get) Token: 0x06000DEC RID: 3564 RVA: 0x000408C3 File Offset: 0x0003EAC3
		// (set) Token: 0x06000DED RID: 3565 RVA: 0x000408CC File Offset: 0x0003EACC
		[Category("Display")]
		[DisplayName("Show Threshold Region")]
		[Description("Outlines everything the threshold caught, before the area, shape and mean filters ran. Turn it on together with Show Redness Image to see which of the filters is rejecting a patch you expected to keep.")]
		public bool ShowThresholdRegion
		{
			get
			{
				return this._showThresholdRegion;
			}
			set
			{
				bool flag = this._showThresholdRegion != value;
				if (flag)
				{
					this._showThresholdRegion = value;
					base.OnPropertyChanged("ShowThresholdRegion");
				}
			}
		}

		// Token: 0x170004F1 RID: 1265
		// (get) Token: 0x06000DEE RID: 3566 RVA: 0x000408FF File Offset: 0x0003EAFF
		// (set) Token: 0x06000DEF RID: 3567 RVA: 0x00040908 File Offset: 0x0003EB08
		[Category("Display")]
		[DisplayName("Show Arrows")]
		public bool ShowArrows
		{
			get
			{
				return this._showArrows;
			}
			set
			{
				bool flag = this._showArrows != value;
				if (flag)
				{
					this._showArrows = value;
					base.OnPropertyChanged("ShowArrows");
				}
			}
		}

		// Token: 0x170004F2 RID: 1266
		// (get) Token: 0x06000DF0 RID: 3568 RVA: 0x0004093B File Offset: 0x0003EB3B
		// (set) Token: 0x06000DF1 RID: 3569 RVA: 0x00040944 File Offset: 0x0003EB44
		[Category("Display")]
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				bool flag = this._showText != value;
				if (flag)
				{
					this._showText = value;
					base.OnPropertyChanged("ShowText");
				}
			}
		}

		// Token: 0x170004F3 RID: 1267
		// (get) Token: 0x06000DF2 RID: 3570 RVA: 0x00040977 File Offset: 0x0003EB77
		// (set) Token: 0x06000DF3 RID: 3571 RVA: 0x00040980 File Offset: 0x0003EB80
		[Category("Display")]
		[DisplayName("Arrow Color")]
		public string ArrowColor
		{
			get
			{
				return this._arrowColor;
			}
			set
			{
				bool flag = this._arrowColor != value;
				if (flag)
				{
					this._arrowColor = value;
					base.OnPropertyChanged("ArrowColor");
				}
			}
		}

		// Token: 0x170004F4 RID: 1268
		// (get) Token: 0x06000DF4 RID: 3572 RVA: 0x000409B3 File Offset: 0x0003EBB3
		// (set) Token: 0x06000DF5 RID: 3573 RVA: 0x000409BC File Offset: 0x0003EBBC
		[Category("Display")]
		[DisplayName("Threshold Color")]
		public string ThresholdColor
		{
			get
			{
				return this._thresholdColor;
			}
			set
			{
				bool flag = this._thresholdColor != value;
				if (flag)
				{
					this._thresholdColor = value;
					base.OnPropertyChanged("ThresholdColor");
				}
			}
		}

		// Token: 0x170004F5 RID: 1269
		// (get) Token: 0x06000DF6 RID: 3574 RVA: 0x000409EF File Offset: 0x0003EBEF
		// (set) Token: 0x06000DF7 RID: 3575 RVA: 0x000409F8 File Offset: 0x0003EBF8
		[Category("Display")]
		[DisplayName("Text Color")]
		public string TextColor
		{
			get
			{
				return this._textColor;
			}
			set
			{
				bool flag = this._textColor != value;
				if (flag)
				{
					this._textColor = value;
					base.OnPropertyChanged("TextColor");
				}
			}
		}

		// Token: 0x170004F6 RID: 1270
		// (get) Token: 0x06000DF8 RID: 3576 RVA: 0x00040A2B File Offset: 0x0003EC2B
		// (set) Token: 0x06000DF9 RID: 3577 RVA: 0x00040A34 File Offset: 0x0003EC34
		[Category("Display")]
		[DisplayName("Text Size")]
		public int TextSize
		{
			get
			{
				return this._textSize;
			}
			set
			{
				int v = (value < 8) ? 8 : value;
				bool flag = this._textSize != v;
				if (flag)
				{
					this._textSize = v;
					base.OnPropertyChanged("TextSize");
				}
			}
		}

		// Token: 0x170004F7 RID: 1271
		// (get) Token: 0x06000DFA RID: 3578 RVA: 0x00040A70 File Offset: 0x0003EC70
		// (set) Token: 0x06000DFB RID: 3579 RVA: 0x00040A78 File Offset: 0x0003EC78
		[Category("Display")]
		[DisplayName("Box Margin (px)")]
		[Description("How far outside an arrow its box is drawn. A box drawn tight on a small mark is easy to miss on a busy image.")]
		public double BoxMargin
		{
			get
			{
				return this._boxMargin;
			}
			set
			{
				double v = (value < 0.0) ? 0.0 : value;
				bool flag = this._boxMargin != v;
				if (flag)
				{
					this._boxMargin = v;
					base.OnPropertyChanged("BoxMargin");
				}
			}
		}

		// Token: 0x040005A4 RID: 1444
		private ImageInputLink _inputLink = new ImageInputLink();

		// Token: 0x040005A5 RID: 1445
		private double _redThreshold = 110.0;

		// Token: 0x040005A6 RID: 1446
		private double _minArea = 1500.0;

		// Token: 0x040005A7 RID: 1447
		private double _maxArea = 200000.0;

		// Token: 0x040005A8 RID: 1448
		private double _maxAnisometry = 6.0;

		// Token: 0x040005A9 RID: 1449
		private double _minMeanRedness = 135.0;

		// Token: 0x040005AA RID: 1450
		private double _closeRadius = 7.5;

		// Token: 0x040005AB RID: 1451
		private double _openRadius = 3.5;

		// Token: 0x040005AC RID: 1452
		private bool _showRoi = true;

		// Token: 0x040005AD RID: 1453
		private bool _showRednessImage;

		// Token: 0x040005AE RID: 1454
		private bool _showThresholdRegion;

		// Token: 0x040005AF RID: 1455
		private bool _showArrows = true;

		// Token: 0x040005B0 RID: 1456
		private bool _showText = true;

		// Token: 0x040005B1 RID: 1457
		private string _arrowColor = "red";

		// Token: 0x040005B2 RID: 1458
		private string _thresholdColor = "yellow";

		// Token: 0x040005B3 RID: 1459
		private string _textColor = "lime";

		// Token: 0x040005B4 RID: 1460
		private int _textSize = 16;

		// Token: 0x040005B5 RID: 1461
		private double _boxMargin = 60.0;
	}
}
