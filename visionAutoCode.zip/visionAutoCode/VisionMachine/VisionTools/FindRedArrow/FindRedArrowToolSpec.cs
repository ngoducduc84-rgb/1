﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.FindRedArrow
{
	// Token: 0x0200010F RID: 271
	public class FindRedArrowToolSpec : ToolSpecBase
	{
		// Token: 0x170004F8 RID: 1272
		// (get) Token: 0x06000DFD RID: 3581 RVA: 0x00040B99 File Offset: 0x0003ED99
		// (set) Token: 0x06000DFE RID: 3582 RVA: 0x00040BA4 File Offset: 0x0003EDA4
		[Category("Arrow Count")]
		[DisplayName("Check Arrow Count")]
		public bool CountEnabled
		{
			get
			{
				return this._countEnabled;
			}
			set
			{
				bool flag = this._countEnabled != value;
				if (flag)
				{
					this._countEnabled = value;
					base.OnPropertyChanged("CountEnabled");
				}
			}
		}

		// Token: 0x170004F9 RID: 1273
		// (get) Token: 0x06000DFF RID: 3583 RVA: 0x00040BD7 File Offset: 0x0003EDD7
		// (set) Token: 0x06000E00 RID: 3584 RVA: 0x00040BE0 File Offset: 0x0003EDE0
		[Category("Arrow Count")]
		[DisplayName("Count Min")]
		[Description("Fewest arrows a good image may hold. Leave at 0 to treat any arrow as a defect; set it to 1 when the arrow is a marking that has to be present.")]
		public double CountMin
		{
			get
			{
				return this._countMin;
			}
			set
			{
				bool flag = this._countMin != value;
				if (flag)
				{
					this._countMin = value;
					base.OnPropertyChanged("CountMin");
				}
			}
		}

		// Token: 0x170004FA RID: 1274
		// (get) Token: 0x06000E01 RID: 3585 RVA: 0x00040C13 File Offset: 0x0003EE13
		// (set) Token: 0x06000E02 RID: 3586 RVA: 0x00040C1C File Offset: 0x0003EE1C
		[Category("Arrow Count")]
		[DisplayName("Count Max")]
		[Description("Most arrows a good image may hold. 0 refuses every one of them, which is the reference program's rule.")]
		public double CountMax
		{
			get
			{
				return this._countMax;
			}
			set
			{
				bool flag = this._countMax != value;
				if (flag)
				{
					this._countMax = value;
					base.OnPropertyChanged("CountMax");
				}
			}
		}

		// Token: 0x170004FB RID: 1275
		// (get) Token: 0x06000E03 RID: 3587 RVA: 0x00040C4F File Offset: 0x0003EE4F
		// (set) Token: 0x06000E04 RID: 3588 RVA: 0x00040C58 File Offset: 0x0003EE58
		[Category("Arrow Area")]
		[DisplayName("Check Arrow Area")]
		[Description("Judges EVERY arrow found: one outside the band makes the image NG and that arrow is marked in the overlay. Only meaningful once the count band allows an arrow to exist at all.")]
		public bool AreaEnabled
		{
			get
			{
				return this._areaEnabled;
			}
			set
			{
				bool flag = this._areaEnabled != value;
				if (flag)
				{
					this._areaEnabled = value;
					base.OnPropertyChanged("AreaEnabled");
				}
			}
		}

		// Token: 0x170004FC RID: 1276
		// (get) Token: 0x06000E05 RID: 3589 RVA: 0x00040C8B File Offset: 0x0003EE8B
		// (set) Token: 0x06000E06 RID: 3590 RVA: 0x00040C94 File Offset: 0x0003EE94
		[Category("Arrow Area")]
		[DisplayName("Area Min (px)")]
		[Description("Smallest acceptable arrow, in image pixels. Starts at the same value as the Min Area filter, so nothing that got through the filter is refused here until you tighten it.")]
		public double AreaMin
		{
			get
			{
				return this._areaMin;
			}
			set
			{
				bool flag = this._areaMin != value;
				if (flag)
				{
					this._areaMin = value;
					base.OnPropertyChanged("AreaMin");
				}
			}
		}

		// Token: 0x170004FD RID: 1277
		// (get) Token: 0x06000E07 RID: 3591 RVA: 0x00040CC7 File Offset: 0x0003EEC7
		// (set) Token: 0x06000E08 RID: 3592 RVA: 0x00040CD0 File Offset: 0x0003EED0
		[Category("Arrow Area")]
		[DisplayName("Area Max (px)")]
		[Description("Largest acceptable arrow, in image pixels.")]
		public double AreaMax
		{
			get
			{
				return this._areaMax;
			}
			set
			{
				bool flag = this._areaMax != value;
				if (flag)
				{
					this._areaMax = value;
					base.OnPropertyChanged("AreaMax");
				}
			}
		}

		// Token: 0x040005B6 RID: 1462
		private bool _countEnabled = true;

		// Token: 0x040005B7 RID: 1463
		private double _countMin;

		// Token: 0x040005B8 RID: 1464
		private double _countMax;

		// Token: 0x040005B9 RID: 1465
		private bool _areaEnabled = true;

		// Token: 0x040005BA RID: 1466
		private double _areaMin = 1500.0;

		// Token: 0x040005BB RID: 1467
		private double _areaMax = 200000.0;
	}
}
