﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.FindRedArrow.Views
{
	// Token: 0x02000110 RID: 272
	public partial class FindRedArrow_para : UserControl
	{
		// Token: 0x06000E0A RID: 3594 RVA: 0x00040D38 File Offset: 0x0003EF38
		public FindRedArrow_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000E0B RID: 3595 RVA: 0x00040D49 File Offset: 0x0003EF49
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.FindRedArrowTrialRun();
			}
		}
	}
}
