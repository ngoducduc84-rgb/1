﻿using System;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.Histogram
{
	// Token: 0x0200005A RID: 90
	public class HistogramActionService : IToolActionService
	{
		// Token: 0x17000155 RID: 341
		// (get) Token: 0x060003F8 RID: 1016 RVA: 0x00014584 File Offset: 0x00012784
		public ToolType ToolType
		{
			get
			{
				return ToolType.Histogram;
			}
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x00014598 File Offset: 0x00012798
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				HistogramProcessResult histogramResult = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (!flag2)
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						string inputSourceToolName = this.GetInputSourceToolName(tool);
						Stopwatch inputStopwatch = Stopwatch.StartNew();
						input = this._pipelineService.BuildInputImageForTool(processContext, tool);
						inputStopwatch.Stop();
						double inputProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds;
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							bool flag4 = input != null;
							if (flag4)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						this.EnsureFullDomainImage(ref input);
						HistogramToolConfig config = tool.Config as HistogramToolConfig;
						bool flag5 = config != null && config.ShowInputImage;
						if (flag5)
						{
							context.DisplayController.DisplayImage(input);
						}
						else
						{
							histogramResult = this._processor.Run(input, tool);
							histogramResult.InputSourceToolName = inputSourceToolName;
							histogramResult.InputProcessingTimeMs = inputProcessingTimeMs;
							bool flag6 = histogramResult.SourceImage != null && histogramResult.SourceImage.IsInitialized();
							if (flag6)
							{
								context.DisplayController.DisplayImage(histogramResult.SourceImage);
							}
							else
							{
								context.DisplayController.DisplayImage(input);
							}
							bool flag7 = histogramResult != null && histogramResult.IsSuccess;
							if (flag7)
							{
								Action<ToolVision, object> resultReporter = context.ResultReporter;
								if (resultReporter != null)
								{
									resultReporter(tool, histogramResult);
								}
								HistogramProcessResult overlayResult = histogramResult;
								histogramResult = null;
								context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
								{
									this._drawer.Draw(window, tool, overlayResult);
								}, overlayResult);
							}
						}
					}
				}
				finally
				{
					if (histogramResult != null)
					{
						histogramResult.Dispose();
					}
					if (input != null)
					{
						input.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					if (original != null)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x0001482C File Offset: 0x00012A2C
		private void EnsureFullDomainImage(ref HObject image)
		{
			bool flag = image == null || !image.IsInitialized();
			if (!flag)
			{
				HObject fullDomainImage;
				HOperatorSet.FullDomain(image, out fullDomainImage);
				image.Dispose();
				image = fullDomainImage;
			}
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x00014868 File Offset: 0x00012A68
		private string GetInputSourceToolName(ToolVision tool)
		{
			ToolVision tool2 = tool;
			HistogramToolConfig config = ((tool2 != null) ? tool2.Config : null) as HistogramToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						TurnSnap parentTurnSnap = tool.ParentTurnSnap;
						ToolVision previousTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).LastOrDefault<ToolVision>() : null;
						result = ((previousTool == null) ? "PreviousToolOutput" : previousTool.Name);
					}
					else
					{
						result = "Unknown";
					}
				}
			}
			return result;
		}

		// Token: 0x040001A0 RID: 416
		private readonly HistogramProcessor _processor = new HistogramProcessor();

		// Token: 0x040001A1 RID: 417
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();

		// Token: 0x040001A2 RID: 418
		private readonly HistogramResultDrawer _drawer = new HistogramResultDrawer();
	}
}
