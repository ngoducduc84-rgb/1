﻿using System;

namespace VisionMachine.VisionTools.Histogram
{
	// Token: 0x0200005D RID: 93
	public class HistogramMasterRuntimeInfo
	{
		// Token: 0x1700016A RID: 362
		// (get) Token: 0x0600042A RID: 1066 RVA: 0x00014D0A File Offset: 0x00012F0A
		// (set) Token: 0x0600042B RID: 1067 RVA: 0x00014D12 File Offset: 0x00012F12
		public string ToolName { get; set; }

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x0600042C RID: 1068 RVA: 0x00014D1B File Offset: 0x00012F1B
		// (set) Token: 0x0600042D RID: 1069 RVA: 0x00014D23 File Offset: 0x00012F23
		public bool IsLinked { get; set; }

		// Token: 0x1700016C RID: 364
		// (get) Token: 0x0600042E RID: 1070 RVA: 0x00014D2C File Offset: 0x00012F2C
		// (set) Token: 0x0600042F RID: 1071 RVA: 0x00014D34 File Offset: 0x00012F34
		public bool IsFound { get; set; }

		// Token: 0x1700016D RID: 365
		// (get) Token: 0x06000430 RID: 1072 RVA: 0x00014D3D File Offset: 0x00012F3D
		// (set) Token: 0x06000431 RID: 1073 RVA: 0x00014D45 File Offset: 0x00012F45
		public double ProcessingTimeMs { get; set; }
	}
}
