﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.Histogram
{
	// Token: 0x0200005B RID: 91
	public class HistogramParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x17000156 RID: 342
		// (get) Token: 0x060003FD RID: 1021 RVA: 0x00014980 File Offset: 0x00012B80
		// (set) Token: 0x060003FE RID: 1022 RVA: 0x00014988 File Offset: 0x00012B88
		public HistogramToolConfig Config { get; set; }

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x060003FF RID: 1023 RVA: 0x00014991 File Offset: 0x00012B91
		// (set) Token: 0x06000400 RID: 1024 RVA: 0x00014999 File Offset: 0x00012B99
		public HistogramToolSpec Spec { get; set; }

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x06000401 RID: 1025 RVA: 0x000149A2 File Offset: 0x00012BA2
		// (set) Token: 0x06000402 RID: 1026 RVA: 0x000149AA File Offset: 0x00012BAA
		public ToolVision Tool { get; set; }

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x06000403 RID: 1027 RVA: 0x000149B3 File Offset: 0x00012BB3
		// (set) Token: 0x06000404 RID: 1028 RVA: 0x000149BB File Offset: 0x00012BBB
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x1700015A RID: 346
		// (get) Token: 0x06000405 RID: 1029 RVA: 0x000149C4 File Offset: 0x00012BC4
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x1700015B RID: 347
		// (get) Token: 0x06000406 RID: 1030 RVA: 0x000149E0 File Offset: 0x00012BE0
		// (set) Token: 0x06000407 RID: 1031 RVA: 0x000149F8 File Offset: 0x00012BF8
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool == value;
				if (!flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.Config != null && this.Config.InputLink != null;
					if (flag2)
					{
						bool flag3 = this._selectedSourceTool != null;
						if (flag3)
						{
							this.Config.InputLink.SourceToolId = null;
							this.Config.InputLink.SourceToolName = this._selectedSourceTool.ToolName;
						}
						else
						{
							this.Config.InputLink.SourceToolId = null;
							this.Config.InputLink.SourceToolName = null;
						}
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x06000408 RID: 1032 RVA: 0x00014AB0 File Offset: 0x00012CB0
		// (remove) Token: 0x06000409 RID: 1033 RVA: 0x00014AE8 File Offset: 0x00012CE8
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x0600040A RID: 1034 RVA: 0x00014B1D File Offset: 0x00012D1D
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x00014B3C File Offset: 0x00012D3C
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.Config == null || this.Config.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.Config.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.Config.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.Config.InputLink.SourceToolId = null;
				this.Config.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x040001A3 RID: 419
		private ToolImageSourceOption _selectedSourceTool;
	}
}
