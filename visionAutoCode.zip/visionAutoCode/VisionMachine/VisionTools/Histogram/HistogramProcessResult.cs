﻿using System;
using System.Collections.Generic;
using HalconDotNet;

namespace VisionMachine.VisionTools.Histogram
{
	// Token: 0x0200005E RID: 94
	public class HistogramProcessResult : IDisposable
	{
		// Token: 0x1700016E RID: 366
		// (get) Token: 0x06000433 RID: 1075 RVA: 0x00014D4E File Offset: 0x00012F4E
		// (set) Token: 0x06000434 RID: 1076 RVA: 0x00014D56 File Offset: 0x00012F56
		public bool IsSuccess { get; set; }

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x06000435 RID: 1077 RVA: 0x00014D5F File Offset: 0x00012F5F
		// (set) Token: 0x06000436 RID: 1078 RVA: 0x00014D67 File Offset: 0x00012F67
		public HObject SourceImage { get; set; }

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x06000437 RID: 1079 RVA: 0x00014D70 File Offset: 0x00012F70
		// (set) Token: 0x06000438 RID: 1080 RVA: 0x00014D78 File Offset: 0x00012F78
		public bool IsOk { get; set; }

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x06000439 RID: 1081 RVA: 0x00014D81 File Offset: 0x00012F81
		// (set) Token: 0x0600043A RID: 1082 RVA: 0x00014D89 File Offset: 0x00012F89
		public double TotalValue { get; set; }

		// Token: 0x17000172 RID: 370
		// (get) Token: 0x0600043B RID: 1083 RVA: 0x00014D92 File Offset: 0x00012F92
		// (set) Token: 0x0600043C RID: 1084 RVA: 0x00014D9A File Offset: 0x00012F9A
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x0600043D RID: 1085 RVA: 0x00014DA3 File Offset: 0x00012FA3
		// (set) Token: 0x0600043E RID: 1086 RVA: 0x00014DAB File Offset: 0x00012FAB
		public string InputSourceToolName { get; set; }

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x0600043F RID: 1087 RVA: 0x00014DB4 File Offset: 0x00012FB4
		// (set) Token: 0x06000440 RID: 1088 RVA: 0x00014DBC File Offset: 0x00012FBC
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x06000441 RID: 1089 RVA: 0x00014DC5 File Offset: 0x00012FC5
		// (set) Token: 0x06000442 RID: 1090 RVA: 0x00014DCD File Offset: 0x00012FCD
		public string Message { get; set; }

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x06000443 RID: 1091 RVA: 0x00014DD6 File Offset: 0x00012FD6
		// (set) Token: 0x06000444 RID: 1092 RVA: 0x00014DDE File Offset: 0x00012FDE
		public List<HistogramRoiResult> RoiResults { get; set; } = new List<HistogramRoiResult>();

		// Token: 0x06000445 RID: 1093 RVA: 0x00014DE8 File Offset: 0x00012FE8
		public void Dispose()
		{
			HObject sourceImage = this.SourceImage;
			if (sourceImage != null)
			{
				sourceImage.Dispose();
			}
			foreach (HistogramRoiResult item in this.RoiResults)
			{
				HObject roiObject = item.RoiObject;
				if (roiObject != null)
				{
					roiObject.Dispose();
				}
				HObject displayRoiObject = item.DisplayRoiObject;
				if (displayRoiObject != null)
				{
					displayRoiObject.Dispose();
				}
				HObject thresholdObject = item.ThresholdObject;
				if (thresholdObject != null)
				{
					thresholdObject.Dispose();
				}
			}
		}
	}
}
