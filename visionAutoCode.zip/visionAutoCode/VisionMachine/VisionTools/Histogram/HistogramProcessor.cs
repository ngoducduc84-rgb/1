﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.Histogram
{
	// Token: 0x0200005F RID: 95
	public class HistogramProcessor : IToolProcessor
	{
		// Token: 0x06000447 RID: 1095 RVA: 0x00014E98 File Offset: 0x00013098
		public HistogramProcessor() : this(null)
		{
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x00014EA3 File Offset: 0x000130A3
		public HistogramProcessor(IDictionary<string, ShapeMatchResult> cachedMasterResults)
		{
			this._cachedMasterResults = cachedMasterResults;
		}

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x06000449 RID: 1097 RVA: 0x00014EB4 File Offset: 0x000130B4
		public ToolType ToolType
		{
			get
			{
				return ToolType.Histogram;
			}
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x00014EC8 File Offset: 0x000130C8
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			ToolProcessResult processResult = new ToolProcessResult();
			bool flag = context == null || context.InputImage == null;
			ToolProcessResult result;
			if (flag)
			{
				processResult.IsSuccess = false;
				processResult.Message = "Input image null.";
				result = processResult;
			}
			else
			{
				HistogramProcessResult histogramResult = this.Run(context.InputImage, tool);
				processResult.IsSuccess = histogramResult.IsSuccess;
				processResult.Message = histogramResult.Message;
				processResult.Data = histogramResult;
				HObject copy;
				HOperatorSet.CopyImage(context.InputImage, out copy);
				context.OutputImage = copy;
				result = processResult;
			}
			return result;
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x00014F58 File Offset: 0x00013158
		public HistogramProcessResult Run(HObject image, ToolVision tool)
		{
			HistogramProcessResult result = new HistogramProcessResult();
			Stopwatch totalStopwatch = Stopwatch.StartNew();
			bool flag = image == null || !image.IsInitialized() || tool == null;
			HistogramProcessResult result2;
			if (flag)
			{
				result.Message = "Histogram input invalid.";
				result2 = result;
			}
			else
			{
				HistogramToolConfig config = tool.Config as HistogramToolConfig;
				HistogramToolSpec spec = tool.Spec as HistogramToolSpec;
				bool flag2 = config == null || spec == null;
				if (flag2)
				{
					result.Message = "Histogram config/spec null.";
					result2 = result;
				}
				else
				{
					bool flag3 = !config.IsEnabled;
					if (flag3)
					{
						result.Message = "Histogram tool is disabled.";
						result2 = result;
					}
					else
					{
						bool flag4 = tool.RoiItems == null || tool.RoiItems.Count == 0;
						if (flag4)
						{
							result.Message = "Histogram has no ROI.";
							result2 = result;
						}
						else
						{
							this._currentMasterRuntimeInfo = this.UpdateMasterShapeModels(image, tool);
							HObject processImage = null;
							HObject grayImage = null;
							try
							{
								processImage = this.CreateMaskAppliedImage(image, tool);
								HObject sourceCopy;
								HOperatorSet.CopyImage(processImage, out sourceCopy);
								result.SourceImage = sourceCopy;
								grayImage = this.CreateGrayImage(processImage);
								foreach (RoiData roi in from x in tool.RoiItems
								where x.IsEnabled
								select x)
								{
									Stopwatch roiStopwatch = Stopwatch.StartNew();
									HObject roiObject = null;
									HObject displayRoiObject = null;
									HObject reduceImage = null;
									HObject thresholdRegion = null;
									try
									{
										roiObject = this.GenRegionFromRoi(roi, tool, grayImage, true);
										displayRoiObject = this.GenRegionFromRoi(roi, tool, grayImage, false);
										bool flag5 = roiObject == null || !roiObject.IsInitialized();
										if (!flag5)
										{
											HTuple roiArea;
											HTuple roiCenterRow;
											HTuple roiCenterColumn;
											HOperatorSet.AreaCenter(roiObject, out roiArea, out roiCenterRow, out roiCenterColumn);
											double totalPixels = (roiArea.Length > 0) ? roiArea.TupleSum().D : 0.0;
											bool flag6 = totalPixels <= 0.0;
											if (!flag6)
											{
												HOperatorSet.ReduceDomain(grayImage, roiObject, out reduceImage);
												HOperatorSet.Threshold(reduceImage, out thresholdRegion, config.GrayMin, config.GrayMax);
												HTuple selectedArea;
												HTuple selectedRow;
												HTuple selectedColumn;
												HOperatorSet.AreaCenter(thresholdRegion, out selectedArea, out selectedRow, out selectedColumn);
												double selectedPixels = (selectedArea.Length > 0) ? selectedArea.TupleSum().D : 0.0;
												double value = selectedPixels / totalPixels * 100.0;
												double labelRow = (selectedRow.Length > 0) ? selectedRow.TupleMean().D : ((roiCenterRow.Length > 0) ? roiCenterRow.TupleMean().D : this.GetFallbackRow(roi));
												double labelColumn = (selectedColumn.Length > 0) ? selectedColumn.TupleMean().D : ((roiCenterColumn.Length > 0) ? roiCenterColumn.TupleMean().D : this.GetFallbackColumn(roi));
												HObject roiCopy;
												HOperatorSet.CopyObj(roiObject, out roiCopy, 1, -1);
												bool flag7 = displayRoiObject != null && displayRoiObject.IsInitialized();
												HObject displayRoiCopy;
												if (flag7)
												{
													HOperatorSet.CopyObj(displayRoiObject, out displayRoiCopy, 1, -1);
												}
												else
												{
													HOperatorSet.CopyObj(roiObject, out displayRoiCopy, 1, -1);
												}
												HObject thresholdCopy;
												HOperatorSet.CopyObj(thresholdRegion, out thresholdCopy, 1, -1);
												string masterPositionToolName = this.GetMasterPositionToolName(roi);
												string masterAngleToolName = this.GetMasterAngleToolName(roi);
												roiStopwatch.Stop();
												result.RoiResults.Add(new HistogramRoiResult
												{
													Roi = roi,
													Value = value,
													SelectedPixelCount = selectedPixels,
													TotalPixelCount = totalPixels,
													LabelRow = labelRow,
													LabelColumn = labelColumn,
													RoiObject = roiCopy,
													DisplayRoiObject = displayRoiCopy,
													ThresholdObject = thresholdCopy,
													ProcessingTimeMs = roiStopwatch.Elapsed.TotalMilliseconds,
													MasterPositionToolName = masterPositionToolName,
													MasterAngleToolName = masterAngleToolName,
													MasterStatus = this.GetMasterStatus(masterPositionToolName, masterAngleToolName),
													MasterProcessingTimeMs = this.GetMasterProcessingTime(masterPositionToolName, masterAngleToolName)
												});
												result.TotalValue += value;
											}
										}
									}
									finally
									{
										bool isRunning = roiStopwatch.IsRunning;
										if (isRunning)
										{
											roiStopwatch.Stop();
										}
										if (roiObject != null)
										{
											roiObject.Dispose();
										}
										if (displayRoiObject != null)
										{
											displayRoiObject.Dispose();
										}
										if (reduceImage != null)
										{
											reduceImage.Dispose();
										}
										if (thresholdRegion != null)
										{
											thresholdRegion.Dispose();
										}
									}
								}
							}
							finally
							{
								if (grayImage != null)
								{
									grayImage.Dispose();
								}
								if (processImage != null)
								{
									processImage.Dispose();
								}
								this._currentMasterRuntimeInfo = null;
							}
							result.IsOk = (result.TotalValue >= spec.MinimumSize && result.TotalValue <= spec.MaximumSize);
							totalStopwatch.Stop();
							result.TotalProcessingTimeMs = totalStopwatch.Elapsed.TotalMilliseconds;
							result.IsSuccess = true;
							result.Message = (result.IsOk ? "Histogram OK." : "Histogram NG.");
							result2 = result;
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x000154CC File Offset: 0x000136CC
		private HObject CreateGrayImage(HObject image)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject result;
			if (flag)
			{
				HObject grayImage;
				HOperatorSet.Rgb1ToGray(image, out grayImage);
				result = grayImage;
			}
			else
			{
				HObject grayImage;
				HOperatorSet.CopyImage(image, out grayImage);
				result = grayImage;
			}
			return result;
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x00015524 File Offset: 0x00013724
		private HObject CreateMaskAppliedImage(HObject image, ToolVision tool)
		{
			HObject current;
			HOperatorSet.CopyImage(image, out current);
			bool flag = ((tool != null) ? tool.MaskRoiItems : null) == null || tool.MaskRoiItems.Count == 0;
			HObject result;
			if (flag)
			{
				result = current;
			}
			else
			{
				foreach (RoiData maskRoi in from x in tool.MaskRoiItems
				where x.IsEnabled && x.RoiType != RoiType.Line
				select x)
				{
					HObject maskRegion = null;
					HObject painted = null;
					try
					{
						maskRegion = this.GenRegionFromRoi(maskRoi, tool, current, true);
						bool flag2 = maskRegion == null || !maskRegion.IsInitialized();
						if (!flag2)
						{
							double grayValue = (double)((maskRoi.Polarity == RoiPolarity.Positive) ? 255 : 0);
							painted = this.PaintRegionToImage(current, maskRegion, grayValue);
							current.Dispose();
							current = painted;
							painted = null;
						}
					}
					finally
					{
						if (maskRegion != null)
						{
							maskRegion.Dispose();
						}
						if (painted != null)
						{
							painted.Dispose();
						}
					}
				}
				result = current;
			}
			return result;
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x00015660 File Offset: 0x00013860
		private HObject PaintRegionToImage(HObject image, HObject region, double grayValue)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject result;
			if (flag)
			{
				result = this.PaintRegionToRgbImage(image, region, grayValue);
			}
			else
			{
				HObject painted;
				HOperatorSet.PaintRegion(region, image, out painted, grayValue, "fill");
				result = painted;
			}
			return result;
		}

		// Token: 0x0600044F RID: 1103 RVA: 0x000156C4 File Offset: 0x000138C4
		private HObject PaintRegionToRgbImage(HObject image, HObject region, double grayValue)
		{
			HObject red = null;
			HObject green = null;
			HObject blue = null;
			HObject paintedRed = null;
			HObject paintedGreen = null;
			HObject paintedBlue = null;
			HObject result = null;
			HObject result2;
			try
			{
				HOperatorSet.Decompose3(image, out red, out green, out blue);
				HOperatorSet.PaintRegion(region, red, out paintedRed, grayValue, "fill");
				HOperatorSet.PaintRegion(region, green, out paintedGreen, grayValue, "fill");
				HOperatorSet.PaintRegion(region, blue, out paintedBlue, grayValue, "fill");
				HOperatorSet.Compose3(paintedRed, paintedGreen, paintedBlue, out result);
				result2 = result;
			}
			finally
			{
				if (red != null)
				{
					red.Dispose();
				}
				if (green != null)
				{
					green.Dispose();
				}
				if (blue != null)
				{
					blue.Dispose();
				}
				if (paintedRed != null)
				{
					paintedRed.Dispose();
				}
				if (paintedGreen != null)
				{
					paintedGreen.Dispose();
				}
				if (paintedBlue != null)
				{
					paintedBlue.Dispose();
				}
			}
			return result2;
		}

		// Token: 0x06000450 RID: 1104 RVA: 0x000157B4 File Offset: 0x000139B4
		private HObject GenRegionFromRoi(RoiData roi, ToolVision tool, HObject image, bool applyMaskMode)
		{
			HistogramProcessor.MasterTransform transform = this.GetMasterTransform(roi, tool);
			HObject region;
			switch (roi.RoiType)
			{
			case RoiType.Rectangle1:
				region = this.GenRectangle1Region(roi, transform);
				break;
			case RoiType.Rectangle2:
				region = this.GenRectangle2Region(roi, transform);
				break;
			case RoiType.Circle:
				region = this.GenCircleRegion(roi, transform);
				break;
			case RoiType.Ellipse:
				region = this.GenEllipseRegion(roi, transform);
				break;
			case RoiType.Line:
				region = this.GenLineRegion(roi, transform);
				break;
			case RoiType.Polygon:
			case RoiType.FreeDraw:
			case RoiType.DrawRegion:
				region = this.GenContourRegion(roi, transform);
				break;
			default:
				HOperatorSet.GenEmptyObj(out region);
				break;
			}
			bool flag = !applyMaskMode;
			HObject result;
			if (flag)
			{
				result = region;
			}
			else
			{
				result = this.ApplyMaskMode(region, roi, image);
			}
			return result;
		}

		// Token: 0x06000451 RID: 1105 RVA: 0x0001586C File Offset: 0x00013A6C
		private HObject GenRectangle1Region(RoiData roi, HistogramProcessor.MasterTransform transform)
		{
			double row = Math.Min(roi.Row1, roi.Row2);
			double row2 = Math.Max(roi.Row1, roi.Row2);
			double col = Math.Min(roi.Col1, roi.Col2);
			double col2 = Math.Max(roi.Col1, roi.Col2);
			bool flag = Math.Abs(transform.Angle) < 1E-06;
			HObject region;
			if (flag)
			{
				HOperatorSet.GenRectangle1(out region, row + transform.Row, col + transform.Column, row2 + transform.Row, col2 + transform.Column);
			}
			else
			{
				Tuple<double, double> r1c = this.TransformPoint(row, col, transform);
				Tuple<double, double> r1c2 = this.TransformPoint(row, col2, transform);
				Tuple<double, double> r2c2 = this.TransformPoint(row2, col2, transform);
				Tuple<double, double> r2c3 = this.TransformPoint(row2, col, transform);
				region = this.GenContourRegion(new double[]
				{
					r1c.Item1,
					r1c2.Item1,
					r2c2.Item1,
					r2c3.Item1
				}, new double[]
				{
					r1c.Item2,
					r1c2.Item2,
					r2c2.Item2,
					r2c3.Item2
				}, true);
			}
			return region;
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x000159C0 File Offset: 0x00013BC0
		private HObject GenRectangle2Region(RoiData roi, HistogramProcessor.MasterTransform transform)
		{
			Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
			HObject region;
			HOperatorSet.GenRectangle2(out region, center.Item1, center.Item2, roi.Phi + transform.Angle, roi.Radius1, roi.Radius2);
			return region;
		}

		// Token: 0x06000453 RID: 1107 RVA: 0x00015A30 File Offset: 0x00013C30
		private HObject GenCircleRegion(RoiData roi, HistogramProcessor.MasterTransform transform)
		{
			Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
			HObject region;
			HOperatorSet.GenCircle(out region, center.Item1, center.Item2, roi.Radius);
			return region;
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x00015A80 File Offset: 0x00013C80
		private HObject GenEllipseRegion(RoiData roi, HistogramProcessor.MasterTransform transform)
		{
			Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
			HObject region;
			HOperatorSet.GenEllipse(out region, center.Item1, center.Item2, roi.Phi + transform.Angle, roi.Radius1, roi.Radius2);
			return region;
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x00015AF0 File Offset: 0x00013CF0
		private HObject GenLineRegion(RoiData roi, HistogramProcessor.MasterTransform transform)
		{
			HObject line = null;
			HObject region = null;
			HObject result;
			try
			{
				Tuple<double, double> p = this.TransformPoint(roi.Row1, roi.Col1, transform);
				Tuple<double, double> p2 = this.TransformPoint(roi.Row2, roi.Col2, transform);
				HOperatorSet.GenRegionLine(out line, p.Item1, p.Item2, p2.Item1, p2.Item2);
				HOperatorSet.DilationCircle(line, out region, 1.5);
				result = region;
			}
			finally
			{
				if (line != null)
				{
					line.Dispose();
				}
			}
			return result;
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x00015B9C File Offset: 0x00013D9C
		private HObject GenContourRegion(RoiData roi, HistogramProcessor.MasterTransform transform)
		{
			bool flag = roi.Rows == null || roi.Cols == null || roi.Rows.Count < 3 || roi.Rows.Count != roi.Cols.Count;
			HObject result;
			if (flag)
			{
				HObject region;
				HOperatorSet.GenEmptyObj(out region);
				result = region;
			}
			else
			{
				double[] rows = new double[roi.Rows.Count];
				double[] cols = new double[roi.Cols.Count];
				for (int i = 0; i < roi.Rows.Count; i++)
				{
					Tuple<double, double> point = this.TransformPoint(roi.Rows[i], roi.Cols[i], transform);
					rows[i] = point.Item1;
					cols[i] = point.Item2;
				}
				result = this.GenContourRegion(rows, cols, false);
			}
			return result;
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x00015C88 File Offset: 0x00013E88
		private HObject GenContourRegion(double[] rows, double[] cols, bool closeContour)
		{
			bool flag = rows == null || cols == null || rows.Length < 3 || rows.Length != cols.Length;
			HObject result;
			if (flag)
			{
				HObject region;
				HOperatorSet.GenEmptyObj(out region);
				result = region;
			}
			else
			{
				HObject contour = null;
				HObject region;
				try
				{
					HTuple contourRows = new HTuple(rows);
					HTuple contourCols = new HTuple(cols);
					if (closeContour)
					{
						contourRows = contourRows.TupleConcat(rows[0]);
						contourCols = contourCols.TupleConcat(cols[0]);
					}
					HOperatorSet.GenContourPolygonXld(out contour, contourRows, contourCols);
					HOperatorSet.GenRegionContourXld(contour, out region, "filled");
				}
				finally
				{
					if (contour != null)
					{
						contour.Dispose();
					}
				}
				result = region;
			}
			return result;
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x00015D48 File Offset: 0x00013F48
		private HObject ApplyMaskMode(HObject roiRegion, RoiData roi, HObject image)
		{
			bool flag = roiRegion == null || !roiRegion.IsInitialized() || roi == null || roi.MaskMode != RoiMaskMode.Outside || image == null || !image.IsInitialized();
			HObject result;
			if (flag)
			{
				result = roiRegion;
			}
			else
			{
				HObject fullRegion = null;
				HObject outsideRegion = null;
				try
				{
					HTuple width;
					HTuple height;
					HOperatorSet.GetImageSize(image, out width, out height);
					HOperatorSet.GenRectangle1(out fullRegion, 0, 0, height.D - 1.0, width.D - 1.0);
					HOperatorSet.Difference(fullRegion, roiRegion, out outsideRegion);
					roiRegion.Dispose();
					result = outsideRegion;
				}
				finally
				{
					if (fullRegion != null)
					{
						fullRegion.Dispose();
					}
				}
			}
			return result;
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x00015E0C File Offset: 0x0001400C
		private HistogramProcessor.MasterTransform GetMasterTransform(RoiData roi, ToolVision tool)
		{
			HistogramProcessor.MasterTransform transform = new HistogramProcessor.MasterTransform();
			bool flag = roi == null || ((tool != null) ? tool.ParentTurnSnap : null) == null;
			HistogramProcessor.MasterTransform result;
			if (flag)
			{
				result = transform;
			}
			else
			{
				ShapeModelToolTrain positionTrain = this.GetMasterTrain(tool, this.GetMasterPositionToolName(roi), true);
				bool flag2 = positionTrain != null;
				if (flag2)
				{
					transform.Row = positionTrain.LastRow - positionTrain.MasterRow;
					transform.Column = positionTrain.LastColumn - positionTrain.MasterColumn;
				}
				ShapeModelToolTrain angleTrain = this.GetMasterTrain(tool, this.GetMasterAngleToolName(roi), false);
				bool flag3 = angleTrain != null;
				if (flag3)
				{
					transform.Angle = angleTrain.LastAngle - angleTrain.MasterAngle;
					transform.MasterRow = angleTrain.MasterRow;
					transform.MasterColumn = angleTrain.MasterColumn;
				}
				result = transform;
			}
			return result;
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x00015ED8 File Offset: 0x000140D8
		private ShapeModelToolTrain GetMasterTrain(ToolVision tool, string masterToolName, bool isPositionMaster)
		{
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || string.IsNullOrWhiteSpace(masterToolName) || masterToolName == "None";
			ShapeModelToolTrain result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HistogramMasterRuntimeInfo runtimeInfo;
				bool flag2 = this._currentMasterRuntimeInfo != null && this._currentMasterRuntimeInfo.TryGetValue(masterToolName, out runtimeInfo) && !runtimeInfo.IsFound;
				if (flag2)
				{
					result = null;
				}
				else
				{
					ToolVision masterTool = tool.ParentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || (isPositionMaster && x.ToolType == ToolType.CircleMaster) || (isPositionMaster && x.ToolType == ToolType.BoundingBoxMaster) || (x.ToolType == ToolType.MinAreaMaster || (isPositionMaster && x.ToolType == ToolType.IntersectingLines)) || (!isPositionMaster && x.ToolType == ToolType.AngleSelector)) && x.Name == masterToolName);
					ShapeModelToolTrain train = ((masterTool != null) ? masterTool.TrainModel : null) as ShapeModelToolTrain;
					bool flag3 = train == null || !train.HasMasterDefined;
					if (flag3)
					{
						result = null;
					}
					else
					{
						result = train;
					}
				}
			}
			return result;
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x00015FE0 File Offset: 0x000141E0
		private string GetMasterPositionToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && roi.MasterPositionToolName != "None";
				if (flag2)
				{
					result = roi.MasterPositionToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x00016070 File Offset: 0x00014270
		private string GetMasterAngleToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && roi.MasterAngleToolName != "None";
				if (flag2)
				{
					result = roi.MasterAngleToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x00016100 File Offset: 0x00014300
		private string GetMasterStatus(string masterPositionToolName, string masterAngleToolName)
		{
			List<string> masterNames = this.GetDistinctMasterNames(masterPositionToolName, masterAngleToolName);
			bool flag = masterNames.Count == 0;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				foreach (string masterName in masterNames)
				{
					HistogramMasterRuntimeInfo info;
					bool flag2 = this._currentMasterRuntimeInfo == null || !this._currentMasterRuntimeInfo.TryGetValue(masterName, out info) || !info.IsFound;
					if (flag2)
					{
						return "Lost Master";
					}
				}
				result = "OK";
			}
			return result;
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x000161AC File Offset: 0x000143AC
		private double GetMasterProcessingTime(string masterPositionToolName, string masterAngleToolName)
		{
			double processingTime = 0.0;
			foreach (string masterName in this.GetDistinctMasterNames(masterPositionToolName, masterAngleToolName))
			{
				HistogramMasterRuntimeInfo info;
				bool flag = this._currentMasterRuntimeInfo != null && this._currentMasterRuntimeInfo.TryGetValue(masterName, out info);
				if (flag)
				{
					processingTime += info.ProcessingTimeMs;
				}
			}
			return processingTime;
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x0001623C File Offset: 0x0001443C
		private List<string> GetDistinctMasterNames(string masterPositionToolName, string masterAngleToolName)
		{
			return (from x in new string[]
			{
				masterPositionToolName,
				masterAngleToolName
			}
			where !string.IsNullOrWhiteSpace(x) && x != "None"
			select x).Distinct<string>().ToList<string>();
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x0001628C File Offset: 0x0001448C
		private Tuple<double, double> TransformPoint(double row, double column, HistogramProcessor.MasterTransform transform)
		{
			bool flag = transform == null;
			Tuple<double, double> result;
			if (flag)
			{
				result = Tuple.Create<double, double>(row, column);
			}
			else
			{
				double cos = Math.Cos(transform.Angle);
				double sin = Math.Sin(transform.Angle);
				double relRow = row - transform.MasterRow;
				double relColumn = column - transform.MasterColumn;
				double newRow = transform.MasterRow + transform.Row + relRow * cos - relColumn * sin;
				double newColumn = transform.MasterColumn + transform.Column + relRow * sin + relColumn * cos;
				result = Tuple.Create<double, double>(newRow, newColumn);
			}
			return result;
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x00016318 File Offset: 0x00014518
		private Dictionary<string, HistogramMasterRuntimeInfo> UpdateMasterShapeModels(HObject image, ToolVision tool)
		{
			Dictionary<string, HistogramMasterRuntimeInfo> runtimeInfo = new Dictionary<string, HistogramMasterRuntimeInfo>();
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null;
			Dictionary<string, HistogramMasterRuntimeInfo> result;
			if (flag)
			{
				result = runtimeInfo;
			}
			else
			{
				List<RoiData> roiItems = new List<RoiData>();
				bool flag2 = tool.RoiItems != null;
				if (flag2)
				{
					roiItems.AddRange(tool.RoiItems);
				}
				bool flag3 = tool.MaskRoiItems != null;
				if (flag3)
				{
					roiItems.AddRange(tool.MaskRoiItems);
				}
				List<string> masterNames = (from x in (from x in roiItems
				where x.IsEnabled
				select x).SelectMany((RoiData x) => new string[]
				{
					this.GetMasterPositionToolName(x),
					this.GetMasterAngleToolName(x)
				})
				where !string.IsNullOrWhiteSpace(x) && x != "None"
				select x).Distinct<string>().ToList<string>();
				bool flag4 = masterNames.Count == 0;
				if (flag4)
				{
					result = runtimeInfo;
				}
				else
				{
					ShapeModelProcessor shapeProcessor = new ShapeModelProcessor();
					using (List<string>.Enumerator enumerator = masterNames.GetEnumerator())
					{
						Func<ToolVision, bool> <>9__3;
						while (enumerator.MoveNext())
						{
							string masterName = enumerator.Current;
							HistogramMasterRuntimeInfo info = new HistogramMasterRuntimeInfo
							{
								ToolName = masterName,
								IsLinked = true
							};
							Stopwatch stopwatch = Stopwatch.StartNew();
							IEnumerable<ToolVision> tools = tool.ParentTurnSnap.Tools;
							Func<ToolVision, bool> predicate;
							if ((predicate = <>9__3) == null)
							{
								predicate = (<>9__3 = ((ToolVision x) => x != tool));
							}
							ToolVision masterTool = tools.TakeWhile(predicate).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.BoundingBoxMaster || x.ToolType == ToolType.MinAreaMaster || x.ToolType == ToolType.IntersectingLines || x.ToolType == ToolType.AngleSelector) && x.Name == masterName);
							bool flag5 = masterTool == null;
							if (flag5)
							{
								stopwatch.Stop();
								info.IsFound = false;
								info.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
								runtimeInfo[masterName] = info;
							}
							else
							{
								ShapeMatchResult matchResult;
								bool flag6 = this.TryGetCachedMasterResult(masterName, out matchResult);
								if (flag6)
								{
									this.ApplyMasterResultToTrain(masterTool, matchResult);
									stopwatch.Stop();
									info.IsFound = matchResult.IsSuccess;
									info.ProcessingTimeMs = Math.Max(0.0, matchResult.ProcessingTimeMs);
									runtimeInfo[masterName] = info;
								}
								else
								{
									bool flag7 = masterTool.ToolType == ToolType.CircleMaster;
									if (flag7)
									{
										matchResult = new CircleMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
									}
									else
									{
										bool flag8 = masterTool.ToolType == ToolType.BoundingBoxMaster;
										if (flag8)
										{
											matchResult = new BoundingBoxMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
										}
										else
										{
											bool flag9 = masterTool.ToolType == ToolType.MinAreaMaster;
											if (flag9)
											{
												matchResult = new MinAreaMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
											}
											else
											{
												bool flag10 = masterTool.ToolType == ToolType.IntersectingLines;
												if (flag10)
												{
													matchResult = new IntersectingLinesProcessor(null, this._cachedMasterResults).Match(image, masterTool);
												}
												else
												{
													bool flag11 = masterTool.ToolType == ToolType.AngleSelector;
													if (flag11)
													{
														matchResult = new AngleSelectorProcessor(null, this._cachedMasterResults).Match(image, masterTool);
													}
													else
													{
														matchResult = shapeProcessor.Match(image, masterTool);
													}
												}
											}
										}
									}
									stopwatch.Stop();
									info.IsFound = (matchResult != null && matchResult.IsSuccess);
									info.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
									runtimeInfo[masterName] = info;
								}
							}
						}
					}
					result = runtimeInfo;
				}
			}
			return result;
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x000166F0 File Offset: 0x000148F0
		private bool TryGetCachedMasterResult(string masterName, out ShapeMatchResult result)
		{
			result = null;
			bool flag = this._cachedMasterResults == null || string.IsNullOrWhiteSpace(masterName);
			return !flag && this._cachedMasterResults.TryGetValue(masterName, out result) && result != null;
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x00016738 File Offset: 0x00014938
		private void ApplyMasterResultToTrain(ToolVision masterTool, ShapeMatchResult result)
		{
			bool flag = masterTool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				ShapeModelToolTrain train = masterTool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (!flag2)
				{
					train.LastRow = result.Row;
					train.LastColumn = result.Column;
					train.LastAngle = result.Angle;
					train.LastScore = result.Score;
				}
			}
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x000167AC File Offset: 0x000149AC
		private double GetFallbackRow(RoiData roi)
		{
			bool flag = roi.RoiType == RoiType.Rectangle1;
			double result;
			if (flag)
			{
				result = Math.Min(roi.Row1, roi.Row2);
			}
			else
			{
				bool flag2 = roi.RoiType == RoiType.Polygon || roi.RoiType == RoiType.FreeDraw || roi.RoiType == RoiType.DrawRegion;
				if (flag2)
				{
					result = ((roi.Rows != null && roi.Rows.Count > 0) ? roi.Rows.Min() : 0.0);
				}
				else
				{
					result = roi.CenterRow;
				}
			}
			return result;
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x00016838 File Offset: 0x00014A38
		private double GetFallbackColumn(RoiData roi)
		{
			bool flag = roi.RoiType == RoiType.Rectangle1;
			double result;
			if (flag)
			{
				result = Math.Min(roi.Col1, roi.Col2);
			}
			else
			{
				bool flag2 = roi.RoiType == RoiType.Polygon || roi.RoiType == RoiType.FreeDraw || roi.RoiType == RoiType.DrawRegion;
				if (flag2)
				{
					result = ((roi.Cols != null && roi.Cols.Count > 0) ? roi.Cols.Min() : 0.0);
				}
				else
				{
					result = roi.CenterCol;
				}
			}
			return result;
		}

		// Token: 0x040001C4 RID: 452
		private readonly IDictionary<string, ShapeMatchResult> _cachedMasterResults;

		// Token: 0x040001C5 RID: 453
		private Dictionary<string, HistogramMasterRuntimeInfo> _currentMasterRuntimeInfo;

		// Token: 0x020002E8 RID: 744
		private class MasterTransform
		{
			// Token: 0x17000B19 RID: 2841
			// (get) Token: 0x060026E2 RID: 9954 RVA: 0x000DFFDC File Offset: 0x000DE1DC
			// (set) Token: 0x060026E3 RID: 9955 RVA: 0x000DFFE4 File Offset: 0x000DE1E4
			public double Row { get; set; }

			// Token: 0x17000B1A RID: 2842
			// (get) Token: 0x060026E4 RID: 9956 RVA: 0x000DFFED File Offset: 0x000DE1ED
			// (set) Token: 0x060026E5 RID: 9957 RVA: 0x000DFFF5 File Offset: 0x000DE1F5
			public double Column { get; set; }

			// Token: 0x17000B1B RID: 2843
			// (get) Token: 0x060026E6 RID: 9958 RVA: 0x000DFFFE File Offset: 0x000DE1FE
			// (set) Token: 0x060026E7 RID: 9959 RVA: 0x000E0006 File Offset: 0x000DE206
			public double Angle { get; set; }

			// Token: 0x17000B1C RID: 2844
			// (get) Token: 0x060026E8 RID: 9960 RVA: 0x000E000F File Offset: 0x000DE20F
			// (set) Token: 0x060026E9 RID: 9961 RVA: 0x000E0017 File Offset: 0x000DE217
			public double MasterRow { get; set; }

			// Token: 0x17000B1D RID: 2845
			// (get) Token: 0x060026EA RID: 9962 RVA: 0x000E0020 File Offset: 0x000DE220
			// (set) Token: 0x060026EB RID: 9963 RVA: 0x000E0028 File Offset: 0x000DE228
			public double MasterColumn { get; set; }
		}
	}
}
