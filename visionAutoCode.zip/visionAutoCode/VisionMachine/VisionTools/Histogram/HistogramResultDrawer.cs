﻿using System;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.Histogram
{
	// Token: 0x02000060 RID: 96
	public class HistogramResultDrawer
	{
		// Token: 0x06000466 RID: 1126 RVA: 0x000168C3 File Offset: 0x00014AC3
		public void Draw(HWindow window, ToolVision tool, HistogramProcessResult result)
		{
			this.Draw(window, tool, result, true, true);
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x000168D4 File Offset: 0x00014AD4
		public void Draw(HWindow window, ToolVision tool, HistogramProcessResult result, bool showTotalText, bool fillThreshold)
		{
			bool flag = window == null || tool == null || result == null;
			if (!flag)
			{
				HistogramToolConfig config = tool.Config as HistogramToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					bool showThreshold = config.ShowThreshold;
					if (showThreshold)
					{
						this.DrawThreshold(window, result, fillThreshold);
					}
					bool showRoi = config.ShowRoi;
					if (showRoi)
					{
						this.DrawRois(window, result);
					}
					bool showText = config.ShowText;
					if (showText)
					{
						this.DrawResultText(window, tool, result, showTotalText);
					}
				}
			}
		}

		// Token: 0x06000468 RID: 1128 RVA: 0x00016950 File Offset: 0x00014B50
		private void DrawThreshold(HWindow window, HistogramProcessResult result, bool fillThreshold)
		{
			bool flag = result.RoiResults == null || result.RoiResults.Count == 0;
			if (!flag)
			{
				HObject thresholdObjects = null;
				HObject thresholdRegion = null;
				try
				{
					HOperatorSet.GenEmptyObj(out thresholdObjects);
					foreach (HistogramRoiResult roiResult in result.RoiResults)
					{
						bool flag2 = roiResult.ThresholdObject == null || !roiResult.ThresholdObject.IsInitialized();
						if (!flag2)
						{
							HObject concat;
							HOperatorSet.ConcatObj(thresholdObjects, roiResult.ThresholdObject, out concat);
							thresholdObjects.Dispose();
							thresholdObjects = concat;
						}
					}
					HTuple count;
					HOperatorSet.CountObj(thresholdObjects, out count);
					bool flag3 = count.Length == 0 || count[0].I <= 0;
					if (!flag3)
					{
						HOperatorSet.Union1(thresholdObjects, out thresholdRegion);
						HOperatorSet.SetDraw(window, fillThreshold ? "fill" : "margin");
						HOperatorSet.SetLineWidth(window, 1);
						HOperatorSet.SetColor(window, "orange");
						HOperatorSet.DispObj(thresholdRegion, window);
					}
				}
				finally
				{
					if (thresholdObjects != null)
					{
						thresholdObjects.Dispose();
					}
					if (thresholdRegion != null)
					{
						thresholdRegion.Dispose();
					}
				}
			}
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x00016AE0 File Offset: 0x00014CE0
		private void DrawRois(HWindow window, HistogramProcessResult result)
		{
			bool flag = result.RoiResults == null || result.RoiResults.Count == 0;
			if (!flag)
			{
				HObject roiBoundaries = null;
				HObject unionBoundary = null;
				try
				{
					HOperatorSet.GenEmptyObj(out roiBoundaries);
					foreach (HistogramRoiResult roiResult in result.RoiResults)
					{
						HObject roiObject = roiResult.DisplayRoiObject;
						bool flag2 = roiObject == null || !roiObject.IsInitialized();
						if (flag2)
						{
							roiObject = roiResult.RoiObject;
						}
						bool flag3 = roiObject == null || !roiObject.IsInitialized();
						if (!flag3)
						{
							HObject boundary = null;
							HObject thickBoundary = null;
							try
							{
								HOperatorSet.Boundary(roiObject, out boundary, "outer");
								HOperatorSet.DilationCircle(boundary, out thickBoundary, 1.5);
								HObject concat;
								HOperatorSet.ConcatObj(roiBoundaries, thickBoundary, out concat);
								roiBoundaries.Dispose();
								roiBoundaries = concat;
							}
							finally
							{
								if (boundary != null)
								{
									boundary.Dispose();
								}
								if (thickBoundary != null)
								{
									thickBoundary.Dispose();
								}
							}
						}
					}
					HTuple count;
					HOperatorSet.CountObj(roiBoundaries, out count);
					bool flag4 = count.Length == 0 || count[0].I <= 0;
					if (!flag4)
					{
						HOperatorSet.Union1(roiBoundaries, out unionBoundary);
						HOperatorSet.SetDraw(window, "fill");
						HOperatorSet.SetColor(window, result.IsOk ? "green" : "red");
						HOperatorSet.SetLineWidth(window, 2);
						HOperatorSet.DispObj(unionBoundary, window);
					}
				}
				finally
				{
					if (roiBoundaries != null)
					{
						roiBoundaries.Dispose();
					}
					if (unionBoundary != null)
					{
						unionBoundary.Dispose();
					}
				}
			}
		}

		// Token: 0x0600046A RID: 1130 RVA: 0x00016D04 File Offset: 0x00014F04
		private void DrawResultText(HWindow window, ToolVision tool, HistogramProcessResult result, bool showTotalText)
		{
			string toolName = string.IsNullOrWhiteSpace((tool != null) ? tool.Name : null) ? "Histogram" : tool.Name;
			string resultColor = result.IsOk ? "green" : "red";
			bool flag = result.RoiResults != null;
			if (flag)
			{
				HOperatorSet.SetColor(window, resultColor);
				foreach (HistogramRoiResult roiResult in result.RoiResults)
				{
					string roiName = this.GetRoiName(roiResult);
					HOperatorSet.SetTposition(window, roiResult.LabelRow, roiResult.LabelColumn);
					HOperatorSet.WriteString(window, string.Concat(new string[]
					{
						toolName,
						" ",
						roiName,
						"=",
						roiResult.Value.ToString("0.000"),
						"%"
					}));
				}
			}
			bool flag2 = !showTotalText;
			if (!flag2)
			{
				HOperatorSet.SetColor(window, resultColor);
				HOperatorSet.SetTposition(window, 20, 20);
				HOperatorSet.WriteString(window, string.Concat(new string[]
				{
					toolName,
					" Total=",
					result.TotalValue.ToString("0.000"),
					"% ",
					result.IsOk ? "OK" : "NG"
				}));
			}
		}

		// Token: 0x0600046B RID: 1131 RVA: 0x00016ED4 File Offset: 0x000150D4
		private string GetRoiName(HistogramRoiResult roiResult)
		{
			string value;
			if (roiResult == null)
			{
				value = null;
			}
			else
			{
				RoiData roi = roiResult.Roi;
				value = ((roi != null) ? roi.Name : null);
			}
			bool flag = !string.IsNullOrWhiteSpace(value);
			string result;
			if (flag)
			{
				result = roiResult.Roi.Name;
			}
			else
			{
				result = "ROI";
			}
			return result;
		}
	}
}
