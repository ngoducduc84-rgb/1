﻿using System;
using HalconDotNet;
using VisionMachine.Models.Roi;

namespace VisionMachine.VisionTools.Histogram
{
	// Token: 0x0200005C RID: 92
	public class HistogramRoiResult
	{
		// Token: 0x1700015C RID: 348
		// (get) Token: 0x0600040D RID: 1037 RVA: 0x00014C1C File Offset: 0x00012E1C
		// (set) Token: 0x0600040E RID: 1038 RVA: 0x00014C24 File Offset: 0x00012E24
		public RoiData Roi { get; set; }

		// Token: 0x1700015D RID: 349
		// (get) Token: 0x0600040F RID: 1039 RVA: 0x00014C2D File Offset: 0x00012E2D
		// (set) Token: 0x06000410 RID: 1040 RVA: 0x00014C35 File Offset: 0x00012E35
		public double Value { get; set; }

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x06000411 RID: 1041 RVA: 0x00014C3E File Offset: 0x00012E3E
		// (set) Token: 0x06000412 RID: 1042 RVA: 0x00014C46 File Offset: 0x00012E46
		public double SelectedPixelCount { get; set; }

		// Token: 0x1700015F RID: 351
		// (get) Token: 0x06000413 RID: 1043 RVA: 0x00014C4F File Offset: 0x00012E4F
		// (set) Token: 0x06000414 RID: 1044 RVA: 0x00014C57 File Offset: 0x00012E57
		public double TotalPixelCount { get; set; }

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x06000415 RID: 1045 RVA: 0x00014C60 File Offset: 0x00012E60
		// (set) Token: 0x06000416 RID: 1046 RVA: 0x00014C68 File Offset: 0x00012E68
		public double LabelRow { get; set; }

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x06000417 RID: 1047 RVA: 0x00014C71 File Offset: 0x00012E71
		// (set) Token: 0x06000418 RID: 1048 RVA: 0x00014C79 File Offset: 0x00012E79
		public double LabelColumn { get; set; }

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x06000419 RID: 1049 RVA: 0x00014C82 File Offset: 0x00012E82
		// (set) Token: 0x0600041A RID: 1050 RVA: 0x00014C8A File Offset: 0x00012E8A
		public HObject RoiObject { get; set; }

		// Token: 0x17000163 RID: 355
		// (get) Token: 0x0600041B RID: 1051 RVA: 0x00014C93 File Offset: 0x00012E93
		// (set) Token: 0x0600041C RID: 1052 RVA: 0x00014C9B File Offset: 0x00012E9B
		public HObject DisplayRoiObject { get; set; }

		// Token: 0x17000164 RID: 356
		// (get) Token: 0x0600041D RID: 1053 RVA: 0x00014CA4 File Offset: 0x00012EA4
		// (set) Token: 0x0600041E RID: 1054 RVA: 0x00014CAC File Offset: 0x00012EAC
		public HObject ThresholdObject { get; set; }

		// Token: 0x17000165 RID: 357
		// (get) Token: 0x0600041F RID: 1055 RVA: 0x00014CB5 File Offset: 0x00012EB5
		// (set) Token: 0x06000420 RID: 1056 RVA: 0x00014CBD File Offset: 0x00012EBD
		public double ProcessingTimeMs { get; set; }

		// Token: 0x17000166 RID: 358
		// (get) Token: 0x06000421 RID: 1057 RVA: 0x00014CC6 File Offset: 0x00012EC6
		// (set) Token: 0x06000422 RID: 1058 RVA: 0x00014CCE File Offset: 0x00012ECE
		public string MasterPositionToolName { get; set; }

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x06000423 RID: 1059 RVA: 0x00014CD7 File Offset: 0x00012ED7
		// (set) Token: 0x06000424 RID: 1060 RVA: 0x00014CDF File Offset: 0x00012EDF
		public string MasterAngleToolName { get; set; }

		// Token: 0x17000168 RID: 360
		// (get) Token: 0x06000425 RID: 1061 RVA: 0x00014CE8 File Offset: 0x00012EE8
		// (set) Token: 0x06000426 RID: 1062 RVA: 0x00014CF0 File Offset: 0x00012EF0
		public string MasterStatus { get; set; }

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x06000427 RID: 1063 RVA: 0x00014CF9 File Offset: 0x00012EF9
		// (set) Token: 0x06000428 RID: 1064 RVA: 0x00014D01 File Offset: 0x00012F01
		public double MasterProcessingTimeMs { get; set; }
	}
}
