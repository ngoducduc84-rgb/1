﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.Histogram
{
	// Token: 0x02000061 RID: 97
	public class HistogramToolConfig : ToolConfigBase
	{
		// Token: 0x17000178 RID: 376
		// (get) Token: 0x0600046D RID: 1133 RVA: 0x00016F1D File Offset: 0x0001511D
		// (set) Token: 0x0600046E RID: 1134 RVA: 0x00016F25 File Offset: 0x00015125
		public ImageInputLink InputLink { get; set; } = new ImageInputLink();

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x0600046F RID: 1135 RVA: 0x00016F30 File Offset: 0x00015130
		// (set) Token: 0x06000470 RID: 1136 RVA: 0x00016F48 File Offset: 0x00015148
		[DisplayName("Gray Min")]
		public double GrayMin
		{
			get
			{
				return this._grayMin;
			}
			set
			{
				bool flag = this._grayMin == value;
				if (!flag)
				{
					this._grayMin = value;
					base.OnPropertyChanged("GrayMin");
				}
			}
		}

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x06000471 RID: 1137 RVA: 0x00016F78 File Offset: 0x00015178
		// (set) Token: 0x06000472 RID: 1138 RVA: 0x00016F90 File Offset: 0x00015190
		[DisplayName("Gray Max")]
		public double GrayMax
		{
			get
			{
				return this._grayMax;
			}
			set
			{
				bool flag = this._grayMax == value;
				if (!flag)
				{
					this._grayMax = value;
					base.OnPropertyChanged("GrayMax");
				}
			}
		}

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x06000473 RID: 1139 RVA: 0x00016FC0 File Offset: 0x000151C0
		// (set) Token: 0x06000474 RID: 1140 RVA: 0x00016FD8 File Offset: 0x000151D8
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				bool flag = this._showRoi == value;
				if (!flag)
				{
					this._showRoi = value;
					base.OnPropertyChanged("ShowRoi");
				}
			}
		}

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x06000475 RID: 1141 RVA: 0x00017008 File Offset: 0x00015208
		// (set) Token: 0x06000476 RID: 1142 RVA: 0x00017020 File Offset: 0x00015220
		[DisplayName("Show Threshold")]
		public bool ShowThreshold
		{
			get
			{
				return this._showThreshold;
			}
			set
			{
				bool flag = this._showThreshold == value;
				if (!flag)
				{
					this._showThreshold = value;
					base.OnPropertyChanged("ShowThreshold");
				}
			}
		}

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x06000477 RID: 1143 RVA: 0x00017050 File Offset: 0x00015250
		// (set) Token: 0x06000478 RID: 1144 RVA: 0x00017068 File Offset: 0x00015268
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				bool flag = this._showText == value;
				if (!flag)
				{
					this._showText = value;
					base.OnPropertyChanged("ShowText");
				}
			}
		}

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x06000479 RID: 1145 RVA: 0x00017098 File Offset: 0x00015298
		// (set) Token: 0x0600047A RID: 1146 RVA: 0x000170B0 File Offset: 0x000152B0
		[DisplayName("Show Input Image")]
		public bool ShowInputImage
		{
			get
			{
				return this._showInputImage;
			}
			set
			{
				bool flag = this._showInputImage == value;
				if (!flag)
				{
					this._showInputImage = value;
					base.OnPropertyChanged("ShowInputImage");
				}
			}
		}

		// Token: 0x040001C6 RID: 454
		private double _grayMin;

		// Token: 0x040001C7 RID: 455
		private double _grayMax = 255.0;

		// Token: 0x040001C8 RID: 456
		private bool _showRoi = true;

		// Token: 0x040001C9 RID: 457
		private bool _showThreshold;

		// Token: 0x040001CA RID: 458
		private bool _showText = true;

		// Token: 0x040001CB RID: 459
		private bool _showInputImage;
	}
}
