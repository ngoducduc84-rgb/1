﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.Histogram
{
	// Token: 0x02000062 RID: 98
	public class HistogramToolSpec : ToolSpecBase
	{
		// Token: 0x1700017F RID: 383
		// (get) Token: 0x0600047C RID: 1148 RVA: 0x00017114 File Offset: 0x00015314
		// (set) Token: 0x0600047D RID: 1149 RVA: 0x0001712C File Offset: 0x0001532C
		[DisplayName("Normal Size")]
		public double NormalSize
		{
			get
			{
				return this._normalSize;
			}
			set
			{
				bool flag = this._normalSize == value;
				if (!flag)
				{
					this._normalSize = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("NormalSize");
				}
			}
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x0600047E RID: 1150 RVA: 0x00017164 File Offset: 0x00015364
		// (set) Token: 0x0600047F RID: 1151 RVA: 0x0001717C File Offset: 0x0001537C
		[DisplayName("Upper Deviation")]
		public double UpperDeviation
		{
			get
			{
				return this._upperDeviation;
			}
			set
			{
				bool flag = this._upperDeviation == value;
				if (!flag)
				{
					this._upperDeviation = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("UpperDeviation");
				}
			}
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x06000480 RID: 1152 RVA: 0x000171B4 File Offset: 0x000153B4
		// (set) Token: 0x06000481 RID: 1153 RVA: 0x000171CC File Offset: 0x000153CC
		[DisplayName("Lower Deviation")]
		public double LowerDeviation
		{
			get
			{
				return this._lowerDeviation;
			}
			set
			{
				bool flag = this._lowerDeviation == value;
				if (!flag)
				{
					this._lowerDeviation = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("LowerDeviation");
				}
			}
		}

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x06000482 RID: 1154 RVA: 0x00017204 File Offset: 0x00015404
		// (set) Token: 0x06000483 RID: 1155 RVA: 0x0001721C File Offset: 0x0001541C
		[DisplayName("Maximum Size")]
		[ReadOnly(true)]
		public double MaximumSize
		{
			get
			{
				return this._maximumSize;
			}
			set
			{
				bool flag = this._maximumSize == value;
				if (!flag)
				{
					this._maximumSize = value;
					base.OnPropertyChanged("MaximumSize");
				}
			}
		}

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x06000484 RID: 1156 RVA: 0x0001724C File Offset: 0x0001544C
		// (set) Token: 0x06000485 RID: 1157 RVA: 0x00017264 File Offset: 0x00015464
		[DisplayName("Minimum Size")]
		[ReadOnly(true)]
		public double MinimumSize
		{
			get
			{
				return this._minimumSize;
			}
			set
			{
				bool flag = this._minimumSize == value;
				if (!flag)
				{
					this._minimumSize = value;
					base.OnPropertyChanged("MinimumSize");
				}
			}
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x00017294 File Offset: 0x00015494
		private void RecalculateLimits()
		{
			this.MaximumSize = this.NormalSize + this.UpperDeviation;
			this.MinimumSize = this.NormalSize - this.LowerDeviation;
		}

		// Token: 0x040001CD RID: 461
		private double _normalSize;

		// Token: 0x040001CE RID: 462
		private double _upperDeviation;

		// Token: 0x040001CF RID: 463
		private double _lowerDeviation;

		// Token: 0x040001D0 RID: 464
		private double _maximumSize;

		// Token: 0x040001D1 RID: 465
		private double _minimumSize;
	}
}
