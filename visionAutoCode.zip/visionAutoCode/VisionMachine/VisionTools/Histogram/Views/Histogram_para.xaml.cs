﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.PropertyGrid;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.Histogram.Views
{
	// Token: 0x02000063 RID: 99
	public partial class Histogram_para : UserControl, IStyleConnector
	{
		// Token: 0x06000488 RID: 1160 RVA: 0x000172BF File Offset: 0x000154BF
		public Histogram_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x000172D0 File Offset: 0x000154D0
		private void Gray_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			HistogramToolConfig config = this.propertyGrid.SelectedObject as HistogramToolConfig;
			bool flag = config == null;
			if (!flag)
			{
				bool flag2 = config.GrayMin > config.GrayMax;
				if (flag2)
				{
					config.GrayMax = config.GrayMin;
				}
			}
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x00017318 File Offset: 0x00015518
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.HistogramTrialRun();
			}
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x000173B4 File Offset: 0x000155B4
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				((TrackBarEdit)target).EditValueChanged += this.Gray_EditValueChanged;
				break;
			case 3:
				((SpinEdit)target).EditValueChanged += this.Gray_EditValueChanged;
				break;
			case 4:
				((TrackBarEdit)target).EditValueChanged += this.Gray_EditValueChanged;
				break;
			case 5:
				((SpinEdit)target).EditValueChanged += this.Gray_EditValueChanged;
				break;
			}
		}
	}
}
