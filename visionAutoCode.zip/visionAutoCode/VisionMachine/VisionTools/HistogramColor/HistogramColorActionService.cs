﻿using System;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.Runtime;

namespace VisionMachine.VisionTools.HistogramColor
{
	// Token: 0x02000050 RID: 80
	public class HistogramColorActionService : IToolActionService
	{
		// Token: 0x1700011F RID: 287
		// (get) Token: 0x06000352 RID: 850 RVA: 0x000110F0 File Offset: 0x0000F2F0
		public ToolType ToolType
		{
			get
			{
				return ToolType.HistogramColor;
			}
		}

		// Token: 0x06000353 RID: 851 RVA: 0x00011104 File Offset: 0x0000F304
		public void TrialRun(ToolActionContext context, ToolVision tool)
		{
			bool flag = context == null || context.DisplayController == null || tool == null;
			if (!flag)
			{
				HObject original = null;
				HObject input = null;
				ImageBufferStore bufferStore = null;
				HistogramColorProcessResult histogramResult = null;
				try
				{
					original = context.DisplayController.GetOriginalImage();
					bool flag2 = original == null || !original.IsInitialized();
					if (!flag2)
					{
						bufferStore = new ImageBufferStore();
						ToolProcessContext processContext = new ToolProcessContext
						{
							OriginalImage = original,
							InputImage = original,
							BufferStore = bufferStore
						};
						string inputSourceToolName = this.GetInputSourceToolName(tool);
						Stopwatch inputStopwatch = Stopwatch.StartNew();
						input = this._pipelineService.BuildInputImageForTool(processContext, tool);
						inputStopwatch.Stop();
						double inputProcessingTimeMs = inputStopwatch.Elapsed.TotalMilliseconds;
						bool flag3 = input == null || !input.IsInitialized();
						if (flag3)
						{
							bool flag4 = input != null;
							if (flag4)
							{
								input.Dispose();
							}
							HOperatorSet.CopyImage(original, out input);
						}
						this.EnsureFullDomainImage(ref input);
						HistogramColorToolConfig config = tool.Config as HistogramColorToolConfig;
						bool flag5 = config != null && config.ShowInputImage;
						if (flag5)
						{
							context.DisplayController.DisplayImage(input);
						}
						else
						{
							histogramResult = this._processor.Run(input, tool);
							histogramResult.InputSourceToolName = inputSourceToolName;
							histogramResult.InputProcessingTimeMs = inputProcessingTimeMs;
							bool flag6 = histogramResult.SourceImage != null && histogramResult.SourceImage.IsInitialized();
							if (flag6)
							{
								context.DisplayController.DisplayImage(histogramResult.SourceImage);
							}
							else
							{
								context.DisplayController.DisplayImage(input);
							}
							bool flag7 = histogramResult != null && histogramResult.IsSuccess;
							if (flag7)
							{
								Action<ToolVision, object> resultReporter = context.ResultReporter;
								if (resultReporter != null)
								{
									resultReporter(tool, histogramResult);
								}
								HistogramColorProcessResult overlayResult = histogramResult;
								histogramResult = null;
								context.DisplayController.SetOverlayRenderer(delegate(HWindow window)
								{
									this._drawer.Draw(window, tool, overlayResult);
								}, overlayResult);
							}
						}
					}
				}
				finally
				{
					if (histogramResult != null)
					{
						histogramResult.Dispose();
					}
					if (input != null)
					{
						input.Dispose();
					}
					if (bufferStore != null)
					{
						bufferStore.Clear();
					}
					if (original != null)
					{
						original.Dispose();
					}
				}
			}
		}

		// Token: 0x06000354 RID: 852 RVA: 0x00011398 File Offset: 0x0000F598
		private void EnsureFullDomainImage(ref HObject image)
		{
			bool flag = image == null || !image.IsInitialized();
			if (!flag)
			{
				HObject fullDomainImage;
				HOperatorSet.FullDomain(image, out fullDomainImage);
				image.Dispose();
				image = fullDomainImage;
			}
		}

		// Token: 0x06000355 RID: 853 RVA: 0x000113D4 File Offset: 0x0000F5D4
		private string GetInputSourceToolName(ToolVision tool)
		{
			ToolVision tool2 = tool;
			HistogramColorToolConfig config = ((tool2 != null) ? tool2.Config : null) as HistogramColorToolConfig;
			ImageInputLink link = (config != null) ? config.InputLink : null;
			bool flag = link == null || link.SourceType == ImageInputSourceType.OriginalImage;
			string result;
			if (flag)
			{
				result = "OriginalImage";
			}
			else
			{
				bool flag2 = link.SourceType == ImageInputSourceType.ToolOutput;
				if (flag2)
				{
					result = (string.IsNullOrWhiteSpace(link.SourceToolName) ? "ToolOutput" : link.SourceToolName);
				}
				else
				{
					bool flag3 = link.SourceType == ImageInputSourceType.PreviousToolOutput;
					if (flag3)
					{
						TurnSnap parentTurnSnap = tool.ParentTurnSnap;
						ToolVision previousTool = (parentTurnSnap != null) ? parentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).LastOrDefault<ToolVision>() : null;
						result = ((previousTool == null) ? "PreviousToolOutput" : previousTool.Name);
					}
					else
					{
						result = "Unknown";
					}
				}
			}
			return result;
		}

		// Token: 0x04000165 RID: 357
		private readonly HistogramColorProcessor _processor = new HistogramColorProcessor();

		// Token: 0x04000166 RID: 358
		private readonly ToolTrialRunPipelineService _pipelineService = new ToolTrialRunPipelineService();

		// Token: 0x04000167 RID: 359
		private readonly HistogramColorResultDrawer _drawer = new HistogramColorResultDrawer();
	}
}
