﻿using System;

namespace VisionMachine.VisionTools.HistogramColor
{
	// Token: 0x02000053 RID: 83
	public class HistogramColorMasterRuntimeInfo
	{
		// Token: 0x17000137 RID: 311
		// (get) Token: 0x0600038A RID: 906 RVA: 0x000118A9 File Offset: 0x0000FAA9
		// (set) Token: 0x0600038B RID: 907 RVA: 0x000118B1 File Offset: 0x0000FAB1
		public string ToolName { get; set; }

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x0600038C RID: 908 RVA: 0x000118BA File Offset: 0x0000FABA
		// (set) Token: 0x0600038D RID: 909 RVA: 0x000118C2 File Offset: 0x0000FAC2
		public bool IsLinked { get; set; }

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x0600038E RID: 910 RVA: 0x000118CB File Offset: 0x0000FACB
		// (set) Token: 0x0600038F RID: 911 RVA: 0x000118D3 File Offset: 0x0000FAD3
		public bool IsFound { get; set; }

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x06000390 RID: 912 RVA: 0x000118DC File Offset: 0x0000FADC
		// (set) Token: 0x06000391 RID: 913 RVA: 0x000118E4 File Offset: 0x0000FAE4
		public double ProcessingTimeMs { get; set; }
	}
}
