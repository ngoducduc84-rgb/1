﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.HistogramColor
{
	// Token: 0x02000051 RID: 81
	public class HistogramColorParameterPanelViewModel : INotifyPropertyChanged
	{
		// Token: 0x17000120 RID: 288
		// (get) Token: 0x06000357 RID: 855 RVA: 0x000114EC File Offset: 0x0000F6EC
		// (set) Token: 0x06000358 RID: 856 RVA: 0x000114F4 File Offset: 0x0000F6F4
		public HistogramColorToolConfig Config { get; set; }

		// Token: 0x17000121 RID: 289
		// (get) Token: 0x06000359 RID: 857 RVA: 0x000114FD File Offset: 0x0000F6FD
		// (set) Token: 0x0600035A RID: 858 RVA: 0x00011505 File Offset: 0x0000F705
		public HistogramColorToolSpec Spec { get; set; }

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x0600035B RID: 859 RVA: 0x0001150E File Offset: 0x0000F70E
		// (set) Token: 0x0600035C RID: 860 RVA: 0x00011516 File Offset: 0x0000F716
		public ToolVision Tool { get; set; }

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x0600035D RID: 861 RVA: 0x0001151F File Offset: 0x0000F71F
		// (set) Token: 0x0600035E RID: 862 RVA: 0x00011527 File Offset: 0x0000F727
		public ObservableCollection<ToolImageSourceOption> AvailableImageOutputTools { get; set; }

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x0600035F RID: 863 RVA: 0x00011530 File Offset: 0x0000F730
		public ImageInputSourceType[] InputSourceTypes
		{
			get
			{
				return new ImageInputSourceType[]
				{
					ImageInputSourceType.OriginalImage,
					ImageInputSourceType.ToolOutput
				};
			}
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x06000360 RID: 864 RVA: 0x0001154C File Offset: 0x0000F74C
		// (set) Token: 0x06000361 RID: 865 RVA: 0x00011564 File Offset: 0x0000F764
		public ToolImageSourceOption SelectedSourceTool
		{
			get
			{
				return this._selectedSourceTool;
			}
			set
			{
				bool flag = this._selectedSourceTool == value;
				if (!flag)
				{
					this._selectedSourceTool = value;
					bool flag2 = this.Config != null && this.Config.InputLink != null;
					if (flag2)
					{
						bool flag3 = this._selectedSourceTool != null;
						if (flag3)
						{
							this.Config.InputLink.SourceToolId = null;
							this.Config.InputLink.SourceToolName = this._selectedSourceTool.ToolName;
						}
						else
						{
							this.Config.InputLink.SourceToolId = null;
							this.Config.InputLink.SourceToolName = null;
						}
					}
					this.OnPropertyChanged("SelectedSourceTool");
				}
			}
		}

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x06000362 RID: 866 RVA: 0x0001161C File Offset: 0x0000F81C
		// (remove) Token: 0x06000363 RID: 867 RVA: 0x00011654 File Offset: 0x0000F854
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		public event PropertyChangedEventHandler PropertyChanged;

		// Token: 0x06000364 RID: 868 RVA: 0x00011689 File Offset: 0x0000F889
		protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
		{
			PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
			if (propertyChanged != null)
			{
				propertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}

		// Token: 0x06000365 RID: 869 RVA: 0x000116A8 File Offset: 0x0000F8A8
		public void RestoreSelectedSourceTool()
		{
			bool flag = this.Config == null || this.Config.InputLink == null || this.AvailableImageOutputTools == null;
			if (!flag)
			{
				foreach (ToolImageSourceOption item in this.AvailableImageOutputTools)
				{
					bool flag2 = item.ToolName == this.Config.InputLink.SourceToolName;
					if (flag2)
					{
						this.SelectedSourceTool = item;
						return;
					}
				}
				this.Config.InputLink.SourceType = ImageInputSourceType.OriginalImage;
				this.Config.InputLink.SourceToolId = null;
				this.Config.InputLink.SourceToolName = null;
				this.SelectedSourceTool = null;
			}
		}

		// Token: 0x04000168 RID: 360
		private ToolImageSourceOption _selectedSourceTool;
	}
}
