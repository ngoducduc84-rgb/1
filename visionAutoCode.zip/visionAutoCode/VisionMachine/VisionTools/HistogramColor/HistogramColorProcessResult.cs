﻿using System;
using System.Collections.Generic;
using HalconDotNet;

namespace VisionMachine.VisionTools.HistogramColor
{
	// Token: 0x02000054 RID: 84
	public class HistogramColorProcessResult : IDisposable
	{
		// Token: 0x1700013B RID: 315
		// (get) Token: 0x06000393 RID: 915 RVA: 0x000118ED File Offset: 0x0000FAED
		// (set) Token: 0x06000394 RID: 916 RVA: 0x000118F5 File Offset: 0x0000FAF5
		public bool IsSuccess { get; set; }

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000395 RID: 917 RVA: 0x000118FE File Offset: 0x0000FAFE
		// (set) Token: 0x06000396 RID: 918 RVA: 0x00011906 File Offset: 0x0000FB06
		public HObject SourceImage { get; set; }

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x06000397 RID: 919 RVA: 0x0001190F File Offset: 0x0000FB0F
		// (set) Token: 0x06000398 RID: 920 RVA: 0x00011917 File Offset: 0x0000FB17
		public bool IsOk { get; set; }

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x06000399 RID: 921 RVA: 0x00011920 File Offset: 0x0000FB20
		// (set) Token: 0x0600039A RID: 922 RVA: 0x00011928 File Offset: 0x0000FB28
		public double TotalValue { get; set; }

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x0600039B RID: 923 RVA: 0x00011931 File Offset: 0x0000FB31
		// (set) Token: 0x0600039C RID: 924 RVA: 0x00011939 File Offset: 0x0000FB39
		public double TotalProcessingTimeMs { get; set; }

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x0600039D RID: 925 RVA: 0x00011942 File Offset: 0x0000FB42
		// (set) Token: 0x0600039E RID: 926 RVA: 0x0001194A File Offset: 0x0000FB4A
		public string InputSourceToolName { get; set; }

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x0600039F RID: 927 RVA: 0x00011953 File Offset: 0x0000FB53
		// (set) Token: 0x060003A0 RID: 928 RVA: 0x0001195B File Offset: 0x0000FB5B
		public double InputProcessingTimeMs { get; set; }

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x060003A1 RID: 929 RVA: 0x00011964 File Offset: 0x0000FB64
		// (set) Token: 0x060003A2 RID: 930 RVA: 0x0001196C File Offset: 0x0000FB6C
		public string Message { get; set; }

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x060003A3 RID: 931 RVA: 0x00011975 File Offset: 0x0000FB75
		// (set) Token: 0x060003A4 RID: 932 RVA: 0x0001197D File Offset: 0x0000FB7D
		public List<HistogramColorRoiResult> RoiResults { get; set; } = new List<HistogramColorRoiResult>();

		// Token: 0x060003A5 RID: 933 RVA: 0x00011988 File Offset: 0x0000FB88
		public void Dispose()
		{
			HObject sourceImage = this.SourceImage;
			if (sourceImage != null)
			{
				sourceImage.Dispose();
			}
			foreach (HistogramColorRoiResult item in this.RoiResults)
			{
				HObject roiObject = item.RoiObject;
				if (roiObject != null)
				{
					roiObject.Dispose();
				}
				HObject displayRoiObject = item.DisplayRoiObject;
				if (displayRoiObject != null)
				{
					displayRoiObject.Dispose();
				}
				HObject thresholdObject = item.ThresholdObject;
				if (thresholdObject != null)
				{
					thresholdObject.Dispose();
				}
			}
		}
	}
}
