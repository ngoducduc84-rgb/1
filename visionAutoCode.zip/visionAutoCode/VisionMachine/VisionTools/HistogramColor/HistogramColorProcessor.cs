﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;
using VisionMachine.Models.Tools;
using VisionMachine.VisionTools.Abstractions;
using VisionMachine.VisionTools.AngleSelector;
using VisionMachine.VisionTools.BoundingBoxMaster;
using VisionMachine.VisionTools.CircleMaster;
using VisionMachine.VisionTools.IntersectingLines;
using VisionMachine.VisionTools.MinAreaMaster;
using VisionMachine.VisionTools.ShapeModel;

namespace VisionMachine.VisionTools.HistogramColor
{
	// Token: 0x02000055 RID: 85
	public class HistogramColorProcessor : IToolProcessor
	{
		// Token: 0x060003A7 RID: 935 RVA: 0x00011A38 File Offset: 0x0000FC38
		public HistogramColorProcessor() : this(null)
		{
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x00011A43 File Offset: 0x0000FC43
		public HistogramColorProcessor(IDictionary<string, ShapeMatchResult> cachedMasterResults)
		{
			this._cachedMasterResults = cachedMasterResults;
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x060003A9 RID: 937 RVA: 0x00011A54 File Offset: 0x0000FC54
		public ToolType ToolType
		{
			get
			{
				return ToolType.HistogramColor;
			}
		}

		// Token: 0x060003AA RID: 938 RVA: 0x00011A68 File Offset: 0x0000FC68
		public ToolProcessResult Execute(ToolProcessContext context, ToolVision tool)
		{
			ToolProcessResult processResult = new ToolProcessResult();
			bool flag = context == null || context.InputImage == null;
			ToolProcessResult result;
			if (flag)
			{
				processResult.IsSuccess = false;
				processResult.Message = "Input image null.";
				result = processResult;
			}
			else
			{
				HistogramColorProcessResult histogramResult = this.Run(context.InputImage, tool);
				processResult.IsSuccess = histogramResult.IsSuccess;
				processResult.Message = histogramResult.Message;
				processResult.Data = histogramResult;
				HObject copy;
				HOperatorSet.CopyImage(context.InputImage, out copy);
				context.OutputImage = copy;
				result = processResult;
			}
			return result;
		}

		// Token: 0x060003AB RID: 939 RVA: 0x00011AF8 File Offset: 0x0000FCF8
		public HistogramColorProcessResult Run(HObject image, ToolVision tool)
		{
			HistogramColorProcessResult result = new HistogramColorProcessResult();
			Stopwatch totalStopwatch = Stopwatch.StartNew();
			bool flag = image == null || !image.IsInitialized() || tool == null;
			HistogramColorProcessResult result2;
			if (flag)
			{
				result.Message = "Histogram Color input invalid.";
				result2 = result;
			}
			else
			{
				HistogramColorToolConfig config = tool.Config as HistogramColorToolConfig;
				HistogramColorToolSpec spec = tool.Spec as HistogramColorToolSpec;
				bool flag2 = config == null || spec == null;
				if (flag2)
				{
					result.Message = "Histogram Color config/spec null.";
					result2 = result;
				}
				else
				{
					bool flag3 = !config.IsEnabled;
					if (flag3)
					{
						result.Message = "Histogram Color tool is disabled.";
						result2 = result;
					}
					else
					{
						bool flag4 = tool.RoiItems == null || tool.RoiItems.Count == 0;
						if (flag4)
						{
							result.Message = "Histogram Color has no ROI.";
							result2 = result;
						}
						else
						{
							this._currentMasterRuntimeInfo = this.UpdateMasterShapeModels(image, tool);
							HObject processImage = null;
							HObject redImage = null;
							HObject greenImage = null;
							HObject blueImage = null;
							try
							{
								processImage = this.CreateMaskAppliedImage(image, tool);
								HObject sourceCopy;
								HOperatorSet.CopyImage(processImage, out sourceCopy);
								result.SourceImage = sourceCopy;
								this.CreateColorImages(processImage, out redImage, out greenImage, out blueImage);
								foreach (RoiData roi in from x in tool.RoiItems
								where x.IsEnabled
								select x)
								{
									Stopwatch roiStopwatch = Stopwatch.StartNew();
									HObject roiObject = null;
									HObject displayRoiObject = null;
									HObject thresholdRegion = null;
									try
									{
										roiObject = this.GenRegionFromRoi(roi, tool, processImage, true);
										displayRoiObject = this.GenRegionFromRoi(roi, tool, processImage, false);
										bool flag5 = roiObject == null || !roiObject.IsInitialized();
										if (!flag5)
										{
											HTuple roiArea;
											HTuple roiCenterRow;
											HTuple roiCenterColumn;
											HOperatorSet.AreaCenter(roiObject, out roiArea, out roiCenterRow, out roiCenterColumn);
											double totalPixels = (roiArea.Length > 0) ? roiArea.TupleSum().D : 0.0;
											bool flag6 = totalPixels <= 0.0;
											if (!flag6)
											{
												double redRate = 0.0;
												double greenRate = 0.0;
												double blueRate = 0.0;
												thresholdRegion = this.CreateColorThresholdRegion(redImage, greenImage, blueImage, roiObject, config, totalPixels, out redRate, out greenRate, out blueRate);
												HTuple selectedArea;
												HTuple selectedRow;
												HTuple selectedColumn;
												HOperatorSet.AreaCenter(thresholdRegion, out selectedArea, out selectedRow, out selectedColumn);
												double selectedPixels = (selectedArea.Length > 0) ? selectedArea.TupleSum().D : 0.0;
												double value = (redRate + greenRate + blueRate) / 3.0;
												double labelRow = (selectedRow.Length > 0) ? selectedRow.TupleMean().D : ((roiCenterRow.Length > 0) ? roiCenterRow.TupleMean().D : this.GetFallbackRow(roi));
												double labelColumn = (selectedColumn.Length > 0) ? selectedColumn.TupleMean().D : ((roiCenterColumn.Length > 0) ? roiCenterColumn.TupleMean().D : this.GetFallbackColumn(roi));
												HObject roiCopy;
												HOperatorSet.CopyObj(roiObject, out roiCopy, 1, -1);
												bool flag7 = displayRoiObject != null && displayRoiObject.IsInitialized();
												HObject displayRoiCopy;
												if (flag7)
												{
													HOperatorSet.CopyObj(displayRoiObject, out displayRoiCopy, 1, -1);
												}
												else
												{
													HOperatorSet.CopyObj(roiObject, out displayRoiCopy, 1, -1);
												}
												HObject thresholdCopy;
												HOperatorSet.CopyObj(thresholdRegion, out thresholdCopy, 1, -1);
												string masterPositionToolName = this.GetMasterPositionToolName(roi);
												string masterAngleToolName = this.GetMasterAngleToolName(roi);
												roiStopwatch.Stop();
												result.RoiResults.Add(new HistogramColorRoiResult
												{
													Roi = roi,
													Value = value,
													RedRate = redRate,
													GreenRate = greenRate,
													BlueRate = blueRate,
													SelectedPixelCount = selectedPixels,
													TotalPixelCount = totalPixels,
													LabelRow = labelRow,
													LabelColumn = labelColumn,
													RoiObject = roiCopy,
													DisplayRoiObject = displayRoiCopy,
													ThresholdObject = thresholdCopy,
													ProcessingTimeMs = roiStopwatch.Elapsed.TotalMilliseconds,
													MasterPositionToolName = masterPositionToolName,
													MasterAngleToolName = masterAngleToolName,
													MasterStatus = this.GetMasterStatus(masterPositionToolName, masterAngleToolName),
													MasterProcessingTimeMs = this.GetMasterProcessingTime(masterPositionToolName, masterAngleToolName)
												});
												result.TotalValue += value;
											}
										}
									}
									finally
									{
										bool isRunning = roiStopwatch.IsRunning;
										if (isRunning)
										{
											roiStopwatch.Stop();
										}
										if (roiObject != null)
										{
											roiObject.Dispose();
										}
										if (displayRoiObject != null)
										{
											displayRoiObject.Dispose();
										}
										if (thresholdRegion != null)
										{
											thresholdRegion.Dispose();
										}
									}
								}
							}
							finally
							{
								if (redImage != null)
								{
									redImage.Dispose();
								}
								if (greenImage != null)
								{
									greenImage.Dispose();
								}
								if (blueImage != null)
								{
									blueImage.Dispose();
								}
								if (processImage != null)
								{
									processImage.Dispose();
								}
								this._currentMasterRuntimeInfo = null;
							}
							result.IsOk = (result.TotalValue >= spec.MinimumSize && result.TotalValue <= spec.MaximumSize);
							totalStopwatch.Stop();
							result.TotalProcessingTimeMs = totalStopwatch.Elapsed.TotalMilliseconds;
							result.IsSuccess = true;
							result.Message = (result.IsOk ? "Histogram Color OK." : "Histogram Color NG.");
							result2 = result;
						}
					}
				}
			}
			return result2;
		}

		// Token: 0x060003AC RID: 940 RVA: 0x000120B0 File Offset: 0x000102B0
		private void CreateColorImages(HObject image, out HObject redImage, out HObject greenImage, out HObject blueImage)
		{
			redImage = null;
			greenImage = null;
			blueImage = null;
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			if (flag)
			{
				HOperatorSet.AccessChannel(image, out redImage, 1);
				HOperatorSet.AccessChannel(image, out greenImage, 2);
				HOperatorSet.AccessChannel(image, out blueImage, 3);
			}
			else
			{
				HOperatorSet.CopyImage(image, out redImage);
				HOperatorSet.CopyImage(image, out greenImage);
				HOperatorSet.CopyImage(image, out blueImage);
			}
		}

		// Token: 0x060003AD RID: 941 RVA: 0x0001213C File Offset: 0x0001033C
		private HObject CreateColorThresholdRegion(HObject redImage, HObject greenImage, HObject blueImage, HObject roiObject, HistogramColorToolConfig config, double totalPixels, out double redRate, out double greenRate, out double blueRate)
		{
			HObject redReduce = null;
			HObject greenReduce = null;
			HObject blueReduce = null;
			HObject redRegion = null;
			HObject greenRegion = null;
			HObject blueRegion = null;
			HObject redGreen = null;
			HObject colorRegion = null;
			redRate = 0.0;
			greenRate = 0.0;
			blueRate = 0.0;
			HObject result;
			try
			{
				HOperatorSet.ReduceDomain(redImage, roiObject, out redReduce);
				HOperatorSet.ReduceDomain(greenImage, roiObject, out greenReduce);
				HOperatorSet.ReduceDomain(blueImage, roiObject, out blueReduce);
				HOperatorSet.Threshold(redReduce, out redRegion, config.RedMin, config.RedMax);
				HOperatorSet.Threshold(greenReduce, out greenRegion, config.GreenMin, config.GreenMax);
				HOperatorSet.Threshold(blueReduce, out blueRegion, config.BlueMin, config.BlueMax);
				redRate = this.CalculateRate(redRegion, totalPixels);
				greenRate = this.CalculateRate(greenRegion, totalPixels);
				blueRate = this.CalculateRate(blueRegion, totalPixels);
				HOperatorSet.Intersection(redRegion, greenRegion, out redGreen);
				HOperatorSet.Intersection(redGreen, blueRegion, out colorRegion);
				HObject resultRegion;
				HOperatorSet.CopyObj(colorRegion, out resultRegion, 1, -1);
				result = resultRegion;
			}
			finally
			{
				if (redReduce != null)
				{
					redReduce.Dispose();
				}
				if (greenReduce != null)
				{
					greenReduce.Dispose();
				}
				if (blueReduce != null)
				{
					blueReduce.Dispose();
				}
				if (redRegion != null)
				{
					redRegion.Dispose();
				}
				if (greenRegion != null)
				{
					greenRegion.Dispose();
				}
				if (blueRegion != null)
				{
					blueRegion.Dispose();
				}
				if (redGreen != null)
				{
					redGreen.Dispose();
				}
				if (colorRegion != null)
				{
					colorRegion.Dispose();
				}
			}
			return result;
		}

		// Token: 0x060003AE RID: 942 RVA: 0x000122E0 File Offset: 0x000104E0
		private double CalculateRate(HObject region, double totalPixels)
		{
			bool flag = region == null || !region.IsInitialized() || totalPixels <= 0.0;
			double result;
			if (flag)
			{
				result = 0.0;
			}
			else
			{
				HTuple area;
				HTuple row;
				HTuple column;
				HOperatorSet.AreaCenter(region, out area, out row, out column);
				double selectedPixels = (area.Length > 0) ? area.TupleSum().D : 0.0;
				result = selectedPixels / totalPixels * 100.0;
			}
			return result;
		}

		// Token: 0x060003AF RID: 943 RVA: 0x00012360 File Offset: 0x00010560
		private HObject CreateMaskAppliedImage(HObject image, ToolVision tool)
		{
			HObject current;
			HOperatorSet.CopyImage(image, out current);
			bool flag = ((tool != null) ? tool.MaskRoiItems : null) == null || tool.MaskRoiItems.Count == 0;
			HObject result;
			if (flag)
			{
				result = current;
			}
			else
			{
				foreach (RoiData maskRoi in from x in tool.MaskRoiItems
				where x.IsEnabled && x.RoiType != RoiType.Line
				select x)
				{
					HObject maskRegion = null;
					HObject painted = null;
					try
					{
						maskRegion = this.GenRegionFromRoi(maskRoi, tool, current, true);
						bool flag2 = maskRegion == null || !maskRegion.IsInitialized();
						if (!flag2)
						{
							double grayValue = (double)((maskRoi.Polarity == RoiPolarity.Positive) ? 255 : 0);
							painted = this.PaintRegionToImage(current, maskRegion, grayValue);
							current.Dispose();
							current = painted;
							painted = null;
						}
					}
					finally
					{
						if (maskRegion != null)
						{
							maskRegion.Dispose();
						}
						if (painted != null)
						{
							painted.Dispose();
						}
					}
				}
				result = current;
			}
			return result;
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x0001249C File Offset: 0x0001069C
		private HObject PaintRegionToImage(HObject image, HObject region, double grayValue)
		{
			HTuple channels;
			HOperatorSet.CountChannels(image, out channels);
			bool flag = channels.Length > 0 && channels[0].I >= 3;
			HObject result;
			if (flag)
			{
				result = this.PaintRegionToRgbImage(image, region, grayValue);
			}
			else
			{
				HObject painted;
				HOperatorSet.PaintRegion(region, image, out painted, grayValue, "fill");
				result = painted;
			}
			return result;
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x00012500 File Offset: 0x00010700
		private HObject PaintRegionToRgbImage(HObject image, HObject region, double grayValue)
		{
			HObject red = null;
			HObject green = null;
			HObject blue = null;
			HObject paintedRed = null;
			HObject paintedGreen = null;
			HObject paintedBlue = null;
			HObject result = null;
			HObject result2;
			try
			{
				HOperatorSet.Decompose3(image, out red, out green, out blue);
				HOperatorSet.PaintRegion(region, red, out paintedRed, grayValue, "fill");
				HOperatorSet.PaintRegion(region, green, out paintedGreen, grayValue, "fill");
				HOperatorSet.PaintRegion(region, blue, out paintedBlue, grayValue, "fill");
				HOperatorSet.Compose3(paintedRed, paintedGreen, paintedBlue, out result);
				result2 = result;
			}
			finally
			{
				if (red != null)
				{
					red.Dispose();
				}
				if (green != null)
				{
					green.Dispose();
				}
				if (blue != null)
				{
					blue.Dispose();
				}
				if (paintedRed != null)
				{
					paintedRed.Dispose();
				}
				if (paintedGreen != null)
				{
					paintedGreen.Dispose();
				}
				if (paintedBlue != null)
				{
					paintedBlue.Dispose();
				}
			}
			return result2;
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x000125F0 File Offset: 0x000107F0
		private HObject GenRegionFromRoi(RoiData roi, ToolVision tool, HObject image, bool applyMaskMode)
		{
			HistogramColorProcessor.MasterTransform transform = this.GetMasterTransform(roi, tool);
			HObject region;
			switch (roi.RoiType)
			{
			case RoiType.Rectangle1:
				region = this.GenRectangle1Region(roi, transform);
				break;
			case RoiType.Rectangle2:
				region = this.GenRectangle2Region(roi, transform);
				break;
			case RoiType.Circle:
				region = this.GenCircleRegion(roi, transform);
				break;
			case RoiType.Ellipse:
				region = this.GenEllipseRegion(roi, transform);
				break;
			case RoiType.Line:
				region = this.GenLineRegion(roi, transform);
				break;
			case RoiType.Polygon:
			case RoiType.FreeDraw:
			case RoiType.DrawRegion:
				region = this.GenContourRegion(roi, transform);
				break;
			default:
				HOperatorSet.GenEmptyObj(out region);
				break;
			}
			bool flag = !applyMaskMode;
			HObject result;
			if (flag)
			{
				result = region;
			}
			else
			{
				result = this.ApplyMaskMode(region, roi, image);
			}
			return result;
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x000126A8 File Offset: 0x000108A8
		private HObject GenRectangle1Region(RoiData roi, HistogramColorProcessor.MasterTransform transform)
		{
			double row = Math.Min(roi.Row1, roi.Row2);
			double row2 = Math.Max(roi.Row1, roi.Row2);
			double col = Math.Min(roi.Col1, roi.Col2);
			double col2 = Math.Max(roi.Col1, roi.Col2);
			bool flag = Math.Abs(transform.Angle) < 1E-06;
			HObject region;
			if (flag)
			{
				HOperatorSet.GenRectangle1(out region, row + transform.Row, col + transform.Column, row2 + transform.Row, col2 + transform.Column);
			}
			else
			{
				Tuple<double, double> r1c = this.TransformPoint(row, col, transform);
				Tuple<double, double> r1c2 = this.TransformPoint(row, col2, transform);
				Tuple<double, double> r2c2 = this.TransformPoint(row2, col2, transform);
				Tuple<double, double> r2c3 = this.TransformPoint(row2, col, transform);
				region = this.GenContourRegion(new double[]
				{
					r1c.Item1,
					r1c2.Item1,
					r2c2.Item1,
					r2c3.Item1
				}, new double[]
				{
					r1c.Item2,
					r1c2.Item2,
					r2c2.Item2,
					r2c3.Item2
				}, true);
			}
			return region;
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x000127FC File Offset: 0x000109FC
		private HObject GenRectangle2Region(RoiData roi, HistogramColorProcessor.MasterTransform transform)
		{
			Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
			HObject region;
			HOperatorSet.GenRectangle2(out region, center.Item1, center.Item2, roi.Phi + transform.Angle, roi.Radius1, roi.Radius2);
			return region;
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x0001286C File Offset: 0x00010A6C
		private HObject GenCircleRegion(RoiData roi, HistogramColorProcessor.MasterTransform transform)
		{
			Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
			HObject region;
			HOperatorSet.GenCircle(out region, center.Item1, center.Item2, roi.Radius);
			return region;
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x000128BC File Offset: 0x00010ABC
		private HObject GenEllipseRegion(RoiData roi, HistogramColorProcessor.MasterTransform transform)
		{
			Tuple<double, double> center = this.TransformPoint(roi.CenterRow, roi.CenterCol, transform);
			HObject region;
			HOperatorSet.GenEllipse(out region, center.Item1, center.Item2, roi.Phi + transform.Angle, roi.Radius1, roi.Radius2);
			return region;
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x0001292C File Offset: 0x00010B2C
		private HObject GenLineRegion(RoiData roi, HistogramColorProcessor.MasterTransform transform)
		{
			HObject line = null;
			HObject region = null;
			HObject result;
			try
			{
				Tuple<double, double> p = this.TransformPoint(roi.Row1, roi.Col1, transform);
				Tuple<double, double> p2 = this.TransformPoint(roi.Row2, roi.Col2, transform);
				HOperatorSet.GenRegionLine(out line, p.Item1, p.Item2, p2.Item1, p2.Item2);
				HOperatorSet.DilationCircle(line, out region, 1.5);
				result = region;
			}
			finally
			{
				if (line != null)
				{
					line.Dispose();
				}
			}
			return result;
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x000129D8 File Offset: 0x00010BD8
		private HObject GenContourRegion(RoiData roi, HistogramColorProcessor.MasterTransform transform)
		{
			bool flag = roi.Rows == null || roi.Cols == null || roi.Rows.Count < 3 || roi.Rows.Count != roi.Cols.Count;
			HObject result;
			if (flag)
			{
				HObject region;
				HOperatorSet.GenEmptyObj(out region);
				result = region;
			}
			else
			{
				double[] rows = new double[roi.Rows.Count];
				double[] cols = new double[roi.Cols.Count];
				for (int i = 0; i < roi.Rows.Count; i++)
				{
					Tuple<double, double> point = this.TransformPoint(roi.Rows[i], roi.Cols[i], transform);
					rows[i] = point.Item1;
					cols[i] = point.Item2;
				}
				result = this.GenContourRegion(rows, cols, false);
			}
			return result;
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x00012AC4 File Offset: 0x00010CC4
		private HObject GenContourRegion(double[] rows, double[] cols, bool closeContour)
		{
			bool flag = rows == null || cols == null || rows.Length < 3 || rows.Length != cols.Length;
			HObject result;
			if (flag)
			{
				HObject region;
				HOperatorSet.GenEmptyObj(out region);
				result = region;
			}
			else
			{
				HObject contour = null;
				HObject region;
				try
				{
					HTuple contourRows = new HTuple(rows);
					HTuple contourCols = new HTuple(cols);
					if (closeContour)
					{
						contourRows = contourRows.TupleConcat(rows[0]);
						contourCols = contourCols.TupleConcat(cols[0]);
					}
					HOperatorSet.GenContourPolygonXld(out contour, contourRows, contourCols);
					HOperatorSet.GenRegionContourXld(contour, out region, "filled");
				}
				finally
				{
					if (contour != null)
					{
						contour.Dispose();
					}
				}
				result = region;
			}
			return result;
		}

		// Token: 0x060003BA RID: 954 RVA: 0x00012B84 File Offset: 0x00010D84
		private HObject ApplyMaskMode(HObject roiRegion, RoiData roi, HObject image)
		{
			bool flag = roiRegion == null || !roiRegion.IsInitialized() || roi == null || roi.MaskMode != RoiMaskMode.Outside || image == null || !image.IsInitialized();
			HObject result;
			if (flag)
			{
				result = roiRegion;
			}
			else
			{
				HObject fullRegion = null;
				HObject outsideRegion = null;
				try
				{
					HTuple width;
					HTuple height;
					HOperatorSet.GetImageSize(image, out width, out height);
					HOperatorSet.GenRectangle1(out fullRegion, 0, 0, height.D - 1.0, width.D - 1.0);
					HOperatorSet.Difference(fullRegion, roiRegion, out outsideRegion);
					roiRegion.Dispose();
					result = outsideRegion;
				}
				finally
				{
					if (fullRegion != null)
					{
						fullRegion.Dispose();
					}
				}
			}
			return result;
		}

		// Token: 0x060003BB RID: 955 RVA: 0x00012C48 File Offset: 0x00010E48
		private HistogramColorProcessor.MasterTransform GetMasterTransform(RoiData roi, ToolVision tool)
		{
			HistogramColorProcessor.MasterTransform transform = new HistogramColorProcessor.MasterTransform();
			bool flag = roi == null || ((tool != null) ? tool.ParentTurnSnap : null) == null;
			HistogramColorProcessor.MasterTransform result;
			if (flag)
			{
				result = transform;
			}
			else
			{
				ShapeModelToolTrain positionTrain = this.GetMasterTrain(tool, this.GetMasterPositionToolName(roi), true);
				bool flag2 = positionTrain != null;
				if (flag2)
				{
					transform.Row = positionTrain.LastRow - positionTrain.MasterRow;
					transform.Column = positionTrain.LastColumn - positionTrain.MasterColumn;
				}
				ShapeModelToolTrain angleTrain = this.GetMasterTrain(tool, this.GetMasterAngleToolName(roi), false);
				bool flag3 = angleTrain != null;
				if (flag3)
				{
					transform.Angle = angleTrain.LastAngle - angleTrain.MasterAngle;
					transform.MasterRow = angleTrain.MasterRow;
					transform.MasterColumn = angleTrain.MasterColumn;
				}
				result = transform;
			}
			return result;
		}

		// Token: 0x060003BC RID: 956 RVA: 0x00012D14 File Offset: 0x00010F14
		private ShapeModelToolTrain GetMasterTrain(ToolVision tool, string masterToolName, bool isPositionMaster)
		{
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null || string.IsNullOrWhiteSpace(masterToolName) || masterToolName == "None";
			ShapeModelToolTrain result;
			if (flag)
			{
				result = null;
			}
			else
			{
				HistogramColorMasterRuntimeInfo runtimeInfo;
				bool flag2 = this._currentMasterRuntimeInfo != null && this._currentMasterRuntimeInfo.TryGetValue(masterToolName, out runtimeInfo) && !runtimeInfo.IsFound;
				if (flag2)
				{
					result = null;
				}
				else
				{
					ToolVision masterTool = tool.ParentTurnSnap.Tools.TakeWhile((ToolVision x) => x != tool).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || (isPositionMaster && x.ToolType == ToolType.CircleMaster) || (isPositionMaster && x.ToolType == ToolType.BoundingBoxMaster) || (x.ToolType == ToolType.MinAreaMaster || (isPositionMaster && x.ToolType == ToolType.IntersectingLines)) || (!isPositionMaster && x.ToolType == ToolType.AngleSelector)) && x.Name == masterToolName);
					ShapeModelToolTrain train = ((masterTool != null) ? masterTool.TrainModel : null) as ShapeModelToolTrain;
					bool flag3 = train == null || !train.HasMasterDefined;
					if (flag3)
					{
						result = null;
					}
					else
					{
						result = train;
					}
				}
			}
			return result;
		}

		// Token: 0x060003BD RID: 957 RVA: 0x00012E1C File Offset: 0x0001101C
		private string GetMasterPositionToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && roi.MasterPositionToolName != "None";
				if (flag2)
				{
					result = roi.MasterPositionToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterPositionToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x060003BE RID: 958 RVA: 0x00012EAC File Offset: 0x000110AC
		private string GetMasterAngleToolName(RoiData roi)
		{
			bool flag = roi == null;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				bool flag2 = !string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && roi.MasterAngleToolName != "None";
				if (flag2)
				{
					result = roi.MasterAngleToolName;
				}
				else
				{
					bool flag3 = string.IsNullOrWhiteSpace(roi.MasterAngleToolName) && !string.IsNullOrWhiteSpace(roi.MasterToolName) && roi.MasterToolName != "None";
					if (flag3)
					{
						result = roi.MasterToolName;
					}
					else
					{
						result = "None";
					}
				}
			}
			return result;
		}

		// Token: 0x060003BF RID: 959 RVA: 0x00012F3C File Offset: 0x0001113C
		private string GetMasterStatus(string masterPositionToolName, string masterAngleToolName)
		{
			List<string> masterNames = this.GetDistinctMasterNames(masterPositionToolName, masterAngleToolName);
			bool flag = masterNames.Count == 0;
			string result;
			if (flag)
			{
				result = "None";
			}
			else
			{
				foreach (string masterName in masterNames)
				{
					HistogramColorMasterRuntimeInfo info;
					bool flag2 = this._currentMasterRuntimeInfo == null || !this._currentMasterRuntimeInfo.TryGetValue(masterName, out info) || !info.IsFound;
					if (flag2)
					{
						return "Lost Master";
					}
				}
				result = "OK";
			}
			return result;
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x00012FE8 File Offset: 0x000111E8
		private double GetMasterProcessingTime(string masterPositionToolName, string masterAngleToolName)
		{
			double processingTime = 0.0;
			foreach (string masterName in this.GetDistinctMasterNames(masterPositionToolName, masterAngleToolName))
			{
				HistogramColorMasterRuntimeInfo info;
				bool flag = this._currentMasterRuntimeInfo != null && this._currentMasterRuntimeInfo.TryGetValue(masterName, out info);
				if (flag)
				{
					processingTime += info.ProcessingTimeMs;
				}
			}
			return processingTime;
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x00013078 File Offset: 0x00011278
		private List<string> GetDistinctMasterNames(string masterPositionToolName, string masterAngleToolName)
		{
			return (from x in new string[]
			{
				masterPositionToolName,
				masterAngleToolName
			}
			where !string.IsNullOrWhiteSpace(x) && x != "None"
			select x).Distinct<string>().ToList<string>();
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x000130C8 File Offset: 0x000112C8
		private Tuple<double, double> TransformPoint(double row, double column, HistogramColorProcessor.MasterTransform transform)
		{
			bool flag = transform == null;
			Tuple<double, double> result;
			if (flag)
			{
				result = Tuple.Create<double, double>(row, column);
			}
			else
			{
				double cos = Math.Cos(transform.Angle);
				double sin = Math.Sin(transform.Angle);
				double relRow = row - transform.MasterRow;
				double relColumn = column - transform.MasterColumn;
				double newRow = transform.MasterRow + transform.Row + relRow * cos - relColumn * sin;
				double newColumn = transform.MasterColumn + transform.Column + relRow * sin + relColumn * cos;
				result = Tuple.Create<double, double>(newRow, newColumn);
			}
			return result;
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x00013154 File Offset: 0x00011354
		private Dictionary<string, HistogramColorMasterRuntimeInfo> UpdateMasterShapeModels(HObject image, ToolVision tool)
		{
			Dictionary<string, HistogramColorMasterRuntimeInfo> runtimeInfo = new Dictionary<string, HistogramColorMasterRuntimeInfo>();
			ToolVision tool2 = tool;
			bool flag = ((tool2 != null) ? tool2.ParentTurnSnap : null) == null;
			Dictionary<string, HistogramColorMasterRuntimeInfo> result;
			if (flag)
			{
				result = runtimeInfo;
			}
			else
			{
				List<RoiData> roiItems = new List<RoiData>();
				bool flag2 = tool.RoiItems != null;
				if (flag2)
				{
					roiItems.AddRange(tool.RoiItems);
				}
				bool flag3 = tool.MaskRoiItems != null;
				if (flag3)
				{
					roiItems.AddRange(tool.MaskRoiItems);
				}
				List<string> masterNames = (from x in (from x in roiItems
				where x.IsEnabled
				select x).SelectMany((RoiData x) => new string[]
				{
					this.GetMasterPositionToolName(x),
					this.GetMasterAngleToolName(x)
				})
				where !string.IsNullOrWhiteSpace(x) && x != "None"
				select x).Distinct<string>().ToList<string>();
				bool flag4 = masterNames.Count == 0;
				if (flag4)
				{
					result = runtimeInfo;
				}
				else
				{
					ShapeModelProcessor shapeProcessor = new ShapeModelProcessor();
					using (List<string>.Enumerator enumerator = masterNames.GetEnumerator())
					{
						Func<ToolVision, bool> <>9__3;
						while (enumerator.MoveNext())
						{
							string masterName = enumerator.Current;
							HistogramColorMasterRuntimeInfo info = new HistogramColorMasterRuntimeInfo
							{
								ToolName = masterName,
								IsLinked = true
							};
							Stopwatch stopwatch = Stopwatch.StartNew();
							IEnumerable<ToolVision> tools = tool.ParentTurnSnap.Tools;
							Func<ToolVision, bool> predicate;
							if ((predicate = <>9__3) == null)
							{
								predicate = (<>9__3 = ((ToolVision x) => x != tool));
							}
							ToolVision masterTool = tools.TakeWhile(predicate).FirstOrDefault((ToolVision x) => (x.ToolType == ToolType.Shape_model || x.ToolType == ToolType.CircleMaster || x.ToolType == ToolType.BoundingBoxMaster || x.ToolType == ToolType.MinAreaMaster || x.ToolType == ToolType.IntersectingLines || x.ToolType == ToolType.AngleSelector) && x.Name == masterName);
							bool flag5 = masterTool == null;
							if (flag5)
							{
								stopwatch.Stop();
								info.IsFound = false;
								info.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
								runtimeInfo[masterName] = info;
							}
							else
							{
								ShapeMatchResult matchResult;
								bool flag6 = this.TryGetCachedMasterResult(masterName, out matchResult);
								if (flag6)
								{
									this.ApplyMasterResultToTrain(masterTool, matchResult);
									stopwatch.Stop();
									info.IsFound = matchResult.IsSuccess;
									info.ProcessingTimeMs = Math.Max(0.0, matchResult.ProcessingTimeMs);
									runtimeInfo[masterName] = info;
								}
								else
								{
									bool flag7 = masterTool.ToolType == ToolType.CircleMaster;
									if (flag7)
									{
										matchResult = new CircleMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
									}
									else
									{
										bool flag8 = masterTool.ToolType == ToolType.BoundingBoxMaster;
										if (flag8)
										{
											matchResult = new BoundingBoxMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
										}
										else
										{
											bool flag9 = masterTool.ToolType == ToolType.MinAreaMaster;
											if (flag9)
											{
												matchResult = new MinAreaMasterProcessor(this._cachedMasterResults).Match(image, masterTool);
											}
											else
											{
												bool flag10 = masterTool.ToolType == ToolType.IntersectingLines;
												if (flag10)
												{
													matchResult = new IntersectingLinesProcessor(null, this._cachedMasterResults).Match(image, masterTool);
												}
												else
												{
													bool flag11 = masterTool.ToolType == ToolType.AngleSelector;
													if (flag11)
													{
														matchResult = new AngleSelectorProcessor(null, this._cachedMasterResults).Match(image, masterTool);
													}
													else
													{
														matchResult = shapeProcessor.Match(image, masterTool);
													}
												}
											}
										}
									}
									stopwatch.Stop();
									info.IsFound = (matchResult != null && matchResult.IsSuccess);
									info.ProcessingTimeMs = stopwatch.Elapsed.TotalMilliseconds;
									runtimeInfo[masterName] = info;
								}
							}
						}
					}
					result = runtimeInfo;
				}
			}
			return result;
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x0001352C File Offset: 0x0001172C
		private bool TryGetCachedMasterResult(string masterName, out ShapeMatchResult result)
		{
			result = null;
			bool flag = this._cachedMasterResults == null || string.IsNullOrWhiteSpace(masterName);
			return !flag && this._cachedMasterResults.TryGetValue(masterName, out result) && result != null;
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x00013574 File Offset: 0x00011774
		private void ApplyMasterResultToTrain(ToolVision masterTool, ShapeMatchResult result)
		{
			bool flag = masterTool == null || result == null || !result.IsSuccess;
			if (!flag)
			{
				ShapeModelToolTrain train = masterTool.TrainModel as ShapeModelToolTrain;
				bool flag2 = train == null;
				if (!flag2)
				{
					train.LastRow = result.Row;
					train.LastColumn = result.Column;
					train.LastAngle = result.Angle;
					train.LastScore = result.Score;
				}
			}
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x000135E8 File Offset: 0x000117E8
		private double GetFallbackRow(RoiData roi)
		{
			bool flag = roi.RoiType == RoiType.Rectangle1;
			double result;
			if (flag)
			{
				result = Math.Min(roi.Row1, roi.Row2);
			}
			else
			{
				bool flag2 = roi.RoiType == RoiType.Polygon || roi.RoiType == RoiType.FreeDraw || roi.RoiType == RoiType.DrawRegion;
				if (flag2)
				{
					result = ((roi.Rows != null && roi.Rows.Count > 0) ? roi.Rows.Min() : 0.0);
				}
				else
				{
					result = roi.CenterRow;
				}
			}
			return result;
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x00013674 File Offset: 0x00011874
		private double GetFallbackColumn(RoiData roi)
		{
			bool flag = roi.RoiType == RoiType.Rectangle1;
			double result;
			if (flag)
			{
				result = Math.Min(roi.Col1, roi.Col2);
			}
			else
			{
				bool flag2 = roi.RoiType == RoiType.Polygon || roi.RoiType == RoiType.FreeDraw || roi.RoiType == RoiType.DrawRegion;
				if (flag2)
				{
					result = ((roi.Cols != null && roi.Cols.Count > 0) ? roi.Cols.Min() : 0.0);
				}
				else
				{
					result = roi.CenterCol;
				}
			}
			return result;
		}

		// Token: 0x0400018C RID: 396
		private readonly IDictionary<string, ShapeMatchResult> _cachedMasterResults;

		// Token: 0x0400018D RID: 397
		private Dictionary<string, HistogramColorMasterRuntimeInfo> _currentMasterRuntimeInfo;

		// Token: 0x020002E0 RID: 736
		private class MasterTransform
		{
			// Token: 0x17000B14 RID: 2836
			// (get) Token: 0x060026C3 RID: 9923 RVA: 0x000DFE29 File Offset: 0x000DE029
			// (set) Token: 0x060026C4 RID: 9924 RVA: 0x000DFE31 File Offset: 0x000DE031
			public double Row { get; set; }

			// Token: 0x17000B15 RID: 2837
			// (get) Token: 0x060026C5 RID: 9925 RVA: 0x000DFE3A File Offset: 0x000DE03A
			// (set) Token: 0x060026C6 RID: 9926 RVA: 0x000DFE42 File Offset: 0x000DE042
			public double Column { get; set; }

			// Token: 0x17000B16 RID: 2838
			// (get) Token: 0x060026C7 RID: 9927 RVA: 0x000DFE4B File Offset: 0x000DE04B
			// (set) Token: 0x060026C8 RID: 9928 RVA: 0x000DFE53 File Offset: 0x000DE053
			public double Angle { get; set; }

			// Token: 0x17000B17 RID: 2839
			// (get) Token: 0x060026C9 RID: 9929 RVA: 0x000DFE5C File Offset: 0x000DE05C
			// (set) Token: 0x060026CA RID: 9930 RVA: 0x000DFE64 File Offset: 0x000DE064
			public double MasterRow { get; set; }

			// Token: 0x17000B18 RID: 2840
			// (get) Token: 0x060026CB RID: 9931 RVA: 0x000DFE6D File Offset: 0x000DE06D
			// (set) Token: 0x060026CC RID: 9932 RVA: 0x000DFE75 File Offset: 0x000DE075
			public double MasterColumn { get; set; }
		}
	}
}
