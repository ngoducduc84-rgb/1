﻿using System;
using HalconDotNet;
using VisionMachine.Models.Roi;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.HistogramColor
{
	// Token: 0x02000056 RID: 86
	public class HistogramColorResultDrawer
	{
		// Token: 0x060003C8 RID: 968 RVA: 0x000136FF File Offset: 0x000118FF
		public void Draw(HWindow window, ToolVision tool, HistogramColorProcessResult result)
		{
			this.Draw(window, tool, result, true, true);
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x00013710 File Offset: 0x00011910
		public void Draw(HWindow window, ToolVision tool, HistogramColorProcessResult result, bool showTotalText, bool fillThreshold)
		{
			bool flag = window == null || tool == null || result == null;
			if (!flag)
			{
				HistogramColorToolConfig config = tool.Config as HistogramColorToolConfig;
				bool flag2 = config == null;
				if (!flag2)
				{
					bool showThreshold = config.ShowThreshold;
					if (showThreshold)
					{
						this.DrawThreshold(window, result, fillThreshold);
					}
					bool showRoi = config.ShowRoi;
					if (showRoi)
					{
						this.DrawRois(window, result);
					}
					bool showText = config.ShowText;
					if (showText)
					{
						this.DrawResultText(window, tool, result, showTotalText);
					}
				}
			}
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0001378C File Offset: 0x0001198C
		private void DrawThreshold(HWindow window, HistogramColorProcessResult result, bool fillThreshold)
		{
			bool flag = result.RoiResults == null || result.RoiResults.Count == 0;
			if (!flag)
			{
				HObject thresholdObjects = null;
				HObject thresholdRegion = null;
				try
				{
					HOperatorSet.GenEmptyObj(out thresholdObjects);
					foreach (HistogramColorRoiResult roiResult in result.RoiResults)
					{
						bool flag2 = roiResult.ThresholdObject == null || !roiResult.ThresholdObject.IsInitialized();
						if (!flag2)
						{
							HObject concat;
							HOperatorSet.ConcatObj(thresholdObjects, roiResult.ThresholdObject, out concat);
							thresholdObjects.Dispose();
							thresholdObjects = concat;
						}
					}
					HTuple count;
					HOperatorSet.CountObj(thresholdObjects, out count);
					bool flag3 = count.Length == 0 || count[0].I <= 0;
					if (!flag3)
					{
						HOperatorSet.Union1(thresholdObjects, out thresholdRegion);
						HOperatorSet.SetDraw(window, fillThreshold ? "fill" : "margin");
						HOperatorSet.SetLineWidth(window, 1);
						HOperatorSet.SetColor(window, "orange");
						HOperatorSet.DispObj(thresholdRegion, window);
					}
				}
				finally
				{
					if (thresholdObjects != null)
					{
						thresholdObjects.Dispose();
					}
					if (thresholdRegion != null)
					{
						thresholdRegion.Dispose();
					}
				}
			}
		}

		// Token: 0x060003CB RID: 971 RVA: 0x0001391C File Offset: 0x00011B1C
		private void DrawRois(HWindow window, HistogramColorProcessResult result)
		{
			bool flag = result.RoiResults == null || result.RoiResults.Count == 0;
			if (!flag)
			{
				HObject roiBoundaries = null;
				HObject unionBoundary = null;
				try
				{
					HOperatorSet.GenEmptyObj(out roiBoundaries);
					foreach (HistogramColorRoiResult roiResult in result.RoiResults)
					{
						HObject roiObject = roiResult.DisplayRoiObject;
						bool flag2 = roiObject == null || !roiObject.IsInitialized();
						if (flag2)
						{
							roiObject = roiResult.RoiObject;
						}
						bool flag3 = roiObject == null || !roiObject.IsInitialized();
						if (!flag3)
						{
							HObject boundary = null;
							HObject thickBoundary = null;
							try
							{
								HOperatorSet.Boundary(roiObject, out boundary, "outer");
								HOperatorSet.DilationCircle(boundary, out thickBoundary, 1.5);
								HObject concat;
								HOperatorSet.ConcatObj(roiBoundaries, thickBoundary, out concat);
								roiBoundaries.Dispose();
								roiBoundaries = concat;
							}
							finally
							{
								if (boundary != null)
								{
									boundary.Dispose();
								}
								if (thickBoundary != null)
								{
									thickBoundary.Dispose();
								}
							}
						}
					}
					HTuple count;
					HOperatorSet.CountObj(roiBoundaries, out count);
					bool flag4 = count.Length == 0 || count[0].I <= 0;
					if (!flag4)
					{
						HOperatorSet.Union1(roiBoundaries, out unionBoundary);
						HOperatorSet.SetDraw(window, "fill");
						HOperatorSet.SetColor(window, result.IsOk ? "green" : "red");
						HOperatorSet.SetLineWidth(window, 2);
						HOperatorSet.DispObj(unionBoundary, window);
					}
				}
				finally
				{
					if (roiBoundaries != null)
					{
						roiBoundaries.Dispose();
					}
					if (unionBoundary != null)
					{
						unionBoundary.Dispose();
					}
				}
			}
		}

		// Token: 0x060003CC RID: 972 RVA: 0x00013B40 File Offset: 0x00011D40
		private void DrawResultText(HWindow window, ToolVision tool, HistogramColorProcessResult result, bool showTotalText)
		{
			string toolName = string.IsNullOrWhiteSpace((tool != null) ? tool.Name : null) ? "Histogram Color" : tool.Name;
			string resultColor = result.IsOk ? "green" : "red";
			bool flag = result.RoiResults != null;
			if (flag)
			{
				HOperatorSet.SetColor(window, resultColor);
				foreach (HistogramColorRoiResult roiResult in result.RoiResults)
				{
					string roiName = this.GetRoiName(roiResult);
					HOperatorSet.SetTposition(window, roiResult.LabelRow, roiResult.LabelColumn);
					HOperatorSet.WriteString(window, string.Concat(new string[]
					{
						toolName,
						" ",
						roiName,
						"=",
						roiResult.Value.ToString("0.000"),
						"% R=",
						roiResult.RedRate.ToString("0.000"),
						"% G=",
						roiResult.GreenRate.ToString("0.000"),
						"% B=",
						roiResult.BlueRate.ToString("0.000"),
						"%"
					}));
				}
			}
			bool flag2 = !showTotalText;
			if (!flag2)
			{
				HOperatorSet.SetColor(window, resultColor);
				HOperatorSet.SetTposition(window, 20, 20);
				HOperatorSet.WriteString(window, string.Concat(new string[]
				{
					toolName,
					" Total=",
					result.TotalValue.ToString("0.000"),
					"% ",
					result.IsOk ? "OK" : "NG"
				}));
			}
		}

		// Token: 0x060003CD RID: 973 RVA: 0x00013D80 File Offset: 0x00011F80
		private string GetRoiName(HistogramColorRoiResult roiResult)
		{
			string value;
			if (roiResult == null)
			{
				value = null;
			}
			else
			{
				RoiData roi = roiResult.Roi;
				value = ((roi != null) ? roi.Name : null);
			}
			bool flag = !string.IsNullOrWhiteSpace(value);
			string result;
			if (flag)
			{
				result = roiResult.Roi.Name;
			}
			else
			{
				result = "ROI";
			}
			return result;
		}
	}
}
