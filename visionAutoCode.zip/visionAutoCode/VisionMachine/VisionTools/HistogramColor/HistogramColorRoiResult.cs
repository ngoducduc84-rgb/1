﻿using System;
using HalconDotNet;
using VisionMachine.Models.Roi;

namespace VisionMachine.VisionTools.HistogramColor
{
	// Token: 0x02000052 RID: 82
	public class HistogramColorRoiResult
	{
		// Token: 0x17000126 RID: 294
		// (get) Token: 0x06000367 RID: 871 RVA: 0x00011788 File Offset: 0x0000F988
		// (set) Token: 0x06000368 RID: 872 RVA: 0x00011790 File Offset: 0x0000F990
		public RoiData Roi { get; set; }

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x06000369 RID: 873 RVA: 0x00011799 File Offset: 0x0000F999
		// (set) Token: 0x0600036A RID: 874 RVA: 0x000117A1 File Offset: 0x0000F9A1
		public double Value { get; set; }

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x0600036B RID: 875 RVA: 0x000117AA File Offset: 0x0000F9AA
		// (set) Token: 0x0600036C RID: 876 RVA: 0x000117B2 File Offset: 0x0000F9B2
		public double RedRate { get; set; }

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x0600036D RID: 877 RVA: 0x000117BB File Offset: 0x0000F9BB
		// (set) Token: 0x0600036E RID: 878 RVA: 0x000117C3 File Offset: 0x0000F9C3
		public double GreenRate { get; set; }

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x0600036F RID: 879 RVA: 0x000117CC File Offset: 0x0000F9CC
		// (set) Token: 0x06000370 RID: 880 RVA: 0x000117D4 File Offset: 0x0000F9D4
		public double BlueRate { get; set; }

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x06000371 RID: 881 RVA: 0x000117DD File Offset: 0x0000F9DD
		// (set) Token: 0x06000372 RID: 882 RVA: 0x000117E5 File Offset: 0x0000F9E5
		public double SelectedPixelCount { get; set; }

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x06000373 RID: 883 RVA: 0x000117EE File Offset: 0x0000F9EE
		// (set) Token: 0x06000374 RID: 884 RVA: 0x000117F6 File Offset: 0x0000F9F6
		public double TotalPixelCount { get; set; }

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x06000375 RID: 885 RVA: 0x000117FF File Offset: 0x0000F9FF
		// (set) Token: 0x06000376 RID: 886 RVA: 0x00011807 File Offset: 0x0000FA07
		public double LabelRow { get; set; }

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x06000377 RID: 887 RVA: 0x00011810 File Offset: 0x0000FA10
		// (set) Token: 0x06000378 RID: 888 RVA: 0x00011818 File Offset: 0x0000FA18
		public double LabelColumn { get; set; }

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x06000379 RID: 889 RVA: 0x00011821 File Offset: 0x0000FA21
		// (set) Token: 0x0600037A RID: 890 RVA: 0x00011829 File Offset: 0x0000FA29
		public HObject RoiObject { get; set; }

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x0600037B RID: 891 RVA: 0x00011832 File Offset: 0x0000FA32
		// (set) Token: 0x0600037C RID: 892 RVA: 0x0001183A File Offset: 0x0000FA3A
		public HObject DisplayRoiObject { get; set; }

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x0600037D RID: 893 RVA: 0x00011843 File Offset: 0x0000FA43
		// (set) Token: 0x0600037E RID: 894 RVA: 0x0001184B File Offset: 0x0000FA4B
		public HObject ThresholdObject { get; set; }

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x0600037F RID: 895 RVA: 0x00011854 File Offset: 0x0000FA54
		// (set) Token: 0x06000380 RID: 896 RVA: 0x0001185C File Offset: 0x0000FA5C
		public double ProcessingTimeMs { get; set; }

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x06000381 RID: 897 RVA: 0x00011865 File Offset: 0x0000FA65
		// (set) Token: 0x06000382 RID: 898 RVA: 0x0001186D File Offset: 0x0000FA6D
		public string MasterPositionToolName { get; set; }

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x06000383 RID: 899 RVA: 0x00011876 File Offset: 0x0000FA76
		// (set) Token: 0x06000384 RID: 900 RVA: 0x0001187E File Offset: 0x0000FA7E
		public string MasterAngleToolName { get; set; }

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x06000385 RID: 901 RVA: 0x00011887 File Offset: 0x0000FA87
		// (set) Token: 0x06000386 RID: 902 RVA: 0x0001188F File Offset: 0x0000FA8F
		public string MasterStatus { get; set; }

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x06000387 RID: 903 RVA: 0x00011898 File Offset: 0x0000FA98
		// (set) Token: 0x06000388 RID: 904 RVA: 0x000118A0 File Offset: 0x0000FAA0
		public double MasterProcessingTimeMs { get; set; }
	}
}
