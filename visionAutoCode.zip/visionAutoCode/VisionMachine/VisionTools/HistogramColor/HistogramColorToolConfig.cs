﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;
using VisionMachine.VisionTools.Abstractions;

namespace VisionMachine.VisionTools.HistogramColor
{
	// Token: 0x02000057 RID: 87
	public class HistogramColorToolConfig : ToolConfigBase
	{
		// Token: 0x17000145 RID: 325
		// (get) Token: 0x060003CF RID: 975 RVA: 0x00013DC9 File Offset: 0x00011FC9
		// (set) Token: 0x060003D0 RID: 976 RVA: 0x00013DD1 File Offset: 0x00011FD1
		public ImageInputLink InputLink { get; set; } = new ImageInputLink();

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x060003D1 RID: 977 RVA: 0x00013DDC File Offset: 0x00011FDC
		// (set) Token: 0x060003D2 RID: 978 RVA: 0x00013DF4 File Offset: 0x00011FF4
		[DisplayName("Red Min")]
		public double RedMin
		{
			get
			{
				return this._redMin;
			}
			set
			{
				bool flag = this._redMin == value;
				if (!flag)
				{
					this._redMin = value;
					base.OnPropertyChanged("RedMin");
				}
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x060003D3 RID: 979 RVA: 0x00013E24 File Offset: 0x00012024
		// (set) Token: 0x060003D4 RID: 980 RVA: 0x00013E3C File Offset: 0x0001203C
		[DisplayName("Red Max")]
		public double RedMax
		{
			get
			{
				return this._redMax;
			}
			set
			{
				bool flag = this._redMax == value;
				if (!flag)
				{
					this._redMax = value;
					base.OnPropertyChanged("RedMax");
				}
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x060003D5 RID: 981 RVA: 0x00013E6C File Offset: 0x0001206C
		// (set) Token: 0x060003D6 RID: 982 RVA: 0x00013E84 File Offset: 0x00012084
		[DisplayName("Green Min")]
		public double GreenMin
		{
			get
			{
				return this._greenMin;
			}
			set
			{
				bool flag = this._greenMin == value;
				if (!flag)
				{
					this._greenMin = value;
					base.OnPropertyChanged("GreenMin");
				}
			}
		}

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x060003D7 RID: 983 RVA: 0x00013EB4 File Offset: 0x000120B4
		// (set) Token: 0x060003D8 RID: 984 RVA: 0x00013ECC File Offset: 0x000120CC
		[DisplayName("Green Max")]
		public double GreenMax
		{
			get
			{
				return this._greenMax;
			}
			set
			{
				bool flag = this._greenMax == value;
				if (!flag)
				{
					this._greenMax = value;
					base.OnPropertyChanged("GreenMax");
				}
			}
		}

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x060003D9 RID: 985 RVA: 0x00013EFC File Offset: 0x000120FC
		// (set) Token: 0x060003DA RID: 986 RVA: 0x00013F14 File Offset: 0x00012114
		[DisplayName("Blue Min")]
		public double BlueMin
		{
			get
			{
				return this._blueMin;
			}
			set
			{
				bool flag = this._blueMin == value;
				if (!flag)
				{
					this._blueMin = value;
					base.OnPropertyChanged("BlueMin");
				}
			}
		}

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x060003DB RID: 987 RVA: 0x00013F44 File Offset: 0x00012144
		// (set) Token: 0x060003DC RID: 988 RVA: 0x00013F5C File Offset: 0x0001215C
		[DisplayName("Blue Max")]
		public double BlueMax
		{
			get
			{
				return this._blueMax;
			}
			set
			{
				bool flag = this._blueMax == value;
				if (!flag)
				{
					this._blueMax = value;
					base.OnPropertyChanged("BlueMax");
				}
			}
		}

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x060003DD RID: 989 RVA: 0x00013F8C File Offset: 0x0001218C
		// (set) Token: 0x060003DE RID: 990 RVA: 0x00013FA4 File Offset: 0x000121A4
		[DisplayName("Show ROI")]
		public bool ShowRoi
		{
			get
			{
				return this._showRoi;
			}
			set
			{
				bool flag = this._showRoi == value;
				if (!flag)
				{
					this._showRoi = value;
					base.OnPropertyChanged("ShowRoi");
				}
			}
		}

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x060003DF RID: 991 RVA: 0x00013FD4 File Offset: 0x000121D4
		// (set) Token: 0x060003E0 RID: 992 RVA: 0x00013FEC File Offset: 0x000121EC
		[DisplayName("Show Threshold")]
		public bool ShowThreshold
		{
			get
			{
				return this._showThreshold;
			}
			set
			{
				bool flag = this._showThreshold == value;
				if (!flag)
				{
					this._showThreshold = value;
					base.OnPropertyChanged("ShowThreshold");
				}
			}
		}

		// Token: 0x1700014E RID: 334
		// (get) Token: 0x060003E1 RID: 993 RVA: 0x0001401C File Offset: 0x0001221C
		// (set) Token: 0x060003E2 RID: 994 RVA: 0x00014034 File Offset: 0x00012234
		[DisplayName("Show Text")]
		public bool ShowText
		{
			get
			{
				return this._showText;
			}
			set
			{
				bool flag = this._showText == value;
				if (!flag)
				{
					this._showText = value;
					base.OnPropertyChanged("ShowText");
				}
			}
		}

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x060003E3 RID: 995 RVA: 0x00014064 File Offset: 0x00012264
		// (set) Token: 0x060003E4 RID: 996 RVA: 0x0001407C File Offset: 0x0001227C
		[DisplayName("Show Input Image")]
		public bool ShowInputImage
		{
			get
			{
				return this._showInputImage;
			}
			set
			{
				bool flag = this._showInputImage == value;
				if (!flag)
				{
					this._showInputImage = value;
					base.OnPropertyChanged("ShowInputImage");
				}
			}
		}

		// Token: 0x0400018E RID: 398
		private double _redMin;

		// Token: 0x0400018F RID: 399
		private double _redMax = 255.0;

		// Token: 0x04000190 RID: 400
		private double _greenMin;

		// Token: 0x04000191 RID: 401
		private double _greenMax = 255.0;

		// Token: 0x04000192 RID: 402
		private double _blueMin;

		// Token: 0x04000193 RID: 403
		private double _blueMax = 255.0;

		// Token: 0x04000194 RID: 404
		private bool _showRoi = true;

		// Token: 0x04000195 RID: 405
		private bool _showThreshold;

		// Token: 0x04000196 RID: 406
		private bool _showText = true;

		// Token: 0x04000197 RID: 407
		private bool _showInputImage;
	}
}
