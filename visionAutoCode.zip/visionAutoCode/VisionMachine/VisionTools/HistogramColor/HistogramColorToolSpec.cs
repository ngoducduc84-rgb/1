﻿using System;
using System.ComponentModel;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.HistogramColor
{
	// Token: 0x02000058 RID: 88
	public class HistogramColorToolSpec : ToolSpecBase
	{
		// Token: 0x17000150 RID: 336
		// (get) Token: 0x060003E6 RID: 998 RVA: 0x00014108 File Offset: 0x00012308
		// (set) Token: 0x060003E7 RID: 999 RVA: 0x00014120 File Offset: 0x00012320
		[DisplayName("Normal Size")]
		public double NormalSize
		{
			get
			{
				return this._normalSize;
			}
			set
			{
				bool flag = this._normalSize == value;
				if (!flag)
				{
					this._normalSize = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("NormalSize");
				}
			}
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x060003E8 RID: 1000 RVA: 0x00014158 File Offset: 0x00012358
		// (set) Token: 0x060003E9 RID: 1001 RVA: 0x00014170 File Offset: 0x00012370
		[DisplayName("Upper Deviation")]
		public double UpperDeviation
		{
			get
			{
				return this._upperDeviation;
			}
			set
			{
				bool flag = this._upperDeviation == value;
				if (!flag)
				{
					this._upperDeviation = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("UpperDeviation");
				}
			}
		}

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x060003EA RID: 1002 RVA: 0x000141A8 File Offset: 0x000123A8
		// (set) Token: 0x060003EB RID: 1003 RVA: 0x000141C0 File Offset: 0x000123C0
		[DisplayName("Lower Deviation")]
		public double LowerDeviation
		{
			get
			{
				return this._lowerDeviation;
			}
			set
			{
				bool flag = this._lowerDeviation == value;
				if (!flag)
				{
					this._lowerDeviation = value;
					this.RecalculateLimits();
					base.OnPropertyChanged("LowerDeviation");
				}
			}
		}

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x060003EC RID: 1004 RVA: 0x000141F8 File Offset: 0x000123F8
		// (set) Token: 0x060003ED RID: 1005 RVA: 0x00014210 File Offset: 0x00012410
		[DisplayName("Maximum Size")]
		[ReadOnly(true)]
		public double MaximumSize
		{
			get
			{
				return this._maximumSize;
			}
			set
			{
				bool flag = this._maximumSize == value;
				if (!flag)
				{
					this._maximumSize = value;
					base.OnPropertyChanged("MaximumSize");
				}
			}
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x060003EE RID: 1006 RVA: 0x00014240 File Offset: 0x00012440
		// (set) Token: 0x060003EF RID: 1007 RVA: 0x00014258 File Offset: 0x00012458
		[DisplayName("Minimum Size")]
		[ReadOnly(true)]
		public double MinimumSize
		{
			get
			{
				return this._minimumSize;
			}
			set
			{
				bool flag = this._minimumSize == value;
				if (!flag)
				{
					this._minimumSize = value;
					base.OnPropertyChanged("MinimumSize");
				}
			}
		}

		// Token: 0x060003F0 RID: 1008 RVA: 0x00014288 File Offset: 0x00012488
		private void RecalculateLimits()
		{
			this.MaximumSize = this.NormalSize + this.UpperDeviation;
			this.MinimumSize = this.NormalSize - this.LowerDeviation;
		}

		// Token: 0x04000199 RID: 409
		private double _normalSize;

		// Token: 0x0400019A RID: 410
		private double _upperDeviation;

		// Token: 0x0400019B RID: 411
		private double _lowerDeviation;

		// Token: 0x0400019C RID: 412
		private double _maximumSize;

		// Token: 0x0400019D RID: 413
		private double _minimumSize;
	}
}
