﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Editors;
using DevExpress.Xpf.PropertyGrid;
using VisionMachine.Views.Setting;

namespace VisionMachine.VisionTools.HistogramColor.Views
{
	// Token: 0x02000059 RID: 89
	public partial class HistogramColor_para : UserControl, IStyleConnector
	{
		// Token: 0x060003F2 RID: 1010 RVA: 0x000142B3 File Offset: 0x000124B3
		public HistogramColor_para()
		{
			this.InitializeComponent();
		}

		// Token: 0x060003F3 RID: 1011 RVA: 0x000142C4 File Offset: 0x000124C4
		private void Color_EditValueChanged(object sender, EditValueChangedEventArgs e)
		{
			HistogramColorToolConfig config = this.propertyGrid.SelectedObject as HistogramColorToolConfig;
			bool flag = config == null;
			if (!flag)
			{
				bool flag2 = config.RedMin > config.RedMax;
				if (flag2)
				{
					config.RedMax = config.RedMin;
				}
				bool flag3 = config.GreenMin > config.GreenMax;
				if (flag3)
				{
					config.GreenMax = config.GreenMin;
				}
				bool flag4 = config.BlueMin > config.BlueMax;
				if (flag4)
				{
					config.BlueMax = config.BlueMin;
				}
			}
		}

		// Token: 0x060003F4 RID: 1012 RVA: 0x0001434C File Offset: 0x0001254C
		private void BtnTrialRun_Click(object sender, RoutedEventArgs e)
		{
			Form_setting instance = Form_setting.Instance;
			if (instance != null)
			{
				instance.HistogramColorTrialRun();
			}
		}

		// Token: 0x060003F7 RID: 1015 RVA: 0x000143E8 File Offset: 0x000125E8
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				((TrackBarEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 3:
				((SpinEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 4:
				((TrackBarEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 5:
				((SpinEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 6:
				((TrackBarEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 7:
				((SpinEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 8:
				((TrackBarEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 9:
				((SpinEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 10:
				((TrackBarEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 11:
				((SpinEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 12:
				((TrackBarEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			case 13:
				((SpinEdit)target).EditValueChanged += this.Color_EditValueChanged;
				break;
			}
		}
	}
}
