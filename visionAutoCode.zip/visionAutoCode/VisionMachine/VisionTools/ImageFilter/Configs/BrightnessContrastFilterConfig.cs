﻿using System;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x0200018D RID: 397
	public class BrightnessContrastFilterConfig : FilterConfigBase
	{
		// Token: 0x17000765 RID: 1893
		// (get) Token: 0x060014CA RID: 5322 RVA: 0x00063A3D File Offset: 0x00061C3D
		// (set) Token: 0x060014CB RID: 5323 RVA: 0x00063A45 File Offset: 0x00061C45
		public double Contrast { get; set; } = 1.2;

		// Token: 0x17000766 RID: 1894
		// (get) Token: 0x060014CC RID: 5324 RVA: 0x00063A4E File Offset: 0x00061C4E
		// (set) Token: 0x060014CD RID: 5325 RVA: 0x00063A56 File Offset: 0x00061C56
		public double Brightness { get; set; } = 0.0;
	}
}
