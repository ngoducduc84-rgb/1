﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x02000191 RID: 401
	public class ColorToGrayFilterConfig : FilterConfigBase
	{
		// Token: 0x1700076B RID: 1899
		// (get) Token: 0x060014D9 RID: 5337 RVA: 0x00063B08 File Offset: 0x00061D08
		// (set) Token: 0x060014DA RID: 5338 RVA: 0x00063B20 File Offset: 0x00061D20
		[DisplayName("Preset")]
		[Description("Picks a ready-made set of weights. Selecting anything but Custom overwrites the three weights below; editing a weight afterwards switches this back to Custom.")]
		public ColorToGrayPreset Preset
		{
			get
			{
				return this._preset;
			}
			set
			{
				bool flag = this._preset == value;
				if (!flag)
				{
					this._preset = value;
					this.ApplyPreset(value);
					base.OnPropertyChanged("Preset");
				}
			}
		}

		// Token: 0x1700076C RID: 1900
		// (get) Token: 0x060014DB RID: 5339 RVA: 0x00063B58 File Offset: 0x00061D58
		// (set) Token: 0x060014DC RID: 5340 RVA: 0x00063B70 File Offset: 0x00061D70
		[DisplayName("Weight B (channel 3)")]
		[Description("How much the BLUE channel contributes. Negative values subtract it, which is what makes a colour that is NOT blue stand out.")]
		public double WeightBlue
		{
			get
			{
				return this._weightBlue;
			}
			set
			{
				bool flag = this._weightBlue == value;
				if (!flag)
				{
					this._weightBlue = value;
					this.SetCustom();
					base.OnPropertyChanged("WeightBlue");
				}
			}
		}

		// Token: 0x1700076D RID: 1901
		// (get) Token: 0x060014DD RID: 5341 RVA: 0x00063BA8 File Offset: 0x00061DA8
		// (set) Token: 0x060014DE RID: 5342 RVA: 0x00063BC0 File Offset: 0x00061DC0
		[DisplayName("Weight G (channel 2)")]
		[Description("How much the GREEN channel contributes. Negative values subtract it.")]
		public double WeightGreen
		{
			get
			{
				return this._weightGreen;
			}
			set
			{
				bool flag = this._weightGreen == value;
				if (!flag)
				{
					this._weightGreen = value;
					this.SetCustom();
					base.OnPropertyChanged("WeightGreen");
				}
			}
		}

		// Token: 0x1700076E RID: 1902
		// (get) Token: 0x060014DF RID: 5343 RVA: 0x00063BF8 File Offset: 0x00061DF8
		// (set) Token: 0x060014E0 RID: 5344 RVA: 0x00063C10 File Offset: 0x00061E10
		[DisplayName("Weight R (channel 1)")]
		[Description("How much the RED channel contributes. Negative values subtract it.")]
		public double WeightRed
		{
			get
			{
				return this._weightRed;
			}
			set
			{
				bool flag = this._weightRed == value;
				if (!flag)
				{
					this._weightRed = value;
					this.SetCustom();
					base.OnPropertyChanged("WeightRed");
				}
			}
		}

		// Token: 0x1700076F RID: 1903
		// (get) Token: 0x060014E1 RID: 5345 RVA: 0x00063C48 File Offset: 0x00061E48
		// (set) Token: 0x060014E2 RID: 5346 RVA: 0x00063C60 File Offset: 0x00061E60
		[DisplayName("Normalize Weights")]
		[Description("Divides by the sum of the weights so the picture keeps its original brightness. Turn it off to let the weights amplify - useful to pull a faint colour difference up, at the cost of clipping the bright areas to white. Ignored when the weights sum to zero, which they do for every Isolate preset.")]
		public bool Normalize
		{
			get
			{
				return this._normalize;
			}
			set
			{
				bool flag = this._normalize == value;
				if (!flag)
				{
					this._normalize = value;
					base.OnPropertyChanged("Normalize");
				}
			}
		}

		// Token: 0x17000770 RID: 1904
		// (get) Token: 0x060014E3 RID: 5347 RVA: 0x00063C90 File Offset: 0x00061E90
		// (set) Token: 0x060014E4 RID: 5348 RVA: 0x00063CA8 File Offset: 0x00061EA8
		[DisplayName("Offset")]
		[Description("Added after weighting. This is what makes negative weights usable: without lifting the result, everything the subtraction pushed below zero would clip to solid black. The Isolate presets set it to 128 so the mark reads bright and the rest sits at mid-gray.")]
		public double Offset
		{
			get
			{
				return this._offset;
			}
			set
			{
				bool flag = this._offset == value;
				if (!flag)
				{
					this._offset = value;
					base.OnPropertyChanged("Offset");
				}
			}
		}

		// Token: 0x060014E5 RID: 5349 RVA: 0x00063CD8 File Offset: 0x00061ED8
		private void SetCustom()
		{
			bool flag = this._preset == ColorToGrayPreset.Custom;
			if (!flag)
			{
				this._preset = ColorToGrayPreset.Custom;
				base.OnPropertyChanged("Preset");
			}
		}

		// Token: 0x060014E6 RID: 5350 RVA: 0x00063D08 File Offset: 0x00061F08
		private void ApplyPreset(ColorToGrayPreset preset)
		{
			switch (preset)
			{
			case ColorToGrayPreset.Luminance:
				this.Set(0.114, 0.587, 0.299, true, 0.0);
				break;
			case ColorToGrayPreset.Average:
				this.Set(1.0, 1.0, 1.0, true, 0.0);
				break;
			case ColorToGrayPreset.BlueOnly:
				this.Set(1.0, 0.0, 0.0, true, 0.0);
				break;
			case ColorToGrayPreset.GreenOnly:
				this.Set(0.0, 1.0, 0.0, true, 0.0);
				break;
			case ColorToGrayPreset.RedOnly:
				this.Set(0.0, 0.0, 1.0, true, 0.0);
				break;
			case ColorToGrayPreset.IsolateBlue:
				this.Set(1.0, -0.5, -0.5, false, 128.0);
				break;
			case ColorToGrayPreset.IsolateGreen:
				this.Set(-0.5, 1.0, -0.5, false, 128.0);
				break;
			case ColorToGrayPreset.IsolateRed:
				this.Set(-0.5, -0.5, 1.0, false, 128.0);
				break;
			}
		}

		// Token: 0x060014E7 RID: 5351 RVA: 0x00063EC8 File Offset: 0x000620C8
		private void Set(double blue, double green, double red, bool normalize, double offset)
		{
			this._weightBlue = blue;
			this._weightGreen = green;
			this._weightRed = red;
			this._normalize = normalize;
			this._offset = offset;
			base.OnPropertyChanged("WeightBlue");
			base.OnPropertyChanged("WeightGreen");
			base.OnPropertyChanged("WeightRed");
			base.OnPropertyChanged("Normalize");
			base.OnPropertyChanged("Offset");
		}

		// Token: 0x040008B0 RID: 2224
		private ColorToGrayPreset _preset = ColorToGrayPreset.Luminance;

		// Token: 0x040008B1 RID: 2225
		private double _weightBlue = 0.114;

		// Token: 0x040008B2 RID: 2226
		private double _weightGreen = 0.587;

		// Token: 0x040008B3 RID: 2227
		private double _weightRed = 0.299;

		// Token: 0x040008B4 RID: 2228
		private bool _normalize = true;

		// Token: 0x040008B5 RID: 2229
		private double _offset;
	}
}
