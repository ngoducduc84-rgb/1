﻿using System;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x02000190 RID: 400
	public enum ColorToGrayPreset
	{
		// Token: 0x040008A7 RID: 2215
		Custom,
		// Token: 0x040008A8 RID: 2216
		Luminance,
		// Token: 0x040008A9 RID: 2217
		Average,
		// Token: 0x040008AA RID: 2218
		BlueOnly,
		// Token: 0x040008AB RID: 2219
		GreenOnly,
		// Token: 0x040008AC RID: 2220
		RedOnly,
		// Token: 0x040008AD RID: 2221
		IsolateBlue,
		// Token: 0x040008AE RID: 2222
		IsolateGreen,
		// Token: 0x040008AF RID: 2223
		IsolateRed
	}
}
