﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x0200018F RID: 399
	public class EmphasizeFilterConfig : FilterConfigBase
	{
		// Token: 0x17000768 RID: 1896
		// (get) Token: 0x060014D2 RID: 5330 RVA: 0x00063AAF File Offset: 0x00061CAF
		// (set) Token: 0x060014D3 RID: 5331 RVA: 0x00063AB7 File Offset: 0x00061CB7
		[DisplayName("Mask Width")]
		public int MaskWidth { get; set; } = 7;

		// Token: 0x17000769 RID: 1897
		// (get) Token: 0x060014D4 RID: 5332 RVA: 0x00063AC0 File Offset: 0x00061CC0
		// (set) Token: 0x060014D5 RID: 5333 RVA: 0x00063AC8 File Offset: 0x00061CC8
		[DisplayName("Mask Height")]
		public int MaskHeight { get; set; } = 7;

		// Token: 0x1700076A RID: 1898
		// (get) Token: 0x060014D6 RID: 5334 RVA: 0x00063AD1 File Offset: 0x00061CD1
		// (set) Token: 0x060014D7 RID: 5335 RVA: 0x00063AD9 File Offset: 0x00061CD9
		[DisplayName("Factor")]
		public double Factor { get; set; } = 1.0;
	}
}
