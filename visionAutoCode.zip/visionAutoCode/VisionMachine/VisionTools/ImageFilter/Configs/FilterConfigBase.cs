﻿using System;
using VisionMachine.Models.Tool;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x02000192 RID: 402
	public abstract class FilterConfigBase : ToolConfigBase
	{
	}
}
