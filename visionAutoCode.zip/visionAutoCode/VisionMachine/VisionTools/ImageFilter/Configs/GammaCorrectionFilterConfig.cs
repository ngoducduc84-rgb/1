﻿using System;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x0200018E RID: 398
	public class GammaCorrectionFilterConfig : FilterConfigBase
	{
		// Token: 0x17000767 RID: 1895
		// (get) Token: 0x060014CF RID: 5327 RVA: 0x00063A86 File Offset: 0x00061C86
		// (set) Token: 0x060014D0 RID: 5328 RVA: 0x00063A8E File Offset: 0x00061C8E
		public double Gamma { get; set; } = 1.0;
	}
}
