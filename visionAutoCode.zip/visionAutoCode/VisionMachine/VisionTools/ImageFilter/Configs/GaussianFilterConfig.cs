﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x02000193 RID: 403
	public class GaussianFilterConfig : FilterConfigBase
	{
		// Token: 0x17000771 RID: 1905
		// (get) Token: 0x060014EA RID: 5354 RVA: 0x00063F87 File Offset: 0x00062187
		// (set) Token: 0x060014EB RID: 5355 RVA: 0x00063F8F File Offset: 0x0006218F
		[DisplayName("Sigma")]
		public double Sigma { get; set; } = 1.5;
	}
}
