﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x02000194 RID: 404
	public class HighpassFilterConfig : FilterConfigBase
	{
		// Token: 0x17000772 RID: 1906
		// (get) Token: 0x060014ED RID: 5357 RVA: 0x00063FB0 File Offset: 0x000621B0
		// (set) Token: 0x060014EE RID: 5358 RVA: 0x00063FB8 File Offset: 0x000621B8
		[DisplayName("Mask Width")]
		public int MaskWidth { get; set; } = 9;

		// Token: 0x17000773 RID: 1907
		// (get) Token: 0x060014EF RID: 5359 RVA: 0x00063FC1 File Offset: 0x000621C1
		// (set) Token: 0x060014F0 RID: 5360 RVA: 0x00063FC9 File Offset: 0x000621C9
		[DisplayName("Mask Height")]
		public int MaskHeight { get; set; } = 9;
	}
}
