﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x02000195 RID: 405
	public class MeanFilterConfig : FilterConfigBase
	{
		// Token: 0x17000774 RID: 1908
		// (get) Token: 0x060014F2 RID: 5362 RVA: 0x00063FEB File Offset: 0x000621EB
		// (set) Token: 0x060014F3 RID: 5363 RVA: 0x00063FF3 File Offset: 0x000621F3
		[DisplayName("Mask Width")]
		public int MaskWidth { get; set; } = 5;

		// Token: 0x17000775 RID: 1909
		// (get) Token: 0x060014F4 RID: 5364 RVA: 0x00063FFC File Offset: 0x000621FC
		// (set) Token: 0x060014F5 RID: 5365 RVA: 0x00064004 File Offset: 0x00062204
		[DisplayName("Mask Height")]
		public int MaskHeight { get; set; } = 5;
	}
}
