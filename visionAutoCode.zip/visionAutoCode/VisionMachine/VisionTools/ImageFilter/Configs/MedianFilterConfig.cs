﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x02000196 RID: 406
	public class MedianFilterConfig : FilterConfigBase
	{
		// Token: 0x17000776 RID: 1910
		// (get) Token: 0x060014F7 RID: 5367 RVA: 0x00064024 File Offset: 0x00062224
		// (set) Token: 0x060014F8 RID: 5368 RVA: 0x0006402C File Offset: 0x0006222C
		[DisplayName("Radius")]
		public int Radius { get; set; } = 3;

		// Token: 0x17000777 RID: 1911
		// (get) Token: 0x060014F9 RID: 5369 RVA: 0x00064035 File Offset: 0x00062235
		// (set) Token: 0x060014FA RID: 5370 RVA: 0x0006403D File Offset: 0x0006223D
		[DisplayName("Mask Type")]
		public string MaskType { get; set; } = "circle";
	}
}
