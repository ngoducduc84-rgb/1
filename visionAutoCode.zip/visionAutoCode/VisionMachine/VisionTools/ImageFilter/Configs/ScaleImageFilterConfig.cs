﻿using System;
using System.ComponentModel;

namespace VisionMachine.VisionTools.ImageFilter.Configs
{
	// Token: 0x02000197 RID: 407
	public class ScaleImageFilterConfig : FilterConfigBase
	{
		// Token: 0x17000778 RID: 1912
		// (get) Token: 0x060014FC RID: 5372 RVA: 0x00064061 File Offset: 0x00062261
		// (set) Token: 0x060014FD RID: 5373 RVA: 0x00064069 File Offset: 0x00062269
		[DisplayName("Factor")]
		public double Factor { get; set; } = 1.2;

		// Token: 0x17000779 RID: 1913
		// (get) Token: 0x060014FE RID: 5374 RVA: 0x00064072 File Offset: 0x00062272
		// (set) Token: 0x060014FF RID: 5375 RVA: 0x0006407A File Offset: 0x0006227A
		[DisplayName("Offset")]
		public double Offset { get; set; } = 0.0;
	}
}
